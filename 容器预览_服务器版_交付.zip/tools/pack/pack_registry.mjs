/**
 * 世界包注册文件的读写helper（纯函数，给部署脚本用，也便于离线测）。
 *
 * ## 为什么单拎出来
 *
 * BDS 靠世界目录里这两个文件决定"这个存档加载哪些包"：
 *
 *   worlds/<世界>/world_resource_packs.json   [{ pack_id, version }]
 *   worlds/<世界>/valid_known_packs.json      [{ file_system, path, uuid, version, hashes }]
 *
 * 两件事都踩过：
 *
 *   1. **必须是数组**。写成单个对象不报错、包也不生效 ——
 *      表现是客户端一个图标都没有（我们的字形是私有区码点，没装包就是空白）。
 *      ⚠️ 不要拿 `[Server] Pack Stack - None` 当判据：本插件只注册资源包、
 *      不注册行为包，那行**永远是 None**，和资源包生效与否无关（实测确认）。
 *   2. **version 必须和包 manifest 完全一致**。资源包版本每次打包都自增，
 *      手动同步漏一次，包就静默失效。
 *
 * 还有一件**搬服务器时才会暴露**的事：这两个文件里**不只我们一个包**。
 * 原来的同步脚本是直接覆盖写，等于把目标服务器上已有的包注册**全删了**。
 * 所以现在改成"合并"：只动我们那一条，别人的原样留着。
 *
 * ⚠️ 解析失败时**抛错而不是当成空**：被当成空再去覆盖，就等于把目标服的包
 * 清光。宁可让部署脚本停下来报错，让人去看一眼那个文件。
 */

/**
 * 读一个包注册文件的内容。
 *
 * @param {string|undefined} text 文件内容（文件不存在就传 undefined / ""）
 * @param {string} [label] 出错时用来指明是哪个文件
 * @returns {object[]} 条目数组（文件不存在或为空时是空数组）
 */
export function readPackList(text, label) {
  const name = label || "包注册文件";
  if (typeof text !== "string") return [];

  const trimmed = text.replace(/^\uFEFF/, "").trim();
  if (trimmed.length === 0) return [];

  let parsed;
  try {
    parsed = JSON.parse(trimmed);
  } catch (err) {
    throw new Error(
      name + " 不是合法 JSON（" + err.message + "）。" +
      "为避免覆盖服务器上已有的包，这里不继续写 —— 先手动看一眼这个文件。"
    );
  }

  // 旧版/手写文件可能是单个对象而不是数组：认它，但要转成数组
  if (Array.isArray(parsed)) {
    return parsed.filter((entry) => entry && typeof entry === "object");
  }
  if (parsed && typeof parsed === "object") return [parsed];
  return [];
}

/**
 * 插入或替换一条记录（按 `key` 字段匹配），**其余条目原样保留、顺序不变**。
 *
 * 同 key 出现多次时只保留第一条（写进新记录），后面的丢掉 —— 重复条目本身
 * 就是坏数据，留着会让客户端不确定用哪条。
 *
 * @param {object[]} list 现有条目
 * @param {object} entry 我们这条（带最新 version）
 * @param {string} key 用来判断"是不是同一条"的字段名（资源包用 pack_id / uuid）
 */
export function upsertPack(list, entry, key) {
  if (!entry || !key) throw new Error("upsertPack 需要 entry 和 key");

  const source = Array.isArray(list) ? list : [];
  const out = [];
  let replaced = false;

  for (const item of source) {
    if (item && typeof item === "object" && item[key] === entry[key]) {
      if (!replaced) {
        out.push(entry);
        replaced = true;
      }
      continue; // 重复的同 key 条目丢掉
    }
    out.push(item);
  }

  if (!replaced) out.push(entry);
  return out;
}

/** 除我们之外还剩几条 —— 部署时打出来，让人一眼看到"没把别人的包弄丢"。 */
export function countOtherPacks(list, entry, key) {
  const source = Array.isArray(list) ? list : [];
  let n = 0;
  for (const item of source) {
    if (item && typeof item === "object" && item[key] !== entry[key]) n++;
  }
  return n;
}
