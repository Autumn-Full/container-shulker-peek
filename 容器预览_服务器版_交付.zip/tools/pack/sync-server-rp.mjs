/**
 * 把本插件包部署到一台 BDS 服务器（资源包 + 可选的 LSE 插件）。
 *
 * ## 它到底做哪几件事
 *
 *   1. 把 `packs/crosshair_container_peek_icons` 拷到 `<服务器>/resource_packs/`；
 *   2. **合并**（不是覆盖）世界里的两个注册文件，把我们的条目更新到最新版本：
 *        worlds/<世界>/world_resource_packs.json   [{ pack_id, version }]
 *        worlds/<世界>/valid_known_packs.json      [{ file_system, path, uuid, version, hashes }]
 *   3. 加了 `--plugin` 时，再把 `dist-lse/CrosshairContainerPeek` 拷到 `<服务器>/plugins/`。
 *
 * ## 为什么这两件事必须由脚本做
 *
 *   · 注册文件必须是 **JSON 数组**（写成对象不报错、包也不生效，
 *     表现是客户端一个图标都没有；注意 `[Server] Pack Stack - None` **不是**判据 ——
 *     我们只注册资源包、不注册行为包，那行永远是 None，实测确认过）；
 *   · 里面的 `version` 必须和资源包 manifest **完全一致**，而版本每次打包都自增，
 *     手抄漏一次包就静默失效；
 *   · 这两个文件里**还有服务器上别的包** —— 覆盖写等于把人家删了。
 *     所以这里是 upsert（见 pack_registry.mjs）。
 *
 * ## 用法
 *
 *   node tools/pack/sync-server-rp.mjs                          # 用默认路径（本机测试服）
 *   node tools/pack/sync-server-rp.mjs --server "D:\BDS" --world MyWorld
 *   node tools/pack/sync-server-rp.mjs --server "D:\BDS" --world MyWorld --plugin
 *
 * 搬去别的服务器：见 docs/搬到别的服务器.md。
 */
import { readFileSync, writeFileSync, mkdirSync, cpSync, existsSync } from "node:fs";
import { dirname, join, resolve, basename } from "node:path";
import { fileURLToPath } from "node:url";
import { readPackList, upsertPack, countOtherPacks } from "./pack_registry.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "..", "..");

function argValue(name, fallback) {
  const index = process.argv.indexOf("--" + name);
  if (index >= 0 && process.argv[index + 1]) return process.argv[index + 1];
  return fallback;
}

const serverDir = resolve(argValue("server", "E:\\BDS1.21.93"));
const worldName = argValue("world", "PluginTestWorld");
const withPlugin = process.argv.indexOf("--plugin") >= 0;

/** 服务器上资源包的目录名（和插件目录并列）。改名要和 valid_known_packs 里的 path 一致。 */
const PACK_FOLDER = "CrosshairContainerPeekIcons";

/** 插件目录名。**必须和插件 manifest 里的 name 一致**，否则 LeviLamina 直接不加载。 */
const PLUGIN_FOLDER = "CrosshairContainerPeek";

const sourceDir = join(root, "packs", "crosshair_container_peek_icons");
const manifestPath = join(sourceDir, "manifest.json");

if (!existsSync(manifestPath)) {
  console.error("找不到资源包 manifest：" + manifestPath + "（先跑一次 build-all.ps1）");
  process.exit(1);
}

const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
const uuid = manifest.header.uuid;
const version = manifest.header.version;

if (!uuid || !Array.isArray(version) || version.length !== 3) {
  console.error("manifest 里的 uuid / version 不合法");
  process.exit(1);
}

const worldDir = join(serverDir, "worlds", worldName);
if (!existsSync(worldDir)) {
  console.error("找不到世界目录：" + worldDir + "（用 --world 指定别的世界名）");
  process.exit(1);
}

function readIfExists(path) {
  return existsSync(path) ? readFileSync(path, "utf8") : "";
}

// ---- 1. 拷资源包 ----
const targetDir = join(serverDir, "resource_packs", PACK_FOLDER);
mkdirSync(targetDir, { recursive: true });
cpSync(sourceDir, targetDir, { recursive: true });

// ---- 2. 合并两个注册文件（必须是数组、必须无 BOM）----
const resourcePacksPath = join(worldDir, "world_resource_packs.json");
const knownPacksPath = join(worldDir, "valid_known_packs.json");

const resourceEntry = { pack_id: uuid, version: version };
const knownEntry = {
  file_system: "RawPath",
  path: "resource_packs/" + PACK_FOLDER,
  uuid: uuid,
  version: version,
  hashes: []
};

let resourcePacks;
let knownPacks;
try {
  resourcePacks = upsertPack(
    readPackList(readIfExists(resourcePacksPath), "world_resource_packs.json"),
    resourceEntry,
    "pack_id"
  );
  knownPacks = upsertPack(
    readPackList(readIfExists(knownPacksPath), "valid_known_packs.json"),
    knownEntry,
    "uuid"
  );
} catch (err) {
  // 解析失败时**绝不覆盖** —— 那会把目标服务器上已有的包注册清空
  console.error(String(err && err.message ? err.message : err));
  process.exit(1);
}

const keptResource = countOtherPacks(resourcePacks, resourceEntry, "pack_id");
const keptKnown = countOtherPacks(knownPacks, knownEntry, "uuid");

writeFileSync(resourcePacksPath, JSON.stringify(resourcePacks), "utf8");
writeFileSync(knownPacksPath, JSON.stringify(knownPacks), "utf8");

// ---- 2.5 可选：主题包（用第三方材质包生成的预览图标）----
//
// 为什么必须由服务器下发：**客户端的"全局资源包"顶不掉服务器下发的资源包**。
// 想换主题只能在世界的包列表里加，而列表顺序决定谁覆盖谁。
//
// 顺序：默认把主题包条目**排到主包之后**（数组靠后 = 优先级更高）。
// 若目标版本的实际语义相反，用 --theme-first 把它排到最前，重跑一次即可。
const themeArg = argValue("theme", "");
let themeInfo = null;
if (themeArg) {
  const themeSrc = resolve(themeArg);
  const themeManifestPath = join(themeSrc, "manifest.json");
  if (!existsSync(themeManifestPath)) {
    console.error("找不到主题包 manifest：" + themeManifestPath +
      "（先跑 tools/theme/build-theme-pack.mjs 生成）");
    process.exit(1);
  }

  const themeManifest = JSON.parse(readFileSync(themeManifestPath, "utf8"));
  const themeUuid = themeManifest.header.uuid;
  const themeVersion = themeManifest.header.version;
  const themeFolder = argValue("theme-folder",
    basename(themeSrc).replace(/[^\w\u4e00-\u9fa5-]+/g, "_"));

  if (!themeUuid || !Array.isArray(themeVersion) || themeVersion.length !== 3) {
    console.error("主题包 manifest 里的 uuid / version 不合法");
    process.exit(1);
  }

  const themeTarget = join(serverDir, "resource_packs", themeFolder);
  mkdirSync(themeTarget, { recursive: true });
  cpSync(themeSrc, themeTarget, { recursive: true });

  const themeResourceEntry = { pack_id: themeUuid, version: themeVersion };
  const themeKnownEntry = {
    file_system: "RawPath",
    path: "resource_packs/" + themeFolder,
    uuid: themeUuid,
    version: themeVersion,
    hashes: []
  };

  // 去重后再按需要排序：upsertPack 对"新条目"是追加，所以默认落在主包之后
  const withoutTheme = (list, key, uuidValue) =>
    (Array.isArray(list) ? list : []).filter((e) => !e || e[key] !== uuidValue);

  resourcePacks = withoutTheme(resourcePacks, "pack_id", themeUuid);
  knownPacks = withoutTheme(knownPacks, "uuid", themeUuid);

  if (process.argv.includes("--theme-first")) {
    resourcePacks.unshift(themeResourceEntry);
    knownPacks.unshift(themeKnownEntry);
  } else {
    resourcePacks.push(themeResourceEntry);
    knownPacks.push(themeKnownEntry);
  }

  writeFileSync(resourcePacksPath, JSON.stringify(resourcePacks), "utf8");
  writeFileSync(knownPacksPath, JSON.stringify(knownPacks), "utf8");

  themeInfo = { src: themeSrc, target: themeTarget, uuid: themeUuid, version: themeVersion, folder: themeFolder };
}

// ---- 3. 可选：拷插件 ----
let pluginTarget = "";
if (withPlugin) {
  const pluginSource = join(root, "dist-lse", PLUGIN_FOLDER);
  if (!existsSync(join(pluginSource, "main.js"))) {
    console.error("找不到插件产物：" + pluginSource + "（先跑一次 tools\\pack\\build-lse-plugin.ps1）");
    process.exit(1);
  }

  pluginTarget = join(serverDir, "plugins", PLUGIN_FOLDER);
  mkdirSync(pluginTarget, { recursive: true });

  // ⚠️ 自检标记文件**绝不能带过去**：它的存在会让插件在开服 6 秒后自动跑一次自检，
  // 而自检会 setblock、拉 tickingarea、生成模拟玩家 —— 那是"会改世界"的东西。
  const skip = new Set(["selftest.on", "selftest-result.txt"]);
  cpSync(pluginSource, pluginTarget, {
    recursive: true,
    filter: (src) => !skip.has(src.split(/[\\/]/).pop())
  });
}

console.log("部署完成");
console.log("  服务器    : " + serverDir);
console.log("  世界      : " + worldName);
console.log("  资源包    : " + targetDir);
console.log("  uuid      : " + uuid);
console.log("  版本      : " + version.join("."));
console.log("  已合并    : world_resource_packs.json（保留别的包 " + keptResource + " 条）");
console.log("              valid_known_packs.json（保留别的包 " + keptKnown + " 条）");
if (withPlugin) {
  console.log("  插件      : " + pluginTarget + "（不含自检标记文件）");
} else {
  console.log("  插件      : 未同步（要一起同步就加 --plugin）");
}
if (themeInfo) {
  console.log("  主题包    : " + themeInfo.target);
  console.log("              uuid " + themeInfo.uuid + "　版本 " + themeInfo.version.join("."));
}
console.log("");
console.log("资源包栈顺序（靠后的优先级更高，决定同名文件用谁的）：");
resourcePacks.forEach((entry, i) => {
  const who = entry.pack_id === uuid ? "（主包）" : (themeInfo && entry.pack_id === themeInfo.uuid ? "（主题包）" : "（其它包）");
  console.log("  " + (i + 1) + ". " + entry.pack_id + " " + who + " " + (entry.version || []).join("."));
});
if (themeInfo) {
  console.log("");
  console.log("主题包没生效时的排查顺序：");
  console.log("  1. 上面的顺序里主题包必须在主包**之后**；不是就加 --theme-first 重跑（或反过来去掉它）；");
  console.log("  2. 服务器要**重启**，客户端要重新下载两个包（版本变了才会重新下载）；");
  console.log("  3. 客户端『全局资源包』顶不掉服务器下发的包，只能在服务器这边加。");
}
console.log("");
console.log("提醒：");
console.log("  1. 资源包/插件都在服务器里，改完要**重启服务器**，客户端重进才会重新下载；");
console.log("  2. clients 没下载到资源包时，字形码点画不出来 —— 要强制的话把");
console.log("     server.properties 的 texturepack-required 设成 true。");
