// 由 tools/pack/bundle-lse-plugin.mjs 打包生成（QuickJS 不支持 ESM，必须单文件）
// 源文件：item_glyphs.js, hud_protocol.js, llse_adapter.js, shulker_box.js, identity.js, config.js, runtime_config.js, item_names_generated.js, item_names.js, box_overlay.js, palette.js, grid_colors.js, text_colors.js, container_shapes.js, format.js, grid_shapes.js, hud_test.js, selftest.js, box_content.js, item_stack_sizes.js, box_stack_sizes.js, box_cache.js, box_selfcheck.js, settings.js, settings_store.js, main.js

// ===== item_glyphs.js =====
/**
 * 物品 -> 字形码点 映射。**由 tools/icons/build-item-glyphs.mjs 自动生成**，手改会被下次生成覆盖。
 *
 * 码点由字形页决定：文件名 glyph_XX.png 服务 U+XX00..U+XXFF，格子按行优先填。
 * 增删物品需改 tools/icons/item_texture_map.mjs 的例外表，或补 item_names.js 的条目。
 *
 * 映射不到的物品不会有图标，显示成中文名 —— 这是刻意的降级，不是错误。
 */

const ITEM_GLYPHS = {
  "acaciaFence": 57856,
  "acacia_boat": 57857,
  "acacia_button": 57858,
  "acacia_chest_boat": 57859,
  "acacia_door": 57860,
  "acacia_double_slab": 57861,
  "acacia_fence": 57862,
  "acacia_fence_gate": 57863,
  "acacia_hanging_sign": 57864,
  "acacia_leaves": 57865,
  "acacia_log": 57866,
  "acacia_planks": 57867,
  "acacia_pressure_plate": 57868,
  "acacia_sapling": 57869,
  "acacia_shelf": 57870,
  "acacia_sign": 57871,
  "acacia_slab": 57872,
  "acacia_stairs": 57873,
  "acacia_standing_sign": 57874,
  "acacia_trapdoor": 57875,
  "acacia_wood": 57876,
  "activator_rail": 57877,
  "allium": 57878,
  "allow": 57879,
  "amethyst_block": 57880,
  "amethyst_cluster": 57881,
  "amethyst_shard": 57882,
  "ancient_debris": 57883,
  "andesite": 57884,
  "andesite_double_slab": 57885,
  "andesite_slab": 57886,
  "andesite_stairs": 57887,
  "andesite_wall": 57888,
  "angler_pottery_sherd": 57889,
  "anvil": 57890,
  "apple": 57891,
  "appleEnchanted": 57892,
  "archer_pottery_sherd": 57893,
  "armadillo_scute": 57894,
  "armor_stand": 57895,
  "arms_up_pottery_sherd": 57896,
  "arrow": 57897,
  "axolotl_bucket": 57898,
  "azalea": 57899,
  "azalea_leaves": 57900,
  "azalea_leaves_flowered": 57901,
  "azure_bluet": 57902,
  "baked_potato": 57903,
  "bamboo": 57904,
  "bamboo_block": 57905,
  "bamboo_button": 57906,
  "bamboo_chest_raft": 57907,
  "bamboo_door": 57908,
  "bamboo_double_slab": 57909,
  "bamboo_fence": 57910,
  "bamboo_fence_gate": 57911,
  "bamboo_hanging_sign": 57912,
  "bamboo_mosaic": 57913,
  "bamboo_mosaic_double_slab": 57914,
  "bamboo_mosaic_slab": 57915,
  "bamboo_mosaic_stairs": 57916,
  "bamboo_planks": 57917,
  "bamboo_pressure_plate": 57918,
  "bamboo_raft": 57919,
  "bamboo_shelf": 57920,
  "bamboo_sign": 57921,
  "bamboo_slab": 57922,
  "bamboo_stairs": 57923,
  "bamboo_trapdoor": 57924,
  "banner": 57925,
  "banner_pattern": 57926,
  "barrel": 57927,
  "barrier": 57928,
  "basalt": 57929,
  "beacon": 57930,
  "bed": 57931,
  "bedrock": 57932,
  "bee_nest": 57933,
  "beef": 57934,
  "beehive": 57935,
  "beetroot": 57936,
  "beetroot_seeds": 57937,
  "beetroot_soup": 57938,
  "bell": 57939,
  "big_dripleaf": 57940,
  "birchFence": 57941,
  "birch_boat": 57942,
  "birch_button": 57943,
  "birch_chest_boat": 57944,
  "birch_door": 57945,
  "birch_double_slab": 57946,
  "birch_fence": 57947,
  "birch_fence_gate": 57948,
  "birch_hanging_sign": 57949,
  "birch_leaves": 57950,
  "birch_log": 57951,
  "birch_planks": 57952,
  "birch_pressure_plate": 57953,
  "birch_sapling": 57954,
  "birch_shelf": 57955,
  "birch_sign": 57956,
  "birch_slab": 57957,
  "birch_stairs": 57958,
  "birch_standing_sign": 57959,
  "birch_trapdoor": 57960,
  "birch_wood": 57961,
  "black_banner": 57962,
  "black_bundle": 57963,
  "black_candle": 57964,
  "black_candle_cake": 57965,
  "black_carpet": 57966,
  "black_concrete": 57967,
  "black_concrete_powder": 57968,
  "black_dye": 57969,
  "black_glazed_terracotta": 57970,
  "black_harness": 57971,
  "black_shulker_box": 57972,
  "black_stained_glass": 57973,
  "black_stained_glass_pane": 57974,
  "black_terracotta": 57975,
  "black_wool": 57976,
  "blackstone": 57977,
  "blackstone_double_slab": 57978,
  "blackstone_slab": 57979,
  "blackstone_stairs": 57980,
  "blackstone_wall": 57981,
  "blade_pottery_sherd": 57982,
  "blast_furnace": 57983,
  "blaze_powder": 57984,
  "blaze_rod": 57985,
  "blue_banner": 57986,
  "blue_bundle": 57987,
  "blue_candle": 57988,
  "blue_candle_cake": 57989,
  "blue_carpet": 57990,
  "blue_concrete": 57991,
  "blue_concrete_powder": 57992,
  "blue_dye": 57993,
  "blue_egg": 57994,
  "blue_glazed_terracotta": 57995,
  "blue_harness": 57996,
  "blue_ice": 57997,
  "blue_orchid": 57998,
  "blue_shulker_box": 57999,
  "blue_stained_glass": 58000,
  "blue_stained_glass_pane": 58001,
  "blue_terracotta": 58002,
  "blue_wool": 58003,
  "bolt_armor_trim_smithing_template": 58004,
  "bone": 58005,
  "bone_block": 58006,
  "bone_meal": 58007,
  "book": 58008,
  "bookshelf": 58009,
  "border_block": 58010,
  "bordure_indented_banner_pattern": 58011,
  "bow": 58012,
  "bowl": 58013,
  "brain_coral": 58014,
  "brain_coral_block": 58015,
  "brain_coral_fan": 58016,
  "bread": 58017,
  "breeze_rod": 58018,
  "brewer_pottery_sherd": 58019,
  "brewing_stand": 58020,
  "brick": 58021,
  "brick_block": 58022,
  "brick_double_slab": 58023,
  "brick_slab": 58024,
  "brick_stairs": 58025,
  "brick_wall": 58026,
  "brown_banner": 58027,
  "brown_bundle": 58028,
  "brown_candle": 58029,
  "brown_candle_cake": 58030,
  "brown_carpet": 58031,
  "brown_concrete": 58032,
  "brown_concrete_powder": 58033,
  "brown_dye": 58034,
  "brown_egg": 58035,
  "brown_glazed_terracotta": 58036,
  "brown_harness": 58037,
  "brown_mushroom": 58038,
  "brown_mushroom_block": 58039,
  "brown_shulker_box": 58040,
  "brown_stained_glass": 58041,
  "brown_stained_glass_pane": 58042,
  "brown_terracotta": 58043,
  "brown_wool": 58044,
  "brush": 58045,
  "bubble_coral": 58046,
  "bubble_coral_block": 58047,
  "bubble_coral_fan": 58048,
  "bucket": 58049,
  "bucketAxolotl": 58050,
  "bucketCustomFish": 58051,
  "bucketFish": 58052,
  "bucketLava": 58053,
  "bucketPowderSnow": 58054,
  "bucketPuffer": 58055,
  "bucketSalmon": 58056,
  "bucketTadpole": 58057,
  "bucketTropical": 58058,
  "bucketWater": 58059,
  "budding_amethyst": 58060,
  "bundle": 58061,
  "burn_pottery_sherd": 58062,
  "bush": 58063,
  "cactus": 58064,
  "cactus_flower": 58065,
  "cake": 58066,
  "calcite": 58067,
  "calibrated_sculk_sensor": 58068,
  "camera": 58069,
  "campfire": 58070,
  "candle": 58071,
  "candle_cake": 58072,
  "carpet": 58073,
  "carrot": 58074,
  "carrotOnAStick": 58075,
  "carrot_on_a_stick": 58076,
  "carrots": 58077,
  "cartography_table": 58078,
  "carved_pumpkin": 58079,
  "cauldron": 58080,
  "cave_vines": 58081,
  "cave_vines_body_with_berries": 58082,
  "cave_vines_head_with_berries": 58083,
  "chain": 58084,
  "chain_command_block": 58085,
  "chainmail_boots": 58086,
  "chainmail_chestplate": 58087,
  "chainmail_helmet": 58088,
  "chainmail_leggings": 58089,
  "charcoal": 58090,
  "cherry_boat": 58091,
  "cherry_button": 58092,
  "cherry_chest_boat": 58093,
  "cherry_door": 58094,
  "cherry_double_slab": 58095,
  "cherry_fence": 58096,
  "cherry_fence_gate": 58097,
  "cherry_hanging_sign": 58098,
  "cherry_leaves": 58099,
  "cherry_log": 58100,
  "cherry_planks": 58101,
  "cherry_pressure_plate": 58102,
  "cherry_sapling": 58103,
  "cherry_shelf": 58104,
  "cherry_sign": 58105,
  "cherry_slab": 58106,
  "cherry_stairs": 58107,
  "cherry_trapdoor": 58108,
  "cherry_wood": 58109,
  "chest": 58110,
  "chest_boat": 58111,
  "chest_minecart": 58112,
  "chicken": 58113,
  "chipped_anvil": 58114,
  "chiseled_bookshelf": 58115,
  "chiseled_copper": 58116,
  "chiseled_deepslate": 58117,
  "chiseled_nether_bricks": 58118,
  "chiseled_polished_blackstone": 58119,
  "chiseled_quartz_block": 58120,
  "chiseled_red_sandstone": 58121,
  "chiseled_resin_bricks": 58122,
  "chiseled_sandstone": 58123,
  "chiseled_stone_bricks": 58124,
  "chiseled_tuff": 58125,
  "chiseled_tuff_bricks": 58126,
  "chorus_flower": 58127,
  "chorus_fruit": 58128,
  "chorus_fruit_popped": 58129,
  "chorus_plant": 58130,
  "clay": 58131,
  "clay_ball": 58132,
  "clock": 58133,
  "closed_eyeblossom": 58134,
  "clownfish": 58135,
  "coal": 58136,
  "coal_block": 58137,
  "coal_ore": 58138,
  "coarse_dirt": 58139,
  "coast_armor_trim_smithing_template": 58140,
  "cobbled_deepslate": 58141,
  "cobbled_deepslate_double_slab": 58142,
  "cobbled_deepslate_slab": 58143,
  "cobbled_deepslate_stairs": 58144,
  "cobbled_deepslate_wall": 58145,
  "cobblestone": 58146,
  "cobblestone_double_slab": 58147,
  "cobblestone_slab": 58148,
  "cobblestone_wall": 58149,
  "cobweb": 58150,
  "cocoa": 58151,
  "cocoa_beans": 58152,
  "cod": 58153,
  "cod_bucket": 58154,
  "command_block": 58155,
  "command_block_minecart": 58156,
  "comparator": 58157,
  "compass": 58158,
  "composter": 58159,
  "conduit": 58160,
  "cooked_beef": 58161,
  "cooked_chicken": 58162,
  "cooked_cod": 58163,
  "cooked_fish": 58164,
  "cooked_mutton": 58165,
  "cooked_porkchop": 58166,
  "cooked_rabbit": 58167,
  "cooked_salmon": 58168,
  "cookie": 58169,
  "copper_block": 58170,
  "copper_bulb": 58171,
  "copper_door": 58172,
  "copper_golem_statue": 58173,
  "copper_grate": 58174,
  "copper_horse_armor": 58175,
  "copper_ingot": 58176,
  "copper_nautilus_armor": 58177,
  "copper_ore": 58178,
  "copper_spear": 58179,
  "copper_trapdoor": 58180,
  "cornflower": 58181,
  "cracked_deepslate_bricks": 58182,
  "cracked_deepslate_tiles": 58183,
  "cracked_nether_bricks": 58184,
  "cracked_polished_blackstone_bricks": 58185,
  "cracked_stone_bricks": 58186,
  "crafter": 58187,
  "crafting_table": 58188,
  "creaking_heart": 58189,
  "creeper_banner_pattern": 58190,
  "creeper_head": 58191,
  "crimson_button": 58192,
  "crimson_door": 58193,
  "crimson_double_slab": 58194,
  "crimson_fence": 58195,
  "crimson_fence_gate": 58196,
  "crimson_fungus": 58197,
  "crimson_hanging_sign": 58198,
  "crimson_hyphae": 58199,
  "crimson_nylium": 58200,
  "crimson_planks": 58201,
  "crimson_pressure_plate": 58202,
  "crimson_roots": 58203,
  "crimson_shelf": 58204,
  "crimson_sign": 58205,
  "crimson_slab": 58206,
  "crimson_stairs": 58207,
  "crimson_standing_sign": 58208,
  "crimson_stem": 58209,
  "crimson_trapdoor": 58210,
  "crimson_wall_sign": 58211,
  "crossbow": 58212,
  "crying_obsidian": 58213,
  "cut_copper": 58214,
  "cut_copper_slab": 58215,
  "cut_copper_stairs": 58216,
  "cut_red_sandstone": 58217,
  "cut_red_sandstone_slab": 58218,
  "cut_sandstone": 58219,
  "cut_sandstone_slab": 58220,
  "cyan_banner": 58221,
  "cyan_bundle": 58222,
  "cyan_candle": 58223,
  "cyan_candle_cake": 58224,
  "cyan_carpet": 58225,
  "cyan_concrete": 58226,
  "cyan_concrete_powder": 58227,
  "cyan_dye": 58228,
  "cyan_glazed_terracotta": 58229,
  "cyan_harness": 58230,
  "cyan_shulker_box": 58231,
  "cyan_stained_glass": 58232,
  "cyan_stained_glass_pane": 58233,
  "cyan_terracotta": 58234,
  "cyan_wool": 58235,
  "damaged_anvil": 58236,
  "dandelion": 58237,
  "danger_pottery_sherd": 58238,
  "darkOakFence": 58239,
  "dark_oak_boat": 58240,
  "dark_oak_button": 58241,
  "dark_oak_chest_boat": 58242,
  "dark_oak_door": 58243,
  "dark_oak_double_slab": 58244,
  "dark_oak_fence": 58245,
  "dark_oak_fence_gate": 58246,
  "dark_oak_hanging_sign": 58247,
  "dark_oak_leaves": 58248,
  "dark_oak_log": 58249,
  "dark_oak_planks": 58250,
  "dark_oak_pressure_plate": 58251,
  "dark_oak_sapling": 58252,
  "dark_oak_shelf": 58253,
  "dark_oak_sign": 58254,
  "dark_oak_slab": 58255,
  "dark_oak_stairs": 58256,
  "dark_oak_trapdoor": 58257,
  "dark_oak_wood": 58258,
  "dark_prismarine": 58259,
  "dark_prismarine_double_slab": 58260,
  "dark_prismarine_slab": 58261,
  "dark_prismarine_stairs": 58262,
  "darkoak_sign": 58263,
  "darkoak_standing_sign": 58264,
  "daylight_detector": 58265,
  "dead_brain_coral": 58266,
  "dead_brain_coral_block": 58267,
  "dead_brain_coral_fan": 58268,
  "dead_brain_coral_wall_fan": 58269,
  "dead_bubble_coral": 58270,
  "dead_bubble_coral_block": 58271,
  "dead_bubble_coral_fan": 58272,
  "dead_bubble_coral_wall_fan": 58273,
  "dead_fire_coral": 58274,
  "dead_fire_coral_block": 58275,
  "dead_fire_coral_fan": 58276,
  "dead_fire_coral_wall_fan": 58277,
  "dead_horn_coral": 58278,
  "dead_horn_coral_block": 58279,
  "dead_horn_coral_fan": 58280,
  "dead_horn_coral_wall_fan": 58281,
  "dead_tube_coral": 58282,
  "dead_tube_coral_block": 58283,
  "dead_tube_coral_fan": 58284,
  "dead_tube_coral_wall_fan": 58285,
  "deadbush": 58286,
  "decorated_pot": 58287,
  "deepslate": 58288,
  "deepslate_brick_double_slab": 58289,
  "deepslate_brick_slab": 58290,
  "deepslate_brick_stairs": 58291,
  "deepslate_brick_wall": 58292,
  "deepslate_bricks": 58293,
  "deepslate_coal_ore": 58294,
  "deepslate_copper_ore": 58295,
  "deepslate_diamond_ore": 58296,
  "deepslate_emerald_ore": 58297,
  "deepslate_gold_ore": 58298,
  "deepslate_iron_ore": 58299,
  "deepslate_lapis_ore": 58300,
  "deepslate_redstone_ore": 58301,
  "deepslate_tile_double_slab": 58302,
  "deepslate_tile_slab": 58303,
  "deepslate_tile_stairs": 58304,
  "deepslate_tile_wall": 58305,
  "deepslate_tiles": 58306,
  "deny": 58307,
  "detector_rail": 58308,
  "diamond": 58309,
  "diamond_axe": 58310,
  "diamond_block": 58311,
  "diamond_boots": 58312,
  "diamond_chestplate": 58313,
  "diamond_helmet": 58314,
  "diamond_hoe": 58315,
  "diamond_horse_armor": 58316,
  "diamond_leggings": 58317,
  "diamond_nautilus_armor": 58318,
  "diamond_ore": 58319,
  "diamond_pickaxe": 58320,
  "diamond_shovel": 58321,
  "diamond_spear": 58322,
  "diamond_sword": 58323,
  "diorite": 58324,
  "diorite_double_slab": 58325,
  "diorite_slab": 58326,
  "diorite_stairs": 58327,
  "diorite_wall": 58328,
  "dirt": 58329,
  "dirt_with_roots": 58330,
  "disc_fragment": 58331,
  "disc_fragment_5": 58332,
  "dispenser": 58333,
  "doorWood": 58334,
  "double_cut_copper_slab": 58335,
  "double_plant": 58336,
  "double_stone_slab": 58337,
  "double_wooden_slab": 58338,
  "dragon_breath": 58339,
  "dragon_egg": 58340,
  "dragon_head": 58341,
  "dried_ghast": 58342,
  "dried_kelp": 58343,
  "dried_kelp_block": 58344,
  "dripstone_block": 58345,
  "dropper": 58346,
  "dune_armor_trim_smithing_template": 58347,
  "echo_shard": 58348,
  "egg": 58349,
  "elytra": 58350,
  "emerald": 58351,
  "emerald_block": 58352,
  "emerald_ore": 58353,
  "emptyLocatorMap": 58354,
  "emptyMap": 58355,
  "enchanted_book": 58356,
  "enchanted_golden_apple": 58357,
  "enchanting_table": 58358,
  "end_brick_stairs": 58359,
  "end_bricks": 58360,
  "end_crystal": 58361,
  "end_portal_frame": 58362,
  "end_rod": 58363,
  "end_stone": 58364,
  "end_stone_brick_double_slab": 58365,
  "end_stone_brick_slab": 58366,
  "end_stone_brick_wall": 58367,
  "enderChest": 58368,
  "ender_chest": 58369,
  "ender_chest_item": 58370,
  "ender_eye": 58371,
  "ender_pearl": 58372,
  "experience_bottle": 58373,
  "explorer_pottery_sherd": 58374,
  "exposed_chiseled_copper": 58375,
  "exposed_copper": 58376,
  "exposed_copper_bulb": 58377,
  "exposed_copper_door": 58378,
  "exposed_copper_golem_statue": 58379,
  "exposed_copper_grate": 58380,
  "exposed_copper_trapdoor": 58381,
  "exposed_cut_copper": 58382,
  "exposed_cut_copper_slab": 58383,
  "exposed_cut_copper_stairs": 58384,
  "exposed_double_cut_copper_slab": 58385,
  "eye_armor_trim_smithing_template": 58386,
  "farmland": 58387,
  "feather": 58388,
  "fence": 58389,
  "fence_gate": 58390,
  "fermented_spider_eye": 58391,
  "fern": 58392,
  "field_masoned_banner_pattern": 58393,
  "fire": 58394,
  "fire_coral": 58395,
  "fire_coral_block": 58396,
  "fire_coral_fan": 58397,
  "fireball": 58398,
  "firefly_bush": 58399,
  "firework_rocket": 58400,
  "firework_star": 58401,
  "fireworks": 58402,
  "fireworksCharge": 58403,
  "fireworks_charge": 58404,
  "fish": 58405,
  "fishing_rod": 58406,
  "fletching_table": 58407,
  "flint": 58408,
  "flint_and_steel": 58409,
  "flow_armor_trim_smithing_template": 58410,
  "flow_banner_pattern": 58411,
  "flow_pottery_sherd": 58412,
  "flower_banner_pattern": 58413,
  "flower_pot": 58414,
  "flowering_azalea": 58415,
  "flowing_lava": 58416,
  "flowing_water": 58417,
  "frame": 58418,
  "friend_pottery_sherd": 58419,
  "frog_spawn": 58420,
  "frosted_ice": 58421,
  "furnace": 58422,
  "furnace_block": 58423,
  "ghast_tear": 58424,
  "gilded_blackstone": 58425,
  "glass": 58426,
  "glass_bottle": 58427,
  "glass_pane": 58428,
  "glazedTerracottaBlack": 58429,
  "glazedTerracottaBlue": 58430,
  "glazedTerracottaBrown": 58431,
  "glazedTerracottaCyan": 58432,
  "glazedTerracottaGray": 58433,
  "glazedTerracottaGreen": 58434,
  "glazedTerracottaLightBlue": 58435,
  "glazedTerracottaLime": 58436,
  "glazedTerracottaMagenta": 58437,
  "glazedTerracottaOrange": 58438,
  "glazedTerracottaPink": 58439,
  "glazedTerracottaPurple": 58440,
  "glazedTerracottaRed": 58441,
  "glazedTerracottaSilver": 58442,
  "glazedTerracottaWhite": 58443,
  "glazedTerracottaYellow": 58444,
  "globe_banner_pattern": 58445,
  "glow_berries": 58446,
  "glow_frame": 58447,
  "glow_ink_sac": 58448,
  "glow_lichen": 58449,
  "glowstone": 58450,
  "glowstone_dust": 58451,
  "goat_horn": 58452,
  "gold_block": 58453,
  "gold_ingot": 58454,
  "gold_nugget": 58455,
  "gold_ore": 58456,
  "golden_apple": 58457,
  "golden_axe": 58458,
  "golden_boots": 58459,
  "golden_carrot": 58460,
  "golden_chestplate": 58461,
  "golden_helmet": 58462,
  "golden_hoe": 58463,
  "golden_horse_armor": 58464,
  "golden_leggings": 58465,
  "golden_nautilus_armor": 58466,
  "golden_pickaxe": 58467,
  "golden_rail": 58468,
  "golden_shovel": 58469,
  "golden_sword": 58470,
  "granite": 58471,
  "granite_double_slab": 58472,
  "granite_slab": 58473,
  "granite_stairs": 58474,
  "granite_wall": 58475,
  "grass": 58476,
  "grass_block": 58477,
  "grass_path": 58478,
  "gravel": 58479,
  "gray_banner": 58480,
  "gray_bundle": 58481,
  "gray_candle": 58482,
  "gray_candle_cake": 58483,
  "gray_carpet": 58484,
  "gray_concrete": 58485,
  "gray_concrete_powder": 58486,
  "gray_dye": 58487,
  "gray_glazed_terracotta": 58488,
  "gray_harness": 58489,
  "gray_shulker_box": 58490,
  "gray_stained_glass": 58491,
  "gray_stained_glass_pane": 58492,
  "gray_terracotta": 58493,
  "gray_wool": 58494,
  "green_banner": 58495,
  "green_bundle": 58496,
  "green_candle": 58497,
  "green_candle_cake": 58498,
  "green_carpet": 58499,
  "green_concrete": 58500,
  "green_concrete_powder": 58501,
  "green_dye": 58502,
  "green_glazed_terracotta": 58503,
  "green_harness": 58504,
  "green_shulker_box": 58505,
  "green_stained_glass": 58506,
  "green_stained_glass_pane": 58507,
  "green_terracotta": 58508,
  "green_wool": 58509,
  "grindstone": 58510,
  "gunpowder": 58511,
  "guster_banner_pattern": 58512,
  "guster_pottery_sherd": 58513,
  "hanging_roots": 58514,
  "hardened_clay": 58515,
  "hay_block": 58516,
  "heart_of_the_sea": 58517,
  "heart_pottery_sherd": 58518,
  "heartbreak_pottery_sherd": 58519,
  "heavy_core": 58520,
  "heavy_weighted_pressure_plate": 58521,
  "honey_block": 58522,
  "honey_bottle": 58523,
  "honeycomb": 58524,
  "honeycomb_block": 58525,
  "hopper": 58526,
  "hopper_minecart": 58527,
  "horn_coral": 58528,
  "horn_coral_block": 58529,
  "horn_coral_fan": 58530,
  "horse_armor_diamond": 58531,
  "horse_armor_gold": 58532,
  "horse_armor_iron": 58533,
  "horse_armor_leather": 58534,
  "horsearmordiamond": 58535,
  "horsearmorgold": 58536,
  "horsearmoriron": 58537,
  "horsearmorleather": 58538,
  "host_armor_trim_smithing_template": 58539,
  "howl_pottery_sherd": 58540,
  "ice": 58541,
  "infested_chiseled_stone_bricks": 58542,
  "infested_cobblestone": 58543,
  "infested_cracked_stone_bricks": 58544,
  "infested_deepslate": 58545,
  "infested_mossy_stone_bricks": 58546,
  "infested_stone": 58547,
  "infested_stone_bricks": 58548,
  "ink_sac": 58549,
  "invisibleBedrock": 58550,
  "iron_axe": 58551,
  "iron_bars": 58552,
  "iron_block": 58553,
  "iron_boots": 58554,
  "iron_chestplate": 58555,
  "iron_door": 58556,
  "iron_helmet": 58557,
  "iron_hoe": 58558,
  "iron_horse_armor": 58559,
  "iron_ingot": 58560,
  "iron_leggings": 58561,
  "iron_nautilus_armor": 58562,
  "iron_nugget": 58563,
  "iron_ore": 58564,
  "iron_pickaxe": 58565,
  "iron_shovel": 58566,
  "iron_spear": 58567,
  "iron_sword": 58568,
  "iron_trapdoor": 58569,
  "jack_o_lantern": 58570,
  "jigsaw": 58571,
  "jukebox": 58572,
  "jungleFence": 58573,
  "jungle_boat": 58574,
  "jungle_button": 58575,
  "jungle_chest_boat": 58576,
  "jungle_door": 58577,
  "jungle_double_slab": 58578,
  "jungle_fence": 58579,
  "jungle_fence_gate": 58580,
  "jungle_hanging_sign": 58581,
  "jungle_leaves": 58582,
  "jungle_log": 58583,
  "jungle_planks": 58584,
  "jungle_pressure_plate": 58585,
  "jungle_sapling": 58586,
  "jungle_shelf": 58587,
  "jungle_sign": 58588,
  "jungle_slab": 58589,
  "jungle_stairs": 58590,
  "jungle_standing_sign": 58591,
  "jungle_trapdoor": 58592,
  "jungle_wood": 58593,
  "kelp": 58594,
  "ladder": 58595,
  "lantern": 58596,
  "lapis_block": 58597,
  "lapis_lazuli": 58598,
  "lapis_ore": 58599,
  "large_amethyst_bud": 58600,
  "large_fern": 58601,
  "lava": 58602,
  "lava_bucket": 58603,
  "lead": 58604,
  "leaf_litter": 58605,
  "leather": 58606,
  "leather_boots": 58607,
  "leather_chestplate": 58608,
  "leather_helmet": 58609,
  "leather_horse_armor": 58610,
  "leather_leggings": 58611,
  "leaves": 58612,
  "lectern": 58613,
  "lever": 58614,
  "light_block": 58615,
  "light_blue_banner": 58616,
  "light_blue_bundle": 58617,
  "light_blue_candle": 58618,
  "light_blue_candle_cake": 58619,
  "light_blue_carpet": 58620,
  "light_blue_concrete": 58621,
  "light_blue_concrete_powder": 58622,
  "light_blue_dye": 58623,
  "light_blue_glazed_terracotta": 58880,
  "light_blue_harness": 58881,
  "light_blue_shulker_box": 58882,
  "light_blue_stained_glass": 58883,
  "light_blue_stained_glass_pane": 58884,
  "light_blue_terracotta": 58885,
  "light_blue_wool": 58886,
  "light_gray_banner": 58887,
  "light_gray_bundle": 58888,
  "light_gray_candle": 58889,
  "light_gray_candle_cake": 58890,
  "light_gray_carpet": 58891,
  "light_gray_concrete": 58892,
  "light_gray_concrete_powder": 58893,
  "light_gray_dye": 58894,
  "light_gray_harness": 58895,
  "light_gray_shulker_box": 58896,
  "light_gray_stained_glass": 58897,
  "light_gray_stained_glass_pane": 58898,
  "light_gray_terracotta": 58899,
  "light_gray_wool": 58900,
  "light_weighted_pressure_plate": 58901,
  "lightning_rod": 58902,
  "lilac": 58903,
  "lily_of_the_valley": 58904,
  "lime_banner": 58905,
  "lime_bundle": 58906,
  "lime_candle": 58907,
  "lime_candle_cake": 58908,
  "lime_carpet": 58909,
  "lime_concrete": 58910,
  "lime_concrete_powder": 58911,
  "lime_dye": 58912,
  "lime_glazed_terracotta": 58913,
  "lime_harness": 58914,
  "lime_shulker_box": 58915,
  "lime_stained_glass": 58916,
  "lime_stained_glass_pane": 58917,
  "lime_terracotta": 58918,
  "lime_wool": 58919,
  "lingering_potion": 58920,
  "lit_blast_furnace": 58921,
  "lit_furnace": 58922,
  "lit_pumpkin": 58923,
  "lit_smoker": 58924,
  "lodestone": 58925,
  "lodestonecompass": 58926,
  "log": 58927,
  "loom": 58928,
  "mace": 58929,
  "magenta_banner": 58930,
  "magenta_bundle": 58931,
  "magenta_candle": 58932,
  "magenta_candle_cake": 58933,
  "magenta_carpet": 58934,
  "magenta_concrete": 58935,
  "magenta_concrete_powder": 58936,
  "magenta_dye": 58937,
  "magenta_glazed_terracotta": 58938,
  "magenta_harness": 58939,
  "magenta_shulker_box": 58940,
  "magenta_stained_glass": 58941,
  "magenta_stained_glass_pane": 58942,
  "magenta_terracotta": 58943,
  "magenta_wool": 58944,
  "magma": 58945,
  "magma_cream": 58946,
  "mangrove_boat": 58947,
  "mangrove_button": 58948,
  "mangrove_chest_boat": 58949,
  "mangrove_door": 58950,
  "mangrove_double_slab": 58951,
  "mangrove_fence": 58952,
  "mangrove_fence_gate": 58953,
  "mangrove_hanging_sign": 58954,
  "mangrove_leaves": 58955,
  "mangrove_log": 58956,
  "mangrove_planks": 58957,
  "mangrove_pressure_plate": 58958,
  "mangrove_propagule": 58959,
  "mangrove_roots": 58960,
  "mangrove_shelf": 58961,
  "mangrove_sign": 58962,
  "mangrove_slab": 58963,
  "mangrove_stairs": 58964,
  "mangrove_trapdoor": 58965,
  "mangrove_wood": 58966,
  "map": 58967,
  "medium_amethyst_bud": 58968,
  "melon": 58969,
  "melon_block": 58970,
  "melon_seeds": 58971,
  "melon_slice": 58972,
  "milk": 58973,
  "milk_bucket": 58974,
  "minecart": 58975,
  "minecartFurnace": 58976,
  "minecart_furnace": 58977,
  "miner_pottery_sherd": 58978,
  "mob_spawner": 58979,
  "mojang_banner_pattern": 58980,
  "monster_egg": 58981,
  "moss_block": 58982,
  "moss_carpet": 58983,
  "mossy_cobblestone": 58984,
  "mossy_cobblestone_double_slab": 58985,
  "mossy_cobblestone_slab": 58986,
  "mossy_cobblestone_stairs": 58987,
  "mossy_cobblestone_wall": 58988,
  "mossy_stone_brick_slab": 58989,
  "mossy_stone_brick_stairs": 58990,
  "mossy_stone_brick_wall": 58991,
  "mossy_stone_bricks": 58992,
  "mourner_pottery_sherd": 58993,
  "mud": 58994,
  "mud_brick_double_slab": 58995,
  "mud_brick_slab": 58996,
  "mud_brick_stairs": 58997,
  "mud_brick_wall": 58998,
  "mud_bricks": 58999,
  "muddy_mangrove_roots": 59000,
  "mushroom": 59001,
  "mushroom_stem": 59002,
  "mushroom_stew": 59003,
  "music_disc_11": 59004,
  "music_disc_13": 59005,
  "music_disc_5": 59006,
  "music_disc_blocks": 59007,
  "music_disc_cat": 59008,
  "music_disc_chirp": 59009,
  "music_disc_creator": 59010,
  "music_disc_creator_music_box": 59011,
  "music_disc_far": 59012,
  "music_disc_mall": 59013,
  "music_disc_mellohi": 59014,
  "music_disc_otherside": 59015,
  "music_disc_pigstep": 59016,
  "music_disc_precipice": 59017,
  "music_disc_relic": 59018,
  "music_disc_stal": 59019,
  "music_disc_strad": 59020,
  "music_disc_tears": 59021,
  "music_disc_wait": 59022,
  "music_disc_ward": 59023,
  "mutton": 59024,
  "muttonCooked": 59025,
  "muttonRaw": 59026,
  "mutton_cooked": 59027,
  "mutton_raw": 59028,
  "mycelium": 59029,
  "name_tag": 59030,
  "nautilus_shell": 59031,
  "netherStar": 59032,
  "nether_brick": 59033,
  "nether_brick_double_slab": 59034,
  "nether_brick_fence": 59035,
  "nether_brick_slab": 59036,
  "nether_brick_stairs": 59037,
  "nether_brick_wall": 59038,
  "nether_gold_ore": 59039,
  "nether_sprouts": 59040,
  "nether_star": 59041,
  "nether_wart": 59042,
  "nether_wart_block": 59043,
  "netherbrick": 59044,
  "netherite_axe": 59045,
  "netherite_block": 59046,
  "netherite_boots": 59047,
  "netherite_chestplate": 59048,
  "netherite_helmet": 59049,
  "netherite_hoe": 59050,
  "netherite_horse_armor": 59051,
  "netherite_ingot": 59052,
  "netherite_leggings": 59053,
  "netherite_nautilus_armor": 59054,
  "netherite_pickaxe": 59055,
  "netherite_scrap": 59056,
  "netherite_shovel": 59057,
  "netherite_spear": 59058,
  "netherite_sword": 59059,
  "netherite_upgrade_smithing_template": 59060,
  "netherrack": 59061,
  "netherreactor": 59062,
  "normal_stone_slab": 59063,
  "normal_stone_stairs": 59064,
  "noteblock": 59065,
  "oak_boat": 59066,
  "oak_button": 59067,
  "oak_chest_boat": 59068,
  "oak_door": 59069,
  "oak_double_slab": 59070,
  "oak_fence": 59071,
  "oak_fence_gate": 59072,
  "oak_hanging_sign": 59073,
  "oak_leaves": 59074,
  "oak_log": 59075,
  "oak_planks": 59076,
  "oak_pressure_plate": 59077,
  "oak_sapling": 59078,
  "oak_shelf": 59079,
  "oak_sign": 59080,
  "oak_slab": 59081,
  "oak_stairs": 59082,
  "oak_trapdoor": 59083,
  "oak_wood": 59084,
  "observer": 59085,
  "obsidian": 59086,
  "ochre_froglight": 59087,
  "ominous_bottle": 59088,
  "ominous_trial_key": 59089,
  "open_eyeblossom": 59090,
  "orange_banner": 59091,
  "orange_bundle": 59092,
  "orange_candle": 59093,
  "orange_candle_cake": 59094,
  "orange_carpet": 59095,
  "orange_concrete": 59096,
  "orange_concrete_powder": 59097,
  "orange_dye": 59098,
  "orange_glazed_terracotta": 59099,
  "orange_harness": 59100,
  "orange_shulker_box": 59101,
  "orange_stained_glass": 59102,
  "orange_stained_glass_pane": 59103,
  "orange_terracotta": 59104,
  "orange_tulip": 59105,
  "orange_wool": 59106,
  "oxeye_daisy": 59107,
  "oxidized_chiseled_copper": 59108,
  "oxidized_copper": 59109,
  "oxidized_copper_bulb": 59110,
  "oxidized_copper_door": 59111,
  "oxidized_copper_golem_statue": 59112,
  "oxidized_copper_grate": 59113,
  "oxidized_copper_trapdoor": 59114,
  "oxidized_cut_copper": 59115,
  "oxidized_cut_copper_slab": 59116,
  "oxidized_cut_copper_stairs": 59117,
  "oxidized_double_cut_copper_slab": 59118,
  "packed_ice": 59119,
  "packed_mud": 59120,
  "painting": 59121,
  "pale_hanging_moss": 59122,
  "pale_moss_block": 59123,
  "pale_moss_carpet": 59124,
  "pale_oak_boat": 59125,
  "pale_oak_button": 59126,
  "pale_oak_chest_boat": 59127,
  "pale_oak_door": 59128,
  "pale_oak_double_slab": 59129,
  "pale_oak_fence": 59130,
  "pale_oak_fence_gate": 59131,
  "pale_oak_hanging_sign": 59132,
  "pale_oak_leaves": 59133,
  "pale_oak_log": 59134,
  "pale_oak_planks": 59135,
  "pale_oak_pressure_plate": 59136,
  "pale_oak_sapling": 59137,
  "pale_oak_shelf": 59138,
  "pale_oak_sign": 59139,
  "pale_oak_slab": 59140,
  "pale_oak_stairs": 59141,
  "pale_oak_trapdoor": 59142,
  "pale_oak_wood": 59143,
  "paper": 59144,
  "pearlescent_froglight": 59145,
  "peony": 59146,
  "petrified_oak_double_slab": 59147,
  "petrified_oak_slab": 59148,
  "phantom_membrane": 59149,
  "piglin_banner_pattern": 59150,
  "piglin_head": 59151,
  "pink_banner": 59152,
  "pink_bundle": 59153,
  "pink_candle": 59154,
  "pink_candle_cake": 59155,
  "pink_carpet": 59156,
  "pink_concrete": 59157,
  "pink_concrete_powder": 59158,
  "pink_dye": 59159,
  "pink_glazed_terracotta": 59160,
  "pink_harness": 59161,
  "pink_petals": 59162,
  "pink_shulker_box": 59163,
  "pink_stained_glass": 59164,
  "pink_stained_glass_pane": 59165,
  "pink_terracotta": 59166,
  "pink_tulip": 59167,
  "pink_wool": 59168,
  "piston": 59169,
  "pitcher_plant": 59170,
  "pitcher_pod": 59171,
  "planks": 59172,
  "player_head": 59173,
  "plenty_pottery_sherd": 59174,
  "podzol": 59175,
  "pointed_dripstone": 59176,
  "poisonous_potato": 59177,
  "polished_andesite": 59178,
  "polished_andesite_double_slab": 59179,
  "polished_andesite_slab": 59180,
  "polished_andesite_stairs": 59181,
  "polished_basalt": 59182,
  "polished_blackstone": 59183,
  "polished_blackstone_brick_double_slab": 59184,
  "polished_blackstone_brick_slab": 59185,
  "polished_blackstone_brick_stairs": 59186,
  "polished_blackstone_brick_wall": 59187,
  "polished_blackstone_bricks": 59188,
  "polished_blackstone_button": 59189,
  "polished_blackstone_double_slab": 59190,
  "polished_blackstone_pressure_plate": 59191,
  "polished_blackstone_slab": 59192,
  "polished_blackstone_stairs": 59193,
  "polished_blackstone_wall": 59194,
  "polished_deepslate": 59195,
  "polished_deepslate_double_slab": 59196,
  "polished_deepslate_slab": 59197,
  "polished_deepslate_stairs": 59198,
  "polished_deepslate_wall": 59199,
  "polished_diorite": 59200,
  "polished_diorite_double_slab": 59201,
  "polished_diorite_slab": 59202,
  "polished_diorite_stairs": 59203,
  "polished_granite": 59204,
  "polished_granite_double_slab": 59205,
  "polished_granite_slab": 59206,
  "polished_granite_stairs": 59207,
  "polished_tuff": 59208,
  "polished_tuff_double_slab": 59209,
  "polished_tuff_slab": 59210,
  "polished_tuff_stairs": 59211,
  "polished_tuff_wall": 59212,
  "poplar_shelf": 59213,
  "popped_chorus_fruit": 59214,
  "poppy": 59215,
  "porkchop": 59216,
  "porkchop_cooked": 59217,
  "portal": 59218,
  "potato": 59219,
  "potatoes": 59220,
  "potion": 59221,
  "powder_snow": 59222,
  "powder_snow_bucket": 59223,
  "powered_rail": 59224,
  "prismarine": 59225,
  "prismarine_brick_double_slab": 59226,
  "prismarine_brick_slab": 59227,
  "prismarine_bricks": 59228,
  "prismarine_bricks_stairs": 59229,
  "prismarine_crystals": 59230,
  "prismarine_double_slab": 59231,
  "prismarine_shard": 59232,
  "prismarine_slab": 59233,
  "prismarine_stairs": 59234,
  "prismarine_wall": 59235,
  "prize_pottery_sherd": 59236,
  "pufferfish": 59237,
  "pufferfish_bucket": 59238,
  "pumpkin": 59239,
  "pumpkin_pie": 59240,
  "pumpkin_seeds": 59241,
  "pumpkin_stem": 59242,
  "purple_banner": 59243,
  "purple_bundle": 59244,
  "purple_candle": 59245,
  "purple_candle_cake": 59246,
  "purple_carpet": 59247,
  "purple_concrete": 59248,
  "purple_concrete_powder": 59249,
  "purple_dye": 59250,
  "purple_glazed_terracotta": 59251,
  "purple_harness": 59252,
  "purple_shulker_box": 59253,
  "purple_stained_glass": 59254,
  "purple_stained_glass_pane": 59255,
  "purple_terracotta": 59256,
  "purple_wool": 59257,
  "purpur_block": 59258,
  "purpur_double_slab": 59259,
  "purpur_pillar": 59260,
  "purpur_slab": 59261,
  "purpur_stairs": 59262,
  "quartz": 59263,
  "quartz_block": 59264,
  "quartz_bricks": 59265,
  "quartz_double_slab": 59266,
  "quartz_ore": 59267,
  "quartz_pillar": 59268,
  "quartz_slab": 59269,
  "quartz_stairs": 59270,
  "rabbit": 59271,
  "rabbit_foot": 59272,
  "rabbit_hide": 59273,
  "rabbit_stew": 59274,
  "rail": 59275,
  "raiser_armor_trim_smithing_template": 59276,
  "raw_copper": 59277,
  "raw_copper_block": 59278,
  "raw_gold": 59279,
  "raw_gold_block": 59280,
  "raw_iron": 59281,
  "raw_iron_block": 59282,
  "record_11": 59283,
  "record_13": 59284,
  "record_5": 59285,
  "record_blocks": 59286,
  "record_cat": 59287,
  "record_chirp": 59288,
  "record_creator": 59289,
  "record_creator_music_box": 59290,
  "record_far": 59291,
  "record_mall": 59292,
  "record_mellohi": 59293,
  "record_otherside": 59294,
  "record_pigstep": 59295,
  "record_precipice": 59296,
  "record_relic": 59297,
  "record_stal": 59298,
  "record_strad": 59299,
  "record_tears": 59300,
  "record_wait": 59301,
  "record_ward": 59302,
  "recovery_compass": 59303,
  "red_banner": 59304,
  "red_bundle": 59305,
  "red_candle": 59306,
  "red_candle_cake": 59307,
  "red_carpet": 59308,
  "red_concrete": 59309,
  "red_concrete_powder": 59310,
  "red_dye": 59311,
  "red_flower": 59312,
  "red_glazed_terracotta": 59313,
  "red_harness": 59314,
  "red_mushroom": 59315,
  "red_mushroom_block": 59316,
  "red_nether_brick": 59317,
  "red_nether_brick_double_slab": 59318,
  "red_nether_brick_slab": 59319,
  "red_nether_brick_stairs": 59320,
  "red_nether_brick_wall": 59321,
  "red_sand": 59322,
  "red_sandstone": 59323,
  "red_sandstone_double_slab": 59324,
  "red_sandstone_slab": 59325,
  "red_sandstone_stairs": 59326,
  "red_sandstone_wall": 59327,
  "red_shulker_box": 59328,
  "red_stained_glass": 59329,
  "red_stained_glass_pane": 59330,
  "red_terracotta": 59331,
  "red_tulip": 59332,
  "red_wool": 59333,
  "redsandstone": 59334,
  "redstone": 59335,
  "redstone_block": 59336,
  "redstone_lamp": 59337,
  "redstone_ore": 59338,
  "redstone_torch": 59339,
  "redstone_wire": 59340,
  "reeds": 59341,
  "reinforced_deepslate": 59342,
  "repeater": 59343,
  "repeating_command_block": 59344,
  "resin_block": 59345,
  "resin_brick": 59346,
  "resin_brick_double_slab": 59347,
  "resin_brick_slab": 59348,
  "resin_brick_stairs": 59349,
  "resin_brick_wall": 59350,
  "resin_bricks": 59351,
  "resin_clump": 59352,
  "respawn_anchor": 59353,
  "rib_armor_trim_smithing_template": 59354,
  "rooted_dirt": 59355,
  "rose_bush": 59356,
  "rotten_flesh": 59357,
  "ruby": 59358,
  "saddle": 59359,
  "salmon": 59360,
  "salmon_bucket": 59361,
  "sand": 59362,
  "sandstone": 59363,
  "sandstone_double_slab": 59364,
  "sandstone_slab": 59365,
  "sandstone_stairs": 59366,
  "sandstone_wall": 59367,
  "scaffolding": 59368,
  "scrape_pottery_sherd": 59369,
  "sculk": 59370,
  "sculk_catalyst": 59371,
  "sculk_sensor": 59372,
  "sculk_shrieker": 59373,
  "sculk_vein": 59374,
  "seaLantern": 59375,
  "sea_lantern": 59376,
  "sea_pickle": 59377,
  "seagrass": 59378,
  "sentry_armor_trim_smithing_template": 59379,
  "shaper_armor_trim_smithing_template": 59380,
  "sheaf_pottery_sherd": 59381,
  "shears": 59382,
  "shelter_pottery_sherd": 59383,
  "shield": 59384,
  "short_dry_grass": 59385,
  "short_grass": 59386,
  "shroomlight": 59387,
  "shulkerBox": 59388,
  "shulkerBoxBlack": 59389,
  "shulkerBoxBlue": 59390,
  "shulkerBoxBrown": 59391,
  "shulkerBoxCyan": 59392,
  "shulkerBoxGray": 59393,
  "shulkerBoxGreen": 59394,
  "shulkerBoxLightBlue": 59395,
  "shulkerBoxLime": 59396,
  "shulkerBoxMagenta": 59397,
  "shulkerBoxOrange": 59398,
  "shulkerBoxPink": 59399,
  "shulkerBoxPurple": 59400,
  "shulkerBoxRed": 59401,
  "shulkerBoxSilver": 59402,
  "shulkerBoxWhite": 59403,
  "shulkerBoxYellow": 59404,
  "shulker_box": 59405,
  "shulker_shell": 59406,
  "sign": 59407,
  "silence_armor_trim_smithing_template": 59408,
  "silver_glazed_terracotta": 59409,
  "skeleton_skull": 59410,
  "skull_banner_pattern": 59411,
  "skull_pottery_sherd": 59412,
  "slime": 59413,
  "slime_ball": 59414,
  "slimeball": 59415,
  "small_amethyst_bud": 59416,
  "small_dripleaf_block": 59417,
  "smithing_table": 59418,
  "smithing_template": 59419,
  "smoker": 59420,
  "smooth_basalt": 59421,
  "smooth_quartz": 59422,
  "smooth_quartz_slab": 59423,
  "smooth_quartz_stairs": 59424,
  "smooth_red_sandstone": 59425,
  "smooth_red_sandstone_double_slab": 59426,
  "smooth_red_sandstone_slab": 59427,
  "smooth_red_sandstone_stairs": 59428,
  "smooth_sandstone": 59429,
  "smooth_sandstone_double_slab": 59430,
  "smooth_sandstone_slab": 59431,
  "smooth_sandstone_stairs": 59432,
  "smooth_stone": 59433,
  "smooth_stone_double_slab": 59434,
  "smooth_stone_slab": 59435,
  "sniffer_egg": 59436,
  "snort_pottery_sherd": 59437,
  "snout_armor_trim_smithing_template": 59438,
  "snow": 59439,
  "snow_layer": 59440,
  "snowball": 59441,
  "soul_campfire": 59442,
  "soul_fire": 59443,
  "soul_lantern": 59444,
  "soul_sand": 59445,
  "soul_soil": 59446,
  "soul_torch": 59447,
  "speckled_melon": 59448,
  "spectral_arrow": 59449,
  "spider_eye": 59450,
  "spire_armor_trim_smithing_template": 59451,
  "splash_potion": 59452,
  "sponge": 59453,
  "spore_blossom": 59454,
  "spruceFence": 59455,
  "spruce_boat": 59456,
  "spruce_button": 59457,
  "spruce_chest_boat": 59458,
  "spruce_door": 59459,
  "spruce_double_slab": 59460,
  "spruce_fence": 59461,
  "spruce_fence_gate": 59462,
  "spruce_hanging_sign": 59463,
  "spruce_leaves": 59464,
  "spruce_log": 59465,
  "spruce_planks": 59466,
  "spruce_pressure_plate": 59467,
  "spruce_sapling": 59468,
  "spruce_shelf": 59469,
  "spruce_sign": 59470,
  "spruce_slab": 59471,
  "spruce_stairs": 59472,
  "spruce_standing_sign": 59473,
  "spruce_trapdoor": 59474,
  "spruce_wood": 59475,
  "spyglass": 59476,
  "stained_hardened_clay": 59477,
  "standing_banner": 59478,
  "standing_sign": 59479,
  "steak": 59480,
  "stick": 59481,
  "stick_pile": 59482,
  "sticky_piston": 59483,
  "stone": 59484,
  "stone_axe": 59485,
  "stone_brick_double_slab": 59486,
  "stone_brick_slab": 59487,
  "stone_brick_stairs": 59488,
  "stone_brick_wall": 59489,
  "stone_bricks": 59490,
  "stone_button": 59491,
  "stone_hoe": 59492,
  "stone_pickaxe": 59493,
  "stone_pressure_plate": 59494,
  "stone_shovel": 59495,
  "stone_slab": 59496,
  "stone_spear": 59497,
  "stone_stairs": 59498,
  "stone_sword": 59499,
  "stonebrick": 59500,
  "stonecutter": 59501,
  "stonecutter_block": 59502,
  "string": 59503,
  "stripped_acacia_log": 59504,
  "stripped_acacia_wood": 59505,
  "stripped_bamboo_block": 59506,
  "stripped_birch_log": 59507,
  "stripped_birch_wood": 59508,
  "stripped_cherry_log": 59509,
  "stripped_cherry_wood": 59510,
  "stripped_crimson_hyphae": 59511,
  "stripped_crimson_stem": 59512,
  "stripped_dark_oak_log": 59513,
  "stripped_dark_oak_wood": 59514,
  "stripped_jungle_log": 59515,
  "stripped_jungle_wood": 59516,
  "stripped_mangrove_log": 59517,
  "stripped_mangrove_wood": 59518,
  "stripped_oak_log": 59519,
  "stripped_oak_wood": 59520,
  "stripped_pale_oak_log": 59521,
  "stripped_pale_oak_wood": 59522,
  "stripped_spruce_log": 59523,
  "stripped_spruce_wood": 59524,
  "stripped_warped_hyphae": 59525,
  "stripped_warped_stem": 59526,
  "structure_block": 59527,
  "structure_void": 59528,
  "sugar": 59529,
  "sugar_cane": 59530,
  "sunflower": 59531,
  "suspicious_gravel": 59532,
  "suspicious_sand": 59533,
  "suspicious_stew": 59534,
  "sweet_berries": 59535,
  "sweet_berry_bush": 59536,
  "tadpole_bucket": 59537,
  "tall_dry_grass": 59538,
  "tall_grass": 59539,
  "tallgrass": 59540,
  "target": 59541,
  "tide_armor_trim_smithing_template": 59542,
  "tinted_glass": 59543,
  "tipped_arrow": 59544,
  "tnt": 59545,
  "tnt_minecart": 59546,
  "torch": 59547,
  "torchflower": 59548,
  "torchflower_seeds": 59549,
  "totem": 59550,
  "totem_of_undying": 59551,
  "trapdoor": 59552,
  "trapped_chest": 59553,
  "trial_key": 59554,
  "trial_spawner": 59555,
  "trident": 59556,
  "tripWire": 59557,
  "trip_wire": 59558,
  "tripwire_hook": 59559,
  "tropical_fish": 59560,
  "tropical_fish_bucket": 59561,
  "tube_coral": 59562,
  "tube_coral_block": 59563,
  "tube_coral_fan": 59564,
  "tuff": 59565,
  "tuff_brick_double_slab": 59566,
  "tuff_brick_slab": 59567,
  "tuff_brick_stairs": 59568,
  "tuff_brick_wall": 59569,
  "tuff_bricks": 59570,
  "tuff_double_slab": 59571,
  "tuff_slab": 59572,
  "tuff_stairs": 59573,
  "tuff_wall": 59574,
  "turtle_egg": 59575,
  "turtle_helmet": 59576,
  "turtle_shell_piece": 59577,
  "twisting_vines": 59578,
  "undyed_shulker_box": 59579,
  "unlit_redstone_torch": 59580,
  "vault": 59581,
  "verdant_froglight": 59582,
  "vex_armor_trim_smithing_template": 59583,
  "vine": 59584,
  "wall_banner": 59585,
  "ward_armor_trim_smithing_template": 59586,
  "warped_button": 59587,
  "warped_door": 59588,
  "warped_double_slab": 59589,
  "warped_fence": 59590,
  "warped_fence_gate": 59591,
  "warped_fungus": 59592,
  "warped_fungus_on_a_stick": 59593,
  "warped_hanging_sign": 59594,
  "warped_hyphae": 59595,
  "warped_nylium": 59596,
  "warped_planks": 59597,
  "warped_pressure_plate": 59598,
  "warped_roots": 59599,
  "warped_shelf": 59600,
  "warped_sign": 59601,
  "warped_slab": 59602,
  "warped_stairs": 59603,
  "warped_standing_sign": 59604,
  "warped_stem": 59605,
  "warped_trapdoor": 59606,
  "warped_wall_sign": 59607,
  "warped_wart_block": 59608,
  "water": 59609,
  "water_bucket": 59610,
  "waterlily": 59611,
  "waxed_chiseled_copper": 59612,
  "waxed_copper": 59613,
  "waxed_copper_bulb": 59614,
  "waxed_copper_door": 59615,
  "waxed_copper_golem_statue": 59616,
  "waxed_copper_grate": 59617,
  "waxed_copper_trapdoor": 59618,
  "waxed_cut_copper": 59619,
  "waxed_cut_copper_slab": 59620,
  "waxed_cut_copper_stairs": 59621,
  "waxed_double_cut_copper_slab": 59622,
  "waxed_exposed_chiseled_copper": 59623,
  "waxed_exposed_copper": 59624,
  "waxed_exposed_copper_bulb": 59625,
  "waxed_exposed_copper_door": 59626,
  "waxed_exposed_copper_golem_statue": 59627,
  "waxed_exposed_copper_grate": 59628,
  "waxed_exposed_copper_trapdoor": 59629,
  "waxed_exposed_cut_copper": 59630,
  "waxed_exposed_cut_copper_slab": 59631,
  "waxed_exposed_cut_copper_stairs": 59632,
  "waxed_exposed_double_cut_copper_slab": 59633,
  "waxed_oxidized_chiseled_copper": 59634,
  "waxed_oxidized_copper": 59635,
  "waxed_oxidized_copper_bulb": 59636,
  "waxed_oxidized_copper_door": 59637,
  "waxed_oxidized_copper_golem_statue": 59638,
  "waxed_oxidized_copper_grate": 59639,
  "waxed_oxidized_copper_trapdoor": 59640,
  "waxed_oxidized_cut_copper": 59641,
  "waxed_oxidized_cut_copper_slab": 59642,
  "waxed_oxidized_cut_copper_stairs": 59643,
  "waxed_oxidized_double_cut_copper_slab": 59644,
  "waxed_weathered_chiseled_copper": 59645,
  "waxed_weathered_copper": 59646,
  "waxed_weathered_copper_bulb": 59647,
  "waxed_weathered_copper_door": 59648,
  "waxed_weathered_copper_golem_statue": 59649,
  "waxed_weathered_copper_grate": 59650,
  "waxed_weathered_copper_trapdoor": 59651,
  "waxed_weathered_cut_copper": 59652,
  "waxed_weathered_cut_copper_slab": 59653,
  "waxed_weathered_cut_copper_stairs": 59654,
  "waxed_weathered_double_cut_copper_slab": 59655,
  "wayfinder_armor_trim_smithing_template": 59656,
  "weathered_chiseled_copper": 59657,
  "weathered_copper": 59658,
  "weathered_copper_bulb": 59659,
  "weathered_copper_door": 59660,
  "weathered_copper_golem_statue": 59661,
  "weathered_copper_grate": 59662,
  "weathered_copper_trapdoor": 59663,
  "weathered_cut_copper": 59664,
  "weathered_cut_copper_slab": 59665,
  "weathered_cut_copper_stairs": 59666,
  "weathered_double_cut_copper_slab": 59667,
  "web": 59668,
  "weeping_vines": 59669,
  "wet_sponge": 59670,
  "wheat": 59671,
  "wheat_seeds": 59672,
  "white_banner": 59673,
  "white_bundle": 59674,
  "white_candle": 59675,
  "white_candle_cake": 59676,
  "white_carpet": 59677,
  "white_concrete": 59678,
  "white_concrete_powder": 59679,
  "white_dye": 59680,
  "white_glazed_terracotta": 59681,
  "white_harness": 59682,
  "white_shulker_box": 59683,
  "white_stained_glass": 59684,
  "white_stained_glass_pane": 59685,
  "white_terracotta": 59686,
  "white_tulip": 59687,
  "white_wool": 59688,
  "wild_armor_trim_smithing_template": 59689,
  "wildflowers": 59690,
  "wind_charge": 59691,
  "wither_rose": 59692,
  "wither_skeleton_skull": 59693,
  "wolf_armor": 59694,
  "wooden_axe": 59695,
  "wooden_button": 59696,
  "wooden_door": 59697,
  "wooden_hoe": 59698,
  "wooden_pickaxe": 59699,
  "wooden_pressure_plate": 59700,
  "wooden_shovel": 59701,
  "wooden_slab": 59702,
  "wooden_sword": 59703,
  "wool": 59704,
  "writable_book": 59705,
  "written_book": 59706,
  "yellow_banner": 59707,
  "yellow_bundle": 59708,
  "yellow_candle": 59709,
  "yellow_candle_cake": 59710,
  "yellow_carpet": 59711,
  "yellow_concrete": 59712,
  "yellow_concrete_powder": 59713,
  "yellow_dye": 59714,
  "yellow_flower": 59715,
  "yellow_glazed_terracotta": 59716,
  "yellow_harness": 59717,
  "yellow_shulker_box": 59718,
  "yellow_stained_glass": 59719,
  "yellow_stained_glass_pane": 59720,
  "yellow_terracotta": 59721,
  "yellow_wool": 59722,
  "zombie_head": 59723
};

const GLYPH_PAGES = [226,227,228,230,231,232,233];

const BOX_GLYPH_PAGES = [248,247,246,245,244,243,242];

/**
 * 物品 -> **亮版**字形码点（只有容器界面那套预览用）。
 *
 * ## 为什么有第二张表
 *
 * 打开容器/背包时，容器界面会在 HUD 上方压一层 alpha=0.4 的暗幕，
 * HUD 整层（含预览）都在它下面 —— 图标被整体压暗、压灰，
 * 因此该预览需要把物品图标的明度与饱和度拉高以抵消压暗。
 *
 * JSON UI 的 label 既没有亮度/饱和度属性，也染不了**彩色字形**（字形页存的是
 * RGBA），更没有混合模式 —— 所以只能另出一套提亮 + 提饱和的字形页，
 * 把码点记在这张表里。普通准星预览仍用 ITEM_GLYPHS（原版那套）。
 *
 * 两张表的**格子下标完全一致**，只有高字节不同；查不到亮版的物品
 * （理论上不会有，除非构建时页不够）会自动退回普通图标。
 */
const BOX_ITEM_GLYPHS = {
  "acaciaFence": 63488,
  "acacia_boat": 63489,
  "acacia_button": 63490,
  "acacia_chest_boat": 63491,
  "acacia_door": 63492,
  "acacia_double_slab": 63493,
  "acacia_fence": 63494,
  "acacia_fence_gate": 63495,
  "acacia_hanging_sign": 63496,
  "acacia_leaves": 63497,
  "acacia_log": 63498,
  "acacia_planks": 63499,
  "acacia_pressure_plate": 63500,
  "acacia_sapling": 63501,
  "acacia_shelf": 63502,
  "acacia_sign": 63503,
  "acacia_slab": 63504,
  "acacia_stairs": 63505,
  "acacia_standing_sign": 63506,
  "acacia_trapdoor": 63507,
  "acacia_wood": 63508,
  "activator_rail": 63509,
  "allium": 63510,
  "allow": 63511,
  "amethyst_block": 63512,
  "amethyst_cluster": 63513,
  "amethyst_shard": 63514,
  "ancient_debris": 63515,
  "andesite": 63516,
  "andesite_double_slab": 63517,
  "andesite_slab": 63518,
  "andesite_stairs": 63519,
  "andesite_wall": 63520,
  "angler_pottery_sherd": 63521,
  "anvil": 63522,
  "apple": 63523,
  "appleEnchanted": 63524,
  "archer_pottery_sherd": 63525,
  "armadillo_scute": 63526,
  "armor_stand": 63527,
  "arms_up_pottery_sherd": 63528,
  "arrow": 63529,
  "axolotl_bucket": 63530,
  "azalea": 63531,
  "azalea_leaves": 63532,
  "azalea_leaves_flowered": 63533,
  "azure_bluet": 63534,
  "baked_potato": 63535,
  "bamboo": 63536,
  "bamboo_block": 63537,
  "bamboo_button": 63538,
  "bamboo_chest_raft": 63539,
  "bamboo_door": 63540,
  "bamboo_double_slab": 63541,
  "bamboo_fence": 63542,
  "bamboo_fence_gate": 63543,
  "bamboo_hanging_sign": 63544,
  "bamboo_mosaic": 63545,
  "bamboo_mosaic_double_slab": 63546,
  "bamboo_mosaic_slab": 63547,
  "bamboo_mosaic_stairs": 63548,
  "bamboo_planks": 63549,
  "bamboo_pressure_plate": 63550,
  "bamboo_raft": 63551,
  "bamboo_shelf": 63552,
  "bamboo_sign": 63553,
  "bamboo_slab": 63554,
  "bamboo_stairs": 63555,
  "bamboo_trapdoor": 63556,
  "banner": 63557,
  "banner_pattern": 63558,
  "barrel": 63559,
  "barrier": 63560,
  "basalt": 63561,
  "beacon": 63562,
  "bed": 63563,
  "bedrock": 63564,
  "bee_nest": 63565,
  "beef": 63566,
  "beehive": 63567,
  "beetroot": 63568,
  "beetroot_seeds": 63569,
  "beetroot_soup": 63570,
  "bell": 63571,
  "big_dripleaf": 63572,
  "birchFence": 63573,
  "birch_boat": 63574,
  "birch_button": 63575,
  "birch_chest_boat": 63576,
  "birch_door": 63577,
  "birch_double_slab": 63578,
  "birch_fence": 63579,
  "birch_fence_gate": 63580,
  "birch_hanging_sign": 63581,
  "birch_leaves": 63582,
  "birch_log": 63583,
  "birch_planks": 63584,
  "birch_pressure_plate": 63585,
  "birch_sapling": 63586,
  "birch_shelf": 63587,
  "birch_sign": 63588,
  "birch_slab": 63589,
  "birch_stairs": 63590,
  "birch_standing_sign": 63591,
  "birch_trapdoor": 63592,
  "birch_wood": 63593,
  "black_banner": 63594,
  "black_bundle": 63595,
  "black_candle": 63596,
  "black_candle_cake": 63597,
  "black_carpet": 63598,
  "black_concrete": 63599,
  "black_concrete_powder": 63600,
  "black_dye": 63601,
  "black_glazed_terracotta": 63602,
  "black_harness": 63603,
  "black_shulker_box": 63604,
  "black_stained_glass": 63605,
  "black_stained_glass_pane": 63606,
  "black_terracotta": 63607,
  "black_wool": 63608,
  "blackstone": 63609,
  "blackstone_double_slab": 63610,
  "blackstone_slab": 63611,
  "blackstone_stairs": 63612,
  "blackstone_wall": 63613,
  "blade_pottery_sherd": 63614,
  "blast_furnace": 63615,
  "blaze_powder": 63616,
  "blaze_rod": 63617,
  "blue_banner": 63618,
  "blue_bundle": 63619,
  "blue_candle": 63620,
  "blue_candle_cake": 63621,
  "blue_carpet": 63622,
  "blue_concrete": 63623,
  "blue_concrete_powder": 63624,
  "blue_dye": 63625,
  "blue_egg": 63626,
  "blue_glazed_terracotta": 63627,
  "blue_harness": 63628,
  "blue_ice": 63629,
  "blue_orchid": 63630,
  "blue_shulker_box": 63631,
  "blue_stained_glass": 63632,
  "blue_stained_glass_pane": 63633,
  "blue_terracotta": 63634,
  "blue_wool": 63635,
  "bolt_armor_trim_smithing_template": 63636,
  "bone": 63637,
  "bone_block": 63638,
  "bone_meal": 63639,
  "book": 63640,
  "bookshelf": 63641,
  "border_block": 63642,
  "bordure_indented_banner_pattern": 63643,
  "bow": 63644,
  "bowl": 63645,
  "brain_coral": 63646,
  "brain_coral_block": 63647,
  "brain_coral_fan": 63648,
  "bread": 63649,
  "breeze_rod": 63650,
  "brewer_pottery_sherd": 63651,
  "brewing_stand": 63652,
  "brick": 63653,
  "brick_block": 63654,
  "brick_double_slab": 63655,
  "brick_slab": 63656,
  "brick_stairs": 63657,
  "brick_wall": 63658,
  "brown_banner": 63659,
  "brown_bundle": 63660,
  "brown_candle": 63661,
  "brown_candle_cake": 63662,
  "brown_carpet": 63663,
  "brown_concrete": 63664,
  "brown_concrete_powder": 63665,
  "brown_dye": 63666,
  "brown_egg": 63667,
  "brown_glazed_terracotta": 63668,
  "brown_harness": 63669,
  "brown_mushroom": 63670,
  "brown_mushroom_block": 63671,
  "brown_shulker_box": 63672,
  "brown_stained_glass": 63673,
  "brown_stained_glass_pane": 63674,
  "brown_terracotta": 63675,
  "brown_wool": 63676,
  "brush": 63677,
  "bubble_coral": 63678,
  "bubble_coral_block": 63679,
  "bubble_coral_fan": 63680,
  "bucket": 63681,
  "bucketAxolotl": 63682,
  "bucketCustomFish": 63683,
  "bucketFish": 63684,
  "bucketLava": 63685,
  "bucketPowderSnow": 63686,
  "bucketPuffer": 63687,
  "bucketSalmon": 63688,
  "bucketTadpole": 63689,
  "bucketTropical": 63690,
  "bucketWater": 63691,
  "budding_amethyst": 63692,
  "bundle": 63693,
  "burn_pottery_sherd": 63694,
  "bush": 63695,
  "cactus": 63696,
  "cactus_flower": 63697,
  "cake": 63698,
  "calcite": 63699,
  "calibrated_sculk_sensor": 63700,
  "camera": 63701,
  "campfire": 63702,
  "candle": 63703,
  "candle_cake": 63704,
  "carpet": 63705,
  "carrot": 63706,
  "carrotOnAStick": 63707,
  "carrot_on_a_stick": 63708,
  "carrots": 63709,
  "cartography_table": 63710,
  "carved_pumpkin": 63711,
  "cauldron": 63712,
  "cave_vines": 63713,
  "cave_vines_body_with_berries": 63714,
  "cave_vines_head_with_berries": 63715,
  "chain": 63716,
  "chain_command_block": 63717,
  "chainmail_boots": 63718,
  "chainmail_chestplate": 63719,
  "chainmail_helmet": 63720,
  "chainmail_leggings": 63721,
  "charcoal": 63722,
  "cherry_boat": 63723,
  "cherry_button": 63724,
  "cherry_chest_boat": 63725,
  "cherry_door": 63726,
  "cherry_double_slab": 63727,
  "cherry_fence": 63728,
  "cherry_fence_gate": 63729,
  "cherry_hanging_sign": 63730,
  "cherry_leaves": 63731,
  "cherry_log": 63732,
  "cherry_planks": 63733,
  "cherry_pressure_plate": 63734,
  "cherry_sapling": 63735,
  "cherry_shelf": 63736,
  "cherry_sign": 63737,
  "cherry_slab": 63738,
  "cherry_stairs": 63739,
  "cherry_trapdoor": 63740,
  "cherry_wood": 63741,
  "chest": 63742,
  "chest_boat": 63743,
  "chest_minecart": 63232,
  "chicken": 63233,
  "chipped_anvil": 63234,
  "chiseled_bookshelf": 63235,
  "chiseled_copper": 63236,
  "chiseled_deepslate": 63237,
  "chiseled_nether_bricks": 63238,
  "chiseled_polished_blackstone": 63239,
  "chiseled_quartz_block": 63240,
  "chiseled_red_sandstone": 63241,
  "chiseled_resin_bricks": 63242,
  "chiseled_sandstone": 63243,
  "chiseled_stone_bricks": 63244,
  "chiseled_tuff": 63245,
  "chiseled_tuff_bricks": 63246,
  "chorus_flower": 63247,
  "chorus_fruit": 63248,
  "chorus_fruit_popped": 63249,
  "chorus_plant": 63250,
  "clay": 63251,
  "clay_ball": 63252,
  "clock": 63253,
  "closed_eyeblossom": 63254,
  "clownfish": 63255,
  "coal": 63256,
  "coal_block": 63257,
  "coal_ore": 63258,
  "coarse_dirt": 63259,
  "coast_armor_trim_smithing_template": 63260,
  "cobbled_deepslate": 63261,
  "cobbled_deepslate_double_slab": 63262,
  "cobbled_deepslate_slab": 63263,
  "cobbled_deepslate_stairs": 63264,
  "cobbled_deepslate_wall": 63265,
  "cobblestone": 63266,
  "cobblestone_double_slab": 63267,
  "cobblestone_slab": 63268,
  "cobblestone_wall": 63269,
  "cobweb": 63270,
  "cocoa": 63271,
  "cocoa_beans": 63272,
  "cod": 63273,
  "cod_bucket": 63274,
  "command_block": 63275,
  "command_block_minecart": 63276,
  "comparator": 63277,
  "compass": 63278,
  "composter": 63279,
  "conduit": 63280,
  "cooked_beef": 63281,
  "cooked_chicken": 63282,
  "cooked_cod": 63283,
  "cooked_fish": 63284,
  "cooked_mutton": 63285,
  "cooked_porkchop": 63286,
  "cooked_rabbit": 63287,
  "cooked_salmon": 63288,
  "cookie": 63289,
  "copper_block": 63290,
  "copper_bulb": 63291,
  "copper_door": 63292,
  "copper_golem_statue": 63293,
  "copper_grate": 63294,
  "copper_horse_armor": 63295,
  "copper_ingot": 63296,
  "copper_nautilus_armor": 63297,
  "copper_ore": 63298,
  "copper_spear": 63299,
  "copper_trapdoor": 63300,
  "cornflower": 63301,
  "cracked_deepslate_bricks": 63302,
  "cracked_deepslate_tiles": 63303,
  "cracked_nether_bricks": 63304,
  "cracked_polished_blackstone_bricks": 63305,
  "cracked_stone_bricks": 63306,
  "crafter": 63307,
  "crafting_table": 63308,
  "creaking_heart": 63309,
  "creeper_banner_pattern": 63310,
  "creeper_head": 63311,
  "crimson_button": 63312,
  "crimson_door": 63313,
  "crimson_double_slab": 63314,
  "crimson_fence": 63315,
  "crimson_fence_gate": 63316,
  "crimson_fungus": 63317,
  "crimson_hanging_sign": 63318,
  "crimson_hyphae": 63319,
  "crimson_nylium": 63320,
  "crimson_planks": 63321,
  "crimson_pressure_plate": 63322,
  "crimson_roots": 63323,
  "crimson_shelf": 63324,
  "crimson_sign": 63325,
  "crimson_slab": 63326,
  "crimson_stairs": 63327,
  "crimson_standing_sign": 63328,
  "crimson_stem": 63329,
  "crimson_trapdoor": 63330,
  "crimson_wall_sign": 63331,
  "crossbow": 63332,
  "crying_obsidian": 63333,
  "cut_copper": 63334,
  "cut_copper_slab": 63335,
  "cut_copper_stairs": 63336,
  "cut_red_sandstone": 63337,
  "cut_red_sandstone_slab": 63338,
  "cut_sandstone": 63339,
  "cut_sandstone_slab": 63340,
  "cyan_banner": 63341,
  "cyan_bundle": 63342,
  "cyan_candle": 63343,
  "cyan_candle_cake": 63344,
  "cyan_carpet": 63345,
  "cyan_concrete": 63346,
  "cyan_concrete_powder": 63347,
  "cyan_dye": 63348,
  "cyan_glazed_terracotta": 63349,
  "cyan_harness": 63350,
  "cyan_shulker_box": 63351,
  "cyan_stained_glass": 63352,
  "cyan_stained_glass_pane": 63353,
  "cyan_terracotta": 63354,
  "cyan_wool": 63355,
  "damaged_anvil": 63356,
  "dandelion": 63357,
  "danger_pottery_sherd": 63358,
  "darkOakFence": 63359,
  "dark_oak_boat": 63360,
  "dark_oak_button": 63361,
  "dark_oak_chest_boat": 63362,
  "dark_oak_door": 63363,
  "dark_oak_double_slab": 63364,
  "dark_oak_fence": 63365,
  "dark_oak_fence_gate": 63366,
  "dark_oak_hanging_sign": 63367,
  "dark_oak_leaves": 63368,
  "dark_oak_log": 63369,
  "dark_oak_planks": 63370,
  "dark_oak_pressure_plate": 63371,
  "dark_oak_sapling": 63372,
  "dark_oak_shelf": 63373,
  "dark_oak_sign": 63374,
  "dark_oak_slab": 63375,
  "dark_oak_stairs": 63376,
  "dark_oak_trapdoor": 63377,
  "dark_oak_wood": 63378,
  "dark_prismarine": 63379,
  "dark_prismarine_double_slab": 63380,
  "dark_prismarine_slab": 63381,
  "dark_prismarine_stairs": 63382,
  "darkoak_sign": 63383,
  "darkoak_standing_sign": 63384,
  "daylight_detector": 63385,
  "dead_brain_coral": 63386,
  "dead_brain_coral_block": 63387,
  "dead_brain_coral_fan": 63388,
  "dead_brain_coral_wall_fan": 63389,
  "dead_bubble_coral": 63390,
  "dead_bubble_coral_block": 63391,
  "dead_bubble_coral_fan": 63392,
  "dead_bubble_coral_wall_fan": 63393,
  "dead_fire_coral": 63394,
  "dead_fire_coral_block": 63395,
  "dead_fire_coral_fan": 63396,
  "dead_fire_coral_wall_fan": 63397,
  "dead_horn_coral": 63398,
  "dead_horn_coral_block": 63399,
  "dead_horn_coral_fan": 63400,
  "dead_horn_coral_wall_fan": 63401,
  "dead_tube_coral": 63402,
  "dead_tube_coral_block": 63403,
  "dead_tube_coral_fan": 63404,
  "dead_tube_coral_wall_fan": 63405,
  "deadbush": 63406,
  "decorated_pot": 63407,
  "deepslate": 63408,
  "deepslate_brick_double_slab": 63409,
  "deepslate_brick_slab": 63410,
  "deepslate_brick_stairs": 63411,
  "deepslate_brick_wall": 63412,
  "deepslate_bricks": 63413,
  "deepslate_coal_ore": 63414,
  "deepslate_copper_ore": 63415,
  "deepslate_diamond_ore": 63416,
  "deepslate_emerald_ore": 63417,
  "deepslate_gold_ore": 63418,
  "deepslate_iron_ore": 63419,
  "deepslate_lapis_ore": 63420,
  "deepslate_redstone_ore": 63421,
  "deepslate_tile_double_slab": 63422,
  "deepslate_tile_slab": 63423,
  "deepslate_tile_stairs": 63424,
  "deepslate_tile_wall": 63425,
  "deepslate_tiles": 63426,
  "deny": 63427,
  "detector_rail": 63428,
  "diamond": 63429,
  "diamond_axe": 63430,
  "diamond_block": 63431,
  "diamond_boots": 63432,
  "diamond_chestplate": 63433,
  "diamond_helmet": 63434,
  "diamond_hoe": 63435,
  "diamond_horse_armor": 63436,
  "diamond_leggings": 63437,
  "diamond_nautilus_armor": 63438,
  "diamond_ore": 63439,
  "diamond_pickaxe": 63440,
  "diamond_shovel": 63441,
  "diamond_spear": 63442,
  "diamond_sword": 63443,
  "diorite": 63444,
  "diorite_double_slab": 63445,
  "diorite_slab": 63446,
  "diorite_stairs": 63447,
  "diorite_wall": 63448,
  "dirt": 63449,
  "dirt_with_roots": 63450,
  "disc_fragment": 63451,
  "disc_fragment_5": 63452,
  "dispenser": 63453,
  "doorWood": 63454,
  "double_cut_copper_slab": 63455,
  "double_plant": 63456,
  "double_stone_slab": 63457,
  "double_wooden_slab": 63458,
  "dragon_breath": 63459,
  "dragon_egg": 63460,
  "dragon_head": 63461,
  "dried_ghast": 63462,
  "dried_kelp": 63463,
  "dried_kelp_block": 63464,
  "dripstone_block": 63465,
  "dropper": 63466,
  "dune_armor_trim_smithing_template": 63467,
  "echo_shard": 63468,
  "egg": 63469,
  "elytra": 63470,
  "emerald": 63471,
  "emerald_block": 63472,
  "emerald_ore": 63473,
  "emptyLocatorMap": 63474,
  "emptyMap": 63475,
  "enchanted_book": 63476,
  "enchanted_golden_apple": 63477,
  "enchanting_table": 63478,
  "end_brick_stairs": 63479,
  "end_bricks": 63480,
  "end_crystal": 63481,
  "end_portal_frame": 63482,
  "end_rod": 63483,
  "end_stone": 63484,
  "end_stone_brick_double_slab": 63485,
  "end_stone_brick_slab": 63486,
  "end_stone_brick_wall": 63487,
  "enderChest": 62976,
  "ender_chest": 62977,
  "ender_chest_item": 62978,
  "ender_eye": 62979,
  "ender_pearl": 62980,
  "experience_bottle": 62981,
  "explorer_pottery_sherd": 62982,
  "exposed_chiseled_copper": 62983,
  "exposed_copper": 62984,
  "exposed_copper_bulb": 62985,
  "exposed_copper_door": 62986,
  "exposed_copper_golem_statue": 62987,
  "exposed_copper_grate": 62988,
  "exposed_copper_trapdoor": 62989,
  "exposed_cut_copper": 62990,
  "exposed_cut_copper_slab": 62991,
  "exposed_cut_copper_stairs": 62992,
  "exposed_double_cut_copper_slab": 62993,
  "eye_armor_trim_smithing_template": 62994,
  "farmland": 62995,
  "feather": 62996,
  "fence": 62997,
  "fence_gate": 62998,
  "fermented_spider_eye": 62999,
  "fern": 63000,
  "field_masoned_banner_pattern": 63001,
  "fire": 63002,
  "fire_coral": 63003,
  "fire_coral_block": 63004,
  "fire_coral_fan": 63005,
  "fireball": 63006,
  "firefly_bush": 63007,
  "firework_rocket": 63008,
  "firework_star": 63009,
  "fireworks": 63010,
  "fireworksCharge": 63011,
  "fireworks_charge": 63012,
  "fish": 63013,
  "fishing_rod": 63014,
  "fletching_table": 63015,
  "flint": 63016,
  "flint_and_steel": 63017,
  "flow_armor_trim_smithing_template": 63018,
  "flow_banner_pattern": 63019,
  "flow_pottery_sherd": 63020,
  "flower_banner_pattern": 63021,
  "flower_pot": 63022,
  "flowering_azalea": 63023,
  "flowing_lava": 63024,
  "flowing_water": 63025,
  "frame": 63026,
  "friend_pottery_sherd": 63027,
  "frog_spawn": 63028,
  "frosted_ice": 63029,
  "furnace": 63030,
  "furnace_block": 63031,
  "ghast_tear": 63032,
  "gilded_blackstone": 63033,
  "glass": 63034,
  "glass_bottle": 63035,
  "glass_pane": 63036,
  "glazedTerracottaBlack": 63037,
  "glazedTerracottaBlue": 63038,
  "glazedTerracottaBrown": 63039,
  "glazedTerracottaCyan": 63040,
  "glazedTerracottaGray": 63041,
  "glazedTerracottaGreen": 63042,
  "glazedTerracottaLightBlue": 63043,
  "glazedTerracottaLime": 63044,
  "glazedTerracottaMagenta": 63045,
  "glazedTerracottaOrange": 63046,
  "glazedTerracottaPink": 63047,
  "glazedTerracottaPurple": 63048,
  "glazedTerracottaRed": 63049,
  "glazedTerracottaSilver": 63050,
  "glazedTerracottaWhite": 63051,
  "glazedTerracottaYellow": 63052,
  "globe_banner_pattern": 63053,
  "glow_berries": 63054,
  "glow_frame": 63055,
  "glow_ink_sac": 63056,
  "glow_lichen": 63057,
  "glowstone": 63058,
  "glowstone_dust": 63059,
  "goat_horn": 63060,
  "gold_block": 63061,
  "gold_ingot": 63062,
  "gold_nugget": 63063,
  "gold_ore": 63064,
  "golden_apple": 63065,
  "golden_axe": 63066,
  "golden_boots": 63067,
  "golden_carrot": 63068,
  "golden_chestplate": 63069,
  "golden_helmet": 63070,
  "golden_hoe": 63071,
  "golden_horse_armor": 63072,
  "golden_leggings": 63073,
  "golden_nautilus_armor": 63074,
  "golden_pickaxe": 63075,
  "golden_rail": 63076,
  "golden_shovel": 63077,
  "golden_sword": 63078,
  "granite": 63079,
  "granite_double_slab": 63080,
  "granite_slab": 63081,
  "granite_stairs": 63082,
  "granite_wall": 63083,
  "grass": 63084,
  "grass_block": 63085,
  "grass_path": 63086,
  "gravel": 63087,
  "gray_banner": 63088,
  "gray_bundle": 63089,
  "gray_candle": 63090,
  "gray_candle_cake": 63091,
  "gray_carpet": 63092,
  "gray_concrete": 63093,
  "gray_concrete_powder": 63094,
  "gray_dye": 63095,
  "gray_glazed_terracotta": 63096,
  "gray_harness": 63097,
  "gray_shulker_box": 63098,
  "gray_stained_glass": 63099,
  "gray_stained_glass_pane": 63100,
  "gray_terracotta": 63101,
  "gray_wool": 63102,
  "green_banner": 63103,
  "green_bundle": 63104,
  "green_candle": 63105,
  "green_candle_cake": 63106,
  "green_carpet": 63107,
  "green_concrete": 63108,
  "green_concrete_powder": 63109,
  "green_dye": 63110,
  "green_glazed_terracotta": 63111,
  "green_harness": 63112,
  "green_shulker_box": 63113,
  "green_stained_glass": 63114,
  "green_stained_glass_pane": 63115,
  "green_terracotta": 63116,
  "green_wool": 63117,
  "grindstone": 63118,
  "gunpowder": 63119,
  "guster_banner_pattern": 63120,
  "guster_pottery_sherd": 63121,
  "hanging_roots": 63122,
  "hardened_clay": 63123,
  "hay_block": 63124,
  "heart_of_the_sea": 63125,
  "heart_pottery_sherd": 63126,
  "heartbreak_pottery_sherd": 63127,
  "heavy_core": 63128,
  "heavy_weighted_pressure_plate": 63129,
  "honey_block": 63130,
  "honey_bottle": 63131,
  "honeycomb": 63132,
  "honeycomb_block": 63133,
  "hopper": 63134,
  "hopper_minecart": 63135,
  "horn_coral": 63136,
  "horn_coral_block": 63137,
  "horn_coral_fan": 63138,
  "horse_armor_diamond": 63139,
  "horse_armor_gold": 63140,
  "horse_armor_iron": 63141,
  "horse_armor_leather": 63142,
  "horsearmordiamond": 63143,
  "horsearmorgold": 63144,
  "horsearmoriron": 63145,
  "horsearmorleather": 63146,
  "host_armor_trim_smithing_template": 63147,
  "howl_pottery_sherd": 63148,
  "ice": 63149,
  "infested_chiseled_stone_bricks": 63150,
  "infested_cobblestone": 63151,
  "infested_cracked_stone_bricks": 63152,
  "infested_deepslate": 63153,
  "infested_mossy_stone_bricks": 63154,
  "infested_stone": 63155,
  "infested_stone_bricks": 63156,
  "ink_sac": 63157,
  "invisibleBedrock": 63158,
  "iron_axe": 63159,
  "iron_bars": 63160,
  "iron_block": 63161,
  "iron_boots": 63162,
  "iron_chestplate": 63163,
  "iron_door": 63164,
  "iron_helmet": 63165,
  "iron_hoe": 63166,
  "iron_horse_armor": 63167,
  "iron_ingot": 63168,
  "iron_leggings": 63169,
  "iron_nautilus_armor": 63170,
  "iron_nugget": 63171,
  "iron_ore": 63172,
  "iron_pickaxe": 63173,
  "iron_shovel": 63174,
  "iron_spear": 63175,
  "iron_sword": 63176,
  "iron_trapdoor": 63177,
  "jack_o_lantern": 63178,
  "jigsaw": 63179,
  "jukebox": 63180,
  "jungleFence": 63181,
  "jungle_boat": 63182,
  "jungle_button": 63183,
  "jungle_chest_boat": 63184,
  "jungle_door": 63185,
  "jungle_double_slab": 63186,
  "jungle_fence": 63187,
  "jungle_fence_gate": 63188,
  "jungle_hanging_sign": 63189,
  "jungle_leaves": 63190,
  "jungle_log": 63191,
  "jungle_planks": 63192,
  "jungle_pressure_plate": 63193,
  "jungle_sapling": 63194,
  "jungle_shelf": 63195,
  "jungle_sign": 63196,
  "jungle_slab": 63197,
  "jungle_stairs": 63198,
  "jungle_standing_sign": 63199,
  "jungle_trapdoor": 63200,
  "jungle_wood": 63201,
  "kelp": 63202,
  "ladder": 63203,
  "lantern": 63204,
  "lapis_block": 63205,
  "lapis_lazuli": 63206,
  "lapis_ore": 63207,
  "large_amethyst_bud": 63208,
  "large_fern": 63209,
  "lava": 63210,
  "lava_bucket": 63211,
  "lead": 63212,
  "leaf_litter": 63213,
  "leather": 63214,
  "leather_boots": 63215,
  "leather_chestplate": 63216,
  "leather_helmet": 63217,
  "leather_horse_armor": 63218,
  "leather_leggings": 63219,
  "leaves": 63220,
  "lectern": 63221,
  "lever": 63222,
  "light_block": 63223,
  "light_blue_banner": 63224,
  "light_blue_bundle": 63225,
  "light_blue_candle": 63226,
  "light_blue_candle_cake": 63227,
  "light_blue_carpet": 63228,
  "light_blue_concrete": 63229,
  "light_blue_concrete_powder": 63230,
  "light_blue_dye": 63231,
  "light_blue_glazed_terracotta": 62720,
  "light_blue_harness": 62721,
  "light_blue_shulker_box": 62722,
  "light_blue_stained_glass": 62723,
  "light_blue_stained_glass_pane": 62724,
  "light_blue_terracotta": 62725,
  "light_blue_wool": 62726,
  "light_gray_banner": 62727,
  "light_gray_bundle": 62728,
  "light_gray_candle": 62729,
  "light_gray_candle_cake": 62730,
  "light_gray_carpet": 62731,
  "light_gray_concrete": 62732,
  "light_gray_concrete_powder": 62733,
  "light_gray_dye": 62734,
  "light_gray_harness": 62735,
  "light_gray_shulker_box": 62736,
  "light_gray_stained_glass": 62737,
  "light_gray_stained_glass_pane": 62738,
  "light_gray_terracotta": 62739,
  "light_gray_wool": 62740,
  "light_weighted_pressure_plate": 62741,
  "lightning_rod": 62742,
  "lilac": 62743,
  "lily_of_the_valley": 62744,
  "lime_banner": 62745,
  "lime_bundle": 62746,
  "lime_candle": 62747,
  "lime_candle_cake": 62748,
  "lime_carpet": 62749,
  "lime_concrete": 62750,
  "lime_concrete_powder": 62751,
  "lime_dye": 62752,
  "lime_glazed_terracotta": 62753,
  "lime_harness": 62754,
  "lime_shulker_box": 62755,
  "lime_stained_glass": 62756,
  "lime_stained_glass_pane": 62757,
  "lime_terracotta": 62758,
  "lime_wool": 62759,
  "lingering_potion": 62760,
  "lit_blast_furnace": 62761,
  "lit_furnace": 62762,
  "lit_pumpkin": 62763,
  "lit_smoker": 62764,
  "lodestone": 62765,
  "lodestonecompass": 62766,
  "log": 62767,
  "loom": 62768,
  "mace": 62769,
  "magenta_banner": 62770,
  "magenta_bundle": 62771,
  "magenta_candle": 62772,
  "magenta_candle_cake": 62773,
  "magenta_carpet": 62774,
  "magenta_concrete": 62775,
  "magenta_concrete_powder": 62776,
  "magenta_dye": 62777,
  "magenta_glazed_terracotta": 62778,
  "magenta_harness": 62779,
  "magenta_shulker_box": 62780,
  "magenta_stained_glass": 62781,
  "magenta_stained_glass_pane": 62782,
  "magenta_terracotta": 62783,
  "magenta_wool": 62784,
  "magma": 62785,
  "magma_cream": 62786,
  "mangrove_boat": 62787,
  "mangrove_button": 62788,
  "mangrove_chest_boat": 62789,
  "mangrove_door": 62790,
  "mangrove_double_slab": 62791,
  "mangrove_fence": 62792,
  "mangrove_fence_gate": 62793,
  "mangrove_hanging_sign": 62794,
  "mangrove_leaves": 62795,
  "mangrove_log": 62796,
  "mangrove_planks": 62797,
  "mangrove_pressure_plate": 62798,
  "mangrove_propagule": 62799,
  "mangrove_roots": 62800,
  "mangrove_shelf": 62801,
  "mangrove_sign": 62802,
  "mangrove_slab": 62803,
  "mangrove_stairs": 62804,
  "mangrove_trapdoor": 62805,
  "mangrove_wood": 62806,
  "map": 62807,
  "medium_amethyst_bud": 62808,
  "melon": 62809,
  "melon_block": 62810,
  "melon_seeds": 62811,
  "melon_slice": 62812,
  "milk": 62813,
  "milk_bucket": 62814,
  "minecart": 62815,
  "minecartFurnace": 62816,
  "minecart_furnace": 62817,
  "miner_pottery_sherd": 62818,
  "mob_spawner": 62819,
  "mojang_banner_pattern": 62820,
  "monster_egg": 62821,
  "moss_block": 62822,
  "moss_carpet": 62823,
  "mossy_cobblestone": 62824,
  "mossy_cobblestone_double_slab": 62825,
  "mossy_cobblestone_slab": 62826,
  "mossy_cobblestone_stairs": 62827,
  "mossy_cobblestone_wall": 62828,
  "mossy_stone_brick_slab": 62829,
  "mossy_stone_brick_stairs": 62830,
  "mossy_stone_brick_wall": 62831,
  "mossy_stone_bricks": 62832,
  "mourner_pottery_sherd": 62833,
  "mud": 62834,
  "mud_brick_double_slab": 62835,
  "mud_brick_slab": 62836,
  "mud_brick_stairs": 62837,
  "mud_brick_wall": 62838,
  "mud_bricks": 62839,
  "muddy_mangrove_roots": 62840,
  "mushroom": 62841,
  "mushroom_stem": 62842,
  "mushroom_stew": 62843,
  "music_disc_11": 62844,
  "music_disc_13": 62845,
  "music_disc_5": 62846,
  "music_disc_blocks": 62847,
  "music_disc_cat": 62848,
  "music_disc_chirp": 62849,
  "music_disc_creator": 62850,
  "music_disc_creator_music_box": 62851,
  "music_disc_far": 62852,
  "music_disc_mall": 62853,
  "music_disc_mellohi": 62854,
  "music_disc_otherside": 62855,
  "music_disc_pigstep": 62856,
  "music_disc_precipice": 62857,
  "music_disc_relic": 62858,
  "music_disc_stal": 62859,
  "music_disc_strad": 62860,
  "music_disc_tears": 62861,
  "music_disc_wait": 62862,
  "music_disc_ward": 62863,
  "mutton": 62864,
  "muttonCooked": 62865,
  "muttonRaw": 62866,
  "mutton_cooked": 62867,
  "mutton_raw": 62868,
  "mycelium": 62869,
  "name_tag": 62870,
  "nautilus_shell": 62871,
  "netherStar": 62872,
  "nether_brick": 62873,
  "nether_brick_double_slab": 62874,
  "nether_brick_fence": 62875,
  "nether_brick_slab": 62876,
  "nether_brick_stairs": 62877,
  "nether_brick_wall": 62878,
  "nether_gold_ore": 62879,
  "nether_sprouts": 62880,
  "nether_star": 62881,
  "nether_wart": 62882,
  "nether_wart_block": 62883,
  "netherbrick": 62884,
  "netherite_axe": 62885,
  "netherite_block": 62886,
  "netherite_boots": 62887,
  "netherite_chestplate": 62888,
  "netherite_helmet": 62889,
  "netherite_hoe": 62890,
  "netherite_horse_armor": 62891,
  "netherite_ingot": 62892,
  "netherite_leggings": 62893,
  "netherite_nautilus_armor": 62894,
  "netherite_pickaxe": 62895,
  "netherite_scrap": 62896,
  "netherite_shovel": 62897,
  "netherite_spear": 62898,
  "netherite_sword": 62899,
  "netherite_upgrade_smithing_template": 62900,
  "netherrack": 62901,
  "netherreactor": 62902,
  "normal_stone_slab": 62903,
  "normal_stone_stairs": 62904,
  "noteblock": 62905,
  "oak_boat": 62906,
  "oak_button": 62907,
  "oak_chest_boat": 62908,
  "oak_door": 62909,
  "oak_double_slab": 62910,
  "oak_fence": 62911,
  "oak_fence_gate": 62912,
  "oak_hanging_sign": 62913,
  "oak_leaves": 62914,
  "oak_log": 62915,
  "oak_planks": 62916,
  "oak_pressure_plate": 62917,
  "oak_sapling": 62918,
  "oak_shelf": 62919,
  "oak_sign": 62920,
  "oak_slab": 62921,
  "oak_stairs": 62922,
  "oak_trapdoor": 62923,
  "oak_wood": 62924,
  "observer": 62925,
  "obsidian": 62926,
  "ochre_froglight": 62927,
  "ominous_bottle": 62928,
  "ominous_trial_key": 62929,
  "open_eyeblossom": 62930,
  "orange_banner": 62931,
  "orange_bundle": 62932,
  "orange_candle": 62933,
  "orange_candle_cake": 62934,
  "orange_carpet": 62935,
  "orange_concrete": 62936,
  "orange_concrete_powder": 62937,
  "orange_dye": 62938,
  "orange_glazed_terracotta": 62939,
  "orange_harness": 62940,
  "orange_shulker_box": 62941,
  "orange_stained_glass": 62942,
  "orange_stained_glass_pane": 62943,
  "orange_terracotta": 62944,
  "orange_tulip": 62945,
  "orange_wool": 62946,
  "oxeye_daisy": 62947,
  "oxidized_chiseled_copper": 62948,
  "oxidized_copper": 62949,
  "oxidized_copper_bulb": 62950,
  "oxidized_copper_door": 62951,
  "oxidized_copper_golem_statue": 62952,
  "oxidized_copper_grate": 62953,
  "oxidized_copper_trapdoor": 62954,
  "oxidized_cut_copper": 62955,
  "oxidized_cut_copper_slab": 62956,
  "oxidized_cut_copper_stairs": 62957,
  "oxidized_double_cut_copper_slab": 62958,
  "packed_ice": 62959,
  "packed_mud": 62960,
  "painting": 62961,
  "pale_hanging_moss": 62962,
  "pale_moss_block": 62963,
  "pale_moss_carpet": 62964,
  "pale_oak_boat": 62965,
  "pale_oak_button": 62966,
  "pale_oak_chest_boat": 62967,
  "pale_oak_door": 62968,
  "pale_oak_double_slab": 62969,
  "pale_oak_fence": 62970,
  "pale_oak_fence_gate": 62971,
  "pale_oak_hanging_sign": 62972,
  "pale_oak_leaves": 62973,
  "pale_oak_log": 62974,
  "pale_oak_planks": 62975,
  "pale_oak_pressure_plate": 62464,
  "pale_oak_sapling": 62465,
  "pale_oak_shelf": 62466,
  "pale_oak_sign": 62467,
  "pale_oak_slab": 62468,
  "pale_oak_stairs": 62469,
  "pale_oak_trapdoor": 62470,
  "pale_oak_wood": 62471,
  "paper": 62472,
  "pearlescent_froglight": 62473,
  "peony": 62474,
  "petrified_oak_double_slab": 62475,
  "petrified_oak_slab": 62476,
  "phantom_membrane": 62477,
  "piglin_banner_pattern": 62478,
  "piglin_head": 62479,
  "pink_banner": 62480,
  "pink_bundle": 62481,
  "pink_candle": 62482,
  "pink_candle_cake": 62483,
  "pink_carpet": 62484,
  "pink_concrete": 62485,
  "pink_concrete_powder": 62486,
  "pink_dye": 62487,
  "pink_glazed_terracotta": 62488,
  "pink_harness": 62489,
  "pink_petals": 62490,
  "pink_shulker_box": 62491,
  "pink_stained_glass": 62492,
  "pink_stained_glass_pane": 62493,
  "pink_terracotta": 62494,
  "pink_tulip": 62495,
  "pink_wool": 62496,
  "piston": 62497,
  "pitcher_plant": 62498,
  "pitcher_pod": 62499,
  "planks": 62500,
  "player_head": 62501,
  "plenty_pottery_sherd": 62502,
  "podzol": 62503,
  "pointed_dripstone": 62504,
  "poisonous_potato": 62505,
  "polished_andesite": 62506,
  "polished_andesite_double_slab": 62507,
  "polished_andesite_slab": 62508,
  "polished_andesite_stairs": 62509,
  "polished_basalt": 62510,
  "polished_blackstone": 62511,
  "polished_blackstone_brick_double_slab": 62512,
  "polished_blackstone_brick_slab": 62513,
  "polished_blackstone_brick_stairs": 62514,
  "polished_blackstone_brick_wall": 62515,
  "polished_blackstone_bricks": 62516,
  "polished_blackstone_button": 62517,
  "polished_blackstone_double_slab": 62518,
  "polished_blackstone_pressure_plate": 62519,
  "polished_blackstone_slab": 62520,
  "polished_blackstone_stairs": 62521,
  "polished_blackstone_wall": 62522,
  "polished_deepslate": 62523,
  "polished_deepslate_double_slab": 62524,
  "polished_deepslate_slab": 62525,
  "polished_deepslate_stairs": 62526,
  "polished_deepslate_wall": 62527,
  "polished_diorite": 62528,
  "polished_diorite_double_slab": 62529,
  "polished_diorite_slab": 62530,
  "polished_diorite_stairs": 62531,
  "polished_granite": 62532,
  "polished_granite_double_slab": 62533,
  "polished_granite_slab": 62534,
  "polished_granite_stairs": 62535,
  "polished_tuff": 62536,
  "polished_tuff_double_slab": 62537,
  "polished_tuff_slab": 62538,
  "polished_tuff_stairs": 62539,
  "polished_tuff_wall": 62540,
  "poplar_shelf": 62541,
  "popped_chorus_fruit": 62542,
  "poppy": 62543,
  "porkchop": 62544,
  "porkchop_cooked": 62545,
  "portal": 62546,
  "potato": 62547,
  "potatoes": 62548,
  "potion": 62549,
  "powder_snow": 62550,
  "powder_snow_bucket": 62551,
  "powered_rail": 62552,
  "prismarine": 62553,
  "prismarine_brick_double_slab": 62554,
  "prismarine_brick_slab": 62555,
  "prismarine_bricks": 62556,
  "prismarine_bricks_stairs": 62557,
  "prismarine_crystals": 62558,
  "prismarine_double_slab": 62559,
  "prismarine_shard": 62560,
  "prismarine_slab": 62561,
  "prismarine_stairs": 62562,
  "prismarine_wall": 62563,
  "prize_pottery_sherd": 62564,
  "pufferfish": 62565,
  "pufferfish_bucket": 62566,
  "pumpkin": 62567,
  "pumpkin_pie": 62568,
  "pumpkin_seeds": 62569,
  "pumpkin_stem": 62570,
  "purple_banner": 62571,
  "purple_bundle": 62572,
  "purple_candle": 62573,
  "purple_candle_cake": 62574,
  "purple_carpet": 62575,
  "purple_concrete": 62576,
  "purple_concrete_powder": 62577,
  "purple_dye": 62578,
  "purple_glazed_terracotta": 62579,
  "purple_harness": 62580,
  "purple_shulker_box": 62581,
  "purple_stained_glass": 62582,
  "purple_stained_glass_pane": 62583,
  "purple_terracotta": 62584,
  "purple_wool": 62585,
  "purpur_block": 62586,
  "purpur_double_slab": 62587,
  "purpur_pillar": 62588,
  "purpur_slab": 62589,
  "purpur_stairs": 62590,
  "quartz": 62591,
  "quartz_block": 62592,
  "quartz_bricks": 62593,
  "quartz_double_slab": 62594,
  "quartz_ore": 62595,
  "quartz_pillar": 62596,
  "quartz_slab": 62597,
  "quartz_stairs": 62598,
  "rabbit": 62599,
  "rabbit_foot": 62600,
  "rabbit_hide": 62601,
  "rabbit_stew": 62602,
  "rail": 62603,
  "raiser_armor_trim_smithing_template": 62604,
  "raw_copper": 62605,
  "raw_copper_block": 62606,
  "raw_gold": 62607,
  "raw_gold_block": 62608,
  "raw_iron": 62609,
  "raw_iron_block": 62610,
  "record_11": 62611,
  "record_13": 62612,
  "record_5": 62613,
  "record_blocks": 62614,
  "record_cat": 62615,
  "record_chirp": 62616,
  "record_creator": 62617,
  "record_creator_music_box": 62618,
  "record_far": 62619,
  "record_mall": 62620,
  "record_mellohi": 62621,
  "record_otherside": 62622,
  "record_pigstep": 62623,
  "record_precipice": 62624,
  "record_relic": 62625,
  "record_stal": 62626,
  "record_strad": 62627,
  "record_tears": 62628,
  "record_wait": 62629,
  "record_ward": 62630,
  "recovery_compass": 62631,
  "red_banner": 62632,
  "red_bundle": 62633,
  "red_candle": 62634,
  "red_candle_cake": 62635,
  "red_carpet": 62636,
  "red_concrete": 62637,
  "red_concrete_powder": 62638,
  "red_dye": 62639,
  "red_flower": 62640,
  "red_glazed_terracotta": 62641,
  "red_harness": 62642,
  "red_mushroom": 62643,
  "red_mushroom_block": 62644,
  "red_nether_brick": 62645,
  "red_nether_brick_double_slab": 62646,
  "red_nether_brick_slab": 62647,
  "red_nether_brick_stairs": 62648,
  "red_nether_brick_wall": 62649,
  "red_sand": 62650,
  "red_sandstone": 62651,
  "red_sandstone_double_slab": 62652,
  "red_sandstone_slab": 62653,
  "red_sandstone_stairs": 62654,
  "red_sandstone_wall": 62655,
  "red_shulker_box": 62656,
  "red_stained_glass": 62657,
  "red_stained_glass_pane": 62658,
  "red_terracotta": 62659,
  "red_tulip": 62660,
  "red_wool": 62661,
  "redsandstone": 62662,
  "redstone": 62663,
  "redstone_block": 62664,
  "redstone_lamp": 62665,
  "redstone_ore": 62666,
  "redstone_torch": 62667,
  "redstone_wire": 62668,
  "reeds": 62669,
  "reinforced_deepslate": 62670,
  "repeater": 62671,
  "repeating_command_block": 62672,
  "resin_block": 62673,
  "resin_brick": 62674,
  "resin_brick_double_slab": 62675,
  "resin_brick_slab": 62676,
  "resin_brick_stairs": 62677,
  "resin_brick_wall": 62678,
  "resin_bricks": 62679,
  "resin_clump": 62680,
  "respawn_anchor": 62681,
  "rib_armor_trim_smithing_template": 62682,
  "rooted_dirt": 62683,
  "rose_bush": 62684,
  "rotten_flesh": 62685,
  "ruby": 62686,
  "saddle": 62687,
  "salmon": 62688,
  "salmon_bucket": 62689,
  "sand": 62690,
  "sandstone": 62691,
  "sandstone_double_slab": 62692,
  "sandstone_slab": 62693,
  "sandstone_stairs": 62694,
  "sandstone_wall": 62695,
  "scaffolding": 62696,
  "scrape_pottery_sherd": 62697,
  "sculk": 62698,
  "sculk_catalyst": 62699,
  "sculk_sensor": 62700,
  "sculk_shrieker": 62701,
  "sculk_vein": 62702,
  "seaLantern": 62703,
  "sea_lantern": 62704,
  "sea_pickle": 62705,
  "seagrass": 62706,
  "sentry_armor_trim_smithing_template": 62707,
  "shaper_armor_trim_smithing_template": 62708,
  "sheaf_pottery_sherd": 62709,
  "shears": 62710,
  "shelter_pottery_sherd": 62711,
  "shield": 62712,
  "short_dry_grass": 62713,
  "short_grass": 62714,
  "shroomlight": 62715,
  "shulkerBox": 62716,
  "shulkerBoxBlack": 62717,
  "shulkerBoxBlue": 62718,
  "shulkerBoxBrown": 62719,
  "shulkerBoxCyan": 62208,
  "shulkerBoxGray": 62209,
  "shulkerBoxGreen": 62210,
  "shulkerBoxLightBlue": 62211,
  "shulkerBoxLime": 62212,
  "shulkerBoxMagenta": 62213,
  "shulkerBoxOrange": 62214,
  "shulkerBoxPink": 62215,
  "shulkerBoxPurple": 62216,
  "shulkerBoxRed": 62217,
  "shulkerBoxSilver": 62218,
  "shulkerBoxWhite": 62219,
  "shulkerBoxYellow": 62220,
  "shulker_box": 62221,
  "shulker_shell": 62222,
  "sign": 62223,
  "silence_armor_trim_smithing_template": 62224,
  "silver_glazed_terracotta": 62225,
  "skeleton_skull": 62226,
  "skull_banner_pattern": 62227,
  "skull_pottery_sherd": 62228,
  "slime": 62229,
  "slime_ball": 62230,
  "slimeball": 62231,
  "small_amethyst_bud": 62232,
  "small_dripleaf_block": 62233,
  "smithing_table": 62234,
  "smithing_template": 62235,
  "smoker": 62236,
  "smooth_basalt": 62237,
  "smooth_quartz": 62238,
  "smooth_quartz_slab": 62239,
  "smooth_quartz_stairs": 62240,
  "smooth_red_sandstone": 62241,
  "smooth_red_sandstone_double_slab": 62242,
  "smooth_red_sandstone_slab": 62243,
  "smooth_red_sandstone_stairs": 62244,
  "smooth_sandstone": 62245,
  "smooth_sandstone_double_slab": 62246,
  "smooth_sandstone_slab": 62247,
  "smooth_sandstone_stairs": 62248,
  "smooth_stone": 62249,
  "smooth_stone_double_slab": 62250,
  "smooth_stone_slab": 62251,
  "sniffer_egg": 62252,
  "snort_pottery_sherd": 62253,
  "snout_armor_trim_smithing_template": 62254,
  "snow": 62255,
  "snow_layer": 62256,
  "snowball": 62257,
  "soul_campfire": 62258,
  "soul_fire": 62259,
  "soul_lantern": 62260,
  "soul_sand": 62261,
  "soul_soil": 62262,
  "soul_torch": 62263,
  "speckled_melon": 62264,
  "spectral_arrow": 62265,
  "spider_eye": 62266,
  "spire_armor_trim_smithing_template": 62267,
  "splash_potion": 62268,
  "sponge": 62269,
  "spore_blossom": 62270,
  "spruceFence": 62271,
  "spruce_boat": 62272,
  "spruce_button": 62273,
  "spruce_chest_boat": 62274,
  "spruce_door": 62275,
  "spruce_double_slab": 62276,
  "spruce_fence": 62277,
  "spruce_fence_gate": 62278,
  "spruce_hanging_sign": 62279,
  "spruce_leaves": 62280,
  "spruce_log": 62281,
  "spruce_planks": 62282,
  "spruce_pressure_plate": 62283,
  "spruce_sapling": 62284,
  "spruce_shelf": 62285,
  "spruce_sign": 62286,
  "spruce_slab": 62287,
  "spruce_stairs": 62288,
  "spruce_standing_sign": 62289,
  "spruce_trapdoor": 62290,
  "spruce_wood": 62291,
  "spyglass": 62292,
  "stained_hardened_clay": 62293,
  "standing_banner": 62294,
  "standing_sign": 62295,
  "steak": 62296,
  "stick": 62297,
  "stick_pile": 62298,
  "sticky_piston": 62299,
  "stone": 62300,
  "stone_axe": 62301,
  "stone_brick_double_slab": 62302,
  "stone_brick_slab": 62303,
  "stone_brick_stairs": 62304,
  "stone_brick_wall": 62305,
  "stone_bricks": 62306,
  "stone_button": 62307,
  "stone_hoe": 62308,
  "stone_pickaxe": 62309,
  "stone_pressure_plate": 62310,
  "stone_shovel": 62311,
  "stone_slab": 62312,
  "stone_spear": 62313,
  "stone_stairs": 62314,
  "stone_sword": 62315,
  "stonebrick": 62316,
  "stonecutter": 62317,
  "stonecutter_block": 62318,
  "string": 62319,
  "stripped_acacia_log": 62320,
  "stripped_acacia_wood": 62321,
  "stripped_bamboo_block": 62322,
  "stripped_birch_log": 62323,
  "stripped_birch_wood": 62324,
  "stripped_cherry_log": 62325,
  "stripped_cherry_wood": 62326,
  "stripped_crimson_hyphae": 62327,
  "stripped_crimson_stem": 62328,
  "stripped_dark_oak_log": 62329,
  "stripped_dark_oak_wood": 62330,
  "stripped_jungle_log": 62331,
  "stripped_jungle_wood": 62332,
  "stripped_mangrove_log": 62333,
  "stripped_mangrove_wood": 62334,
  "stripped_oak_log": 62335,
  "stripped_oak_wood": 62336,
  "stripped_pale_oak_log": 62337,
  "stripped_pale_oak_wood": 62338,
  "stripped_spruce_log": 62339,
  "stripped_spruce_wood": 62340,
  "stripped_warped_hyphae": 62341,
  "stripped_warped_stem": 62342,
  "structure_block": 62343,
  "structure_void": 62344,
  "sugar": 62345,
  "sugar_cane": 62346,
  "sunflower": 62347,
  "suspicious_gravel": 62348,
  "suspicious_sand": 62349,
  "suspicious_stew": 62350,
  "sweet_berries": 62351,
  "sweet_berry_bush": 62352,
  "tadpole_bucket": 62353,
  "tall_dry_grass": 62354,
  "tall_grass": 62355,
  "tallgrass": 62356,
  "target": 62357,
  "tide_armor_trim_smithing_template": 62358,
  "tinted_glass": 62359,
  "tipped_arrow": 62360,
  "tnt": 62361,
  "tnt_minecart": 62362,
  "torch": 62363,
  "torchflower": 62364,
  "torchflower_seeds": 62365,
  "totem": 62366,
  "totem_of_undying": 62367,
  "trapdoor": 62368,
  "trapped_chest": 62369,
  "trial_key": 62370,
  "trial_spawner": 62371,
  "trident": 62372,
  "tripWire": 62373,
  "trip_wire": 62374,
  "tripwire_hook": 62375,
  "tropical_fish": 62376,
  "tropical_fish_bucket": 62377,
  "tube_coral": 62378,
  "tube_coral_block": 62379,
  "tube_coral_fan": 62380,
  "tuff": 62381,
  "tuff_brick_double_slab": 62382,
  "tuff_brick_slab": 62383,
  "tuff_brick_stairs": 62384,
  "tuff_brick_wall": 62385,
  "tuff_bricks": 62386,
  "tuff_double_slab": 62387,
  "tuff_slab": 62388,
  "tuff_stairs": 62389,
  "tuff_wall": 62390,
  "turtle_egg": 62391,
  "turtle_helmet": 62392,
  "turtle_shell_piece": 62393,
  "twisting_vines": 62394,
  "undyed_shulker_box": 62395,
  "unlit_redstone_torch": 62396,
  "vault": 62397,
  "verdant_froglight": 62398,
  "vex_armor_trim_smithing_template": 62399,
  "vine": 62400,
  "wall_banner": 62401,
  "ward_armor_trim_smithing_template": 62402,
  "warped_button": 62403,
  "warped_door": 62404,
  "warped_double_slab": 62405,
  "warped_fence": 62406,
  "warped_fence_gate": 62407,
  "warped_fungus": 62408,
  "warped_fungus_on_a_stick": 62409,
  "warped_hanging_sign": 62410,
  "warped_hyphae": 62411,
  "warped_nylium": 62412,
  "warped_planks": 62413,
  "warped_pressure_plate": 62414,
  "warped_roots": 62415,
  "warped_shelf": 62416,
  "warped_sign": 62417,
  "warped_slab": 62418,
  "warped_stairs": 62419,
  "warped_standing_sign": 62420,
  "warped_stem": 62421,
  "warped_trapdoor": 62422,
  "warped_wall_sign": 62423,
  "warped_wart_block": 62424,
  "water": 62425,
  "water_bucket": 62426,
  "waterlily": 62427,
  "waxed_chiseled_copper": 62428,
  "waxed_copper": 62429,
  "waxed_copper_bulb": 62430,
  "waxed_copper_door": 62431,
  "waxed_copper_golem_statue": 62432,
  "waxed_copper_grate": 62433,
  "waxed_copper_trapdoor": 62434,
  "waxed_cut_copper": 62435,
  "waxed_cut_copper_slab": 62436,
  "waxed_cut_copper_stairs": 62437,
  "waxed_double_cut_copper_slab": 62438,
  "waxed_exposed_chiseled_copper": 62439,
  "waxed_exposed_copper": 62440,
  "waxed_exposed_copper_bulb": 62441,
  "waxed_exposed_copper_door": 62442,
  "waxed_exposed_copper_golem_statue": 62443,
  "waxed_exposed_copper_grate": 62444,
  "waxed_exposed_copper_trapdoor": 62445,
  "waxed_exposed_cut_copper": 62446,
  "waxed_exposed_cut_copper_slab": 62447,
  "waxed_exposed_cut_copper_stairs": 62448,
  "waxed_exposed_double_cut_copper_slab": 62449,
  "waxed_oxidized_chiseled_copper": 62450,
  "waxed_oxidized_copper": 62451,
  "waxed_oxidized_copper_bulb": 62452,
  "waxed_oxidized_copper_door": 62453,
  "waxed_oxidized_copper_golem_statue": 62454,
  "waxed_oxidized_copper_grate": 62455,
  "waxed_oxidized_copper_trapdoor": 62456,
  "waxed_oxidized_cut_copper": 62457,
  "waxed_oxidized_cut_copper_slab": 62458,
  "waxed_oxidized_cut_copper_stairs": 62459,
  "waxed_oxidized_double_cut_copper_slab": 62460,
  "waxed_weathered_chiseled_copper": 62461,
  "waxed_weathered_copper": 62462,
  "waxed_weathered_copper_bulb": 62463,
  "waxed_weathered_copper_door": 61952,
  "waxed_weathered_copper_golem_statue": 61953,
  "waxed_weathered_copper_grate": 61954,
  "waxed_weathered_copper_trapdoor": 61955,
  "waxed_weathered_cut_copper": 61956,
  "waxed_weathered_cut_copper_slab": 61957,
  "waxed_weathered_cut_copper_stairs": 61958,
  "waxed_weathered_double_cut_copper_slab": 61959,
  "wayfinder_armor_trim_smithing_template": 61960,
  "weathered_chiseled_copper": 61961,
  "weathered_copper": 61962,
  "weathered_copper_bulb": 61963,
  "weathered_copper_door": 61964,
  "weathered_copper_golem_statue": 61965,
  "weathered_copper_grate": 61966,
  "weathered_copper_trapdoor": 61967,
  "weathered_cut_copper": 61968,
  "weathered_cut_copper_slab": 61969,
  "weathered_cut_copper_stairs": 61970,
  "weathered_double_cut_copper_slab": 61971,
  "web": 61972,
  "weeping_vines": 61973,
  "wet_sponge": 61974,
  "wheat": 61975,
  "wheat_seeds": 61976,
  "white_banner": 61977,
  "white_bundle": 61978,
  "white_candle": 61979,
  "white_candle_cake": 61980,
  "white_carpet": 61981,
  "white_concrete": 61982,
  "white_concrete_powder": 61983,
  "white_dye": 61984,
  "white_glazed_terracotta": 61985,
  "white_harness": 61986,
  "white_shulker_box": 61987,
  "white_stained_glass": 61988,
  "white_stained_glass_pane": 61989,
  "white_terracotta": 61990,
  "white_tulip": 61991,
  "white_wool": 61992,
  "wild_armor_trim_smithing_template": 61993,
  "wildflowers": 61994,
  "wind_charge": 61995,
  "wither_rose": 61996,
  "wither_skeleton_skull": 61997,
  "wolf_armor": 61998,
  "wooden_axe": 61999,
  "wooden_button": 62000,
  "wooden_door": 62001,
  "wooden_hoe": 62002,
  "wooden_pickaxe": 62003,
  "wooden_pressure_plate": 62004,
  "wooden_shovel": 62005,
  "wooden_slab": 62006,
  "wooden_sword": 62007,
  "wool": 62008,
  "writable_book": 62009,
  "written_book": 62010,
  "yellow_banner": 62011,
  "yellow_bundle": 62012,
  "yellow_candle": 62013,
  "yellow_candle_cake": 62014,
  "yellow_carpet": 62015,
  "yellow_concrete": 62016,
  "yellow_concrete_powder": 62017,
  "yellow_dye": 62018,
  "yellow_flower": 62019,
  "yellow_glazed_terracotta": 62020,
  "yellow_harness": 62021,
  "yellow_shulker_box": 62022,
  "yellow_stained_glass": 62023,
  "yellow_stained_glass_pane": 62024,
  "yellow_terracotta": 62025,
  "yellow_wool": 62026,
  "zombie_head": 62027
};

const PREVIEW_MARKER_GLYPH_CODE = 59858;

/**
 * **预览标记字形**：肉眼不可见、几乎不占宽度（墨迹只有 1 像素宽 = 1/64 格）。
 *
 * 预览正文以它开头，作为"这段文本是我们自己的预览"的**文本内**证据。
 *
 * ⚠️ 资源包**当前不用它**做字号判据（用的是 title 通道的 `peek::r…`）：
 * 文本判据要写 `'%.1s' * $actionbar_text = '<本字符>'`，而 `$` 工厂变量在绑定
 * 表达式里取不到值、绑定会被静默忽略 —— 那正是"屏幕上多出一个 4 倍大的预览
 * 副本"那个 bug 的成因。它是**备用信号**，协议两半都带着。
 *
 * ⚠️ 它必须保持"**不可见 + 墨迹极窄**"：出现在预览最前面，可见墨迹会被直接
 * 看见；而墨迹一旦变宽，按不变量 I2 就会把居中的预览整块推走
 *（构建期有断言盯着这一格的可见墨迹与墨迹宽度）。
 */
function previewMarkerGlyph() {
  return String.fromCharCode(PREVIEW_MARKER_GLYPH_CODE);
}

const BLANK_GLYPH_CODE = 59903;

const BOX_BADGE_GLYPH_BASE = 60160;

/**
 * 物品 -> **潜影盒角标字形**（右下角半格那张小图）。
 *
 * 用途：箱子里的潜影盒满足"27 格全满 + 全是同一种物品"时，在盒子图标右下角画出
 * 该物品的小图（屏幕上 8×8 像素）。判据在脚本侧，资源包只按码点画。
 *
 * ## 下标与主页一一对应
 *
 * 角标页是按**与主页完全相同的物品顺序**烤的，所以这里不需要再存一张 1600 多行的表：
 * 从 ITEM_GLYPHS 的码点反推出全局下标（页序 × 256 + 页内序），加上角标基址即可。
 * 用公式而不是查表，还有一个好处：物品表变长时这里**不可能漂**。
 *
 * @param {string} itemId 物品 id（可带/不带 minecraft: 前缀）
 * @returns {string} 角标字形；该物品没有主页图标时返回空串（不画角标）
 */
function boxBadgeGlyph(itemId) {
  if (!itemId) return "";
  const raw = String(itemId);
  const bare = raw.replace(/^[a-z_]+:/, "");
  const code = Object.prototype.hasOwnProperty.call(ITEM_GLYPHS, bare)
    ? ITEM_GLYPHS[bare]
    : (Object.prototype.hasOwnProperty.call(ITEM_GLYPHS, raw) ? ITEM_GLYPHS[raw] : undefined);
  if (code === undefined) return "";
  const page = GLYPH_PAGES.indexOf(code >> 8);
  if (page < 0) return "";
  return String.fromCharCode(BOX_BADGE_GLYPH_BASE + page * 256 + (code & 0xff));
}

/**
 * 空格位占位用的空白字形：**宽度和物品图标一样**，肉眼不可见。
 *
 * 按箱子真实格位排版时必须用它占位 —— 普通空格只有几像素宽，
 * 而一格图标有十几像素，用空格占位整张表会错列。
 */
function blankGlyph() {
  return String.fromCharCode(BLANK_GLYPH_CODE);
}

const BLANK_NARROW_GLYPH_CODE = 59902;

/**
 * 空格位里"数目那一格"用的**窄**空白字形。
 *
 * 宽度必须和数目字形一致，否则"有物品的行"会比"空行"宽，列照样错位。
 */
function blankNarrowGlyph() {
  return String.fromCharCode(BLANK_NARROW_GLYPH_CODE);
}

const PLACEHOLDER_GLYPH_CODE = 59901;

/**
 * 没有图标的物品用的**占位图**（一个问号）。
 *
 * 用占位图而不是中文名，除了好看，还有一个硬理由：中文名的宽度和图标
 * 完全不同，会让那一行整列错位；而 4 成以上的物品没有图标，撞上的概率很高。
 * 换成等比占位图之后每格宽度重新一致，对齐问题一并消失。
 */
function placeholderGlyph() {
  return String.fromCharCode(PLACEHOLDER_GLYPH_CODE);
}

const DARK_BLANK_GLYPH_CODE = 59856;

/**
 * 深色空白字形：格位排版里**空槽位**用它。
 *
 * 每格自带深色底（黑框 = 网格格子本身），所以空槽位显示成深色空格子，
 * 整张表的框才完整。宽度与图标一格相同，列不会错位。
 */
function darkBlankGlyph() {
  return String.fromCharCode(DARK_BLANK_GLYPH_CODE);
}

const DISABLED_SLOT_GLYPH_CODE = 59857;

/**
 * "该槽位被机器禁用"的字形：深色底 + 一个叉。
 *
 * 用在合成器上 —— 被玩家禁用掉的格子放不进东西，但在容器里仍然是个格子。
 * 空槽位在图标层是**透明空白**，所以不加这个记号就完全看不出"这格被锁了"。
 * 宽度与图标一格相同，列不会错位。
 */
function disabledSlotGlyph() {
  return String.fromCharCode(DISABLED_SLOT_GLYPH_CODE);
}

const COUNT_GLYPH_BASE = 59792;
const COUNT_GLYPH_MAX = 64;

/**
 * 取数目的字形（1..64 每个数目各有一个字形）。超范围夹到 1..64。
 *
 * 为什么给每个数目单独做字形、而不是用数字字符拼：
 * 数目要显示在图标旁边，而格位排版靠"每格等宽"对齐 ——
 * 拼 "x64" 会占掉好几个字形的宽度，整列立刻错位。
 * 做成整形字形后，每个物品固定占两格（图标 + 数目），宽度恒定。
 */
function countGlyph(amount) {
  let n = Math.round(Number(amount));
  if (!isFinite(n) || n < 1) n = 1;
  if (n > COUNT_GLYPH_MAX) n = COUNT_GLYPH_MAX;
  return String.fromCharCode(COUNT_GLYPH_BASE + (n - 1));
}

const CENTER_DIGIT_BASE = 59859;

/**
 * 取**居中数字**的字形（0–9，各自独立、前进 16 像素）。
 *
 * 与 countGlyph（右下角、整格、1..64 各一个）不同：这是 /peek:badgetotal
 * 在潜影盒图标正中叠放总数用的，排版按位数**两侧**补空格尺把整串居中（见
 * scripts/box_overlay.js 的 cellFor —— 那里的居中补位和这里的 16 像素前进宽度是同一个约定）。
 */
function centerDigitGlyph(digit) {
  const d = Math.round(Number(digit));
  if (!isFinite(d) || d < 0 || d > 9) return "";
  return String.fromCharCode(CENTER_DIGIT_BASE + d);
}

/**
 * 取物品的图标字符。没有图标则返回空串。
 *
 * 带不带命名空间都认：表里的键是裸 id（"composter"），但有些调用方会给
 * "minecraft:composter"（比如伪容器那条路径直接传方块 id）。
 * 早先是精确匹配，于是堆肥桶永远查不到图标、退化成占位问号。
 */
function itemGlyph(itemId) {
  if (!itemId) return "";
  const raw = String(itemId);
  const bare = raw.replace(/^[a-z_]+:/, "");
  const code = Object.prototype.hasOwnProperty.call(ITEM_GLYPHS, bare)
    ? ITEM_GLYPHS[bare]
    : (Object.prototype.hasOwnProperty.call(ITEM_GLYPHS, raw) ? ITEM_GLYPHS[raw] : undefined);
  return code === undefined ? "" : String.fromCharCode(code);
}

function glyphCount() {
  return Object.keys(ITEM_GLYPHS).length;
}

/**
 * 取物品的**亮版**图标字符（容器界面预览用，见 BOX_ITEM_GLYPHS 的说明）。
 *
 * 查不到亮版就退回普通图标 —— 宁可用暗一点的图，也不留空一格。
 */
function boxItemGlyph(itemId) {
  if (!itemId) return "";
  const raw = String(itemId);
  const bare = raw.replace(/^[a-z_]+:/, "");
  const code = Object.prototype.hasOwnProperty.call(BOX_ITEM_GLYPHS, bare)
    ? BOX_ITEM_GLYPHS[bare]
    : (Object.prototype.hasOwnProperty.call(BOX_ITEM_GLYPHS, raw) ? BOX_ITEM_GLYPHS[raw] : undefined);
  return code === undefined ? itemGlyph(itemId) : String.fromCharCode(code);
}

const SPACER_GLYPH_BASE = 59888;
const SPACER_STEPS = 8;

/**
 * 空格尺：取一段**宽度可调、肉眼不可见**的字符，用来横向推整块预览。
 *
 * units 的单位是 1/8 格：units=8 就是「一格宽」，17 = 两格零 1/8。
 * 正值由调用方插在**行首**（内容右移），负值插在**行尾**（内容左移）——
 * 居中的行，总宽每增加 N，内容起点净位移 N/2。
 *
 * 这些字形只有一条 alpha=1 的最上行墨迹（肉眼不可见），但引擎按墨迹算
 * 前进宽度，所以推进的距离正好等于它们的墨迹宽度。
 */
function spacerGlyph(units) {
  let n = Math.round(Number(units));
  if (!isFinite(n) || n <= 0) return "";
  const full = Math.floor(n / SPACER_STEPS);
  const rest = n % SPACER_STEPS;
  let out = "";
  for (let i = 0; i < full; i++) out += String.fromCharCode(SPACER_GLYPH_BASE + SPACER_STEPS - 1);
  if (rest > 0) out += String.fromCharCode(SPACER_GLYPH_BASE + rest - 1);
  return out;
}


// ===== 容器名字形（见上面 NAME_PAGE_HIGH_BYTE 那一段）=====

/**
 * 容器名汉字 -> 字形码点。**由 tools/icons/build-item-glyphs.mjs 自动生成**。
 *
 * ## 为什么容器名也要做成字形
 *
 * 标题行用的原版 label 带 `font_scale_factor: 0.25`，普通中文在那个字号下
 * 只有 2~3 像素高，是看不清的残影（所以 config.js 的 SHOW_CONTAINER_NAME
 * 以前一直是 false）。而**字形**的显示尺寸跟着格子尺寸走 —— 做成和物品图标
 * 一样的 64 像素格子之后，名字就和图标显示成同样大，且和图标**同属一条标签、
 * 同一个 font_scale_factor**（另起标签或另设字号会让两者对不齐，不能那么做）。
 *
 * 字是从**游戏自带的 CJK 位图字体**里切的（方案 A，没有引入任何第三方字体），
 * 切法与坐标换算见 tools/icons/container_name_glyphs_ref.js。
 *
 * 表键是**单个汉字**：同一套字形可以拼出任意容器名，新增颜色/木种不用重新出页。
 */
const CONTAINER_NAME_GLYPHS = {
  "丛": 59904,
  "云": 59905,
  "发": 59906,
  "台": 59907,
  "合": 59908,
  "品": 59909,
  "唱": 59910,
  "器": 59911,
  "堆": 59912,
  "子": 59913,
  "射": 59914,
  "影": 59915,
  "成": 59916,
  "投": 59917,
  "掷": 59918,
  "斗": 59919,
  "木": 59920,
  "末": 59921,
  "机": 59922,
  "杉": 59923,
  "林": 59924,
  "树": 59925,
  "桦": 59926,
  "桶": 59927,
  "棕": 59928,
  "樱": 59929,
  "橙": 59930,
  "橡": 59931,
  "欢": 59932,
  "淡": 59933,
  "深": 59934,
  "漏": 59935,
  "潜": 59936,
  "灰": 59937,
  "炉": 59938,
  "烟": 59939,
  "熏": 59940,
  "熔": 59941,
  "片": 59942,
  "白": 59943,
  "盒": 59944,
  "矿": 59945,
  "竹": 59946,
  "筏": 59947,
  "箱": 59948,
  "粉": 59949,
  "紫": 59950,
  "红": 59951,
  "绿": 59952,
  "肥": 59953,
  "船": 59954,
  "色": 59955,
  "花": 59956,
  "苍": 59957,
  "蓝": 59958,
  "车": 59959,
  "输": 59960,
  "运": 59961,
  "造": 59962,
  "酿": 59963,
  "金": 59964,
  "阱": 59965,
  "陷": 59966,
  "青": 59967,
  "高": 59968,
  "黄": 59969,
  "黑": 59970
};

/**
 * 取整串容器名的字形。
 *
 * **只要有一个字没有字形就整体返回空串** —— 半个名字（比如只有"箱"）比不显示
 * 名字更糟，调用方拿到空串会自动退回显示中文名。表里的字是从容器白名单
 * 逐个算出来的（构建期还有一条 missingNameChars 回归检查兜着），正常不会缺，
 * 这条是防「版本/语言包变了」的最后一道。
 *
 * 为了不让调用方多一次全表扫描，这里用一次遍历同时完成校验与拼接。
 */
function containerNameGlyphs(name) {
  if (!name) return "";
  const text = String(name);
  let out = "";
  for (let i = 0; i < text.length; i++) {
    const ch = text.charAt(i);
    const code = CONTAINER_NAME_GLYPHS[ch];
    if (code === undefined) return "";
    out += String.fromCharCode(code);
  }
  return out;
}

// ===== hud_protocol.js =====
/**
 * HUD 通道协议：标记前缀。
 *
 * 数目行借的是**原版 title 通道**（脚本用 `setTitle` 写，资源包的控件读）。
 * 把该通道整体设成透明（`"hud_title_text": { "alpha": 0 }`）会连带吞掉服务器和
 * 其它附加包发出的标题，因此不采用该做法。
 *
 * 当前做法（见 `json-ui/preserve-title-texts.md`，第三方模组也是同一套）：
 *   · 发出的标题文本一律带标记前缀 HUD_MARKER；
 *   · 资源包给原版标题控件**追加一条可见性绑定**：文本以该标记开头就隐藏，
 *     其余一律照常显示，服务器的标题因此完全不受影响；
 *   · 自有控件把标记**剪掉**再显示。
 *
 * 独立成文件的理由：资源包的构建脚本要写死同一个标记文本，而本模块不引用引擎，
 * Node 构建脚本可直接 import —— 构建脚本导入这些常量，资源包和脚本的标记
 * 因此不可能对不上。
 */

// 预览标记字形（见下方的 PREVIEW_MARKER）从生成的字形模块取，保证资源包与脚本
// 用的是**同一个码点**；本模块仍不引用引擎，构建脚本照旧可以直接 import。


/** 发往 title 通道的标题文本的标记前缀。必须是纯 ASCII，且不会出现在正常标题里 */
const HUD_MARKER = "peek::";

/**
 * **容器界面模式**的第二个标记前缀（"点一下潜影盒看内容"）。
 *
 * 容器界面打开时 `hud_screen` **依然在渲染**，只是屏幕中间被容器面板压住、
 * 还压了一层暗色滤镜。所以两套控件分开：
 *   · 正常模式（准星看容器方块）—— 预览画在居中原有位置；
 *   · 容器界面模式（在打开的箱子里点潜影盒）—— 预览画到**屏幕左边缘**那片空白区。
 *
 * 两套控件共用同一对文本通道（actionbar 图标 + title 数目），靠**标记前缀不同**
 * 区分：以 `peek::box::` 开头的走左边缘那套，其余走居中那套，
 * 资源包那边各自绑一条可见性判断。
 *
 * 它**必须**以 HUD_MARKER 开头：原版标题的过滤器只测试 HUD_MARKER 这个前缀，
 * 不这么写的话原版标题控件会把数目串当成正常标题显示出来。
 *
 * 形状标记插在**模式前缀之后**（`peek::box::r3c9…`），所以上面这两条前缀判断
 * （`'%.6s' = 'peek::'`、`'%.10s' = 'peek::box::'`）都不受影响 —— 定在前缀上的
 * 字符串比较只看开头那几个字符。
 */
const BOX_MARKER = HUD_MARKER + "box::";

/**
 * **形状标记字段的定宽**（字符数）。
 *
 * 标记里除前缀外还带 4 个字符的"容器网格形状"（见 scripts/grid_shapes.js 的
 * `shapeToken`，形如 `r3c9` = 3 行 9 列）：
 *
 *     准星：   peek::r3c9<数目串>        （title 通道）
 *     容器界面：peek::box::r3c9<图标串>  （title 通道）
 *
 * **为什么必须定宽**：资源包要显示这串文本里的"正文"部分，就得把
 * "前缀 + 形状"这一段剪掉。JSON-UI 没有"从第 N 个字符开始取"的写法，
 * 只能"减去前 K 个字符"（`'%.Ks' * #text` 取前 K 个，再做字符串减法），
 * 所以 K 必须是**构建期就能写死的常量** —— 形状字段定宽才不会变。
 * 形状标记因此永远是 4 个字符（算不出形状时用兜底标记 `r0c0`，长度相同）。
 *
 * 两处调用点各剪一次：准星那套剪 `HUD_MARKER + 4` = 10 个字符，
 * 容器界面那套剪 `BOX_MARKER + 4` = 15（BOX_MARKER 本身 11 个字符）。
 * 长度由 build-rp-ui.mjs 的 stripMarkerBindings 用**常量长度**算出来写进绑定，
 * 不手写数字（见该函数）。
 */
const SHAPE_TOKEN_LENGTH = 4;

/**
 * **预览缩放档位**的档位码（1 个字符，插在 `peek::` 之后、形状字段之前）。
 *
 *     准星预览： peek::<档位码><形状><正文>    例：`peek::rr3c9…`（100%）
 *     容器界面： peek::box::<形状><正文>        （左边缘那套**不参与缩放**）
 *
 * 为什么要有这个字符：字形的显示尺寸由资源包里的 `font_scale_factor` 决定，那是**静态属性**、
 * 脚本改不了。资源包于是为每个档位准备一套控件（不同 `font_scale_factor`），
 * 靠这一个字符区分该显示哪一套 —— 见 tools/pack/build-rp-ui.mjs 的 PREVIEW_SCALE_STEPS。
 *
 * ⚠️ 档位码占用 1 个字符之后，正文 = 剪掉 `HUD_MARKER + 档位码 + 形状字段` =
 * 6 + 1 + 4 = **11 个字符**（见 `TITLE_FIELD_LENGTH`）。资源包按定长剪，改这里必须同步改
 * `markerWithShapeLength`（它会从这些常量算出来，不用手写数字）。
 */
const PREVIEW_STEP_CODES = {
  full: "r",      // 100%（原始尺寸）
  three4: "q",    // 75%
  half: "h"       // 50%
};

/** 默认档位（100%）。档位码就是形状字段前那一个字符。 */
const DEFAULT_PREVIEW_STEP = "full";

/**
 * 把档位名（`/peek:scale` 的取值）翻成档位码（1 字符）。
 * 不认识的名字退回默认档位 —— 与 settings.js 的枚举校验双保险。
 */
function previewStepCode(step) {
  const key = String(step === undefined || step === null ? "" : step).trim().toLowerCase();
  return PREVIEW_STEP_CODES[key] || PREVIEW_STEP_CODES[DEFAULT_PREVIEW_STEP];
}

/** 准星预览标题里"档位码 + 形状字段"的总长（构建期剪前缀用）。 */
const TITLE_FIELD_LENGTH = 1 + SHAPE_TOKEN_LENGTH;

/**
 * 给要发往 title 通道的文本加上标记。
 * 空串也加标记（清屏时用），这样清屏操作才会生效。
 *
 * @param {string} text  正文（数目串 / 容器界面模式的图标串）
 * @param {string} [shape] 形状字段：准星预览是 **5 字符**（档位码 + 4 字符形状，见
 *        `TITLE_FIELD_LENGTH`），容器界面模式是 4 字符（见 grid_shapes.js 的 shapeToken）。
 *        省略 = 不带形状（清屏路径如此）：资源包那边**没有任何底衬变体命中**，
 *        于是只显示网格、不显示灰区 —— 这正是清屏时要的效果。
 */
function markTitleText(text, shape) {
  return HUD_MARKER + (shape || "") + (typeof text === "string" ? text : "");
}

/** 剪掉标记（自测用；游戏里由资源包的字符串减法负责） */
function stripMarker(text) {
  if (typeof text !== "string") return "";
  return text.indexOf(HUD_MARKER) === 0 ? text.slice(HUD_MARKER.length) : text;
}

/**
 * **预览标记字形**：预览正文最前面的那一个字符（肉眼不可见、墨迹只有 1 像素宽）。
 *
 * ## 它现在**不是**资源包的判据（重要，别改回去）
 *
 * 设计初衷是让资源包据此把 0.25 倍字号只用于自己的预览：判据写
 * `'%.1s' * $actionbar_text = '<本标记>'`。**这个写法在游戏里不成立**：
 * `$actionbar_text` 是 `hud_actionbar_text` 这个 factory 实例注入的变量，
 * 它能沿控件树替换进 `text` 一类属性（图标因此正常显示），但在**绑定表达式**里
 * 取不到值 —— 表达式失效、绑定被静默忽略、`#visible` 停在默认的"可见"，
 * 于是 0.25 那层和 1.0 那层**同时显示**，屏幕上出现一份 4 倍大的预览副本
 *（用户报的"多了一个超级大的 UI 盖在屏幕上"）。
 *
 * 资源包现在改判 **title 通道的准星预览标记**（`peek::r…`，即本模块的 HUD_MARKER
 * 加形状字段首字符），理由是那条路在本包里**已经在游戏里生效**（底衬变体、原版标题
 * 过滤都走它）。详见 tools/pack/build-rp-ui.mjs 的 PREVIEW_TITLE_MARKER。
 *
 * ## 那还留着它做什么
 *
 * 它跟着预览正文一起发（图标层与数目层都带），**保留备用**：万一某天 title 通道那条
 * 判据在某个版本上不可靠，文本内的标记是现成的第二信号，两半已经对齐、不用再改协议。
 * 代价只有 1 像素宽的不可见墨迹（前进宽度 1/64 格 ≈ 0.25 屏幕像素）。
 *
 * ## 使用范围（很重要）
 *
 * **只标记"预览正文"**，不要标记清屏用的那个空格（清屏状态靠 title 只剩 `peek::`
 * 来识别），也不必标记高亮信息那类文本（它们不带标记、按 1.0 渲染，反而更清楚）。
 */
const PREVIEW_MARKER = previewMarkerGlyph();

/**
 * 给**预览正文**加上标记字形（见 PREVIEW_MARKER）。
 *
 * @param {string} text 预览正文（图标串 / 数目串）
 */
function markPreviewText(text) {
  return PREVIEW_MARKER + (typeof text === "string" ? text : "");
}

/**
 * 容器界面模式（左边缘那套）的标记。
 *
 * @param {string} text  图标串
 * @param {string} [shape] 形状标记（4 字符），容器界面模式下同样要发
 *        —— 那一套底衬也是按形状写死尺寸的（见 build-rp-ui.mjs 的 boxBackdropLayer）。
 */
function markBoxText(text, shape) {
  return BOX_MARKER + (shape || "") + (typeof text === "string" ? text : "");
}

// ===== llse_adapter.js =====
/**
 * LSE（LegacyScriptEngine）适配层。
 *
 * 该层把 LSE 的全局 API（mc / ll / logger）包成主逻辑需要的统一接口，
 * 使核心功能（format.js 排版、名字表、字形表等）可与行为包版共用一份。
 *
 * 这是唯一直接调用 LeviLamina / LSE 原生 API 的层，其余代码保持引擎无关。
 * 所有调用按官方文档签名编写，并带防御式回退；标有【实测确认】的位置
 * 指依赖运行时确认的引擎行为，仅凭离线文档无法保证。
 *
 * 参考文档：https://lse.levimc.org/zh/apis/
 */

// HUD 标记前缀与行为包共用同一份定义（纯逻辑模块，两侧引同一来源，
// 避免标记改动后只有一侧同步）


/** 在线玩家（LSE Player 对象数组）。 */
function onlinePlayers() {
  try {
    return mc.getOnlinePlayers() || [];
  } catch (err) {
    logWarn("getOnlinePlayers 失败: " + err);
    return [];
  }
}

/**
 * 玩家注视的方块（LSE Block）或 null。
 *
 * LSE 签名：pl.getBlockFromViewVector([includeLiquid, solidOnly, maxDistance, fullOnly])
 */
function lookedBlock(player, maxDistance) {
  try {
    if (typeof player.getBlockFromViewVector !== "function") return null;
    // 【实测确认】四个布尔/数值参数的顺序与默认值
    const block = player.getBlockFromViewVector(false, false, maxDistance, false);
    if (!block) return null;
    if (block.type === "minecraft:air" || block.id === 0) return null;
    return block;
  } catch (err) {
    logWarn("getBlockFromViewVector 失败: " + err);
    return null;
  }
}

/**
 * 非容器方块中"内部状态值得预览"的几类，也折成容器的形状返回。
 *
 * 返回值与 readContainerObject 一致（containerSize + items + fingerprint），
 * 可另带 `noTitle: true`（不画标题行，"图标 + 数字"直接充当状态显示）。
 *
 *   · 堆肥桶：方块状态 `composter_fill_level`（0..8）即堆肥层数。
 *     与行为包一致，用"堆肥桶图标 + 层数"表示，不画标题行。
 *     层数为 0 时返回 null（空桶无内容，与原版不显示堆肥条一致）。
 *
 *   · 唱片机：在此不处理。其唱片槽是一个真实的容器槽
 *     （getContainer().size === 1），走普通容器路径即可读到唱片。
 */
function readSpecialBlockContent(block) {
  const typeId = stripNamespace(block.type);

  if (typeId === "composter") {
    const states = readBlockStates(block);
    let level = 0;
    if (states && states["composter_fill_level"] !== undefined) {
      level = Number(states["composter_fill_level"]) || 0;
    }
    if (!(level > 0)) return null;
    const items = [{ slot: 0, typeId: "minecraft:composter", amount: level }];
    return {
      containerSize: 1,
      items: items,
      noTitle: true,
      fingerprint: "composter:" + level
    };
  }

  return null;
}

/**
 * 读"被机器禁用的槽位"（目前只有合成器 crafter 有）。
 *
 * ## 为什么不是方块状态
 *
 * 自检读出的合成器方块状态只有 crafting / orientation / triggered_bit，
 * **没有** disabled_slots —— 被禁用的槽位存在**方块实体（BlockActor）的 NBT** 里，
 * 因此此处走 `block.getBlockEntity().getNbt()`。
 *
 * 该信息只有**插件版**能取得：行为包的 @minecraft/server API 没有读取
 * 方块实体 NBT 的接口，故行为包版无法实现该功能。
 *
 * NBT 里 `disabled_slots` 是一个位掩码：第 i 位为 1 表示第 i 个槽位被禁用
 * （槽位号 0..8，与 3x3 网格左上到右下一致）。
 *
 * @returns {number[]|null} 被禁用的槽位号数组；读不到返回 null（调用方视为无禁用）
 */
function readDisabledSlots(block) {
  // 先按容器类型粗筛：目前只有合成器有该概念，其余方块无需取方块实体
  const typeId = stripNamespace(block.type);
  if (typeId !== "crafter") return null;

  let nbt = null;
  try {
    if (typeof block.getBlockEntity !== "function") return null;
    const entity = block.getBlockEntity();
    if (!entity || typeof entity.getNbt !== "function") return null;
    nbt = entity.getNbt();
  } catch (err) {
    logWarn("读合成器方块实体 NBT 失败: " + err);
    return null;
  }
  if (!nbt) return null;

  let raw = null;
  try {
    raw = typeof nbt.getData === "function" ? nbt.getData("disabled_slots") : null;
  } catch (err) {
    logWarn("读 disabled_slots 失败: " + err);
    return null;
  }
  if (raw === null || raw === undefined) return null;

  const mask = Number(raw);
  if (!isFinite(mask) || mask <= 0) return [];

  const slots = [];
  for (let slot = 0; slot < 9; slot++) {
    if (mask & (1 << slot)) slots.push(slot);
  }
  return slots;
}

/**
 * 读**物品形态**潜影盒里的内容物。
 *
 * 行为包的 @minecraft/server API 读不到物品形态潜影盒的内容，
 * 因此"在打开的界面里点潜影盒看内容"只能由插件实现。插件可直接读物品 NBT，
 * 内容随物品本身存放，无需捕获、登记表等时序取巧。
 *
 * NBT 路径：
 *
 *   item.getNbt()                    → {Block, Count, Damage, Name, WasPickedUp, tag}
 *     .getTag("tag")                 → 玩家数据子复合（LLSE 把物品栈字段和玩家数据分开）
 *       .getTag("Items").toArray()   → [{Name:"minecraft:diamond", Count:5, Slot:0}, ...]
 *
 * 三条硬性约束：
 *   1. 键名是 **Items**（大写 I），不是 items；
 *   2. 内容物**不在顶层**，在 `tag` 子复合里；
 *   3. `getData("Items")` 对列表返回空对象，必须用 `getTag()` + `toArray()`。
 *
 * @returns {Array<{slot:number,id:string,count:number}>|null}
 *          null = 不是潜影盒 / 读不到 NBT；数组（可能是空的）= 读到了
 */
function readShulkerItemContents(stack) {
  if (!stack) return null;

  let typeId = "";
  try {
    typeId = stripNamespace(stack.type);
  } catch (_err) {
    return null;
  }
  if (typeId.indexOf("shulker_box") < 0) return null;

  let list = null;
  try {
    if (typeof stack.getNbt !== "function") return null;
    const nbt = stack.getNbt();
    if (!nbt || typeof nbt.getTag !== "function") return null;

    const userTag = nbt.getTag("tag");
    if (!userTag || typeof userTag.getTag !== "function") return [];

    list = userTag.getTag("Items");
  } catch (err) {
    logWarn("读潜影盒物品 NBT 失败: " + err);
    return null;
  }
  if (!list || typeof list.toArray !== "function") return [];

  let raw = null;
  try {
    raw = list.toArray();
  } catch (err) {
    logWarn("潜影盒 items 转数组失败: " + err);
    return null;
  }
  if (!Array.isArray(raw)) return [];

  const out = [];
  for (let i = 0; i < raw.length; i++) {
    const entry = raw[i];
    if (!entry) continue;
    const name = entry.Name === undefined ? entry.name : entry.Name;
    const count = entry.Count === undefined ? entry.count : entry.Count;
    if (!name) continue;
    out.push({
      slot: Number(entry.Slot === undefined ? entry.slot : entry.Slot) || 0,
      id: String(name),
      count: Number(count) || 1
    });
  }
  return out;
}

/**
 * 玩家注视的实体（LSE Entity）或 null。
 *
 * ⚠️ 签名与方块版**不同**：`getEntityFromViewVector(maxDistance)` 只接受
 * 一个参数且必须是数字。`PlayerClass::getEntityFromViewVector` 在
 * args.size() > 0 时执行 CHECK_ARG_TYPE(args[0], kNumber)，传入布尔值即被
 * 判为类型错误 —— 且**引擎不抛 JS 异常**，只在日志中记录 ERROR 并返回
 * undefined；模拟玩家在线时每 2 tick 记录一条，很快累积上千行。
 * 四布尔参数形式属于 getBlockFromViewVector，不可混用。
 *
 * 正确形式：getEntityFromViewVector(maxDistance)
 */
function lookedEntity(player, maxDistance) {
  try {
    if (typeof player.getEntityFromViewVector !== "function") return null;
    const entity = player.getEntityFromViewVector(maxDistance);
    return entity || null;
  } catch (err) {
    logWarn("getEntityFromViewVector 失败: " + err);
    return null;
  }
}

/**
 * 判断实体是不是容器实体（箱子矿车/漏斗矿车/运输船）。
 *
 * 【实测确认】1.21.93 的 BDS 里真正存在的容器实体 id 只有这三个，
 * 由自检用 summon 逐个试出：
 *   chest_minecart  27 格   （name: Minecart with Chest）
 *   hopper_minecart  5 格   （name: Minecart with Hopper）
 *   chest_boat      27 格   （name: Boat with Chest）
 * 运输船**不分树种**：`oak_chest_boat` / `bamboo_chest_raft` 之类
 * summon 直接失败（报无此 id），因此不可照抄 Java 的 id 列表。
 */
const CONTAINER_ENTITY_TYPES = [
  "chest_minecart",
  "hopper_minecart",
  "chest_boat"
];

function stripNamespace(id) {
  return typeof id === "string" ? id.replace("minecraft:", "") : "";
}

function isContainerEntityType(type) {
  return CONTAINER_ENTITY_TYPES.indexOf(stripNamespace(type)) >= 0;
}

/**
 * 读取方块的容器内容，统一成主逻辑所需的结构：
 *   { containerSize, items: [{slot, typeId, amount}] }
 *
 * LSE：bl.getContainer() -> Container（ct.size、ct.getItem(i)）。
 * LSE Item：.type（带 minecraft: 前缀的 id）、.count（数量）。
 */
function readBlockContainer(block) {
  const typeId = stripNamespace(block.type);

  // 先确认它真的是容器方块：理由见 EXTRA_CONTAINER_BLOCKS 的注释
  let isContainer = false;
  try {
    if (typeof block.hasContainer === "function") isContainer = block.hasContainer() === true;
  } catch (err) {
    logWarn("hasContainer 失败 (" + typeId + "): " + err);
  }
  if (!isContainer && EXTRA_CONTAINER_BLOCKS.indexOf(typeId) < 0) return null;

  let container = null;
  try {
    if (typeof block.getContainer !== "function") return null;
    container = block.getContainer();
  } catch (err) {
    logWarn("getContainer 失败 (" + typeId + "): " + err);
    return null;
  }
  if (!container) return null;
  return readContainerObject(container);
}

/**
 * 读方块的**方块状态**（而不是容器）。
 *
 * `BlockClass::getBlockState()` 返回方块序列化数据里的 states 表，
 * 因此无需容器即可取得状态值，例如：
 *   · 堆肥桶 -> composter_fill_level（0..8，堆肥层数）
 * 取不到返回 null（不同版本的状态字段名可能不同，由调用方判断）。
 */
function readBlockStates(block) {
  try {
    if (typeof block.getBlockState !== "function") return null;
    const states = block.getBlockState();
    if (!states || typeof states !== "object") return null;
    return states;
  } catch (err) {
    logWarn("getBlockState 失败: " + err);
    return null;
  }
}

/**
 * 读取实体的容器内容（箱子矿车/运输船）。
 * LSE Entity 同样提供 getContainer()。
 */
function readEntityContainer(entity) {
  try {
    if (typeof entity.getContainer !== "function") return null;
    const container = entity.getContainer();
    if (!container) return null;
    return readContainerObject(container);
  } catch (err) {
    logWarn("实体 getContainer 失败: " + err);
    return null;
  }
}

/**
 * 方块 id（去掉 minecraft: 前缀）里，hasContainer() 报 false
 * 但**确实带方块实体容器**的几个。
 *
 * 白名单的必要性：`BlockClass::getContainer()` 在引擎里的实现是
 * `getBlockEntity(pos)->getContainer()`，方块实体不存在时走空指针路径。
 * 因此不可对任意方块调用 getContainer()，须先确认其为容器方块。
 * 唱片机/讲台正好卡在中间：`isContainerBlock()` 判定为非容器，
 * 但其方块实体带一个槽位（唱片 / 书），getContainer() 可读出 size=1。
 */
const EXTRA_CONTAINER_BLOCKS = ["jukebox", "lectern"];

/**
 * "准星正对着的方块**有没有可看的内容**" —— 只做**便宜**的判断。
 *
 * 用途：盒预览（左边缘那套）占着三条文本通道时，准星预览必须让位；但让位不能拖太久
 * （用户报的"盯着容器一直没有预览"）。判断"准星已经对着容器"时**不能读容器内容**：
 * 这条判据每个 tick 都问一次，读一次 27 格 getItem 就不划算了。
 *
 * 判据 = `hasContainer()`（引擎自己认的容器）或白名单（唱片机 / 讲台 / 堆肥桶 ——
 * 前两个在 `EXTRA_CONTAINER_BLOCKS` 里，堆肥桶走"方块状态伪容器"那条路）。
 * 取不到就当场返回 false，绝不抛出去打断主循环。
 */
function isPreviewableBlock(block) {
  if (!block) return false;
  const typeId = stripNamespace(block.type);
  try {
    if (typeof block.hasContainer === "function" && block.hasContainer() === true) return true;
  } catch (_err) {
    // hasContainer 不可用就退回白名单
  }
  return EXTRA_CONTAINER_BLOCKS.indexOf(typeId) >= 0 || typeId === "composter";
}

/**
 * 判断一个槽位上的物品是不是"空"。
 *
 * ⚠️ 引擎行为：`container.getItem(slot)` 对空槽**不返回 null**，而是返回一个
 * Item 对象，只是其 `isNull()` 为真、`type` 为空串、`count` 为 0。
 * 仅用 `if (!item) continue;` 判断时，全部空槽都会被当作有物品读入列表，
 * 显示结果为一整片问号。
 */
function itemIsEmpty(item) {
  if (!item) return true;
  try {
    if (typeof item.isNull === "function") return item.isNull() === true;
  } catch (_err) {
    // 拿不到 isNull() 就退回去看类型/数量
  }
  const type = typeof item.type === "string" ? item.type : "";
  const count = typeof item.count === "number" ? item.count : 0;
  return type.length === 0 || count <= 0;
}

function readContainerObject(container) {
  let size = 0;
  try {
    size = container.size;
  } catch (_err) {
    size = 0;
  }
  if (!(size > 0)) return null;

  const items = [];
  for (let slot = 0; slot < size; slot++) {
    let item = null;
    try {
      item = container.getItem(slot);
    } catch (_err) {
      continue;
    }
    if (itemIsEmpty(item)) continue;

    // 【实测确认】LSE Item 的数量字段是 .count（.amount 不存在，取到的是 undefined）
    const amount = typeof item.count === "number" ? item.count
      : (typeof item.amount === "number" ? item.amount : 1);

    items.push({
      slot: slot,
      typeId: stripNamespace(item.type),
      amount: amount,
      // ⚠️ 把**原始物品对象**一起带上：潜影盒角标要读这个盒子的 NBT
      //（见 main.js 的 boxRecordsFor → box_content.scanBoxes）。只在这里能拿到它 ——
      // 事件回调结束后再回头去容器里取是另一份数据，而且要多读一遍容器。
      // 注意：**只在本次调用期间有效**，不要存起来跨 tick 用（LSE 对象生命周期短）。
      stack: item
    });
  }

  return {
    containerSize: size,
    items: items,
    fingerprint: items.map((i) => i.slot + ":" + i.typeId + "x" + i.amount).join("|") || "empty"
  };
}

/**
 * 往 actionbar 发文本（图标行）。
 *
 * LSE：pl.setTitle(content, type, fadeIn, stay, fadeOut)
 *   type 2 = 主标题，type 3 = 副标题，type 4 = Actionbar。
 * 【实测确认】actionbar 在该引擎里的持续显示与淡出时长。
 */
function sendActionbar(player, text) {
  try {
    player.setTitle(text, 4, 0, 60, 0);
    return true;
  } catch (err) {
    logWarn("setTitle(actionbar) 失败: " + err);
    return false;
  }
}

/**
 * 往主标题发文本（数量行）。
 *
 * ⚠️ **必须带 HUD 标记前缀**：数量行借用原版 title 通道，而资源包的过滤规则是
 * "文本以 peek:: 开头才隐藏原版标题"。省略前缀会导致两个后果：
 *   1. 原版标题控件视为"非本模组消息"照常显示，其黑色文字背景板随文本尺寸增长；
 *      数量串有几十行（前面还有顶部位移的空行），背景板被撑到整屏 ——
 *      表现为**一瞄准容器整个屏幕大幅变暗**；
 *   2. 清屏时发送空串，引擎忽略空标题，旧串留在通道里 ——
 *      表现为**图标立刻消失、数量文字要等标题自身寿命结束才消失**（迟滞）。
 * 加上前缀后两者同时消除：原版标题被隐藏，清屏用 "peek::" 即可立刻生效
 * （资源包内本模组标签会剪掉标记，剩余空串等同于不显示）。
 *
 * @param {string} text  数目串
 * @param {string} [shape] 网格形状标记（4 字符）。资源包的底衬尺寸**按形状写死**：
 *        不带形状 = 没有任何底衬变体命中（网格与数字还在、灰区没了，且不报错）。
 *        清屏路径（sendTitle(player, "")）故意不传。
 */
function sendTitle(player, text, shape) {
  try {
    // stay 取一个**极大值**（与行为包一致）：标题一出现就是全亮、且不自己消失，
    // 由脚本按节奏重发。stay 短（原来 60 tick = 3 秒）时，只要重发被打断一下
    //（例如引擎在打开容器界面时动了 title 通道），判据就会短暂落空 —— 那是
    // "看着容器却什么都没有/闪一下"的来源之一。清屏是显式发 `peek::`，不靠它自然过期。
    player.setTitle(markTitleText(text, shape), 2, 0, 100000, 0);
    return true;
  } catch (err) {
    logWarn("setTitle(title) 失败: " + err);
    return false;
  }
}

/**
 * 往主标题发**不带标记**的纯文本（只给 `/peek:hudtest` 的显示自检用）。
 *
 * 为什么必须单独一个函数：本套东西的**判据与文本同源**都在 title 通道上，所以"带不带
 * `peek::` 标记"直接决定资源包把这条标题当成什么 ——
 *   · 带标记（`sendTitle`）→ 资源包按我们的字号/位置画（自检就变成"用被检验的那套渲染
 *     去检验它自己"，而且没装资源包时屏幕上会多出一串 `peek::` 字母）；
 *   · 不带标记（本函数）→ 资源包 `hud_title_text` 那条覆盖的判据是"**不**以标记开头就可见"，
 *     于是走**原版标题**的渲染路径 —— 玩家本来能看到什么，自检就显示什么。
 *
 * stay 取 60 tick（3 秒）：自检那几行不该像预览那样常驻，由脚本按节奏重发
 *（见 main.js 的 HUD_TEST_RESEND_TICKS = 40，重叠 1 秒保证不断档）。
 */
function sendPlainTitle(player, text) {
  try {
    player.setTitle(text, 2, 0, 60, 0);
    return true;
  } catch (err) {
    logWarn("setTitle(plain title) 失败: " + err);
    return false;
  }
}

/**
 * 往主标题发**容器界面模式**的文本（左边缘那套预览的**图标行**）。
 *
 * 与 sendTitle 的唯一区别是标记前缀不同（`peek::box::`，即 BOX_MARKER），
 * 资源包据此把该段文本画到屏幕左边缘，而不是中间那套位置。
 *
 * ⚠️ 通道分配（为何图标走 title、数量走 subtitle）：
 * 居中那套的图标读的是 `$actionbar_text` —— 它是 `hud_actionbar_text` 这个
 * factory 控件的实例属性，出了那个子树就无法取得；左边缘那套挂在 root_panel，
 * 只能读**全局绑定**。全局里文本有 title / subtitle 两个通道，正好各给一行：
 * title 放图标（带盒子标记）、subtitle 放数量（纯字形）。
 *
 * 与 sendTitle 一样必须带**形状字段**：左边缘那套底衬同样按形状写死尺寸
 * （见 build-rp-ui.mjs 的 backdropVariantControls 与 scripts/grid_shapes.js）。
 */
function sendBoxTitle(player, text, shape) {
  try {
    player.setTitle(markBoxText(text, shape), 2, 0, 60, 0);
    return true;
  } catch (err) {
    logWarn("setTitle(box title) 失败: " + err);
    return false;
  }
}

/**
 * 往**字幕**通道发容器界面模式的**数量行**（不带标记）。
 *
 * LSE setTitle 的 type：2 = 主标题、3 = 副标题/字幕、4 = actionbar。
 * 原版 subtitle 标签读的也是全局 `#hud_subtitle_text_string`，
 * 因此该行从 root_panel 下的任何标签都可读到。
 *
 * 无需加标记的原因：原版标题控件整块（标题 + 字幕 + 背景）的显隐由 title 通道的
 * 标记决定 —— 盒子模式下 title 必带 `peek::box::` 前缀、整块被隐藏，
 * 字幕这串字形不会泄露到屏幕中间。
 */
function sendSubtitle(player, text) {
  try {
    player.setTitle(text, 3, 0, 60, 0);
    return true;
  } catch (err) {
    logWarn("setTitle(subtitle) 失败: " + err);
    return false;
  }
}

/** 向玩家发送聊天消息（命令回显 / 诊断）。 */
function tell(player, text) {
  try {
    // LSE：pl.tell(msg)（type 默认 Raw）
    if (typeof player.tell === "function") player.tell(text);
    else player.sendText(text, 0);
  } catch (err) {
    logWarn("tell 失败: " + err);
  }
}

/**
 * ===== 日志：常规信息可关，警告与"被要求输出的东西"永远不关 =====
 *
 * 为什么要分三层（用户问："插件在服务端后台显示的那个日志现在能关吗"）：
 *   · `logInfo`   —— **常规信息**：开机那一串、扫描耗时、盒预览收掉的缘由。多人服的管理员
 *                    嫌它刷屏，所以由 `/peek:log off`（全局、持久化）关掉；
 *   · `logAlways` —— **关不掉的输出**：命令回执（控制台敲 `/peek:status` 必须能看到结果）、
 *                    开机那**一行**"已启动"（管理员靠它确认插件起来了），以及
 *                    **显式打开**的诊断日志（`/peek:trace`、`/peek:check` 的证据）。
 *                    这些东西的共同点：**是有人要它才出现的** —— 被日志开关吞掉才是 bug；
 *   · `logWarn`   —— **警告/错误**：引擎 API 失败、清屏失败这类"出事了"的记录，
 *                    任何时候都不能关（它们正是排障的唯一线索）。
 */

/** 常规信息日志是否输出（`/peek:log`，全局旋钮、持久化）。 */
let infoLogEnabled = true;

/** 设置常规信息日志开关（启动读配置、命令改旋钮时调用）。 */
function setInfoLogEnabled(enabled) {
  infoLogEnabled = enabled !== false;
}

/** 常规信息：受 `/peek:log off` 影响。 */
function logInfo(msg) {
  if (!infoLogEnabled) return;
  logRaw(msg);
}

/**
 * **关不掉**的信息输出：命令回执、开机那一行、显式打开的诊断日志。
 *
 * 见本段开头的三层说明 —— 尤其"控制台敲命令必须看得到结果"这一条：
 * 命令回执如果走 `logInfo`，`/peek:log off` 之后管理员敲 `/peek:check` 会一片空白，
 * 看起来就像插件坏了。
 */
function logAlways(msg) {
  logRaw(msg);
}

/** 真正的输出（`logInfo` / `logAlways` 共用；LSE 的 logger 取不到时退回 print）。 */
function logRaw(msg) {
  try {
    if (typeof logger !== "undefined" && logger.info) logger.info("[peek] " + msg);
    else if (typeof log === "function") log("[peek] " + msg);
  } catch (_err) {
    // 忽略
  }
}

function logWarn(msg) {
  try {
    if (typeof logger !== "undefined" && logger.warn) logger.warn("[peek] " + msg);
    else if (typeof logger !== "undefined" && logger.error) logger.error("[peek] " + msg);
  } catch (_err) {
    // 忽略
  }
}

// ===== shulker_box.js =====
/**
 * 潜影盒判定。
 *
 * 只此一个函数，单独成文件是因为它被插件主逻辑和字形工具共用；
 * 原先放在写 lore 那个模块里（那个功能已删除）。
 */

/** 是不是潜影盒类方块/物品（含全部 16 种染色变体）。 */
function isShulkerBox(typeId) {
  return typeof typeId === "string" && typeId.indexOf("shulker_box") >= 0;
}

// ===== identity.js =====
/**
 * 项目标识：署名、项目名与防伪指纹。
 *
 * 单一来源：行为包、LSE 插件、资源包生成器都从这里取。
 * 资源包那份是**构建时**写进 `ui/hud_screen.json` 的，所以改这里要重新打包。
 */

/** 项目英文名（给日志/清单用）。 */
const PROJECT_NAME = "Crosshair Container Peek";

/** 项目中文名（给玩家看的）。 */
const PROJECT_NAME_CN = "准星容器内容预览";

/**
 * 发布者署名（**不带** "by " 的名字本身）。
 *
 * 单独留一个常量是给**包清单**用的：`manifest.json` 的 `metadata.authors` 要的是
 * 干净的名字（`shykingsui`），而游戏内署名行要的是 `by shykingsui` —— 两边都从这里取，
 * 免得改一处忘一处（自测有一条断言盯着"清单里的作者名 = 这里的值"）。
 */
const AUTHOR_NAME = "shykingsui";

/**
 * 发布者署名（游戏内显示的那一份）。
 *
 * 留空时署名行只显示项目名。该值同时进入游戏内 `/peek:about`、
 * 资源包 `ui/hud_screen.json` 的标识面板与插件启动日志。
 * 进服提示默认不弹（由插件侧的 `SHOW_SIGNATURE_ON_JOIN` 控制）。
 */
const AUTHOR = AUTHOR_NAME ? "by " + AUTHOR_NAME : "";

/**
 * 许可协议标识（写进包清单的 `metadata.license`）。
 *
 * 2026-09 由"自定义条款"改成 **CC BY-NC-SA 4.0**（用户要求：可以修改但禁止商用）——
 * 条款全文、边界说明（什么算商业用途）见仓库根目录的 `LICENSE.txt`。
 * 这里只放**标识字符串**：清单字段里塞整篇协议既没人读，也会与 LICENSE.txt 漂。
 */
const LICENSE_ID = "CC BY-NC-SA 4.0";

/**
 * 防伪指纹：与资源包 uuid 绑定，用来证明一份产物出自本项目。
 *
 * 它出现在三个地方，任何一处被删/被改都说明这份产物被人动过：
 *   1. 游戏内 `/peek:about`
 *   2. 资源包 `ui/hud_screen.json` 里一个**从不被实例化**的定义 `hud_peek_signature`
 *      （玩法中完全不出现，但文本搜 `CCP/` 就能搜出来）
 *   3. 插件启动日志
 *
 * 说清楚它的作用边界：这只是一枚**署名与溯源标记**，不构成技术保护 ——
 * 拿到插件文件的人可以读代码、可以直接把这一行删掉。
 */
const FINGERPRINT = "CCP/3f8a1c62-9d47-4b15-8e30-6a2c7f5b9d41";

/** 一行署名（有署名时带上署名）。 */
function signatureLine() {
  return PROJECT_NAME_CN + (AUTHOR ? " · " + AUTHOR : "");
}

/**
 * `/peek:about` 的正文。
 *
 * @param {string[]} [extra] 追加的自定义行（可省）
 * @returns {string[]} 逐行文本，已带颜色代码
 */
function aboutLines(extra) {
  const lines = [
    "§a" + signatureLine(),
    "§7" + PROJECT_NAME + "　§8指纹 §f" + FINGERPRINT
  ];
  if (Array.isArray(extra)) {
    for (let i = 0; i < extra.length; i++) lines.push(extra[i]);
  }
  return lines;
}

// ===== config.js =====
/**
 * 集中配置。手机优先：所有数值都按"窄屏 HUD 也放得下"来定。
 *
 * 本文件是调参入口：每个常量都标出单位、含义，以及调大/调小会改变什么。
 */

/** 准星射线最远距离（格）。8 格对应"走近箱子看"的距离，同时避免隔着房间读取。 */
const REACH_DISTANCE = 8;

/** 轮询间隔（tick）。4 tick ≈ 0.2 秒：跟随视线足够跟手，又不至于把发包量拉满。 */
const POLL_INTERVAL_TICKS = 4;

/**
 * 目标不变时，**重发**同一段 HUD 文本的间隔（tick）。
 *
 * 必须重发的原因：原版 actionbar 那行文字自带淡出动画
 * （`alpha: "@hud.anim_actionbar_text_alpha_out"`，见 .research/vanilla_ui/hud_screen.json），
 * 到点即自行消失。而发送只在内容变化时触发 —— 于是"瞄准一个容器不动"会让 HUD 淡出，
 * 而这正是最常用的场景。
 *
 * **4 tick（0.2 秒）= 每个轮询周期都重发一次。**重发用的是**已经算好的字符串**
 * （不重读容器、不重新排版，只调用一次 setActionBar），所以按周期重发的开销可接受，
 * 且无论淡出动画多快都不会淡出。
 */
const HUD_RESEND_TICKS = 4;

/**
 * 目标不变时，**重读容器**的间隔（tick）。
 *
 * 用来发现内容变化（例如其它实体往容器里放入物品）。重读后比对指纹，
 * 内容一致就只走重发、不重新排版。
 *
 * **8 tick = 0.4 秒**。轮询本身每 4 tick 一次，所以 0.4 秒正好是两个轮询周期。
 */
const HUD_REFRESH_TICKS = 8;

/**
 * 网格前的**空行数** —— 这就是"HUD 高度"的调节旋钮。
 *
 * 原理：UI 的锚点位置写在资源包里，脚本改不了；但**空行**可以把整张网格往下推
 * （一行 ≈ 2 个像素单位）。所以把锚点固定在一个偏高的位置，再用计分板把网格压到
 * 舒服的高度。⚠️ 这些空行**本轮换过通道**：不再拼进 actionbar 那条字符串，
 * 改由 `formatTopPad()` 走字幕通道送出 —— 原因见下。
 *
 * 游戏内指令（改完立刻生效，不用重装包）：
 *   /scoreboard objectives add peek_top dummy
 *   /scoreboard players set @s peek_top 30
 *   删掉目标或删掉分数 = 恢复默认
 *
 * 顶部空行把网格往下推。⚠️ 这条**本轮改过落点**：
 *   · 旧：P 个换行拼在 actionbar 串最前面。锚点定的是标签中心，所以 P 行只推 P/2 行。
 *     但底衬（peek_backdrop）尺寸取内容盒，于是灰区把这 P 行一起包进去 ——
 *     默认 20 行 ≈ 42 显示单位，容器越小越离谱（用户报的"底衬比预览高好几倍"）。
 *   · 新：P 个换行改由 `formatTopPad()` 产出、脚本走**字幕**通道送出，资源包把它
 *     变成网格上方一块"零宽、P 行高"的占位。底衬只量得到看得见的网格。
 *     换算上，新结构里填充与网格同属一个自顶向下的栈，**P 行就是 P 行位移**
 *     （不再折半），常量侧对应地做了一次静态补偿（见 tools/pack/build-rp-ui.mjs
 *     的 HUD_OFFSET_Y）。所以本旋钮的**方向和范围不变**，同一取值下的绝对位置
 *     与旧版会有 (P-20)/2 行的差 —— 这是 JSON-UI 绑不了运行期 offset 造成的取舍。
 */
const TOP_PADDING_LINES = 20;

/**
 * 整块预览的**横向微调**，单位是"八分之一格"（正数往右，负数往左）。
 *
 * 该旋钮可行的原因：UI 锚点写在资源包里，标签是**居中**的，横向位置本来没有抓手；
 * 但引擎给字形算前进宽度时用的是**墨迹宽度**（见 tools/icons/build-item-glyphs.mjs
 * 的 paintInkFrame），于是可以插一个"只有一条 alpha=1 极淡墨迹、宽度任意"的占位字形
 * 当**空格尺**：
 *     行首插 N 个 → 内容整体右移 N/2
 *     行尾插 N 个 → 内容整体左移 N/2
 * （居中标签的总宽每增加 N，左边缘左移 N/2，而内容起点右移 N，净位移 +N/2；
 *   插在行尾则净位移 −N/2。）
 *
 * 图标层和数目层**必须插一样的尺子**，否则两层会错开 ——
 * 这一点由 scripts/format.js 里共用的 spacing 函数保证。
 *
 * 单位取 1/8 格：一格约 16 个 UI 单位宽，所以 1 单位≈2 个 UI 单位，够细也够用。
 * 范围见 scripts/tuning.js 的 MAX_HSPACE。
 */
const HSPACE_UNITS = 0;

/**
 * 实体检测的水平横向容差（格）。
 *
 * 判定量是**水平面内**"实体中心到视线的横向偏移"，只看左右偏多少，
 * **不把垂直方向算进去**。
 *
 * 排除垂直方向的原因：眼睛比地面上的矿车中心高约 1.62 格，所以垂直偏移恒 ≥ 1.62，
 * 任何合理容差都过不了；而"低头多少"本来就不该用来判断"有没有左右对准"。
 *
 * 取 1.0 的判别力（设矿车在正前方）：
 *   正前方 5 格、低头 20°  -> 偏移 0.33  通过
 *   正前方 5 格、不低头    -> 偏移 0.00  通过
 *   斜前方 2 格、低头 20°  -> 偏移 0.68  通过
 *   旁侧 2 格、不低头      -> 偏移 2.00  拒绝
 *   旁侧 4 格              -> 偏移 4.00  拒绝
 *
 * 想更容易瞄上就调大，想更严格就调小。
 */
const ENTITY_LATERAL_TOLERANCE = 1.0;

/**
 * 眼睛相对脚底的高度（格）。
 * 用于把"脚底位置"修正成视线真正的起点。
 */
const EYE_HEIGHT = 1.62;

/**
 * 实体检测的搜索半径（格）。比 REACH_DISTANCE 略大，
 * 因为矿车中心可能落在瞄准点稍后方。
 */
const ENTITY_SEARCH_RADIUS = 12;

/**
 * 支持的方块容器白名单（去掉 minecraft: 前缀后比较）。
 *
 * 注意：这里只是"允许尝试读取"。真正能不能读出内容，取决于该方块在引擎里
 * 是否挂有 minecraft:inventory 组件。所以白名单可以放宽，不会因此误报。
 */
const CONTAINER_BLOCK_IDS = [
  // 箱子类
  "chest",
  "trapped_chest",
  "barrel",
  // 潜影盒（全部颜色）
  "undyed_shulker_box",
  "white_shulker_box",
  "orange_shulker_box",
  "magenta_shulker_box",
  "light_blue_shulker_box",
  "yellow_shulker_box",
  "lime_shulker_box",
  "pink_shulker_box",
  "gray_shulker_box",
  "light_gray_shulker_box",
  "cyan_shulker_box",
  "purple_shulker_box",
  "blue_shulker_box",
  "brown_shulker_box",
  "green_shulker_box",
  "red_shulker_box",
  "black_shulker_box",
  // 红石容器
  "dispenser",
  "dropper",
  "hopper",
  "crafter",
  // 烧炼/酿造（异形布局，见 container_shapes.js）
  "furnace",
  "lit_furnace",
  "blast_furnace",
  "lit_blast_furnace",
  "smoker",
  "lit_smoker",
  "brewing_stand",
  // 下面两个不是 inventory 容器，在 target.js 里特殊处理（方块状态/组件）
  "composter",
  "jukebox"
];

/**
 * 支持的实体容器白名单（矿车是实体，不走方块路径）。
 * 用 EntityInventoryComponent 读取。
 */
const CONTAINER_ENTITY_IDS = [
  "chest_minecart",
  "hopper_minecart",
  // 运输船（带箱子的船）。
  // 新版按木种区分实体 id（oak_chest_boat 等）；旧版是单个 chest_boat
  // 实体 + 木种变体，所以两种写法都列上，命中哪个算哪个。
  "chest_boat",
  "oak_chest_boat",
  "spruce_chest_boat",
  "birch_chest_boat",
  "jungle_chest_boat",
  "acacia_chest_boat",
  "dark_oak_chest_boat",
  "mangrove_chest_boat",
  "cherry_chest_boat",
  "bamboo_chest_raft",
  "pale_oak_chest_boat"
];

/**
 * **屏幕上最多能容纳的总行数。这是整个高度预算的根参数。**
 *
 * 两条实测数据界定了量级：
 *   小箱子：1 标题 + 3 网格 + 8 物品 = 12 行 → **正常**
 *   大箱子：1 标题 + 6 网格 + 10 物品 = 17 行 → **从屏幕下面溢出**
 *
 * "屏幕能放几行"是唯一算不出来的参数，而且**跟设备有关**（屏幕高度、GUI 缩放、
 * 横竖屏都影响），所以做成计分板可调：
 *
 *   /scoreboard objectives add peek_lines dummy
 *   /scoreboard players set @s peek_lines 56
 *
 * 立刻生效。详见 scripts/tuning.js。
 *
 * **单位是"文本行"，不是"看得见的行"**：图标模式下每行物品还会插 ROW_GAP 个空行
 * （原因见 ROW_GAP 的说明 —— 字形高度远大于行高，不撑开就上下重叠）。
 * 所以**一行物品实际占 1 + ROW_GAP = 7 个文本行**。
 *
 * 取值依据（按格位排版的最大情形）：
 *   大箱子 6 行 x 7 + 标题 1 + 块间空隙 7 = **50 行**
 * 所以取 56 留一点余量。
 *
 * 文字是从锚点（屏幕中心上方 68px）**向下生长**的，屏幕上方那块空白用不上 ——
 * 锚点由原版 UI 固定，本模块不动 UI。所以高度不够只能靠减少行数，不能靠上移。
 *
 * 物品行的额度 = 本值 − 标题 − **网格实际行数**（网格会裁剪，所以能自适应）。
 */
const MAX_TOTAL_LINES = 56;

/**
 * 标题固定占 1 行。
 */
const TITLE_LINES = 1;

/**
 * 物品行的**绝对上限**（次要约束）。
 *
 * 真正决定能显示几行物品的是 MAX_TOTAL_LINES 减去标题和网格。
 * 这个值只是防止"网格关掉时"物品行无限膨胀。
 */
const MAX_ITEM_LINES = 10;

/**
 * 每行最多放多少个物品。**这是"用宽度换高度"唯一的旋钮。**
 *
 * ===== 为什么只留一个旋钮 =====
 *
 * 本值与 LINE_WIDTH_BUDGET 都是限制行宽的上限，两者会**互相遮挡**：撞到其中一个时，
 * 另一个怎么调都看不出变化，而调用方无法从显示结果判断是哪个在生效。
 * 所以现在只留本值，行宽默认不限制（LINE_WIDTH_BUDGET = 0）：本值往上加就一定能
 * 看到变化，直到行真的折行为止 —— 那一步才说明撞到了屏幕的真实宽度，反馈直接、可学。
 *
 * ===== 怎么调 =====
 *
 *   /scoreboard objectives add peek_per_line dummy
 *   /scoreboard players set @s peek_per_line 9
 *
 * 每次加 1，一旦出现"某一行被拆成两行"或整体从屏幕下面溢出，就往回退一格 ——
 * 那个值就是这台设备一行能放下的极限。
 *
 * ===== 默认值 9 的依据（实测）=====
 *
 * 在参考设备（Android 手机）上逐步加、逐格验证：**9 个刚好正常显示**，
 * 加到 10 就不行。所以 9 是该参考设备的**实测上限**，不是估算。
 *
 * 顺带把屏幕宽度也框出来了：9 个典型物品约 75~85 列，
 * 所以该设备的宽度上限大约在这个量级 —— 比早期估算的 43~50 列宽得多。
 *
 * 注意这个值是**设备相关**的：屏幕更小或竖屏时应该调小。换设备就重新试一遍。
 */
const ITEMS_PER_LINE = 9;

/**
 * 每行文字的**可选**列数上限。**0 = 不限制（默认）。**
 *
 * 单位：显示列数，一个汉字 = 2 列，一个字母 = 1 列。
 *
 * ===== 为什么默认关掉 =====
 *
 * 它和 `ITEMS_PER_LINE` 是两个会互相遮挡的上限：撞到其中一个时，另一个调了也没有
 * 反应，而两个上限无法从显示结果区分，只能逐个试。**两个上限互相遮挡本身就是设计
 * 错误** —— 所以默认关掉：调密度只认 `ITEMS_PER_LINE` 一个旋钮，加多少就显示多少，
 * 直到行真的折行为止。
 *
 * ===== 还想用的话 =====
 *
 * 只在"容器里塞满附魔金苹果这类超长名字、行宽得离谱"时才需要当保险：
 *
 *   /scoreboard objectives add peek_width dummy
 *   /scoreboard players set @s peek_width 48
 *
 * 设成 0 就是关掉。
 *
 * ===== 附：早期那个 32 是没有依据的 =====
 *
 * 曾定成 32，理由是"实测约 36 列会被截断"，而该推断不成立：那次截断实际由**行数
 * 溢出**造成（4 行物品 + 6 行网格早就超出屏幕高度），和宽度无关。
 * 也曾按高度反推过 48（14 行 + 横纵比 2.2:1 + 字符格宽 ≈ 行高 → 约 43~50 列），
 * 方向没错，但**不该把它变成一个会遮住另一个旋钮的硬上限**。
 */
const LINE_WIDTH_BUDGET = 0;

/**
 * 最多显示多少个物品（**纯安全上限**，正常不会碰到）。
 *
 * 真正的截断由 MAX_TOTAL_LINES（行数）决定。这个值只是防止极端情况下
 * 一次性排太多行、白算一遍。
 *
 * 取 64 是因为上限容器（大箱子 54 格）在行很宽时理论上能全部列出，
 * 安全上限不应反过来成为瓶颈。
 */
const MAX_ITEMS_SHOWN = 64;

/**
 * 物品之间的间隔。
 *
 * 用 1 个空格而不是 2 个：颜色已经把相邻物品分开了，多一个空格纯属浪费，
 * 而宽度直接决定一行能放几个。少一个空格往往就能多放一个物品。
 */
const ITEM_SEPARATOR = " ";

/**
 * 物品行之间的**空行数**。图标模式下这是**必需的**，不是装饰。
 *
 * ===== 为什么必须有它（引擎行为，反直觉但很关键）=====
 *
 * 把字形页的格子做大之后会出现一个不对称：
 *   - 字形的**横向前进宽度跟着格子走** —— 所以一行里 9 个图标不会横向挤在一起；
 *   - **行高是字体自己的度量**，跟着 `font_scale_factor` 走，**不跟格子走**。
 *
 * 于是格子放大到 64（为了清晰度）之后：
 *   字形高度 ≈ 格子倍数 x 基准高度 = 4 倍
 *   实际行高 ≈ font_scale_factor x 基准高度 = 0.25 倍
 * 两者差 16 倍 —— 相邻两行会**严重重叠**；而 actionbar 的黑色背景尺寸是按文字
 * 排版算的，于是只盖住一条缝。**这两个现象是同一个原因。**
 *
 * 补法是**插空行**，把行距撑回字形高度 —— 空行本身几乎没有高度，
 * 所以每行物品多占的那几行加起来才等于一个图标高。
 *
 * ===== 这个值是怎么定的 =====
 *
 * 结论：**6**（在 1.21.93 / Android 上把 `peek_gap` 从 2 试到 6，6 时行距正好）。
 *
 * 按"需要的空行数 = 字形高度 / 行高 - 1 ≈ 格子倍数 - 1 = 64/16 - 1 = 3"推导会得到 3，
 * 与实测不符：6 说明这个模型里"字形高度 / 行高"根本不是格子倍数（4），而更接近 **7**。
 * 也就是说：
 *   - 行高**不是**随 line-height 与 font_scale_factor 一起等比缩的常量假设；
 *   - 或者字形高度并不等于"格子倍数 x 基准高度"。
 * 具体是哪一种需要再做一次标定实验；在那之前**该值不能从格子尺寸反推** ——
 * 只能靠游戏里试（这正是把它做成 `peek_gap` 的理由）。该倍数关系涉及三个不透明的量
 * （字体行高度量、字形绘制尺寸、font_scale_factor 的作用面），只能量，推不出来。
 *
 * 代价：每行物品占 1 + 6 = 7 个文本行。空行本身只有很小的高度，
 * 所以 7 行加起来也不过一个图标那么高。
 */
const ROW_GAP = 6;

/**
 * 是否**按容器的真实格位**排版（默认开启）。
 *
 * true  = 一个槽位一格，空格位留空 —— 显示出来的形状就是容器的形状。
 *         物品在左下角，显示出来就在左下角。真正的"仿箱子页面"。
 * false = 紧凑排版：把物品按槽位顺序每行塞满（ITEMS_PER_LINE 个）。
 *         省高度，但**看不出位置**。
 *
 * 实现细节：
 *   - 空格位用 `blankGlyph()`（宽度和图标一格一样、肉眼不可见的字形），
 *     **不能用普通空格** —— 空格只有几像素宽，整张表会错列；
 *   - 显示的行数由**容器容量**决定（小箱子 3 行、大箱子 6 行），
 *     所以两种容器的形状本来就不同。
 *
 * **开启时 `SHOW_ITEM_NAMES` / `SHOW_ITEM_COUNTS` 不生效**：
 * 格位排版靠"每格宽度相同"对齐，而名字和数量的宽度跟字形差很多，
 * 带上它们整列都会错位。所以这个模式下每格只放图标。
 * 想要名字或数量，就把这个开关关掉、回到紧凑排版。
 */
const LAYOUT_AS_GRID = true;

/**
 * 是否在物品列表**上方**显示"位置网格"。**默认关闭。**
 *
 * 网格用原版实心方块字符 `▓` 表示容器里每个槽位的状态：
 *   彩色 = 有物品（颜色和下方物品一一对应）
 *   深灰 = 空格位
 *
 * 关闭的两个原因：
 *   1. 它是**原版字体**的字符，在这个 0.25 倍字号的 label 里跟着缩了 4 倍，
 *      只剩 2~3 像素，几乎看不清；
 *   2. 物品图标本身已经是"更直接的图片"，网格只是重复表达"哪一列有东西"。
 *
 * **连带效果（重要）**：关掉网格会同时关掉**按列上色**（见 formatItem 里的
 * `shouldColor`）。这是有意的 —— 上色原本是让网格色块和物品一一对应；
 * 网格没了，颜色就只剩"染色"这一个效果，而**染色会把图标本身的颜色改掉**
 * （比如钻石被染成列色）。关掉之后图标显示的是它自己的真实颜色，
 * 正好就是"更直接的物品图片"。
 *
 * 想恢复网格：把它设回 true 即可（连同按列上色一起回来）。更好的做法是改用
 * E5 那张 64 像素颜色页（scripts/grid_colors.js），那样网格会和图标同一个
 * 缩放体系、不会再偏小。
 */
const SHOW_SLOT_GRID = false;

/**
 * 是否用同一套颜色把网格格子和物品名对应起来。
 *
 * true  -> 网格是彩色的，物品名也染成同一个颜色，靠颜色对应
 * false -> 网格只是网格，物品名不着色
 */
const COLOR_LINK_GRID = true;

/**
 * 网格和物品名用哪种方式上色。
 *
 * true（默认） -> 用 `§` 文字颜色代码**直接改变文字颜色**。
 *                 已在 actionbar 上确认可正常解析渲染。
 *
 * false        -> 退回彩色方块字形（备用）。
 *                 文字本身不变色，靠每项前面的彩色方块对应。
 *
 * ===== 颜色怎么分配（这条最重要）=====
 *
 * **索引 = 列号**，不是"列表里的第几个"。
 * 所以第 1 列永远是第 0 种颜色，第 2 行第 1 列也是第 0 种颜色。
 *
 * 颜色一共 9 种（见 scripts/palette.js），正好对应标准容器的 9 列，
 * 一列一色、不需要轮换。同一列的多个物品会用同一种颜色 ——
 * 这时候要靠**名字**区分它们，颜色只能表达"在哪一列"。
 *
 * 如果想让"每个物品一个独立颜色、按显示顺序轮换"，需要改
 * scripts/format.js 里的 columnColorIndex()。
 */
const GRID_USE_COLOR_CODES = true;

/**
 * 网格格子的填充符号（配合 § 颜色代码使用时）。
 *
 * 用实心方块字符，染上物品对应的颜色；空格位用同一个字符染深灰。
 * 相邻字符之间留空格，避免视觉上连成一片。
 */
const GRID_FILL_CHAR = "▓";

/**
 * 是否在物品前面显示槽位（容器内的位置）。
 *
 * true  -> `槽位(1,2):钻石 x3`，能看出物品在容器里的排布
 * false（默认）-> 只显示 `钻石 x3`
 *
 * **默认关闭**：颜色已经按列对应（见 GRID_USE_COLOR_CODES 的说明），
 * 看颜色就知道物品在第几列，坐标是重复信息，而且每项多占 8 个字符宽
 * —— 窄屏被截断的主因就是它。
 *
 * 打开时格子位置用"行,列"表示（列从左到右、行从上到下，都从 1 数起）。
 */
const SHOW_SLOT_POSITION = false;

/**
 * 显示槽位时用的列数。
 *
 * 标准容器（箱子、木桶、潜影盒、大箱子）都是 9 列，
 * 所以行号 = 槽位 / 9 + 1。改成 0 会自动按容器实际容量推算。
 *
 * 注意：这个值同时决定**有几种颜色** —— 颜色索引就是列号。
 * 因此不宜随意修改：改了颜色含义会跟着变。
 */
const CONTAINER_COLUMNS = 9;

/**
 * 是否显示物品图标（字形）。
 *
 * **true（当前）** = 图标模式：每行 9 个图标，最接近"仿箱子页面"的观感。
 * false            = 纯文字模式：只有中文名和数量。
 *
 * 图标现在**是清晰的**，所以默认打开：
 *   1. 字形页用 64 像素格子 —— 16 像素下等轴方块的斜边只有 4 级台阶
 *      （实测行宽 2,6,10,14,16x8,14,10,6,2），锯齿来自分辨率不够，抗锯齿救不了；
 *   2. 引擎的字形显示尺寸跟着格子尺寸走（64 格子 = 16 格子的 4 倍），
 *      所以资源包里 ui/hud_screen.json 把 font_scale_factor 设成 0.25
 *      （= 16/64），把显示尺寸缩回原来那档。
 *
 * 两条缺一不可：只放大格子图标会变得很大，只缩字号又拿不到清晰度。
 * 详见 tools/icons/build-item-glyphs.mjs 与 tools/pack/build-rp-ui.mjs 的注释。
 */
const GLYPHS_ENABLED = true;

/**
 * 是否在图标后面显示中文物品名。
 *
 * **false（当前）** = 只显示 `<图标>x数量`：一行能放 9 个，最接近容器里那一格的样子。
 * true             = `<图标> 中文名 x数量`：更好认，但每行放不了几个、会多占行数。
 *
 * 纯文字模式下这个开关无意义（图标关了就一定显示名字）。
 *
 * 没有图标的物品**无论这个开关如何都会显示中文名**，否则无法辨认。
 */
const SHOW_ITEM_NAMES = false;

/**
 * 容器标题（第一行）是否显示名称。**默认关闭**：只显示容器图标。
 *
 * 关闭是用户实机看过之后的选择（原名"名字与图标同尺寸"已做到，但观感不合意）。
 * 整套字形机制都还在，想让标题行带名字，把这个开关打开即可 —— 下面的说明依旧成立。
 *
 * 打开时标题行拼成 `[容器图标][半格间隙][中文容器名]`。
 *
 * **名字是字形，不是普通文字。** 这一点很关键：标题行用的原版 label 被写上了
 * `font_scale_factor: 0.25`，普通中文在那个字号下只有 2~3 像素高，是看不清的
 * 残影 —— 这正是以前这里默认 false 的原因。
 *
 * 现在名字和物品图标走同一条路：每个汉字做成一个**64 像素格子**的字形
 * （字从游戏自带的 CJK 位图字体里切，见 tools/icons/container_name_glyphs_ref.js）。
 * 字形的显示尺寸跟着**格子尺寸**走，不受 font_scale_factor 影响，所以名字和
 * 图标显示成一样大；两者同属一条标签、同一个字号，也就不会对不齐。
 *
 * 容器名要用到的汉字是有限的一小撮（箱子/熔炉/潜影盒… 去重后 67 个），
 * 所以"中文不可能做成字形"这个从前的前提**在容器名这个场景下不成立** ——
 * 物品名有上千种、按整名做字形不现实；容器名只有几十个字，按**单字**做就够了。
 *
 * 关掉这个开关就退回"只显示容器图标"（旋钮见 scripts/tuning.js 的
 * `header`，对应计分板目标 peek_title；命令名叫 header 而不是 title，
 * 是因为 `/peek:title` 的自动别名会和**原版 `/title`** 撞名）。
 * 名字里万一有字没有字形，也会自动退回只显示图标 —— 不会显示残影。
 */
const SHOW_CONTAINER_NAME = false;

/**
 * 是否给预览画那块淡灰底衬。**默认关**（2026-09 用户拍板）。
 *
 * 游戏内用 `/peek:backdrop on|off` 切换（计分板目标 `peek_backdrop`，可持久化）。
 *
 * 关掉的实现很省：**不发形状字段**给资源包 —— 没有任何底衬变体命中，
 * 自然就不画灰区（预览正文照常显示）。所以这条开关不需要资源包配合。
 *
 * 为什么默认关：底衬的位置与尺寸都是**资源包里写死的**（只有文本能按运行期值挪），
 * 所以只要用了横向位移（`/peek:hspace`）、或改了行距（`/peek:gap`）、或遇到尺寸表没覆盖的
 * 容器，灰区就会与网格错开。默认关掉 = 默认不会看到一块错位的灰；想看底衬的人自己开。
 */
const SHOW_BACKDROP = false;

/**
 * 高亮信息显示（WAILA 式，**默认关**）：
 * 准星没看容器时，显示注视目标（任何方块/实体）的名字。
 * 开着会让 HUD 常驻有内容，所以做成开关。
 * 名字来自 scripts/item_names.js 的名字表，查不到就显示去前缀的 id。
 */
const HIGHLIGHT = false;

/**
 * **显示总开关**（`/peek:display on|off`，计分板 `peek_display`）。
 *
 * true（默认） = 正常预览。
 * false        = 本包**不再往 HUD 通道写任何东西**：先把 actionbar 与 title
 *                各清一次（actionbar 发一个空格 —— 空串会被引擎忽略，旧文本会
 *                留到原版淡出寿命结束，和"目标消失"那条路同一个理由），
 *                之后**只为显示存在的那部分每玩家工作全部跳过**：
 *                不再找容器、不再读容器内容、不再排版、不再发包。
 *
 * 关掉时**仍然**每轮读一次游戏内调参（计分板）：`peek_display` 就是靠这条路
 * 重新打开的，不读就永远开不回来。
 *
 * 为什么要有它（用户需求）：想看纯净画面、或者只想留着 WAILA 式高亮却嫌预览
 * 挡视线时，之前唯一的办法是把包卸掉。现在一条指令就能停，且和别的旋钮一样
 * 持久化（写计分板）。
 *
 * 注意这是**总**开关：关掉时高亮信息（HIGHLIGHT）也一起停 —— 两者写的是同一条
 * HUD 通道，"停掉写入"必须彻底，留一半会出现"关了还在闪"的怪现象。
 */
const DISPLAY_ENABLED = true;

/**
 * 物品后面是否显示数量（`x64`）。
 *
 * **默认关闭**，理由同上：数字是原版字体，在当前字号下只有 2~3 像素高，
 * 显示出来也读不了，只是徒增噪声。"仿箱子页面"要的是**物品图片**。
 *
 * 想把它做回来有办法：从原版 `font/default8.png` 里取出数字，
 * 4 倍最近邻放大进 64 像素格子做成**数字字形** —— 那样它就和物品图标
 * 同属一个缩放体系，会跟着一起放大。代价是每个数字占掉一格的宽度。
 */
const SHOW_ITEM_COUNTS = false;

/**
 * 诊断模式。
 *
 * true  = 输出诊断信息，主通道是**内容日志**
 *         （设置 → 创作者 → 内容日志），聊天栏通道默认不可用。
 * false = 正常模式，只显示 HUD。
 *
 * 会覆盖"脚本没加载 / 射线没命中 / 实体没找到 / setActionBar 失败"
 * 这几类故障，并打印每个物品的真实槽位号。
 *
 * 当前关闭：正常使用只需要 HUD 内容。要排查故障再打开。
 */
const DIAGNOSTICS = false;

/** 脚本启动后，诊断信息持续输出的 tick 窗口。4 tick 一次轮询，200 tick ≈ 10 秒。 */
const DIAGNOSTIC_TICKS = 200;

/**
 * 版本标记。每次改动实质逻辑时改一下。
 *
 * 它的唯一用途是回答"现在跑的到底是哪一份代码" ——
 * 排查时第一件该确认的事。诊断输出里会带上它。
 */
const BUILD_TAG = "b21-per-line-9";

/**
 * 诊断模式下，是否把当次读取的摘要附在 HUD 文本末尾。
 *
 * 之所以单独做这一条：聊天栏输出可能完全没出现（被运行环境吞掉），
 * 而 setActionBar 是唯一被证实可用的通道。所以让诊断"骑"在它上面。
 */
const DIAGNOSTIC_HUD_ECHO = true;

// ===== runtime_config.js =====
/**
 * LSE 插件版的"运行期配置"：**可变状态**（`/peek:*` 调参命令直接改这里的属性）。
 *
 * format.js 原本从 runtime_config.js 读开关，那份文件依赖 @minecraft/server。
 * 插件版不改 format.js，用这份配置替代，让核心排版逻辑原样复用 ——
 * 而 format.js / grid_shapes.js 读的是**属性**、不是常量，所以命令改完立刻生效。
 *
 * 取值对齐行为包的默认显示效果：
 *   格位排版开、位置网格开、中文物品名关（手机上太小）、
 *   彩色格位、图标开、行距 6、顶部填充 20、每行 9 格。
 *
 * ⚠️ 这里的默认值必须与 `settings.js` 的旋钮默认值一致（自测有一条断言盯着）：
 *    两处不一致时"/peek:reset 之后的实际效果"和"文档里写的默认值"就会对不上，
 *    而且不报任何错。
 */
const runtime = {
  DIAGNOSTICS: false,

  /**
   * **常规信息日志**（`/peek:log`，全局、持久化）：关掉后服务端控制台只在
   * "开机一行 + 命令回执 + 警告/错误"时才说话（见 llse_adapter.js 的三层日志说明）。
   * 热路径的细节日志本来就由 `/peek:trace` 单独控制、默认关。
   */
  INFO_LOG_ENABLED: true,

  // ===== 总开关（/peek:display、/peek:box）=====
  /** 准星预览总开关：关掉后不发预览、并清屏一次。 */
  PREVIEW_ENABLED: true,
  /** 潜影盒预览（容器界面里点盒子）总开关。 */
  BOX_PEEK_ENABLED: true,
  /**
   * **潜影盒角标**：箱子里那个盒子满足档位判据时，在盒子图标右下角画一张该物品的小图
   *（每人独立开关，见 settings.js 的 boxbadge）。
   * 关掉时**一次 NBT 都不读**（见 main.js 的 boxRecordsFor）。
   */
  BOX_BADGE_ENABLED: true,
  /**
   * 角标**档位**（/peek:badgelevel），判据实现在 box_content.js 的 badgeItemIdFor：
   *   low  = 盒里有东西就画**槽位最小**那件（混装也画）
   *   high = 盒里**只有一种**物品就画（不要求装满、不要求满堆）
   *   max  = 27 格全占满 + 只有一种 + **每格堆满**（按该物品自己的上限，16/1 堆叠的另算）
   */
  BADGE_LEVEL: "max",
  /**
   * 准星预览的**缩放档位**（`/peek:scale`）：`full` / `three4` / `half`。
   *
   * 字形显示尺寸由资源包的 `font_scale_factor` 决定（静态属性、脚本改不了），所以
   * 资源包为每个档位准备了一整套控件，脚本把这个档位写进 title 标记的一个字符里，
   * 客户端据此选那一套 —— 见 scripts/grid_shapes.js 的 `previewTitleField` 与
   * scripts/hud_protocol.js 的 `PREVIEW_STEP_CODES`。
   *
   * ⚠️ 潜影盒预览（容器界面左边缘那套）**不参与缩放**，一直是原始大小。
   */
  PREVIEW_SCALE: "full",
  /**
   * 底衬（淡灰背景）。**默认关**（与行为包同口径，见 scripts/config.js 的说明）：
   * 灰区的位置/尺寸写死在资源包里，只有文本能按运行期值挪 —— 用了 `/peek:hspace`
   * 或改了行距就会与网格错开，所以默认不要它。
   * 关掉时 `previewShapeToken` 会返回兜底形状（与"没有形状"等价）：资源包那边
   * 没有任何变体命中，于是不画灰区，**但缩放档位仍然生效**（档位码在那 5 字符字段的
   * 第一位，与形状无关）。
   */
  SHOW_BACKDROP: false,

  // 显示格式
  LAYOUT_AS_GRID: true,
  SHOW_SLOT_GRID: true,
  SHOW_SLOT_POSITION: false,
  COLOR_LINK_GRID: true,
  GRID_USE_COLOR_CODES: true,
  SHOW_ITEM_NAMES: false,
  SHOW_ITEM_COUNTS: true,
  SHOW_CONTAINER_NAME: false,
  GLYPHS_ENABLED: true,

  // 节奏（插件版主循环自己控制）
  //
  // 重发 2 tick（0.1 秒）而不是更松：预览的三条通道随时可能被引擎清掉
  //（打开容器/背包界面时会动 title 通道），重发越密，"落空"的窗口越短。
  POLL_INTERVAL_TICKS: 2,
  HUD_RESEND_TICKS: 2,
  HUD_REFRESH_TICKS: 8,

  // 排版预算
  MAX_TOTAL_LINES: 56,
  LINE_WIDTH_BUDGET: 400,
  ITEMS_PER_LINE: 9,
  ROW_GAP: 6,
  TOP_PADDING_LINES: 20,
  HSPACE_UNITS: 0,
  /** 潜影盒预览（左边缘那套）自己的位置，与准星预览分开（/peek:boxpos、/peek:boxhspace）。 */
  BOX_POS_LINES: 0,
  BOX_HSPACE_UNITS: 0,

  // 探测
  REACH_DISTANCE: 8
};

// ===== item_names_generated.js =====
/**
 * 物品中文名映射 —— **由 tools/icons/build-item-names.mjs 从原版 zh_CN.lang 自动生成**，手改会被下次生成覆盖。
 *
 * 来源：zh_CN.lang
 * 键取自 item.<typeId>.name 与 tile.<typeId>.name。
 *
 * 语言文件的键名和 typeId 常常不一致（tile.noteblock.name 对应 typeId
 * note_block），所以查名字用 officialDisplayName()，它先精确匹配、
 * 再去掉下划线规范化匹配。
 *
 * 想补充或修正个别名称，改 scripts/item_names.js 里的手工表，那张表优先。
 */

const OFFICIAL_ITEM_NAMES = {
  "acaciaFence": "金合欢木栅栏",
  "acacia_boat": "金合欢木船",
  "acacia_button": "金合欢木按钮",
  "acacia_chest_boat": "金合欢木运输船",
  "acacia_door": "金合欢木门",
  "acacia_double_slab": "金合欢木台阶",
  "acacia_fence": "金合欢木栅栏",
  "acacia_fence_gate": "金合欢木栅栏门",
  "acacia_hanging_sign": "金合欢悬挂告示牌",
  "acacia_leaves": "金合欢树叶",
  "acacia_log": "金合欢原木",
  "acacia_planks": "金合欢木板",
  "acacia_pressure_plate": "金合欢木压力板",
  "acacia_sapling": "金合欢树苗",
  "acacia_sign": "金合欢木告示牌",
  "acacia_slab": "金合欢木台阶",
  "acacia_stairs": "金合欢木楼梯",
  "acacia_standing_sign": "金合欢木告示牌",
  "acacia_trapdoor": "金合欢木活板门",
  "acacia_wood": "金合欢木",
  "activator_rail": "激活铁轨",
  "air": "空气",
  "allium": "绒球葱",
  "allow": "允许方块",
  "amethyst_block": "紫水晶方块",
  "amethyst_cluster": "紫水晶簇",
  "amethyst_shard": "紫水晶碎片",
  "ancient_debris": "远古残骸",
  "andesite": "安山岩",
  "andesite_double_slab": "安山岩台阶",
  "andesite_slab": "安山岩台阶",
  "andesite_stairs": "安山岩楼梯",
  "andesite_wall": "安山岩墙",
  "angler_pottery_sherd": "垂钓纹样陶片",
  "anvil": "铁砧",
  "apple": "苹果",
  "appleEnchanted": "附魔金苹果",
  "archer_pottery_sherd": "弓箭纹样陶片",
  "armadillo_scute": "犰狳鳞甲",
  "armor_stand": "盔甲架",
  "arms_up_pottery_sherd": "举臂纹样陶片",
  "arrow": "箭",
  "axolotlColorBlue": "蓝色",
  "axolotlColorCyan": "青色",
  "axolotlColorGold": "金色",
  "axolotlColorLucy": "白化",
  "axolotlColorWild": "棕色",
  "azalea": "杜鹃花",
  "azalea_leaves": "杜鹃花叶",
  "azalea_leaves_flowered": "盛开的杜鹃花树叶",
  "azure_bluet": "蓝花美耳草",
  "baked_potato": "烤马铃薯",
  "bamboo": "竹子",
  "bamboo_block": "竹子方块",
  "bamboo_button": "竹制按钮",
  "bamboo_chest_raft": "带宝箱的的竹筏",
  "bamboo_door": "竹门",
  "bamboo_double_slab": "竹制台阶",
  "bamboo_fence": "竹制围墙",
  "bamboo_fence_gate": "竹制围墙大门",
  "bamboo_hanging_sign": "竹制悬挂告示牌",
  "bamboo_mosaic": "竹制马赛克",
  "bamboo_mosaic_double_slab": "竹制马赛克台阶",
  "bamboo_mosaic_slab": "竹制马赛克台阶",
  "bamboo_mosaic_stairs": "竹制马赛克楼梯",
  "bamboo_planks": "竹板",
  "bamboo_pressure_plate": "竹制压力板",
  "bamboo_raft": "竹筏",
  "bamboo_sign": "竹制告示牌",
  "bamboo_slab": "竹制台阶",
  "bamboo_stairs": "竹制楼梯",
  "bamboo_trapdoor": "竹制活板门",
  "banner_pattern": "旗帜图案",
  "barrel": "木桶",
  "barrier": "屏障",
  "basalt": "玄武岩",
  "beacon": "信标",
  "bed": "床",
  "bedrock": "基岩",
  "bee_nest": "蜂巢",
  "beef": "生牛肉",
  "beehive": "蜂箱",
  "beetroot": "甜菜根",
  "beetroot_seeds": "甜菜种子",
  "beetroot_soup": "甜菜汤",
  "bell": "钟",
  "big_dripleaf": "大型垂滴叶",
  "birchFence": "白桦木栅栏",
  "birch_boat": "白桦木船",
  "birch_button": "白桦木按钮",
  "birch_chest_boat": "白桦木运输船",
  "birch_door": "白桦木门",
  "birch_double_slab": "白桦木台阶",
  "birch_fence": "白桦木栅栏",
  "birch_fence_gate": "白桦木栅栏门",
  "birch_hanging_sign": "白桦木悬挂告示牌",
  "birch_leaves": "桦树叶",
  "birch_log": "桦树原木",
  "birch_planks": "白桦木板",
  "birch_pressure_plate": "白桦木压力板",
  "birch_sapling": "桦树苗",
  "birch_sign": "白桦木告示牌",
  "birch_slab": "白桦木台阶",
  "birch_stairs": "白桦木楼梯",
  "birch_standing_sign": "白桦木告示牌",
  "birch_trapdoor": "白桦木活板门",
  "birch_wood": "白桦木",
  "black_candle": "黑色蜡烛",
  "black_candle_cake": "带黑色蜡烛的蛋糕",
  "black_carpet": "黑色地毯",
  "black_concrete": "黑色混凝土",
  "black_concrete_powder": "黑色混凝土粉末",
  "black_glazed_terracotta": "黑色带釉陶瓦",
  "black_harness": "黑色挽具",
  "black_stained_glass": "黑色玻璃",
  "black_stained_glass_pane": "黑色玻璃板",
  "black_terracotta": "黑色陶瓦",
  "black_wool": "黑色羊毛",
  "blackstone": "黑石",
  "blackstone_double_slab": "黑石台阶",
  "blackstone_slab": "黑石台阶",
  "blackstone_stairs": "黑石楼梯",
  "blackstone_wall": "黑石墙",
  "blade_pottery_sherd": "利刃纹样陶片",
  "blast_furnace": "高炉",
  "blaze_powder": "烈焰粉",
  "blaze_rod": "烈焰棒",
  "blue_candle": "蓝色蜡烛",
  "blue_candle_cake": "带蓝色蜡烛的蛋糕",
  "blue_carpet": "蓝色地毯",
  "blue_concrete": "蓝色混凝土",
  "blue_concrete_powder": "蓝色混凝土粉末",
  "blue_egg": "蓝色蛋",
  "blue_glazed_terracotta": "蓝色带釉陶瓦",
  "blue_harness": "蓝色挽具",
  "blue_ice": "蓝冰",
  "blue_orchid": "兰花",
  "blue_stained_glass": "蓝色玻璃",
  "blue_stained_glass_pane": "蓝色玻璃板",
  "blue_terracotta": "蓝色陶瓦",
  "blue_wool": "蓝色羊毛",
  "bolt_armor_trim_smithing_template": "镶铆盔甲纹饰",
  "bone": "骨头",
  "bone_block": "骨块",
  "book": "书",
  "bookshelf": "书架",
  "border_block": "边界方块",
  "bordure_indented_banner_pattern": "波纹边旗帜图案",
  "bow": "弓",
  "bowl": "碗",
  "brain_coral": "脑纹珊瑚",
  "brain_coral_block": "脑纹珊瑚块",
  "brain_coral_fan": "脑纹珊瑚扇",
  "bread": "面包",
  "breeze_rod": "旋风棒",
  "brewer_pottery_sherd": "佳酿纹样陶片",
  "brewing_stand": "酿造台",
  "brick": "红砖",
  "brick_block": "砖",
  "brick_double_slab": "砖台阶",
  "brick_slab": "砖台阶",
  "brick_stairs": "砖楼梯",
  "brick_wall": "砖墙",
  "brown_candle": "棕色蜡烛",
  "brown_candle_cake": "带棕色蜡烛的蛋糕",
  "brown_carpet": "棕色地毯",
  "brown_concrete": "棕色混凝土",
  "brown_concrete_powder": "棕色混凝土粉末",
  "brown_egg": "棕色蛋",
  "brown_glazed_terracotta": "棕色带釉陶瓦",
  "brown_harness": "棕色挽具",
  "brown_mushroom": "棕色蘑菇",
  "brown_mushroom_block": "蘑菇",
  "brown_stained_glass": "棕色玻璃",
  "brown_stained_glass_pane": "棕色玻璃板",
  "brown_terracotta": "棕色陶瓦",
  "brown_wool": "棕色羊毛",
  "brush": "刷子",
  "bubble_coral": "气泡珊瑚",
  "bubble_coral_block": "气泡珊瑚块",
  "bubble_coral_fan": "气泡珊瑚扇",
  "bucket": "桶",
  "bucketAxolotl": "美西螈桶",
  "bucketCustomFish": "桶装",
  "bucketFish": "桶装鳕鱼",
  "bucketLava": "熔岩桶",
  "bucketPowderSnow": "细雪桶",
  "bucketPuffer": "桶装河豚",
  "bucketSalmon": "桶装鲑鱼",
  "bucketTadpole": "蝌蚪桶",
  "bucketTropical": "桶装热带鱼",
  "bucketWater": "水桶",
  "budding_amethyst": "紫水晶母岩",
  "burn_pottery_sherd": "烈焰纹样陶片",
  "bush": "灌木",
  "cactus": "仙人掌",
  "cactus_flower": "仙人掌花",
  "cake": "蛋糕",
  "calcite": "方解石",
  "calibrated_sculk_sensor": "已校准潜声感测器",
  "camera": "摄像机",
  "campfire": "营火",
  "candle": "蜡烛",
  "candle_cake": "带蜡烛的蛋糕",
  "carpet": "地毯",
  "carrot": "胡萝卜",
  "carrotOnAStick": "胡萝卜钓竿",
  "carrot_on_a_stick": "胡萝卜钓竿",
  "carrots": "胡萝卜",
  "cartography_table": "制图台",
  "carved_pumpkin": "雕刻过的南瓜",
  "cauldron": "炼药锅",
  "cave_vines": "洞穴藤蔓",
  "cave_vines_body_with_berries": "洞穴藤蔓",
  "cave_vines_head_with_berries": "洞穴藤蔓",
  "chain": "锁链",
  "chain_command_block": "连锁型命令方块",
  "chainmail_boots": "链甲靴",
  "chainmail_chestplate": "链甲胸甲",
  "chainmail_helmet": "链甲头盔",
  "chainmail_leggings": "链甲护腿",
  "charcoal": "木炭",
  "cherry_boat": "樱花木船",
  "cherry_button": "樱花木按钮",
  "cherry_chest_boat": "樱花木运输船",
  "cherry_door": "樱花木门",
  "cherry_double_slab": "樱花木双台阶",
  "cherry_fence": "樱花木栅栏",
  "cherry_fence_gate": "樱花木栅栏门",
  "cherry_hanging_sign": "樱花木悬挂告示牌",
  "cherry_leaves": "樱花树叶",
  "cherry_log": "樱花原木",
  "cherry_planks": "樱花木板",
  "cherry_pressure_plate": "樱花木压力板",
  "cherry_sapling": "樱花树苗",
  "cherry_sign": "樱花木告示牌",
  "cherry_slab": "樱花木台阶",
  "cherry_stairs": "樱花木楼梯",
  "cherry_trapdoor": "樱花木活板门",
  "cherry_wood": "樱花木",
  "chest": "箱子",
  "chest_minecart": "运输矿车",
  "chicken": "生鸡肉",
  "chipped_anvil": "开裂的铁砧",
  "chiseled_bookshelf": "錾制书架",
  "chiseled_copper": "雕纹铜块",
  "chiseled_deepslate": "錾制深板岩",
  "chiseled_nether_bricks": "錾制下界砖",
  "chiseled_polished_blackstone": "錾制磨制黑石",
  "chiseled_quartz_block": "錾制石英块",
  "chiseled_red_sandstone": "錾制红砂岩",
  "chiseled_resin_bricks": "錾制树脂砖块",
  "chiseled_sandstone": "錾制砂岩",
  "chiseled_stone_bricks": "錾制石砖",
  "chiseled_tuff": "雕纹凝灰岩",
  "chiseled_tuff_bricks": "雕纹凝灰岩砖",
  "chorus_flower": "紫颂花",
  "chorus_fruit": "紫颂果",
  "chorus_fruit_popped": "爆裂紫颂果",
  "chorus_plant": "紫颂植株",
  "clay": "黏土",
  "clay_ball": "粘土球",
  "clock": "钟",
  "closed_eyeblossom": "合拢的眼眸花",
  "clownfish": "热带鱼",
  "coal": "煤炭",
  "coal_block": "煤炭块",
  "coal_ore": "煤矿石",
  "coarse_dirt": "砂土",
  "coast_armor_trim_smithing_template": "海岸盔甲纹饰",
  "cobbled_deepslate": "深板岩圆石",
  "cobbled_deepslate_double_slab": "深板岩圆石双台阶",
  "cobbled_deepslate_slab": "深板岩圆石台阶",
  "cobbled_deepslate_stairs": "深板岩圆石楼梯",
  "cobbled_deepslate_wall": "深板岩圆石墙",
  "cobblestone": "圆石",
  "cobblestone_double_slab": "圆石台阶",
  "cobblestone_slab": "圆石台阶",
  "cobblestone_wall": "圆石墙",
  "cocoa": "可可",
  "command_block": "命令方块",
  "command_block_minecart": "命令方块矿车",
  "comparator": "红石比较器",
  "compass": "指南针",
  "composter": "堆肥箱",
  "conduit": "潮涌核心",
  "cooked_beef": "牛排",
  "cooked_chicken": "熟鸡肉",
  "cooked_fish": "熟鳕鱼",
  "cooked_porkchop": "熟猪排",
  "cooked_rabbit": "熟兔肉",
  "cooked_salmon": "熟鲑鱼",
  "cookie": "曲奇",
  "copper_block": "铜方块",
  "copper_bulb": "铜灯泡",
  "copper_door": "铜门",
  "copper_grate": "铜格栅",
  "copper_ingot": "铜锭",
  "copper_ore": "铜矿石",
  "copper_trapdoor": "铜活板门",
  "cornflower": "矢车菊",
  "cracked_deepslate_bricks": "裂纹深板岩砖",
  "cracked_deepslate_tiles": "裂纹深板岩瓦",
  "cracked_nether_bricks": "裂纹下界砖",
  "cracked_polished_blackstone_bricks": "裂纹磨制黑石砖",
  "cracked_stone_bricks": "裂纹石砖",
  "crafter": "合成器",
  "crafting_table": "工作台",
  "creaking_heart": "嘎枝之心",
  "creeper_banner_pattern": "苦力怕头像旗帜图案",
  "creeper_head": "苦力怕的头",
  "crimson_button": "绯红木按钮",
  "crimson_door": "绯红木门",
  "crimson_double_slab": "绯红木台阶",
  "crimson_fence": "绯红木栅栏",
  "crimson_fence_gate": "绯红木栅栏门",
  "crimson_fungus": "绯红菌",
  "crimson_hanging_sign": "绯红木悬挂告示牌",
  "crimson_hyphae": "绯红菌核",
  "crimson_nylium": "绯红菌岩",
  "crimson_planks": "绯红木板",
  "crimson_pressure_plate": "绯红木压力板",
  "crimson_roots": "绯红菌索",
  "crimson_sign": "绯红木告示牌",
  "crimson_slab": "绯红木台阶",
  "crimson_stairs": "绯红木楼梯",
  "crimson_standing_sign": "绯红木告示牌",
  "crimson_stem": "绯红菌柄",
  "crimson_trapdoor": "绯红木活板门",
  "crimson_wall_sign": "绯红木告示牌",
  "crossbow": "弩",
  "crying_obsidian": "哭泣的黑曜石",
  "cut_copper": "切制铜块",
  "cut_copper_slab": "切制铜块台阶",
  "cut_copper_stairs": "切制铜楼梯",
  "cut_red_sandstone": "切制红砂岩",
  "cut_red_sandstone_slab": "切制红砂岩台阶",
  "cut_sandstone": "切制砂岩",
  "cut_sandstone_slab": "切制砂岩台阶",
  "cyan_candle": "青色蜡烛",
  "cyan_candle_cake": "带青色蜡烛的蛋糕",
  "cyan_carpet": "青色地毯",
  "cyan_concrete": "青色混凝土",
  "cyan_concrete_powder": "青色混凝土粉末",
  "cyan_glazed_terracotta": "青色带釉陶瓦",
  "cyan_harness": "青色挽具",
  "cyan_stained_glass": "青色玻璃",
  "cyan_stained_glass_pane": "青色玻璃板",
  "cyan_terracotta": "青色陶瓦",
  "cyan_wool": "青色羊毛",
  "damaged_anvil": "损坏的铁砧",
  "dandelion": "蒲公英",
  "danger_pottery_sherd": "危机纹样陶片",
  "darkOakFence": "深色橡木栅栏",
  "dark_oak_boat": "深色橡木船",
  "dark_oak_button": "深色橡木按钮",
  "dark_oak_chest_boat": "深色橡木运输船",
  "dark_oak_door": "深色橡木门",
  "dark_oak_double_slab": "深色橡木台阶",
  "dark_oak_fence": "深色橡木栅栏",
  "dark_oak_fence_gate": "深色橡木栅栏门",
  "dark_oak_hanging_sign": "深色橡木悬挂告示牌",
  "dark_oak_leaves": "深色橡树叶",
  "dark_oak_log": "深色橡树原木",
  "dark_oak_planks": "深色橡木板",
  "dark_oak_pressure_plate": "深色橡木压力板",
  "dark_oak_sapling": "深色橡树苗",
  "dark_oak_sign": "深色橡木告示牌",
  "dark_oak_slab": "深色橡木台阶",
  "dark_oak_stairs": "深色橡木楼梯",
  "dark_oak_trapdoor": "深色橡木活板门",
  "dark_oak_wood": "深色橡木",
  "dark_prismarine": "暗海晶石",
  "dark_prismarine_double_slab": "暗海晶石台阶",
  "dark_prismarine_slab": "暗海晶石台阶",
  "dark_prismarine_stairs": "暗海晶石楼梯",
  "darkoak_sign": "深色橡木告示牌",
  "darkoak_standing_sign": "深色橡木告示牌",
  "daylight_detector": "阳光探测器",
  "deadbush": "枯萎的灌木",
  "decorated_pot": "装饰罐",
  "deepslate": "深板岩",
  "deepslate_brick_double_slab": "深板岩砖双台阶",
  "deepslate_brick_slab": "深板岩砖台阶",
  "deepslate_brick_stairs": "深板岩砖楼梯",
  "deepslate_brick_wall": "深板岩砖墙",
  "deepslate_bricks": "深板岩砖",
  "deepslate_coal_ore": "深层煤矿石",
  "deepslate_copper_ore": "深层铜矿石",
  "deepslate_diamond_ore": "深层钻石矿石",
  "deepslate_emerald_ore": "深层绿宝石矿石",
  "deepslate_gold_ore": "深层金矿石",
  "deepslate_iron_ore": "深层铁矿石",
  "deepslate_lapis_ore": "深板岩青金石矿石",
  "deepslate_redstone_ore": "深层红石矿石",
  "deepslate_tile_double_slab": "深板岩瓦双台阶",
  "deepslate_tile_slab": "深板岩瓦台阶",
  "deepslate_tile_stairs": "深板岩瓦楼梯",
  "deepslate_tile_wall": "深板岩瓦墙",
  "deepslate_tiles": "深板岩瓦",
  "deny": "拒绝方块",
  "detector_rail": "探测铁轨",
  "diamond": "钻石",
  "diamond_axe": "钻石斧",
  "diamond_block": "钻石块",
  "diamond_boots": "钻石靴子",
  "diamond_chestplate": "钻石胸甲",
  "diamond_helmet": "钻石头盔",
  "diamond_hoe": "钻石锄",
  "diamond_leggings": "钻石护腿",
  "diamond_ore": "钻石矿石",
  "diamond_pickaxe": "钻石镐",
  "diamond_shovel": "钻石锹",
  "diamond_sword": "钻石剑",
  "diorite": "闪长岩",
  "diorite_double_slab": "闪长岩台阶",
  "diorite_slab": "闪长岩台阶",
  "diorite_stairs": "闪长岩楼梯",
  "diorite_wall": "闪长岩墙",
  "dirt": "泥土",
  "dirt_with_roots": "缠根泥土",
  "disc_fragment": "唱片残片",
  "disc_fragment_5": "唱片 - 5",
  "dispenser": "发射器",
  "doorWood": "木门",
  "double_cut_copper_slab": "切制铜块台阶",
  "double_plant": "植物",
  "double_stone_slab": "石台阶",
  "double_wooden_slab": "木台阶",
  "dragon_breath": "龙息",
  "dragon_egg": "龙蛋",
  "dragon_head": "龙首",
  "dried_ghast": "脱水恶魂",
  "dried_kelp": "干海带",
  "dried_kelp_block": "干海带块",
  "dripstone_block": "滴水石块",
  "dropper": "投掷器",
  "dune_armor_trim_smithing_template": "沙丘盔甲纹饰",
  "echo_shard": "回响碎片",
  "egg": "鸡蛋",
  "elytra": "鞘翅",
  "emerald": "绿宝石",
  "emerald_block": "绿宝石块",
  "emerald_ore": "绿宝石矿石",
  "emptyLocatorMap": "空定位器地图",
  "emptyMap": "空地图",
  "enchanted_book": "附魔书",
  "enchanting_table": "附魔台",
  "end_brick_stairs": "末地石砖楼梯",
  "end_bricks": "末地石砖",
  "end_crystal": "末地水晶",
  "end_portal_frame": "末地传送门框架",
  "end_rod": "末地烛",
  "end_stone": "末地石",
  "end_stone_brick_double_slab": "末地石砖台阶",
  "end_stone_brick_slab": "末地石砖台阶",
  "end_stone_brick_wall": "末地石砖墙",
  "enderChest": "末影箱",
  "ender_chest": "末影箱",
  "ender_eye": "末影之眼",
  "ender_pearl": "末影珍珠",
  "experience_bottle": "附魔之瓶",
  "explorer_pottery_sherd": "探险纹样陶片",
  "exposed_chiseled_copper": "外露錾制铜块",
  "exposed_copper": "斑驳的铜块",
  "exposed_copper_bulb": "外露铜灯泡",
  "exposed_copper_door": "外露铜门",
  "exposed_copper_grate": "外露铜格栅",
  "exposed_copper_trapdoor": "外露铜活板门",
  "exposed_cut_copper": "外露切制铜块",
  "exposed_cut_copper_slab": "外露切制铜块台阶",
  "exposed_cut_copper_stairs": "外露切制铜楼梯",
  "exposed_double_cut_copper_slab": "外露切制铜块台阶",
  "eye_armor_trim_smithing_template": "眼眸盔甲纹饰",
  "farmland": "耕地",
  "feather": "羽毛",
  "fence": "橡木栅栏",
  "fence_gate": "橡木栅栏门",
  "fermented_spider_eye": "发酵蛛眼",
  "fern": "蕨",
  "field_masoned_banner_pattern": "砖纹旗帜图案",
  "fire": "火",
  "fire_coral": "火珊瑚",
  "fire_coral_block": "火珊瑚块",
  "fire_coral_fan": "火珊瑚扇",
  "fireball": "火焰弹",
  "firefly_bush": "萤火虫灌木",
  "fireworks": "焰火火箭",
  "fireworksCharge": "焰火之星",
  "fireworks_charge": "焰火之星",
  "fish": "生鳕鱼",
  "fishing_rod": "钓鱼竿",
  "fletching_table": "制箭台",
  "flint": "燧石",
  "flint_and_steel": "打火石",
  "flow_armor_trim_smithing_template": "涡流盔甲纹饰",
  "flow_banner_pattern": "涡流旗帜图案",
  "flow_pottery_sherd": "涡流纹样陶片",
  "flower_banner_pattern": "花朵图案旗帜图案",
  "flower_pot": "花盆",
  "flowering_azalea": "盛开的杜鹃花",
  "flowing_lava": "熔岩",
  "flowing_water": "水",
  "frame": "物品展示框",
  "friend_pottery_sherd": "挚友纹样陶片",
  "frog_spawn": "青蛙卵",
  "frosted_ice": "冰霜",
  "furnace": "熔炉",
  "ghast_tear": "恶魂之泪",
  "gilded_blackstone": "镶金黑石",
  "glass": "玻璃",
  "glass_bottle": "玻璃瓶",
  "glass_pane": "玻璃板",
  "glazedTerracottaBlack": "黑色带釉陶瓦",
  "glazedTerracottaBlue": "蓝色带釉陶瓦",
  "glazedTerracottaBrown": "棕色带釉陶瓦",
  "glazedTerracottaCyan": "青色带釉陶瓦",
  "glazedTerracottaGray": "灰色带釉陶瓦",
  "glazedTerracottaGreen": "绿色带釉陶瓦",
  "glazedTerracottaLightBlue": "淡蓝色带釉陶瓦",
  "glazedTerracottaLime": "黄绿色带釉陶瓦",
  "glazedTerracottaMagenta": "品红色带釉陶瓦",
  "glazedTerracottaOrange": "橙色带釉陶瓦",
  "glazedTerracottaPink": "粉红色带釉陶瓦",
  "glazedTerracottaPurple": "紫色带釉陶瓦",
  "glazedTerracottaRed": "红色带釉陶瓦",
  "glazedTerracottaSilver": "淡灰色带釉陶瓦",
  "glazedTerracottaWhite": "白色带釉陶瓦",
  "glazedTerracottaYellow": "黄色带釉陶瓦",
  "globe_banner_pattern": "地球旗帜图案",
  "glow_berries": "发光浆果",
  "glow_frame": "荧光物品展示框",
  "glow_ink_sac": "荧光墨囊",
  "glow_lichen": "发光地衣",
  "glowstone": "荧石",
  "glowstone_dust": "荧石粉",
  "goat_horn": "山羊角",
  "gold_block": "金块",
  "gold_ingot": "金锭",
  "gold_nugget": "金粒",
  "gold_ore": "金矿石",
  "golden_apple": "金苹果",
  "golden_axe": "金斧",
  "golden_boots": "金靴子",
  "golden_carrot": "金胡萝卜",
  "golden_chestplate": "金胸甲",
  "golden_helmet": "金头盔",
  "golden_hoe": "金锄",
  "golden_leggings": "金护腿",
  "golden_pickaxe": "金镐",
  "golden_rail": "动力铁轨",
  "golden_shovel": "金锹",
  "golden_sword": "金剑",
  "granite": "花岗岩",
  "granite_double_slab": "花岗岩台阶",
  "granite_slab": "花岗岩台阶",
  "granite_stairs": "花岗岩楼梯",
  "granite_wall": "花岗岩墙",
  "grass": "草方块",
  "grass_path": "土径",
  "gravel": "砂砾",
  "gray_candle": "灰色蜡烛",
  "gray_candle_cake": "带灰色蜡烛的蛋糕",
  "gray_carpet": "灰色地毯",
  "gray_concrete": "灰色混凝土",
  "gray_concrete_powder": "灰色混凝土粉末",
  "gray_glazed_terracotta": "灰色带釉陶瓦",
  "gray_harness": "灰色挽具",
  "gray_stained_glass": "灰色玻璃",
  "gray_stained_glass_pane": "灰色玻璃板",
  "gray_terracotta": "灰色陶瓦",
  "gray_wool": "灰色羊毛",
  "green_candle": "绿色蜡烛",
  "green_candle_cake": "带绿色蜡烛的蛋糕",
  "green_carpet": "绿色地毯",
  "green_concrete": "绿色混凝土",
  "green_concrete_powder": "绿色混凝土粉末",
  "green_glazed_terracotta": "绿色带釉陶瓦",
  "green_harness": "绿色挽具",
  "green_stained_glass": "绿色玻璃",
  "green_stained_glass_pane": "绿色玻璃板",
  "green_terracotta": "绿色陶瓦",
  "green_wool": "绿色羊毛",
  "grindstone": "砂轮",
  "gunpowder": "火药",
  "guster_banner_pattern": "旋风旗帜图案",
  "guster_pottery_sherd": "旋风纹样陶片",
  "hanging_roots": "垂根",
  "hardened_clay": "陶瓦",
  "hay_block": "干草块",
  "heart_of_the_sea": "海洋之心",
  "heart_pottery_sherd": "爱心纹样陶片",
  "heartbreak_pottery_sherd": "心碎纹样陶片",
  "heavy_core": "沉重核心",
  "heavy_weighted_pressure_plate": "重质测重压力板",
  "honey_block": "蜂蜜方块",
  "honey_bottle": "蜂蜜瓶",
  "honeycomb": "蜜脾",
  "honeycomb_block": "蜜脾块",
  "hopper": "漏斗",
  "hopper_minecart": "漏斗矿车",
  "horn_coral": "鹿角珊瑚",
  "horn_coral_block": "鹿角珊瑚块",
  "horn_coral_fan": "鹿角珊瑚扇",
  "horsearmordiamond": "钻石马铠",
  "horsearmorgold": "黄金马铠",
  "horsearmoriron": "铁马铠",
  "horsearmorleather": "皮革马铠",
  "host_armor_trim_smithing_template": "雇主盔甲纹饰",
  "howl_pottery_sherd": "狼嚎纹样陶片",
  "ice": "冰",
  "infested_chiseled_stone_bricks": "被虫蚀的錾制石砖",
  "infested_cobblestone": "被虫蚀的圆石",
  "infested_cracked_stone_bricks": "被虫蚀的裂纹石砖",
  "infested_deepslate": "被虫蚀的深板岩",
  "infested_mossy_stone_bricks": "被虫蚀的苔石砖",
  "infested_stone": "被虫蚀的石头",
  "infested_stone_bricks": "虫蚀石砖",
  "invisibleBedrock": "隐形基岩",
  "iron_axe": "铁斧",
  "iron_bars": "铁栏杆",
  "iron_block": "铁块",
  "iron_boots": "铁靴子",
  "iron_chestplate": "铁胸甲",
  "iron_door": "铁门",
  "iron_helmet": "铁头盔",
  "iron_hoe": "铁锄",
  "iron_ingot": "铁锭",
  "iron_leggings": "铁护腿",
  "iron_nugget": "铁粒",
  "iron_ore": "铁矿石",
  "iron_pickaxe": "铁镐",
  "iron_shovel": "铁锹",
  "iron_sword": "铁剑",
  "iron_trapdoor": "铁活板门",
  "jigsaw": "拼图方块",
  "jukebox": "唱片机",
  "jungleFence": "丛林木栅栏",
  "jungle_boat": "丛林木船",
  "jungle_button": "丛林木按钮",
  "jungle_chest_boat": "丛林木运输船",
  "jungle_door": "丛林木门",
  "jungle_double_slab": "丛林木台阶",
  "jungle_fence": "丛林木栅栏",
  "jungle_fence_gate": "丛林木栅栏门",
  "jungle_hanging_sign": "丛林悬挂告示牌",
  "jungle_leaves": "丛林树叶",
  "jungle_log": "丛林原木",
  "jungle_planks": "丛林木板",
  "jungle_pressure_plate": "丛林木压力板",
  "jungle_sapling": "丛林树苗",
  "jungle_sign": "丛林木告示牌",
  "jungle_slab": "丛林木台阶",
  "jungle_stairs": "丛林木楼梯",
  "jungle_standing_sign": "丛林木告示牌",
  "jungle_trapdoor": "丛林木活板门",
  "jungle_wood": "丛林木",
  "kelp": "海带",
  "ladder": "梯子",
  "lantern": "灯",
  "lapis_block": "青金石块",
  "lapis_ore": "青金石矿石",
  "large_amethyst_bud": "大型紫晶芽",
  "large_fern": "大型蕨",
  "lava": "熔岩",
  "lead": "拴绳",
  "leaf_litter": "落叶堆",
  "leather": "皮革",
  "leather_boots": "皮革靴子",
  "leather_chestplate": "皮革胸甲",
  "leather_helmet": "皮革帽子",
  "leather_leggings": "皮革裤子",
  "leaves": "树叶",
  "lectern": "讲台",
  "lever": "拉杆",
  "light_block": "浅色",
  "light_blue_candle": "淡蓝色蜡烛",
  "light_blue_candle_cake": "带淡蓝色蜡烛的蛋糕",
  "light_blue_carpet": "淡蓝色地毯",
  "light_blue_concrete": "淡蓝色混凝土",
  "light_blue_concrete_powder": "淡蓝色混凝土粉末",
  "light_blue_glazed_terracotta": "淡蓝色带釉陶瓦",
  "light_blue_harness": "淡蓝色挽具",
  "light_blue_stained_glass": "淡蓝色玻璃",
  "light_blue_stained_glass_pane": "淡蓝色玻璃板",
  "light_blue_terracotta": "淡蓝色陶瓦",
  "light_blue_wool": "淡蓝色羊毛",
  "light_gray_candle": "淡灰色蜡烛",
  "light_gray_candle_cake": "带淡灰色蜡烛的蛋糕",
  "light_gray_carpet": "淡灰色地毯",
  "light_gray_concrete": "淡灰色混凝土",
  "light_gray_concrete_powder": "淡灰色混凝土粉末",
  "light_gray_harness": "淡灰色挽具",
  "light_gray_stained_glass": "淡灰色玻璃",
  "light_gray_stained_glass_pane": "淡灰色玻璃板",
  "light_gray_terracotta": "淡灰色陶瓦",
  "light_gray_wool": "淡灰色羊毛",
  "light_weighted_pressure_plate": "轻质测重压力板",
  "lightning_rod": "避雷针",
  "lilac": "丁香",
  "lily_of_the_valley": "铃兰",
  "lime_candle": "黄绿色蜡烛",
  "lime_candle_cake": "带黄绿色蜡烛的蛋糕",
  "lime_carpet": "黄绿色地毯",
  "lime_concrete": "黄绿色混凝土",
  "lime_concrete_powder": "黄绿色混凝土粉末",
  "lime_glazed_terracotta": "黄绿色带釉陶瓦",
  "lime_harness": "黄绿色挽具",
  "lime_stained_glass": "黄绿色玻璃",
  "lime_stained_glass_pane": "黄绿色玻璃板",
  "lime_terracotta": "黄绿色陶瓦",
  "lime_wool": "黄绿色羊毛",
  "lit_pumpkin": "南瓜灯",
  "lockedchest": "上锁的箱子",
  "lodestone": "磁石",
  "lodestonecompass": "磁石指南针",
  "log": "原木",
  "loom": "织布机",
  "mace": "重锤",
  "magenta_candle": "品红色蜡烛",
  "magenta_candle_cake": "带品红色蜡烛的蛋糕",
  "magenta_carpet": "品红色地毯",
  "magenta_concrete": "品红色混凝土",
  "magenta_concrete_powder": "品红色混凝土粉末",
  "magenta_glazed_terracotta": "品红色带釉陶瓦",
  "magenta_harness": "品红色挽具",
  "magenta_stained_glass": "品红色玻璃",
  "magenta_stained_glass_pane": "品红色玻璃板",
  "magenta_terracotta": "品红色陶瓦",
  "magenta_wool": "品红色羊毛",
  "magma": "岩浆块",
  "magma_cream": "岩浆膏",
  "mangrove_boat": "红树木船",
  "mangrove_button": "红树木按钮",
  "mangrove_chest_boat": "红树木运输船",
  "mangrove_door": "红树木门",
  "mangrove_double_slab": "红树木台阶",
  "mangrove_fence": "红树木栅栏",
  "mangrove_fence_gate": "红树木栅栏大门",
  "mangrove_hanging_sign": "红树林悬挂告示牌",
  "mangrove_leaves": "红树木树叶",
  "mangrove_log": "红树木原木",
  "mangrove_planks": "红树木木板",
  "mangrove_pressure_plate": "红树木压力板",
  "mangrove_propagule": "红树木繁殖体",
  "mangrove_roots": "红树木根",
  "mangrove_sign": "红树木告示牌",
  "mangrove_slab": "红树木台阶",
  "mangrove_stairs": "红树木楼梯",
  "mangrove_trapdoor": "红树木活板门",
  "mangrove_wood": "红树木木材",
  "map": "地图",
  "medium_amethyst_bud": "中型紫晶芽",
  "melon": "西瓜片",
  "melon_block": "西瓜",
  "melon_seeds": "西瓜种子",
  "milk": "牛奶桶",
  "minecart": "矿车",
  "minecartFurnace": "动力矿车",
  "minecart_furnace": "动力矿车",
  "miner_pottery_sherd": "采矿纹样陶片",
  "mob_spawner": "刷怪笼",
  "mojang_banner_pattern": "Mojang 徽标旗帜图案",
  "monster_egg": "被虫蚀的石头",
  "moss_block": "苔藓块",
  "moss_carpet": "苔藓地毯",
  "mossy_cobblestone": "苔石",
  "mossy_cobblestone_double_slab": "苔石台阶",
  "mossy_cobblestone_slab": "苔石台阶",
  "mossy_cobblestone_stairs": "苔圆石楼梯",
  "mossy_cobblestone_wall": "苔石墙",
  "mossy_stone_brick_slab": "苔石砖台阶",
  "mossy_stone_brick_stairs": "苔石砖楼梯",
  "mossy_stone_brick_wall": "苔石砖墙",
  "mossy_stone_bricks": "苔石砖",
  "mourner_pottery_sherd": "哀悼纹样陶片",
  "mud": "泥巴",
  "mud_brick_double_slab": "泥砖台阶",
  "mud_brick_slab": "泥砖台阶",
  "mud_brick_stairs": "泥砖楼梯",
  "mud_brick_wall": "泥砖墙",
  "mud_bricks": "泥砖",
  "muddy_mangrove_roots": "沾泥的红树木根",
  "mushroom": "蘑菇",
  "mushroom_stem": "蘑菇柄",
  "mushroom_stew": "蘑菇煲",
  "music_disc_11": "C418 - 11",
  "music_disc_13": "C418 - 13",
  "music_disc_5": "塞缪尔·阿伯格 - 5",
  "music_disc_blocks": "C418 - blocks",
  "music_disc_cat": "C418 - cat",
  "music_disc_chirp": "C418 - chirp",
  "music_disc_creator": "莉娜·雷恩 - 创作者",
  "music_disc_creator_music_box": "莉娜·雷恩 - 创作者（音乐盒）",
  "music_disc_far": "C418 - far",
  "music_disc_mall": "C418 - mall",
  "music_disc_mellohi": "C418 - mellohi",
  "music_disc_otherside": "莉娜·雷恩 - otherside",
  "music_disc_pigstep": "莉娜·雷恩 - Pigstep",
  "music_disc_precipice": "亚伦·切罗夫 - 峭壁",
  "music_disc_relic": "亚伦·切罗夫 - Relic",
  "music_disc_stal": "C418 - stal",
  "music_disc_strad": "C418 - strad",
  "music_disc_tears": "Amos Roddy - 泪水",
  "music_disc_wait": "C418 - wait",
  "music_disc_ward": "C418 - ward",
  "muttonCooked": "熟羊肉",
  "muttonRaw": "生羊肉",
  "mutton_cooked": "熟羊肉",
  "mutton_raw": "生羊肉",
  "mycelium": "菌丝",
  "name_tag": "命名牌",
  "nautilus_shell": "鹦鹉螺壳",
  "netherStar": "下界之星",
  "nether_brick": "下界砖",
  "nether_brick_double_slab": "下界砖台阶",
  "nether_brick_fence": "下界砖栅栏",
  "nether_brick_slab": "下界砖台阶",
  "nether_brick_stairs": "下界砖楼梯",
  "nether_brick_wall": "下界砖墙",
  "nether_gold_ore": "下界金矿石",
  "nether_sprouts": "下界苗",
  "nether_star": "下界之星",
  "nether_wart": "下界疣",
  "nether_wart_block": "下界疣方块",
  "netherbrick": "下界砖",
  "netherite_axe": "下界合金斧头",
  "netherite_block": "下界合金块",
  "netherite_boots": "下界合金靴子",
  "netherite_chestplate": "下界合金胸甲",
  "netherite_helmet": "下界合金头盔",
  "netherite_hoe": "下界合金锄头",
  "netherite_ingot": "下界合金锭",
  "netherite_leggings": "下界合金护腿",
  "netherite_pickaxe": "下界合金镐",
  "netherite_scrap": "下界合金碎片",
  "netherite_shovel": "下界合金锹",
  "netherite_sword": "下界合金剑",
  "netherite_upgrade_smithing_template": "下界合金升级",
  "netherrack": "下界岩",
  "netherreactor": "下界反应核",
  "normal_stone_slab": "平滑石台阶",
  "normal_stone_stairs": "石质楼梯",
  "noteblock": "音符盒",
  "oak_boat": "橡木船",
  "oak_button": "橡木按钮",
  "oak_chest_boat": "橡木运输船",
  "oak_door": "橡木门",
  "oak_double_slab": "橡木台阶",
  "oak_fence": "橡木栅栏",
  "oak_fence_gate": "橡木栅栏门",
  "oak_hanging_sign": "橡木悬挂告示牌",
  "oak_leaves": "橡树叶",
  "oak_log": "橡树原木",
  "oak_planks": "橡木板",
  "oak_pressure_plate": "橡木压力板",
  "oak_sapling": "橡树苗",
  "oak_sign": "橡木告示牌",
  "oak_slab": "橡木台阶",
  "oak_stairs": "橡木楼梯",
  "oak_trapdoor": "橡木活板门",
  "oak_wood": "橡木",
  "observer": "侦测器",
  "obsidian": "黑曜石",
  "ochre_froglight": "赭黄蛙明灯",
  "ominous_bottle": "不祥之瓶",
  "ominous_trial_key": "不祥试炼钥匙",
  "open_eyeblossom": "绽放的眼眸花",
  "orange_candle": "橙色蜡烛",
  "orange_candle_cake": "带橙色蜡烛的蛋糕",
  "orange_carpet": "橙色地毯",
  "orange_concrete": "橙色混凝土",
  "orange_concrete_powder": "橙色混凝土粉末",
  "orange_glazed_terracotta": "橙色带釉陶瓦",
  "orange_harness": "橙色挽具",
  "orange_stained_glass": "橙色玻璃",
  "orange_stained_glass_pane": "橙色玻璃板",
  "orange_terracotta": "橙色陶瓦",
  "orange_tulip": "橙色郁金香",
  "orange_wool": "橙色羊毛",
  "oreRuby": "红宝石矿石",
  "oxeye_daisy": "滨菊",
  "oxidized_chiseled_copper": "氧化錾制铜",
  "oxidized_copper": "氧化的铜块",
  "oxidized_copper_bulb": "氧化铜灯泡",
  "oxidized_copper_door": "氧化铜门",
  "oxidized_copper_grate": "氧化铜格栅",
  "oxidized_copper_trapdoor": "氧化铜活板门",
  "oxidized_cut_copper": "氧化切制铜块",
  "oxidized_cut_copper_slab": "氧化切制铜块台阶",
  "oxidized_cut_copper_stairs": "氧化切制铜楼梯",
  "oxidized_double_cut_copper_slab": "氧化切制铜块台阶",
  "packed_ice": "浮冰",
  "packed_mud": "填充泥浆",
  "painting": "画",
  "pale_hanging_moss": "苍白垂须",
  "pale_moss_block": "苍白苔藓块",
  "pale_moss_carpet": "苍白苔藓地毯",
  "pale_oak_boat": "苍白橡木船",
  "pale_oak_button": "苍白橡木按钮",
  "pale_oak_chest_boat": "苍白橡树运输船",
  "pale_oak_door": "苍白橡木门",
  "pale_oak_double_slab": "苍白橡木双台阶",
  "pale_oak_fence": "苍白橡木栅栏",
  "pale_oak_fence_gate": "苍白橡木栅栏大门",
  "pale_oak_hanging_sign": "苍白橡木悬挂告示牌",
  "pale_oak_leaves": "苍白橡木树叶",
  "pale_oak_log": "苍白橡树原木",
  "pale_oak_planks": "苍白橡木木板",
  "pale_oak_pressure_plate": "苍白橡木压力板",
  "pale_oak_sapling": "苍白橡木树苗",
  "pale_oak_sign": "苍白橡木告示牌",
  "pale_oak_slab": "苍白橡木台阶",
  "pale_oak_stairs": "苍白橡木楼梯",
  "pale_oak_trapdoor": "苍白橡木活板门",
  "pale_oak_wood": "苍白橡木",
  "paper": "纸",
  "pearlescent_froglight": "珠光蛙明灯",
  "peony": "牡丹",
  "petrified_oak_double_slab": "石化橡木台阶",
  "petrified_oak_slab": "石化橡木台阶",
  "phantom_membrane": "幻翼膜",
  "photo": "照片",
  "piglin_banner_pattern": "猪鼻旗帜图案",
  "piglin_head": "猪灵头颅",
  "pink_candle": "粉红色蜡烛",
  "pink_candle_cake": "带粉红色蜡烛的蛋糕",
  "pink_carpet": "粉红色地毯",
  "pink_concrete": "粉红色混凝土",
  "pink_concrete_powder": "粉红色混凝土粉末",
  "pink_glazed_terracotta": "粉红色带釉陶瓦",
  "pink_harness": "粉红色挽具",
  "pink_petals": "粉红色花瓣",
  "pink_stained_glass": "粉红色玻璃",
  "pink_stained_glass_pane": "粉红色玻璃板",
  "pink_terracotta": "粉红色陶瓦",
  "pink_tulip": "粉红色郁金香",
  "pink_wool": "粉红色羊毛",
  "piston": "活塞",
  "pitcher_plant": "猪笼草",
  "pitcher_pod": "猪笼草荚果",
  "planks": "木板",
  "player_head": "玩家头颅",
  "plenty_pottery_sherd": "富饶纹样陶片",
  "podzol": "灰化土",
  "pointed_dripstone": "滴水石锥",
  "poisonous_potato": "毒马铃薯",
  "polished_andesite": "磨制安山岩",
  "polished_andesite_double_slab": "磨制安山岩台阶",
  "polished_andesite_slab": "磨制安山岩台阶",
  "polished_andesite_stairs": "磨制安山岩楼梯",
  "polished_basalt": "磨制玄武岩",
  "polished_blackstone": "磨制黑石",
  "polished_blackstone_brick_double_slab": "磨制黑石砖台阶",
  "polished_blackstone_brick_slab": "磨制黑石砖台阶",
  "polished_blackstone_brick_stairs": "磨制黑石砖楼梯",
  "polished_blackstone_brick_wall": "磨制黑石砖墙",
  "polished_blackstone_bricks": "磨制黑石砖",
  "polished_blackstone_button": "磨制黑石按钮",
  "polished_blackstone_double_slab": "磨制黑石台阶",
  "polished_blackstone_pressure_plate": "磨制黑石压力板",
  "polished_blackstone_slab": "磨制黑石台阶",
  "polished_blackstone_stairs": "磨制黑石楼梯",
  "polished_blackstone_wall": "磨制黑石墙",
  "polished_deepslate": "磨制深板岩",
  "polished_deepslate_double_slab": "磨制深板岩双台阶",
  "polished_deepslate_slab": "磨制深板岩台阶",
  "polished_deepslate_stairs": "磨制深板岩楼梯",
  "polished_deepslate_wall": "磨制深板岩墙",
  "polished_diorite": "磨制闪长岩",
  "polished_diorite_double_slab": "磨制闪长岩台阶",
  "polished_diorite_slab": "磨制闪长岩台阶",
  "polished_diorite_stairs": "磨制闪长岩楼梯",
  "polished_granite": "磨制花岗岩",
  "polished_granite_double_slab": "磨制花岗岩台阶",
  "polished_granite_slab": "磨制花岗岩台阶",
  "polished_granite_stairs": "磨制花岗岩楼梯",
  "polished_tuff": "磨制凝灰岩",
  "polished_tuff_double_slab": "磨制凝灰岩台阶",
  "polished_tuff_slab": "磨制凝灰岩台阶",
  "polished_tuff_stairs": "磨制凝灰岩楼梯",
  "polished_tuff_wall": "磨制凝灰岩墙",
  "popped_chorus_fruit": "爆裂紫颂果",
  "poppy": "虞美人",
  "porkchop": "生猪排",
  "porkchop_cooked": "熟猪排",
  "portal": "传送门",
  "portfolio": "相片簿",
  "potato": "马铃薯",
  "potatoes": "马铃薯",
  "powder_snow": "细雪",
  "powered_rail": "动力铁轨",
  "prismarine": "海晶石",
  "prismarine_brick_double_slab": "海晶石砖台阶",
  "prismarine_brick_slab": "海晶石砖台阶",
  "prismarine_bricks": "海晶石砖",
  "prismarine_bricks_stairs": "海晶石砖楼梯",
  "prismarine_crystals": "海晶砂粒",
  "prismarine_double_slab": "海晶石台阶",
  "prismarine_shard": "海晶碎片",
  "prismarine_slab": "海晶石台阶",
  "prismarine_stairs": "海晶石楼梯",
  "prismarine_wall": "海晶石墙",
  "prize_pottery_sherd": "珍宝纹样陶片",
  "pufferfish": "河豚",
  "pumpkin": "南瓜",
  "pumpkin_pie": "南瓜派",
  "pumpkin_seeds": "南瓜种子",
  "pumpkin_stem": "南瓜茎",
  "purple_candle": "紫色蜡烛",
  "purple_candle_cake": "带紫色蜡烛的蛋糕",
  "purple_carpet": "紫色地毯",
  "purple_concrete": "紫色混凝土",
  "purple_concrete_powder": "紫色混凝土粉末",
  "purple_glazed_terracotta": "紫色带釉陶瓦",
  "purple_harness": "紫色挽具",
  "purple_stained_glass": "紫色玻璃",
  "purple_stained_glass_pane": "紫色玻璃板",
  "purple_terracotta": "紫色陶瓦",
  "purple_wool": "紫色羊毛",
  "purpur_block": "紫珀方块",
  "purpur_double_slab": "紫珀台阶",
  "purpur_pillar": "紫珀柱子",
  "purpur_slab": "紫珀台阶",
  "purpur_stairs": "紫珀楼梯",
  "quartz": "下界石英",
  "quartz_block": "石英块",
  "quartz_bricks": "石英砖",
  "quartz_double_slab": "石英台阶",
  "quartz_ore": "下界石英矿石",
  "quartz_pillar": "石英柱",
  "quartz_slab": "石英台阶",
  "quartz_stairs": "石英楼梯",
  "rabbit": "生兔肉",
  "rabbit_foot": "兔子脚",
  "rabbit_hide": "兔子皮",
  "rabbit_stew": "兔肉煲",
  "rail": "铁轨",
  "raiser_armor_trim_smithing_template": "牧民盔甲纹饰",
  "raw_copper": "粗铜",
  "raw_copper_block": "粗铜块",
  "raw_gold": "粗金",
  "raw_gold_block": "粗金块",
  "raw_iron": "粗铁",
  "raw_iron_block": "粗铁块",
  "record": "音乐唱片",
  "record_11": "C418 - 11",
  "record_13": "C418 - 13",
  "record_5": "塞缪尔·阿伯格 - 5",
  "record_blocks": "C418 - blocks",
  "record_cat": "C418 - cat",
  "record_chirp": "C418 - chirp",
  "record_creator": "莉娜·雷恩 - 创作者",
  "record_creator_music_box": "莉娜·雷恩 - 创作者（音乐盒）",
  "record_far": "C418 - far",
  "record_mall": "C418 - mall",
  "record_mellohi": "C418 - mellohi",
  "record_otherside": "莉娜·雷恩 - otherside",
  "record_pigstep": "莉娜·雷恩 - Pigstep",
  "record_precipice": "亚伦·切罗夫 - 峭壁",
  "record_relic": "亚伦·切罗夫 - Relic",
  "record_stal": "C418 - stal",
  "record_strad": "C418 - strad",
  "record_tears": "Amos Roddy - 泪水",
  "record_wait": "C418 - wait",
  "record_ward": "C418 - ward",
  "recovery_compass": "追溯指针",
  "red_candle": "红色蜡烛",
  "red_candle_cake": "带红色蜡烛的蛋糕",
  "red_carpet": "红色地毯",
  "red_concrete": "红色混凝土",
  "red_concrete_powder": "红色混凝土粉末",
  "red_flower": "花",
  "red_glazed_terracotta": "红色带釉陶瓦",
  "red_harness": "红色挽具",
  "red_mushroom": "红蘑菇",
  "red_mushroom_block": "红蘑菇方块",
  "red_nether_brick": "红色下界砖块",
  "red_nether_brick_double_slab": "红色下界砖台阶",
  "red_nether_brick_slab": "红色下界砖台阶",
  "red_nether_brick_stairs": "红色下界砖楼梯",
  "red_nether_brick_wall": "红色下界砖墙",
  "red_sand": "红沙",
  "red_sandstone": "红砂岩",
  "red_sandstone_double_slab": "红砂岩台阶",
  "red_sandstone_slab": "红砂岩台阶",
  "red_sandstone_stairs": "红砂岩楼梯",
  "red_sandstone_wall": "红砂岩墙",
  "red_stained_glass": "红色玻璃",
  "red_stained_glass_pane": "红色玻璃板",
  "red_terracotta": "红色陶瓦",
  "red_tulip": "红色郁金香",
  "red_wool": "红色羊毛",
  "redsandstone": "红砂岩",
  "redstone": "红石粉",
  "redstone_block": "红石块",
  "redstone_lamp": "红石灯",
  "redstone_ore": "红石矿石",
  "redstone_torch": "红石火把",
  "redstone_wire": "红石粉",
  "reeds": "甘蔗",
  "reinforced_deepslate": "强化深板岩",
  "repeater": "红石中继器",
  "repeating_command_block": "循环型命令方块",
  "resin_block": "树脂块",
  "resin_brick": "树脂砖",
  "resin_brick_double_slab": "树脂砖双台阶",
  "resin_brick_slab": "树脂砖台阶",
  "resin_brick_stairs": "树脂砖楼梯",
  "resin_brick_wall": "树脂砖墙",
  "resin_bricks": "树脂砖块",
  "resin_clump": "树脂团",
  "respawn_anchor": "重生锚",
  "rib_armor_trim_smithing_template": "肋骨盔甲纹饰",
  "rose_bush": "玫瑰丛",
  "rotten_flesh": "腐肉",
  "ruby": "红宝石",
  "saddle": "鞍",
  "salmon": "生鲑鱼",
  "sand": "沙子",
  "sandstone": "砂岩",
  "sandstone_double_slab": "砂岩台阶",
  "sandstone_slab": "砂岩台阶",
  "sandstone_stairs": "砂岩楼梯",
  "sandstone_wall": "砂岩墙",
  "scaffolding": "脚手架",
  "scrape_pottery_sherd": "刮削纹样陶片",
  "sculk": "潜声",
  "sculk_catalyst": "幽匿催发体",
  "sculk_sensor": "潜声感测器",
  "sculk_shrieker": "幽匿尖啸体",
  "sculk_vein": "幽匿脉络",
  "seaLantern": "海晶灯",
  "sea_lantern": "海晶灯",
  "sea_pickle": "海泡菜",
  "sentry_armor_trim_smithing_template": "哨兵盔甲纹饰",
  "shaper_armor_trim_smithing_template": "塑造盔甲纹饰",
  "sheaf_pottery_sherd": "麦捆纹样陶片",
  "shears": "剪刀",
  "shelter_pottery_sherd": "树荫纹样陶片",
  "shield": "盾牌",
  "short_dry_grass": "矮干草丛",
  "short_grass": "草丛",
  "shroomlight": "菌光体",
  "shulkerBox": "潜影盒",
  "shulkerBoxBlack": "黑色潜影盒",
  "shulkerBoxBlue": "蓝色潜影盒",
  "shulkerBoxBrown": "棕色潜影盒",
  "shulkerBoxCyan": "青色潜影盒",
  "shulkerBoxGray": "灰色潜影盒",
  "shulkerBoxGreen": "绿色潜影盒",
  "shulkerBoxLightBlue": "淡蓝色潜影盒",
  "shulkerBoxLime": "黄绿色潜影盒",
  "shulkerBoxMagenta": "品红色潜影盒",
  "shulkerBoxOrange": "橙色潜影盒",
  "shulkerBoxPink": "粉红色潜影盒",
  "shulkerBoxPurple": "紫色潜影盒",
  "shulkerBoxRed": "红色潜影盒",
  "shulkerBoxSilver": "淡灰色潜影盒",
  "shulkerBoxWhite": "白色潜影盒",
  "shulkerBoxYellow": "黄色潜影盒",
  "shulker_box": "潜影盒",
  "shulker_shell": "潜影壳",
  "sign": "橡木告示牌",
  "silence_armor_trim_smithing_template": "幽静盔甲纹饰",
  "silver_glazed_terracotta": "淡灰色带釉陶瓦",
  "skeleton_skull": "骷髅头颅",
  "skull_banner_pattern": "头颅头像旗帜图案",
  "skull_pottery_sherd": "头颅纹样陶片",
  "slime": "黏液块",
  "slime_ball": "黏液球",
  "slimeball": "黏液球",
  "small_amethyst_bud": "小型紫晶芽",
  "small_dripleaf_block": "小型垂滴叶",
  "smithing_table": "锻造台",
  "smithing_template": "锻造模板",
  "smoker": "烟熏炉",
  "smooth_basalt": "平滑玄武岩",
  "smooth_quartz": "平滑石英块",
  "smooth_quartz_slab": "平滑石英台阶",
  "smooth_quartz_stairs": "平滑石英楼梯",
  "smooth_red_sandstone": "平滑红砂岩",
  "smooth_red_sandstone_double_slab": "平滑红砂岩台阶",
  "smooth_red_sandstone_slab": "平滑红砂岩台阶",
  "smooth_red_sandstone_stairs": "平滑红砂岩楼梯",
  "smooth_sandstone": "平滑砂岩",
  "smooth_sandstone_double_slab": "平滑砂岩台阶",
  "smooth_sandstone_slab": "平滑砂岩台阶",
  "smooth_sandstone_stairs": "平滑砂岩楼梯",
  "smooth_stone": "平滑石",
  "smooth_stone_double_slab": "平滑石台阶",
  "smooth_stone_slab": "平滑石台阶",
  "sniffer_egg": "嗅探兽蛋",
  "snort_pottery_sherd": "嗅探纹样陶片",
  "snout_armor_trim_smithing_template": "猪鼻盔甲纹饰",
  "snow": "雪块",
  "snow_layer": "雪",
  "snowball": "雪球",
  "soul_campfire": "灵魂营火",
  "soul_fire": "灵魂火",
  "soul_lantern": "灵魂灯",
  "soul_sand": "灵魂沙",
  "soul_soil": "灵魂土",
  "soul_torch": "灵魂火把",
  "speckled_melon": "闪烁的西瓜片",
  "spider_eye": "蜘蛛眼",
  "spire_armor_trim_smithing_template": "尖塔盔甲纹饰",
  "spore_blossom": "孢子花",
  "spruceFence": "云杉木栅栏",
  "spruce_boat": "云杉木船",
  "spruce_button": "云杉木按钮",
  "spruce_chest_boat": "云杉木运输船",
  "spruce_door": "云杉木门",
  "spruce_double_slab": "云杉木台阶",
  "spruce_fence": "云杉木栅栏",
  "spruce_fence_gate": "云杉木栅栏门",
  "spruce_hanging_sign": "云杉木悬挂告示牌",
  "spruce_leaves": "云杉树叶",
  "spruce_log": "云杉原木",
  "spruce_planks": "云杉木板",
  "spruce_pressure_plate": "云杉木压力板",
  "spruce_sapling": "云杉树苗",
  "spruce_sign": "云杉木告示牌",
  "spruce_slab": "云杉木台阶",
  "spruce_stairs": "云杉木楼梯",
  "spruce_standing_sign": "云杉木告示牌",
  "spruce_trapdoor": "云杉木活板门",
  "spruce_wood": "云杉木",
  "spyglass": "望远镜",
  "stained_hardened_clay": "陶瓦",
  "standing_banner": "旗帜",
  "standing_sign": "告示牌",
  "steak": "牛排",
  "stick": "木棍",
  "sticky_piston": "黏性活塞",
  "stone": "石头",
  "stone_axe": "石斧",
  "stone_brick_double_slab": "石砖台阶",
  "stone_brick_slab": "石砖台阶",
  "stone_brick_stairs": "石砖楼梯",
  "stone_brick_wall": "石砖墙",
  "stone_bricks": "石砖",
  "stone_button": "石头按钮",
  "stone_hoe": "石锄",
  "stone_pickaxe": "石镐",
  "stone_pressure_plate": "石质压力板",
  "stone_shovel": "石锹",
  "stone_slab": "石台阶",
  "stone_stairs": "圆石楼梯",
  "stone_sword": "石剑",
  "stonebrick": "石砖",
  "stonecutter": "切石机",
  "stonecutter_block": "切石机",
  "string": "线",
  "stripped_acacia_log": "去皮金合欢原木",
  "stripped_acacia_wood": "去皮金合欢木",
  "stripped_bamboo_block": "去皮竹块",
  "stripped_birch_log": "去皮桦树原木",
  "stripped_birch_wood": "去皮白桦木",
  "stripped_cherry_log": "去皮樱花原木",
  "stripped_cherry_wood": "去皮樱花木",
  "stripped_crimson_hyphae": "去皮绯红菌核",
  "stripped_crimson_stem": "去皮绯红菌柄",
  "stripped_dark_oak_log": "去皮深色橡树原木",
  "stripped_dark_oak_wood": "去皮深色橡木",
  "stripped_jungle_log": "去皮丛林原木",
  "stripped_jungle_wood": "去皮丛林木",
  "stripped_mangrove_log": "去皮红树木原木",
  "stripped_mangrove_wood": "去皮红树木木材",
  "stripped_oak_log": "去皮橡树原木",
  "stripped_oak_wood": "去皮橡木",
  "stripped_pale_oak_log": "去皮苍白橡树原木",
  "stripped_pale_oak_wood": "去皮苍白橡木",
  "stripped_spruce_log": "去皮云杉原木",
  "stripped_spruce_wood": "去皮云杉木",
  "stripped_warped_hyphae": "去皮诡异菌丝",
  "stripped_warped_stem": "去皮诡异菌柄",
  "structure_block": "结构方块",
  "structure_void": "结构空位",
  "sugar": "糖",
  "sugar_cane": "甘蔗",
  "sunflower": "向日葵",
  "suspicious_gravel": "可疑砂砾",
  "suspicious_sand": "可疑的沙子",
  "suspicious_stew": "迷之炖菜",
  "sweet_berries": "甜浆果",
  "sweet_berry_bush": "甜浆果灌木丛",
  "tall_dry_grass": "高干草丛",
  "tall_grass": "高草丛",
  "tallgrass": "矮草丛",
  "target": "标靶",
  "tide_armor_trim_smithing_template": "潮汐盔甲纹饰",
  "tinted_glass": "遮光玻璃",
  "tipped_arrow": "药箭",
  "tnt": "TNT",
  "tnt_minecart": "TNT 矿车",
  "torch": "火把",
  "torchflower": "火把花",
  "torchflower_seeds": "火把花种子",
  "totem": "不死图腾",
  "trapdoor": "橡木活板门",
  "trapped_chest": "陷阱箱",
  "trial_key": "试炼钥匙",
  "trial_spawner": "试炼刷怪笼",
  "trident": "三叉戟",
  "tripWire": "绊线",
  "trip_wire": "绊线",
  "tripwire_hook": "绊线钩",
  "tropicalColorBlue": "蓝色",
  "tropicalColorBrown": "棕色",
  "tropicalColorGray": "灰色",
  "tropicalColorGreen": "绿色",
  "tropicalColorLime": "黄绿色",
  "tropicalColorMagenta": "品红色",
  "tropicalColorOrange": "橙色",
  "tropicalColorPlum": "紫红色",
  "tropicalColorRed": "红色",
  "tropicalColorRose": "玫瑰色",
  "tropicalColorSilver": "银色",
  "tropicalColorSky": "天蓝色",
  "tropicalColorTeal": "水鸭色",
  "tropicalColorWhite": "白色",
  "tropicalColorYellow": "黄色",
  "tropicalSchoolAnemone": "海葵鱼",
  "tropicalSchoolBlackTang": "黑刺尾鲷",
  "tropicalSchoolBlueDory": "拟刺尾鲷",
  "tropicalSchoolButterflyFish": "蝶鱼",
  "tropicalSchoolCichlid": "慈鲷",
  "tropicalSchoolClownfish": "海葵鱼",
  "tropicalSchoolCottonCandyBetta": "五彩搏鱼",
  "tropicalSchoolDottyback": "拟雀鲷",
  "tropicalSchoolEmperorRedSnapper": "川纹笛鲷",
  "tropicalSchoolGoatfish": "拟羊鱼",
  "tropicalSchoolMoorishIdol": "镰鱼",
  "tropicalSchoolOrnateButterfly": "华丽蝴蝶鱼",
  "tropicalSchoolParrotfish": "鹦嘴鱼",
  "tropicalSchoolQueenAngelFish": "额斑刺蝶鱼",
  "tropicalSchoolRedCichlid": "红慈鲷",
  "tropicalSchoolRedLippedBlenny": "红唇鳚鱼",
  "tropicalSchoolRedSnapper": "红边笛鲷",
  "tropicalSchoolThreadfin": "马鲅",
  "tropicalSchoolTomatoClown": "白条双锯鱼",
  "tropicalSchoolTriggerfish": "鳞鲀",
  "tropicalSchoolYellowTang": "黄刺尾鲷",
  "tropicalSchoolYellowtailParrot": "黄尾鹦嘴鱼",
  "tube_coral": "管珊瑚",
  "tube_coral_block": "管珊瑚块",
  "tube_coral_fan": "管珊瑚扇",
  "tuff": "凝灰岩",
  "tuff_brick_double_slab": "凝灰岩砖台阶",
  "tuff_brick_slab": "凝灰岩砖台阶",
  "tuff_brick_stairs": "凝灰岩砖楼梯",
  "tuff_brick_wall": "凝灰岩砖墙",
  "tuff_bricks": "凝灰岩砖",
  "tuff_double_slab": "凝灰岩台阶",
  "tuff_slab": "凝灰岩台阶",
  "tuff_stairs": "凝灰岩楼梯",
  "tuff_wall": "凝灰岩墙",
  "turtle_egg": "海龟蛋",
  "turtle_helmet": "海龟壳",
  "turtle_shell_piece": "海龟鳞甲",
  "twisting_vines": "缠怨藤",
  "unknown": "未知",
  "unlit_redstone_torch": "红石火把",
  "vault": "宝库",
  "verdant_froglight": "青翠蛙明灯",
  "vex_armor_trim_smithing_template": "恼鬼盔甲纹饰",
  "vine": "藤蔓",
  "ward_armor_trim_smithing_template": "监守盔甲纹饰",
  "warped_button": "诡异木按钮",
  "warped_door": "诡异门",
  "warped_double_slab": "诡异木台阶",
  "warped_fence": "诡异木栅栏",
  "warped_fence_gate": "诡异木栅栏门",
  "warped_fungus": "诡异真菌",
  "warped_fungus_on_a_stick": "诡异真菌钓竿",
  "warped_hanging_sign": "翘曲悬挂告示牌",
  "warped_hyphae": "诡异菌丝",
  "warped_nylium": "诡异菌岩",
  "warped_planks": "诡异木板",
  "warped_pressure_plate": "诡异木压力板",
  "warped_roots": "诡异菌根",
  "warped_sign": "诡异木告示牌",
  "warped_slab": "诡异木台阶",
  "warped_stairs": "诡异楼梯",
  "warped_standing_sign": "诡异木告示牌",
  "warped_stem": "诡异菌柄",
  "warped_trapdoor": "诡异木活板门",
  "warped_wall_sign": "诡异木告示牌",
  "warped_wart_block": "诡异疣方块",
  "water": "水",
  "waterlily": "睡莲",
  "waxed_chiseled_copper": "涂蜡錾制铜",
  "waxed_copper": "涂蜡铜方块",
  "waxed_copper_bulb": "涂蜡铜灯泡",
  "waxed_copper_door": "涂蜡铜门",
  "waxed_copper_grate": "涂蜡铜格栅",
  "waxed_copper_trapdoor": "涂蜡铜活板门",
  "waxed_cut_copper": "涂蜡切制铜块",
  "waxed_cut_copper_slab": "涂蜡切制铜块台阶",
  "waxed_cut_copper_stairs": "涂蜡切制铜楼梯",
  "waxed_double_cut_copper_slab": "涂蜡切制铜块台阶",
  "waxed_exposed_chiseled_copper": "涂蜡外露錾制铜",
  "waxed_exposed_copper": "斑驳的涂蜡铜块",
  "waxed_exposed_copper_bulb": "涂蜡外露铜灯泡",
  "waxed_exposed_copper_door": "涂蜡外露铜门",
  "waxed_exposed_copper_grate": "涂蜡外露铜格栅",
  "waxed_exposed_copper_trapdoor": "外露的涂蜡铜活板门",
  "waxed_exposed_cut_copper": "斑驳的涂蜡切制铜块",
  "waxed_exposed_cut_copper_slab": "斑驳的涂蜡切制铜块台阶",
  "waxed_exposed_cut_copper_stairs": "斑驳的涂蜡切制铜楼梯",
  "waxed_exposed_double_cut_copper_slab": "斑驳的涂蜡切制铜块台阶",
  "waxed_oxidized_chiseled_copper": "涂蜡氧化錾制铜",
  "waxed_oxidized_copper": "氧化的涂蜡铜块",
  "waxed_oxidized_copper_bulb": "氧化的涂蜡铜灯泡",
  "waxed_oxidized_copper_door": "涂蜡氧化铜门",
  "waxed_oxidized_copper_grate": "涂蜡氧化铜格栅",
  "waxed_oxidized_copper_trapdoor": "涂蜡氧化铜活板门",
  "waxed_oxidized_cut_copper": "氧化的涂蜡切制铜块",
  "waxed_oxidized_cut_copper_slab": "氧化的涂蜡切制铜块台阶",
  "waxed_oxidized_cut_copper_stairs": "氧化的涂蜡切制铜楼梯",
  "waxed_oxidized_double_cut_copper_slab": "氧化的涂蜡切制铜块台阶",
  "waxed_weathered_chiseled_copper": "涂蜡风化錾制铜",
  "waxed_weathered_copper": "锈蚀的涂蜡铜块",
  "waxed_weathered_copper_bulb": "涂蜡风化铜灯泡",
  "waxed_weathered_copper_door": "涂蜡风化铜门",
  "waxed_weathered_copper_grate": "涂蜡风化铜格栅",
  "waxed_weathered_copper_trapdoor": "涂蜡风化铜活板门",
  "waxed_weathered_cut_copper": "锈蚀的涂蜡切制铜块",
  "waxed_weathered_cut_copper_slab": "锈蚀的涂蜡切制铜块台阶",
  "waxed_weathered_cut_copper_stairs": "锈蚀的涂蜡切制铜楼梯",
  "waxed_weathered_double_cut_copper_slab": "锈蚀的涂蜡切制铜块台阶",
  "wayfinder_armor_trim_smithing_template": "向导盔甲纹饰",
  "weathered_chiseled_copper": "风化錾制铜",
  "weathered_copper": "锈蚀的铜块",
  "weathered_copper_bulb": "风化铜灯泡",
  "weathered_copper_door": "风化铜门",
  "weathered_copper_grate": "风化铜格栅",
  "weathered_copper_trapdoor": "风化铜活板门",
  "weathered_cut_copper": "风化切制铜块",
  "weathered_cut_copper_slab": "风化切制铜块台阶",
  "weathered_cut_copper_stairs": "风化切制铜楼梯",
  "weathered_double_cut_copper_slab": "风化切制铜块台阶",
  "web": "蜘蛛网",
  "weeping_vines": "垂泪藤",
  "wet_sponge": "湿海绵",
  "wheat": "小麦",
  "wheat_seeds": "小麦种子",
  "white_candle": "白色蜡烛",
  "white_candle_cake": "带白色蜡烛的蛋糕",
  "white_carpet": "白色地毯",
  "white_concrete": "白色混凝土",
  "white_concrete_powder": "白色混凝土粉末",
  "white_glazed_terracotta": "白色带釉陶瓦",
  "white_harness": "白色挽具",
  "white_stained_glass": "白色玻璃",
  "white_stained_glass_pane": "白色玻璃板",
  "white_terracotta": "白色陶瓦",
  "white_tulip": "白色郁金香",
  "white_wool": "白色羊毛",
  "wild_armor_trim_smithing_template": "荒野盔甲纹饰",
  "wildflowers": "野花",
  "wind_charge": "风弹",
  "wither_rose": "凋零玫瑰",
  "wither_skeleton_skull": "凋灵骷髅头颅",
  "wolf_armor": "狼铠",
  "wooden_axe": "木斧",
  "wooden_button": "橡木按钮",
  "wooden_door": "橡木门",
  "wooden_hoe": "木锄",
  "wooden_pickaxe": "木镐",
  "wooden_pressure_plate": "橡木压力板",
  "wooden_shovel": "木锹",
  "wooden_slab": "木台阶",
  "wooden_sword": "木剑",
  "wool": "羊毛",
  "writable_book": "书和羽毛",
  "written_book": "成书",
  "yellow_candle": "黄色蜡烛",
  "yellow_candle_cake": "带黄色蜡烛的蛋糕",
  "yellow_carpet": "黄色地毯",
  "yellow_concrete": "黄色混凝土",
  "yellow_concrete_powder": "黄色混凝土粉末",
  "yellow_flower": "花",
  "yellow_glazed_terracotta": "黄色带釉陶瓦",
  "yellow_harness": "黄色挽具",
  "yellow_stained_glass": "黄色玻璃",
  "yellow_stained_glass_pane": "黄色玻璃板",
  "yellow_terracotta": "黄色陶瓦",
  "yellow_wool": "黄色羊毛",
  "zombie_head": "僵尸的头"
};

/** 规范化键（去下划线、转小写）-> 真实键 */
const NORMALIZED = {"acaciafence":"acaciaFence","acaciaboat":"acacia_boat","acaciabutton":"acacia_button","acaciachestboat":"acacia_chest_boat","acaciadoor":"acacia_door","acaciafencegate":"acacia_fence_gate","acaciahangingsign":"acacia_hanging_sign","acacialeaves":"acacia_leaves","acacialog":"acacia_log","acaciaplanks":"acacia_planks","acaciapressureplate":"acacia_pressure_plate","acaciasapling":"acacia_sapling","acaciasign":"acacia_sign","acaciaslab":"acacia_slab","acaciastairs":"acacia_stairs","acaciastandingsign":"acacia_standing_sign","acaciatrapdoor":"acacia_trapdoor","acaciawood":"acacia_wood","activatorrail":"activator_rail","air":"air","allium":"allium","allow":"allow","amethystblock":"amethyst_block","amethystcluster":"amethyst_cluster","amethystshard":"amethyst_shard","ancientdebris":"ancient_debris","andesite":"andesite","andesiteslab":"andesite_slab","andesitestairs":"andesite_stairs","andesitewall":"andesite_wall","anglerpotterysherd":"angler_pottery_sherd","anvil":"anvil","apple":"apple","appleenchanted":"appleEnchanted","archerpotterysherd":"archer_pottery_sherd","armadilloscute":"armadillo_scute","armorstand":"armor_stand","armsuppotterysherd":"arms_up_pottery_sherd","arrow":"arrow","axolotlcolorblue":"axolotlColorBlue","axolotlcolorcyan":"axolotlColorCyan","axolotlcolorgold":"axolotlColorGold","axolotlcolorlucy":"axolotlColorLucy","axolotlcolorwild":"axolotlColorWild","azalea":"azalea","azalealeaves":"azalea_leaves","azalealeavesflowered":"azalea_leaves_flowered","azurebluet":"azure_bluet","bakedpotato":"baked_potato","bamboo":"bamboo","bambooblock":"bamboo_block","bamboobutton":"bamboo_button","bamboochestraft":"bamboo_chest_raft","bamboodoor":"bamboo_door","bamboofence":"bamboo_fence","bamboofencegate":"bamboo_fence_gate","bamboohangingsign":"bamboo_hanging_sign","bamboomosaic":"bamboo_mosaic","bamboomosaicslab":"bamboo_mosaic_slab","bamboomosaicstairs":"bamboo_mosaic_stairs","bambooplanks":"bamboo_planks","bamboopressureplate":"bamboo_pressure_plate","bambooraft":"bamboo_raft","bamboosign":"bamboo_sign","bambooslab":"bamboo_slab","bamboostairs":"bamboo_stairs","bambootrapdoor":"bamboo_trapdoor","bannerpattern":"banner_pattern","barrel":"barrel","barrier":"barrier","basalt":"basalt","beacon":"beacon","bed":"bed","bedrock":"bedrock","beenest":"bee_nest","beef":"beef","beehive":"beehive","beetroot":"beetroot","beetrootseeds":"beetroot_seeds","beetrootsoup":"beetroot_soup","bell":"bell","bigdripleaf":"big_dripleaf","birchfence":"birchFence","birchboat":"birch_boat","birchbutton":"birch_button","birchchestboat":"birch_chest_boat","birchdoor":"birch_door","birchfencegate":"birch_fence_gate","birchhangingsign":"birch_hanging_sign","birchleaves":"birch_leaves","birchlog":"birch_log","birchplanks":"birch_planks","birchpressureplate":"birch_pressure_plate","birchsapling":"birch_sapling","birchsign":"birch_sign","birchslab":"birch_slab","birchstairs":"birch_stairs","birchstandingsign":"birch_standing_sign","birchtrapdoor":"birch_trapdoor","birchwood":"birch_wood","blackcandle":"black_candle","blackcandlecake":"black_candle_cake","blackcarpet":"black_carpet","blackconcrete":"black_concrete","blackconcretepowder":"black_concrete_powder","blackglazedterracotta":"black_glazed_terracotta","blackharness":"black_harness","blackstainedglass":"black_stained_glass","blackstainedglasspane":"black_stained_glass_pane","blackterracotta":"black_terracotta","blackwool":"black_wool","blackstone":"blackstone","blackstoneslab":"blackstone_slab","blackstonestairs":"blackstone_stairs","blackstonewall":"blackstone_wall","bladepotterysherd":"blade_pottery_sherd","blastfurnace":"blast_furnace","blazepowder":"blaze_powder","blazerod":"blaze_rod","bluecandle":"blue_candle","bluecandlecake":"blue_candle_cake","bluecarpet":"blue_carpet","blueconcrete":"blue_concrete","blueconcretepowder":"blue_concrete_powder","blueegg":"blue_egg","blueglazedterracotta":"blue_glazed_terracotta","blueharness":"blue_harness","blueice":"blue_ice","blueorchid":"blue_orchid","bluestainedglass":"blue_stained_glass","bluestainedglasspane":"blue_stained_glass_pane","blueterracotta":"blue_terracotta","bluewool":"blue_wool","boltarmortrimsmithingtemplate":"bolt_armor_trim_smithing_template","bone":"bone","boneblock":"bone_block","book":"book","bookshelf":"bookshelf","borderblock":"border_block","bordureindentedbannerpattern":"bordure_indented_banner_pattern","bow":"bow","bowl":"bowl","braincoral":"brain_coral","braincoralblock":"brain_coral_block","braincoralfan":"brain_coral_fan","bread":"bread","breezerod":"breeze_rod","brewerpotterysherd":"brewer_pottery_sherd","brewingstand":"brewing_stand","brick":"brick","brickblock":"brick_block","brickdoubleslab":"brick_double_slab","brickslab":"brick_slab","brickstairs":"brick_stairs","brickwall":"brick_wall","browncandle":"brown_candle","browncandlecake":"brown_candle_cake","browncarpet":"brown_carpet","brownconcrete":"brown_concrete","brownconcretepowder":"brown_concrete_powder","brownegg":"brown_egg","brownglazedterracotta":"brown_glazed_terracotta","brownharness":"brown_harness","brownmushroom":"brown_mushroom","brownmushroomblock":"brown_mushroom_block","brownstainedglass":"brown_stained_glass","brownstainedglasspane":"brown_stained_glass_pane","brownterracotta":"brown_terracotta","brownwool":"brown_wool","brush":"brush","bubblecoral":"bubble_coral","bubblecoralblock":"bubble_coral_block","bubblecoralfan":"bubble_coral_fan","bucket":"bucket","bucketaxolotl":"bucketAxolotl","bucketcustomfish":"bucketCustomFish","bucketfish":"bucketFish","bucketlava":"bucketLava","bucketpowdersnow":"bucketPowderSnow","bucketpuffer":"bucketPuffer","bucketsalmon":"bucketSalmon","buckettadpole":"bucketTadpole","buckettropical":"bucketTropical","bucketwater":"bucketWater","buddingamethyst":"budding_amethyst","burnpotterysherd":"burn_pottery_sherd","bush":"bush","cactus":"cactus","cactusflower":"cactus_flower","cake":"cake","calcite":"calcite","calibratedsculksensor":"calibrated_sculk_sensor","camera":"camera","campfire":"campfire","candle":"candle","candlecake":"candle_cake","carpet":"carpet","carrot":"carrot","carrotonastick":"carrotOnAStick","carrots":"carrots","cartographytable":"cartography_table","carvedpumpkin":"carved_pumpkin","cauldron":"cauldron","cavevines":"cave_vines","cavevinesbodywithberries":"cave_vines_body_with_berries","cavevinesheadwithberries":"cave_vines_head_with_berries","chain":"chain","chaincommandblock":"chain_command_block","chainmailboots":"chainmail_boots","chainmailchestplate":"chainmail_chestplate","chainmailhelmet":"chainmail_helmet","chainmailleggings":"chainmail_leggings","charcoal":"charcoal","cherryboat":"cherry_boat","cherrybutton":"cherry_button","cherrychestboat":"cherry_chest_boat","cherrydoor":"cherry_door","cherrydoubleslab":"cherry_double_slab","cherryfence":"cherry_fence","cherryfencegate":"cherry_fence_gate","cherryhangingsign":"cherry_hanging_sign","cherryleaves":"cherry_leaves","cherrylog":"cherry_log","cherryplanks":"cherry_planks","cherrypressureplate":"cherry_pressure_plate","cherrysapling":"cherry_sapling","cherrysign":"cherry_sign","cherryslab":"cherry_slab","cherrystairs":"cherry_stairs","cherrytrapdoor":"cherry_trapdoor","cherrywood":"cherry_wood","chest":"chest","chestminecart":"chest_minecart","chicken":"chicken","chippedanvil":"chipped_anvil","chiseledbookshelf":"chiseled_bookshelf","chiseledcopper":"chiseled_copper","chiseleddeepslate":"chiseled_deepslate","chiselednetherbricks":"chiseled_nether_bricks","chiseledpolishedblackstone":"chiseled_polished_blackstone","chiseledquartzblock":"chiseled_quartz_block","chiseledredsandstone":"chiseled_red_sandstone","chiseledresinbricks":"chiseled_resin_bricks","chiseledsandstone":"chiseled_sandstone","chiseledstonebricks":"chiseled_stone_bricks","chiseledtuff":"chiseled_tuff","chiseledtuffbricks":"chiseled_tuff_bricks","chorusflower":"chorus_flower","chorusfruit":"chorus_fruit","chorusfruitpopped":"chorus_fruit_popped","chorusplant":"chorus_plant","clay":"clay","clayball":"clay_ball","clock":"clock","closedeyeblossom":"closed_eyeblossom","clownfish":"clownfish","coal":"coal","coalblock":"coal_block","coalore":"coal_ore","coarsedirt":"coarse_dirt","coastarmortrimsmithingtemplate":"coast_armor_trim_smithing_template","cobbleddeepslate":"cobbled_deepslate","cobbleddeepslatedoubleslab":"cobbled_deepslate_double_slab","cobbleddeepslateslab":"cobbled_deepslate_slab","cobbleddeepslatestairs":"cobbled_deepslate_stairs","cobbleddeepslatewall":"cobbled_deepslate_wall","cobblestone":"cobblestone","cobblestonedoubleslab":"cobblestone_double_slab","cobblestoneslab":"cobblestone_slab","cobblestonewall":"cobblestone_wall","cocoa":"cocoa","commandblock":"command_block","commandblockminecart":"command_block_minecart","comparator":"comparator","compass":"compass","composter":"composter","conduit":"conduit","cookedbeef":"cooked_beef","cookedchicken":"cooked_chicken","cookedfish":"cooked_fish","cookedporkchop":"cooked_porkchop","cookedrabbit":"cooked_rabbit","cookedsalmon":"cooked_salmon","cookie":"cookie","copperblock":"copper_block","copperbulb":"copper_bulb","copperdoor":"copper_door","coppergrate":"copper_grate","copperingot":"copper_ingot","copperore":"copper_ore","coppertrapdoor":"copper_trapdoor","cornflower":"cornflower","crackeddeepslatebricks":"cracked_deepslate_bricks","crackeddeepslatetiles":"cracked_deepslate_tiles","crackednetherbricks":"cracked_nether_bricks","crackedpolishedblackstonebricks":"cracked_polished_blackstone_bricks","crackedstonebricks":"cracked_stone_bricks","crafter":"crafter","craftingtable":"crafting_table","creakingheart":"creaking_heart","creeperbannerpattern":"creeper_banner_pattern","creeperhead":"creeper_head","crimsonbutton":"crimson_button","crimsondoor":"crimson_door","crimsondoubleslab":"crimson_double_slab","crimsonfence":"crimson_fence","crimsonfencegate":"crimson_fence_gate","crimsonfungus":"crimson_fungus","crimsonhangingsign":"crimson_hanging_sign","crimsonhyphae":"crimson_hyphae","crimsonnylium":"crimson_nylium","crimsonplanks":"crimson_planks","crimsonpressureplate":"crimson_pressure_plate","crimsonroots":"crimson_roots","crimsonsign":"crimson_sign","crimsonslab":"crimson_slab","crimsonstairs":"crimson_stairs","crimsonstandingsign":"crimson_standing_sign","crimsonstem":"crimson_stem","crimsontrapdoor":"crimson_trapdoor","crimsonwallsign":"crimson_wall_sign","crossbow":"crossbow","cryingobsidian":"crying_obsidian","cutcopper":"cut_copper","cutcopperslab":"cut_copper_slab","cutcopperstairs":"cut_copper_stairs","cutredsandstone":"cut_red_sandstone","cutredsandstoneslab":"cut_red_sandstone_slab","cutsandstone":"cut_sandstone","cutsandstoneslab":"cut_sandstone_slab","cyancandle":"cyan_candle","cyancandlecake":"cyan_candle_cake","cyancarpet":"cyan_carpet","cyanconcrete":"cyan_concrete","cyanconcretepowder":"cyan_concrete_powder","cyanglazedterracotta":"cyan_glazed_terracotta","cyanharness":"cyan_harness","cyanstainedglass":"cyan_stained_glass","cyanstainedglasspane":"cyan_stained_glass_pane","cyanterracotta":"cyan_terracotta","cyanwool":"cyan_wool","damagedanvil":"damaged_anvil","dandelion":"dandelion","dangerpotterysherd":"danger_pottery_sherd","darkoakfence":"darkOakFence","darkoakboat":"dark_oak_boat","darkoakbutton":"dark_oak_button","darkoakchestboat":"dark_oak_chest_boat","darkoakdoor":"dark_oak_door","darkoakfencegate":"dark_oak_fence_gate","darkoakhangingsign":"dark_oak_hanging_sign","darkoakleaves":"dark_oak_leaves","darkoaklog":"dark_oak_log","darkoakplanks":"dark_oak_planks","darkoakpressureplate":"dark_oak_pressure_plate","darkoaksapling":"dark_oak_sapling","darkoakslab":"dark_oak_slab","darkoakstairs":"dark_oak_stairs","darkoaktrapdoor":"dark_oak_trapdoor","darkoakwood":"dark_oak_wood","darkprismarine":"dark_prismarine","darkprismarineslab":"dark_prismarine_slab","darkprismarinestairs":"dark_prismarine_stairs","darkoaksign":"darkoak_sign","darkoakstandingsign":"darkoak_standing_sign","daylightdetector":"daylight_detector","deadbush":"deadbush","decoratedpot":"decorated_pot","deepslate":"deepslate","deepslatebrickdoubleslab":"deepslate_brick_double_slab","deepslatebrickslab":"deepslate_brick_slab","deepslatebrickstairs":"deepslate_brick_stairs","deepslatebrickwall":"deepslate_brick_wall","deepslatebricks":"deepslate_bricks","deepslatecoalore":"deepslate_coal_ore","deepslatecopperore":"deepslate_copper_ore","deepslatediamondore":"deepslate_diamond_ore","deepslateemeraldore":"deepslate_emerald_ore","deepslategoldore":"deepslate_gold_ore","deepslateironore":"deepslate_iron_ore","deepslatelapisore":"deepslate_lapis_ore","deepslateredstoneore":"deepslate_redstone_ore","deepslatetiledoubleslab":"deepslate_tile_double_slab","deepslatetileslab":"deepslate_tile_slab","deepslatetilestairs":"deepslate_tile_stairs","deepslatetilewall":"deepslate_tile_wall","deepslatetiles":"deepslate_tiles","deny":"deny","detectorrail":"detector_rail","diamond":"diamond","diamondaxe":"diamond_axe","diamondblock":"diamond_block","diamondboots":"diamond_boots","diamondchestplate":"diamond_chestplate","diamondhelmet":"diamond_helmet","diamondhoe":"diamond_hoe","diamondleggings":"diamond_leggings","diamondore":"diamond_ore","diamondpickaxe":"diamond_pickaxe","diamondshovel":"diamond_shovel","diamondsword":"diamond_sword","diorite":"diorite","dioriteslab":"diorite_slab","dioritestairs":"diorite_stairs","dioritewall":"diorite_wall","dirt":"dirt","dirtwithroots":"dirt_with_roots","discfragment":"disc_fragment","discfragment5":"disc_fragment_5","dispenser":"dispenser","doorwood":"doorWood","doubleplant":"double_plant","doublestoneslab":"double_stone_slab","dragonbreath":"dragon_breath","dragonegg":"dragon_egg","dragonhead":"dragon_head","driedghast":"dried_ghast","driedkelp":"dried_kelp","driedkelpblock":"dried_kelp_block","dripstoneblock":"dripstone_block","dropper":"dropper","dunearmortrimsmithingtemplate":"dune_armor_trim_smithing_template","echoshard":"echo_shard","egg":"egg","elytra":"elytra","emerald":"emerald","emeraldblock":"emerald_block","emeraldore":"emerald_ore","emptylocatormap":"emptyLocatorMap","emptymap":"emptyMap","enchantedbook":"enchanted_book","enchantingtable":"enchanting_table","endbrickstairs":"end_brick_stairs","endbricks":"end_bricks","endcrystal":"end_crystal","endportalframe":"end_portal_frame","endrod":"end_rod","endstone":"end_stone","endstonebrickslab":"end_stone_brick_slab","endstonebrickwall":"end_stone_brick_wall","enderchest":"enderChest","endereye":"ender_eye","enderpearl":"ender_pearl","experiencebottle":"experience_bottle","explorerpotterysherd":"explorer_pottery_sherd","exposedchiseledcopper":"exposed_chiseled_copper","exposedcopper":"exposed_copper","exposedcopperbulb":"exposed_copper_bulb","exposedcopperdoor":"exposed_copper_door","exposedcoppergrate":"exposed_copper_grate","exposedcoppertrapdoor":"exposed_copper_trapdoor","exposedcutcopper":"exposed_cut_copper","exposedcutcopperslab":"exposed_cut_copper_slab","exposedcutcopperstairs":"exposed_cut_copper_stairs","eyearmortrimsmithingtemplate":"eye_armor_trim_smithing_template","farmland":"farmland","feather":"feather","fence":"fence","fencegate":"fence_gate","fermentedspidereye":"fermented_spider_eye","fern":"fern","fieldmasonedbannerpattern":"field_masoned_banner_pattern","fire":"fire","firecoral":"fire_coral","firecoralblock":"fire_coral_block","firecoralfan":"fire_coral_fan","fireball":"fireball","fireflybush":"firefly_bush","fireworks":"fireworks","fireworkscharge":"fireworksCharge","fish":"fish","fishingrod":"fishing_rod","fletchingtable":"fletching_table","flint":"flint","flintandsteel":"flint_and_steel","flowarmortrimsmithingtemplate":"flow_armor_trim_smithing_template","flowbannerpattern":"flow_banner_pattern","flowpotterysherd":"flow_pottery_sherd","flowerbannerpattern":"flower_banner_pattern","flowerpot":"flower_pot","floweringazalea":"flowering_azalea","flowinglava":"flowing_lava","flowingwater":"flowing_water","frame":"frame","friendpotterysherd":"friend_pottery_sherd","frogspawn":"frog_spawn","frostedice":"frosted_ice","furnace":"furnace","ghasttear":"ghast_tear","gildedblackstone":"gilded_blackstone","glass":"glass","glassbottle":"glass_bottle","glasspane":"glass_pane","glazedterracottablack":"glazedTerracottaBlack","glazedterracottablue":"glazedTerracottaBlue","glazedterracottabrown":"glazedTerracottaBrown","glazedterracottacyan":"glazedTerracottaCyan","glazedterracottagray":"glazedTerracottaGray","glazedterracottagreen":"glazedTerracottaGreen","glazedterracottalightblue":"glazedTerracottaLightBlue","glazedterracottalime":"glazedTerracottaLime","glazedterracottamagenta":"glazedTerracottaMagenta","glazedterracottaorange":"glazedTerracottaOrange","glazedterracottapink":"glazedTerracottaPink","glazedterracottapurple":"glazedTerracottaPurple","glazedterracottared":"glazedTerracottaRed","glazedterracottasilver":"glazedTerracottaSilver","glazedterracottawhite":"glazedTerracottaWhite","glazedterracottayellow":"glazedTerracottaYellow","globebannerpattern":"globe_banner_pattern","glowberries":"glow_berries","glowframe":"glow_frame","glowinksac":"glow_ink_sac","glowlichen":"glow_lichen","glowstone":"glowstone","glowstonedust":"glowstone_dust","goathorn":"goat_horn","goldblock":"gold_block","goldingot":"gold_ingot","goldnugget":"gold_nugget","goldore":"gold_ore","goldenapple":"golden_apple","goldenaxe":"golden_axe","goldenboots":"golden_boots","goldencarrot":"golden_carrot","goldenchestplate":"golden_chestplate","goldenhelmet":"golden_helmet","goldenhoe":"golden_hoe","goldenleggings":"golden_leggings","goldenpickaxe":"golden_pickaxe","goldenrail":"golden_rail","goldenshovel":"golden_shovel","goldensword":"golden_sword","granite":"granite","graniteslab":"granite_slab","granitestairs":"granite_stairs","granitewall":"granite_wall","grass":"grass","grasspath":"grass_path","gravel":"gravel","graycandle":"gray_candle","graycandlecake":"gray_candle_cake","graycarpet":"gray_carpet","grayconcrete":"gray_concrete","grayconcretepowder":"gray_concrete_powder","grayglazedterracotta":"gray_glazed_terracotta","grayharness":"gray_harness","graystainedglass":"gray_stained_glass","graystainedglasspane":"gray_stained_glass_pane","grayterracotta":"gray_terracotta","graywool":"gray_wool","greencandle":"green_candle","greencandlecake":"green_candle_cake","greencarpet":"green_carpet","greenconcrete":"green_concrete","greenconcretepowder":"green_concrete_powder","greenglazedterracotta":"green_glazed_terracotta","greenharness":"green_harness","greenstainedglass":"green_stained_glass","greenstainedglasspane":"green_stained_glass_pane","greenterracotta":"green_terracotta","greenwool":"green_wool","grindstone":"grindstone","gunpowder":"gunpowder","gusterbannerpattern":"guster_banner_pattern","gusterpotterysherd":"guster_pottery_sherd","hangingroots":"hanging_roots","hardenedclay":"hardened_clay","hayblock":"hay_block","heartofthesea":"heart_of_the_sea","heartpotterysherd":"heart_pottery_sherd","heartbreakpotterysherd":"heartbreak_pottery_sherd","heavycore":"heavy_core","heavyweightedpressureplate":"heavy_weighted_pressure_plate","honeyblock":"honey_block","honeybottle":"honey_bottle","honeycomb":"honeycomb","honeycombblock":"honeycomb_block","hopper":"hopper","hopperminecart":"hopper_minecart","horncoral":"horn_coral","horncoralblock":"horn_coral_block","horncoralfan":"horn_coral_fan","horsearmordiamond":"horsearmordiamond","horsearmorgold":"horsearmorgold","horsearmoriron":"horsearmoriron","horsearmorleather":"horsearmorleather","hostarmortrimsmithingtemplate":"host_armor_trim_smithing_template","howlpotterysherd":"howl_pottery_sherd","ice":"ice","infestedchiseledstonebricks":"infested_chiseled_stone_bricks","infestedcobblestone":"infested_cobblestone","infestedcrackedstonebricks":"infested_cracked_stone_bricks","infesteddeepslate":"infested_deepslate","infestedmossystonebricks":"infested_mossy_stone_bricks","infestedstone":"infested_stone","infestedstonebricks":"infested_stone_bricks","invisiblebedrock":"invisibleBedrock","ironaxe":"iron_axe","ironbars":"iron_bars","ironblock":"iron_block","ironboots":"iron_boots","ironchestplate":"iron_chestplate","irondoor":"iron_door","ironhelmet":"iron_helmet","ironhoe":"iron_hoe","ironingot":"iron_ingot","ironleggings":"iron_leggings","ironnugget":"iron_nugget","ironore":"iron_ore","ironpickaxe":"iron_pickaxe","ironshovel":"iron_shovel","ironsword":"iron_sword","irontrapdoor":"iron_trapdoor","jigsaw":"jigsaw","jukebox":"jukebox","junglefence":"jungleFence","jungleboat":"jungle_boat","junglebutton":"jungle_button","junglechestboat":"jungle_chest_boat","jungledoor":"jungle_door","junglefencegate":"jungle_fence_gate","junglehangingsign":"jungle_hanging_sign","jungleleaves":"jungle_leaves","junglelog":"jungle_log","jungleplanks":"jungle_planks","junglepressureplate":"jungle_pressure_plate","junglesapling":"jungle_sapling","junglesign":"jungle_sign","jungleslab":"jungle_slab","junglestairs":"jungle_stairs","junglestandingsign":"jungle_standing_sign","jungletrapdoor":"jungle_trapdoor","junglewood":"jungle_wood","kelp":"kelp","ladder":"ladder","lantern":"lantern","lapisblock":"lapis_block","lapisore":"lapis_ore","largeamethystbud":"large_amethyst_bud","largefern":"large_fern","lava":"lava","lead":"lead","leaflitter":"leaf_litter","leather":"leather","leatherboots":"leather_boots","leatherchestplate":"leather_chestplate","leatherhelmet":"leather_helmet","leatherleggings":"leather_leggings","leaves":"leaves","lectern":"lectern","lever":"lever","lightblock":"light_block","lightbluecandle":"light_blue_candle","lightbluecandlecake":"light_blue_candle_cake","lightbluecarpet":"light_blue_carpet","lightblueconcrete":"light_blue_concrete","lightblueconcretepowder":"light_blue_concrete_powder","lightblueglazedterracotta":"light_blue_glazed_terracotta","lightblueharness":"light_blue_harness","lightbluestainedglass":"light_blue_stained_glass","lightbluestainedglasspane":"light_blue_stained_glass_pane","lightblueterracotta":"light_blue_terracotta","lightbluewool":"light_blue_wool","lightgraycandle":"light_gray_candle","lightgraycandlecake":"light_gray_candle_cake","lightgraycarpet":"light_gray_carpet","lightgrayconcrete":"light_gray_concrete","lightgrayconcretepowder":"light_gray_concrete_powder","lightgrayharness":"light_gray_harness","lightgraystainedglass":"light_gray_stained_glass","lightgraystainedglasspane":"light_gray_stained_glass_pane","lightgrayterracotta":"light_gray_terracotta","lightgraywool":"light_gray_wool","lightweightedpressureplate":"light_weighted_pressure_plate","lightningrod":"lightning_rod","lilac":"lilac","lilyofthevalley":"lily_of_the_valley","limecandle":"lime_candle","limecandlecake":"lime_candle_cake","limecarpet":"lime_carpet","limeconcrete":"lime_concrete","limeconcretepowder":"lime_concrete_powder","limeglazedterracotta":"lime_glazed_terracotta","limeharness":"lime_harness","limestainedglass":"lime_stained_glass","limestainedglasspane":"lime_stained_glass_pane","limeterracotta":"lime_terracotta","limewool":"lime_wool","litpumpkin":"lit_pumpkin","lockedchest":"lockedchest","lodestone":"lodestone","lodestonecompass":"lodestonecompass","log":"log","loom":"loom","mace":"mace","magentacandle":"magenta_candle","magentacandlecake":"magenta_candle_cake","magentacarpet":"magenta_carpet","magentaconcrete":"magenta_concrete","magentaconcretepowder":"magenta_concrete_powder","magentaglazedterracotta":"magenta_glazed_terracotta","magentaharness":"magenta_harness","magentastainedglass":"magenta_stained_glass","magentastainedglasspane":"magenta_stained_glass_pane","magentaterracotta":"magenta_terracotta","magentawool":"magenta_wool","magma":"magma","magmacream":"magma_cream","mangroveboat":"mangrove_boat","mangrovebutton":"mangrove_button","mangrovechestboat":"mangrove_chest_boat","mangrovedoor":"mangrove_door","mangrovefence":"mangrove_fence","mangrovefencegate":"mangrove_fence_gate","mangrovehangingsign":"mangrove_hanging_sign","mangroveleaves":"mangrove_leaves","mangrovelog":"mangrove_log","mangroveplanks":"mangrove_planks","mangrovepressureplate":"mangrove_pressure_plate","mangrovepropagule":"mangrove_propagule","mangroveroots":"mangrove_roots","mangrovesign":"mangrove_sign","mangroveslab":"mangrove_slab","mangrovestairs":"mangrove_stairs","mangrovetrapdoor":"mangrove_trapdoor","mangrovewood":"mangrove_wood","map":"map","mediumamethystbud":"medium_amethyst_bud","melon":"melon","melonblock":"melon_block","melonseeds":"melon_seeds","milk":"milk","minecart":"minecart","minecartfurnace":"minecartFurnace","minerpotterysherd":"miner_pottery_sherd","mobspawner":"mob_spawner","mojangbannerpattern":"mojang_banner_pattern","monsteregg":"monster_egg","mossblock":"moss_block","mosscarpet":"moss_carpet","mossycobblestone":"mossy_cobblestone","mossycobblestoneslab":"mossy_cobblestone_slab","mossycobblestonestairs":"mossy_cobblestone_stairs","mossycobblestonewall":"mossy_cobblestone_wall","mossystonebrickslab":"mossy_stone_brick_slab","mossystonebrickstairs":"mossy_stone_brick_stairs","mossystonebrickwall":"mossy_stone_brick_wall","mossystonebricks":"mossy_stone_bricks","mournerpotterysherd":"mourner_pottery_sherd","mud":"mud","mudbrickslab":"mud_brick_slab","mudbrickstairs":"mud_brick_stairs","mudbrickwall":"mud_brick_wall","mudbricks":"mud_bricks","muddymangroveroots":"muddy_mangrove_roots","mushroom":"mushroom","mushroomstem":"mushroom_stem","mushroomstew":"mushroom_stew","muttoncooked":"muttonCooked","muttonraw":"muttonRaw","mycelium":"mycelium","nametag":"name_tag","nautilusshell":"nautilus_shell","netherstar":"netherStar","netherbrick":"netherbrick","netherbrickdoubleslab":"nether_brick_double_slab","netherbrickfence":"nether_brick_fence","netherbrickslab":"nether_brick_slab","netherbrickstairs":"nether_brick_stairs","netherbrickwall":"nether_brick_wall","nethergoldore":"nether_gold_ore","nethersprouts":"nether_sprouts","netherwart":"nether_wart","netherwartblock":"nether_wart_block","netheriteaxe":"netherite_axe","netheriteblock":"netherite_block","netheriteboots":"netherite_boots","netheritechestplate":"netherite_chestplate","netheritehelmet":"netherite_helmet","netheritehoe":"netherite_hoe","netheriteingot":"netherite_ingot","netheriteleggings":"netherite_leggings","netheritepickaxe":"netherite_pickaxe","netheritescrap":"netherite_scrap","netheriteshovel":"netherite_shovel","netheritesword":"netherite_sword","netheriteupgradesmithingtemplate":"netherite_upgrade_smithing_template","netherrack":"netherrack","netherreactor":"netherreactor","normalstoneslab":"normal_stone_slab","normalstonestairs":"normal_stone_stairs","noteblock":"noteblock","oakboat":"oak_boat","oakchestboat":"oak_chest_boat","oakhangingsign":"oak_hanging_sign","oakleaves":"oak_leaves","oaklog":"oak_log","oakplanks":"oak_planks","oaksapling":"oak_sapling","oakslab":"oak_slab","oakstairs":"oak_stairs","oakwood":"oak_wood","observer":"observer","obsidian":"obsidian","ochrefroglight":"ochre_froglight","ominousbottle":"ominous_bottle","ominoustrialkey":"ominous_trial_key","openeyeblossom":"open_eyeblossom","orangecandle":"orange_candle","orangecandlecake":"orange_candle_cake","orangecarpet":"orange_carpet","orangeconcrete":"orange_concrete","orangeconcretepowder":"orange_concrete_powder","orangeglazedterracotta":"orange_glazed_terracotta","orangeharness":"orange_harness","orangestainedglass":"orange_stained_glass","orangestainedglasspane":"orange_stained_glass_pane","orangeterracotta":"orange_terracotta","orangetulip":"orange_tulip","orangewool":"orange_wool","oreruby":"oreRuby","oxeyedaisy":"oxeye_daisy","oxidizedchiseledcopper":"oxidized_chiseled_copper","oxidizedcopper":"oxidized_copper","oxidizedcopperbulb":"oxidized_copper_bulb","oxidizedcopperdoor":"oxidized_copper_door","oxidizedcoppergrate":"oxidized_copper_grate","oxidizedcoppertrapdoor":"oxidized_copper_trapdoor","oxidizedcutcopper":"oxidized_cut_copper","oxidizedcutcopperslab":"oxidized_cut_copper_slab","oxidizedcutcopperstairs":"oxidized_cut_copper_stairs","packedice":"packed_ice","packedmud":"packed_mud","painting":"painting","palehangingmoss":"pale_hanging_moss","palemossblock":"pale_moss_block","palemosscarpet":"pale_moss_carpet","paleoakboat":"pale_oak_boat","paleoakbutton":"pale_oak_button","paleoakchestboat":"pale_oak_chest_boat","paleoakdoor":"pale_oak_door","paleoakdoubleslab":"pale_oak_double_slab","paleoakfence":"pale_oak_fence","paleoakfencegate":"pale_oak_fence_gate","paleoakhangingsign":"pale_oak_hanging_sign","paleoakleaves":"pale_oak_leaves","paleoaklog":"pale_oak_log","paleoakplanks":"pale_oak_planks","paleoakpressureplate":"pale_oak_pressure_plate","paleoaksapling":"pale_oak_sapling","paleoaksign":"pale_oak_sign","paleoakslab":"pale_oak_slab","paleoakstairs":"pale_oak_stairs","paleoaktrapdoor":"pale_oak_trapdoor","paleoakwood":"pale_oak_wood","paper":"paper","pearlescentfroglight":"pearlescent_froglight","peony":"peony","phantommembrane":"phantom_membrane","photo":"photo","piglinbannerpattern":"piglin_banner_pattern","piglinhead":"piglin_head","pinkcandle":"pink_candle","pinkcandlecake":"pink_candle_cake","pinkcarpet":"pink_carpet","pinkconcrete":"pink_concrete","pinkconcretepowder":"pink_concrete_powder","pinkglazedterracotta":"pink_glazed_terracotta","pinkharness":"pink_harness","pinkpetals":"pink_petals","pinkstainedglass":"pink_stained_glass","pinkstainedglasspane":"pink_stained_glass_pane","pinkterracotta":"pink_terracotta","pinktulip":"pink_tulip","pinkwool":"pink_wool","piston":"piston","pitcherplant":"pitcher_plant","pitcherpod":"pitcher_pod","planks":"planks","playerhead":"player_head","plentypotterysherd":"plenty_pottery_sherd","podzol":"podzol","pointeddripstone":"pointed_dripstone","poisonouspotato":"poisonous_potato","polishedandesite":"polished_andesite","polishedandesiteslab":"polished_andesite_slab","polishedandesitestairs":"polished_andesite_stairs","polishedbasalt":"polished_basalt","polishedblackstone":"polished_blackstone","polishedblackstonebrickslab":"polished_blackstone_brick_slab","polishedblackstonebrickstairs":"polished_blackstone_brick_stairs","polishedblackstonebrickwall":"polished_blackstone_brick_wall","polishedblackstonebricks":"polished_blackstone_bricks","polishedblackstonebutton":"polished_blackstone_button","polishedblackstonepressureplate":"polished_blackstone_pressure_plate","polishedblackstoneslab":"polished_blackstone_slab","polishedblackstonestairs":"polished_blackstone_stairs","polishedblackstonewall":"polished_blackstone_wall","polisheddeepslate":"polished_deepslate","polisheddeepslatedoubleslab":"polished_deepslate_double_slab","polisheddeepslateslab":"polished_deepslate_slab","polisheddeepslatestairs":"polished_deepslate_stairs","polisheddeepslatewall":"polished_deepslate_wall","polisheddiorite":"polished_diorite","polisheddioriteslab":"polished_diorite_slab","polisheddioritestairs":"polished_diorite_stairs","polishedgranite":"polished_granite","polishedgraniteslab":"polished_granite_slab","polishedgranitestairs":"polished_granite_stairs","polishedtuff":"polished_tuff","polishedtuffslab":"polished_tuff_slab","polishedtuffstairs":"polished_tuff_stairs","polishedtuffwall":"polished_tuff_wall","poppy":"poppy","porkchop":"porkchop","porkchopcooked":"porkchop_cooked","portal":"portal","portfolio":"portfolio","potato":"potato","potatoes":"potatoes","powdersnow":"powder_snow","prismarine":"prismarine","prismarinebrickslab":"prismarine_brick_slab","prismarinebricks":"prismarine_bricks","prismarinebricksstairs":"prismarine_bricks_stairs","prismarinecrystals":"prismarine_crystals","prismarineshard":"prismarine_shard","prismarineslab":"prismarine_slab","prismarinestairs":"prismarine_stairs","prismarinewall":"prismarine_wall","prizepotterysherd":"prize_pottery_sherd","pufferfish":"pufferfish","pumpkin":"pumpkin","pumpkinpie":"pumpkin_pie","pumpkinseeds":"pumpkin_seeds","pumpkinstem":"pumpkin_stem","purplecandle":"purple_candle","purplecandlecake":"purple_candle_cake","purplecarpet":"purple_carpet","purpleconcrete":"purple_concrete","purpleconcretepowder":"purple_concrete_powder","purpleglazedterracotta":"purple_glazed_terracotta","purpleharness":"purple_harness","purplestainedglass":"purple_stained_glass","purplestainedglasspane":"purple_stained_glass_pane","purpleterracotta":"purple_terracotta","purplewool":"purple_wool","purpurblock":"purpur_block","purpurpillar":"purpur_pillar","purpurslab":"purpur_slab","purpurstairs":"purpur_stairs","quartz":"quartz","quartzblock":"quartz_block","quartzbricks":"quartz_bricks","quartzdoubleslab":"quartz_double_slab","quartzore":"quartz_ore","quartzpillar":"quartz_pillar","quartzslab":"quartz_slab","quartzstairs":"quartz_stairs","rabbit":"rabbit","rabbitfoot":"rabbit_foot","rabbithide":"rabbit_hide","rabbitstew":"rabbit_stew","rail":"rail","raiserarmortrimsmithingtemplate":"raiser_armor_trim_smithing_template","rawcopper":"raw_copper","rawcopperblock":"raw_copper_block","rawgold":"raw_gold","rawgoldblock":"raw_gold_block","rawiron":"raw_iron","rawironblock":"raw_iron_block","record":"record","record11":"record_11","record13":"record_13","record5":"record_5","recordblocks":"record_blocks","recordcat":"record_cat","recordchirp":"record_chirp","recordcreator":"record_creator","recordcreatormusicbox":"record_creator_music_box","recordfar":"record_far","recordmall":"record_mall","recordmellohi":"record_mellohi","recordotherside":"record_otherside","recordpigstep":"record_pigstep","recordprecipice":"record_precipice","recordrelic":"record_relic","recordstal":"record_stal","recordstrad":"record_strad","recordtears":"record_tears","recordwait":"record_wait","recordward":"record_ward","recoverycompass":"recovery_compass","redcandle":"red_candle","redcandlecake":"red_candle_cake","redcarpet":"red_carpet","redconcrete":"red_concrete","redconcretepowder":"red_concrete_powder","redflower":"red_flower","redglazedterracotta":"red_glazed_terracotta","redharness":"red_harness","redmushroom":"red_mushroom","redmushroomblock":"red_mushroom_block","rednetherbrick":"red_nether_brick","rednetherbrickslab":"red_nether_brick_slab","rednetherbrickstairs":"red_nether_brick_stairs","rednetherbrickwall":"red_nether_brick_wall","redsand":"red_sand","redsandstone":"red_sandstone","redsandstonedoubleslab":"red_sandstone_double_slab","redsandstoneslab":"red_sandstone_slab","redsandstonestairs":"red_sandstone_stairs","redsandstonewall":"red_sandstone_wall","redstainedglass":"red_stained_glass","redstainedglasspane":"red_stained_glass_pane","redterracotta":"red_terracotta","redtulip":"red_tulip","redwool":"red_wool","redstone":"redstone","redstoneblock":"redstone_block","redstonelamp":"redstone_lamp","redstoneore":"redstone_ore","redstonetorch":"redstone_torch","redstonewire":"redstone_wire","reeds":"reeds","reinforceddeepslate":"reinforced_deepslate","repeater":"repeater","repeatingcommandblock":"repeating_command_block","resinblock":"resin_block","resinbrick":"resin_brick","resinbrickdoubleslab":"resin_brick_double_slab","resinbrickslab":"resin_brick_slab","resinbrickstairs":"resin_brick_stairs","resinbrickwall":"resin_brick_wall","resinbricks":"resin_bricks","resinclump":"resin_clump","respawnanchor":"respawn_anchor","ribarmortrimsmithingtemplate":"rib_armor_trim_smithing_template","rosebush":"rose_bush","rottenflesh":"rotten_flesh","ruby":"ruby","saddle":"saddle","salmon":"salmon","sand":"sand","sandstone":"sandstone","sandstonedoubleslab":"sandstone_double_slab","sandstoneslab":"sandstone_slab","sandstonestairs":"sandstone_stairs","sandstonewall":"sandstone_wall","scaffolding":"scaffolding","scrapepotterysherd":"scrape_pottery_sherd","sculk":"sculk","sculkcatalyst":"sculk_catalyst","sculksensor":"sculk_sensor","sculkshrieker":"sculk_shrieker","sculkvein":"sculk_vein","sealantern":"seaLantern","seapickle":"sea_pickle","sentryarmortrimsmithingtemplate":"sentry_armor_trim_smithing_template","shaperarmortrimsmithingtemplate":"shaper_armor_trim_smithing_template","sheafpotterysherd":"sheaf_pottery_sherd","shears":"shears","shelterpotterysherd":"shelter_pottery_sherd","shield":"shield","shortdrygrass":"short_dry_grass","shroomlight":"shroomlight","shulkerbox":"shulkerBox","shulkerboxblack":"shulkerBoxBlack","shulkerboxblue":"shulkerBoxBlue","shulkerboxbrown":"shulkerBoxBrown","shulkerboxcyan":"shulkerBoxCyan","shulkerboxgray":"shulkerBoxGray","shulkerboxgreen":"shulkerBoxGreen","shulkerboxlightblue":"shulkerBoxLightBlue","shulkerboxlime":"shulkerBoxLime","shulkerboxmagenta":"shulkerBoxMagenta","shulkerboxorange":"shulkerBoxOrange","shulkerboxpink":"shulkerBoxPink","shulkerboxpurple":"shulkerBoxPurple","shulkerboxred":"shulkerBoxRed","shulkerboxsilver":"shulkerBoxSilver","shulkerboxwhite":"shulkerBoxWhite","shulkerboxyellow":"shulkerBoxYellow","shulkershell":"shulker_shell","sign":"sign","silencearmortrimsmithingtemplate":"silence_armor_trim_smithing_template","silverglazedterracotta":"silver_glazed_terracotta","skeletonskull":"skeleton_skull","skullbannerpattern":"skull_banner_pattern","skullpotterysherd":"skull_pottery_sherd","slime":"slime","slimeball":"slime_ball","smallamethystbud":"small_amethyst_bud","smalldripleafblock":"small_dripleaf_block","smithingtable":"smithing_table","smithingtemplate":"smithing_template","smoker":"smoker","smoothbasalt":"smooth_basalt","smoothquartz":"smooth_quartz","smoothquartzslab":"smooth_quartz_slab","smoothquartzstairs":"smooth_quartz_stairs","smoothredsandstone":"smooth_red_sandstone","smoothredsandstoneslab":"smooth_red_sandstone_slab","smoothredsandstonestairs":"smooth_red_sandstone_stairs","smoothsandstone":"smooth_sandstone","smoothsandstoneslab":"smooth_sandstone_slab","smoothsandstonestairs":"smooth_sandstone_stairs","smoothstone":"smooth_stone","smoothstoneslab":"smooth_stone_slab","snifferegg":"sniffer_egg","snortpotterysherd":"snort_pottery_sherd","snoutarmortrimsmithingtemplate":"snout_armor_trim_smithing_template","snow":"snow","snowlayer":"snow_layer","snowball":"snowball","soulcampfire":"soul_campfire","soulfire":"soul_fire","soullantern":"soul_lantern","soulsand":"soul_sand","soulsoil":"soul_soil","soultorch":"soul_torch","speckledmelon":"speckled_melon","spidereye":"spider_eye","spirearmortrimsmithingtemplate":"spire_armor_trim_smithing_template","sporeblossom":"spore_blossom","sprucefence":"spruceFence","spruceboat":"spruce_boat","sprucebutton":"spruce_button","sprucechestboat":"spruce_chest_boat","sprucedoor":"spruce_door","sprucefencegate":"spruce_fence_gate","sprucehangingsign":"spruce_hanging_sign","spruceleaves":"spruce_leaves","sprucelog":"spruce_log","spruceplanks":"spruce_planks","sprucepressureplate":"spruce_pressure_plate","sprucesapling":"spruce_sapling","sprucesign":"spruce_sign","spruceslab":"spruce_slab","sprucestairs":"spruce_stairs","sprucestandingsign":"spruce_standing_sign","sprucetrapdoor":"spruce_trapdoor","sprucewood":"spruce_wood","spyglass":"spyglass","stainedhardenedclay":"stained_hardened_clay","standingbanner":"standing_banner","standingsign":"standing_sign","steak":"steak","stick":"stick","stickypiston":"sticky_piston","stone":"stone","stoneaxe":"stone_axe","stonebrickdoubleslab":"stone_brick_double_slab","stonebrickslab":"stone_brick_slab","stonebrickstairs":"stone_brick_stairs","stonebrickwall":"stone_brick_wall","stonebricks":"stone_bricks","stonebutton":"stone_button","stonehoe":"stone_hoe","stonepickaxe":"stone_pickaxe","stonepressureplate":"stone_pressure_plate","stoneshovel":"stone_shovel","stoneslab":"stone_slab","stonestairs":"stone_stairs","stonesword":"stone_sword","stonebrick":"stonebrick","stonecutter":"stonecutter","stonecutterblock":"stonecutter_block","string":"string","strippedacacialog":"stripped_acacia_log","strippedbambooblock":"stripped_bamboo_block","strippedbirchlog":"stripped_birch_log","strippedcherrylog":"stripped_cherry_log","strippedcherrywood":"stripped_cherry_wood","strippedcrimsonhyphae":"stripped_crimson_hyphae","strippedcrimsonstem":"stripped_crimson_stem","strippeddarkoaklog":"stripped_dark_oak_log","strippedjunglelog":"stripped_jungle_log","strippedmangrovelog":"stripped_mangrove_log","strippedmangrovewood":"stripped_mangrove_wood","strippedoaklog":"stripped_oak_log","strippedpaleoaklog":"stripped_pale_oak_log","strippedpaleoakwood":"stripped_pale_oak_wood","strippedsprucelog":"stripped_spruce_log","strippedwarpedhyphae":"stripped_warped_hyphae","strippedwarpedstem":"stripped_warped_stem","structureblock":"structure_block","structurevoid":"structure_void","sugar":"sugar","sunflower":"sunflower","suspiciousgravel":"suspicious_gravel","suspicioussand":"suspicious_sand","suspiciousstew":"suspicious_stew","sweetberries":"sweet_berries","sweetberrybush":"sweet_berry_bush","talldrygrass":"tall_dry_grass","tallgrass":"tallgrass","target":"target","tidearmortrimsmithingtemplate":"tide_armor_trim_smithing_template","tintedglass":"tinted_glass","tippedarrow":"tipped_arrow","tnt":"tnt","tntminecart":"tnt_minecart","torch":"torch","torchflower":"torchflower","torchflowerseeds":"torchflower_seeds","totem":"totem","trapdoor":"trapdoor","trappedchest":"trapped_chest","trialkey":"trial_key","trialspawner":"trial_spawner","trident":"trident","tripwire":"tripWire","tripwirehook":"tripwire_hook","tropicalcolorblue":"tropicalColorBlue","tropicalcolorbrown":"tropicalColorBrown","tropicalcolorgray":"tropicalColorGray","tropicalcolorgreen":"tropicalColorGreen","tropicalcolorlime":"tropicalColorLime","tropicalcolormagenta":"tropicalColorMagenta","tropicalcolororange":"tropicalColorOrange","tropicalcolorplum":"tropicalColorPlum","tropicalcolorred":"tropicalColorRed","tropicalcolorrose":"tropicalColorRose","tropicalcolorsilver":"tropicalColorSilver","tropicalcolorsky":"tropicalColorSky","tropicalcolorteal":"tropicalColorTeal","tropicalcolorwhite":"tropicalColorWhite","tropicalcoloryellow":"tropicalColorYellow","tropicalschoolanemone":"tropicalSchoolAnemone","tropicalschoolblacktang":"tropicalSchoolBlackTang","tropicalschoolbluedory":"tropicalSchoolBlueDory","tropicalschoolbutterflyfish":"tropicalSchoolButterflyFish","tropicalschoolcichlid":"tropicalSchoolCichlid","tropicalschoolclownfish":"tropicalSchoolClownfish","tropicalschoolcottoncandybetta":"tropicalSchoolCottonCandyBetta","tropicalschooldottyback":"tropicalSchoolDottyback","tropicalschoolemperorredsnapper":"tropicalSchoolEmperorRedSnapper","tropicalschoolgoatfish":"tropicalSchoolGoatfish","tropicalschoolmoorishidol":"tropicalSchoolMoorishIdol","tropicalschoolornatebutterfly":"tropicalSchoolOrnateButterfly","tropicalschoolparrotfish":"tropicalSchoolParrotfish","tropicalschoolqueenangelfish":"tropicalSchoolQueenAngelFish","tropicalschoolredcichlid":"tropicalSchoolRedCichlid","tropicalschoolredlippedblenny":"tropicalSchoolRedLippedBlenny","tropicalschoolredsnapper":"tropicalSchoolRedSnapper","tropicalschoolthreadfin":"tropicalSchoolThreadfin","tropicalschooltomatoclown":"tropicalSchoolTomatoClown","tropicalschooltriggerfish":"tropicalSchoolTriggerfish","tropicalschoolyellowtang":"tropicalSchoolYellowTang","tropicalschoolyellowtailparrot":"tropicalSchoolYellowtailParrot","tubecoral":"tube_coral","tubecoralblock":"tube_coral_block","tubecoralfan":"tube_coral_fan","tuff":"tuff","tuffbrickslab":"tuff_brick_slab","tuffbrickstairs":"tuff_brick_stairs","tuffbrickwall":"tuff_brick_wall","tuffbricks":"tuff_bricks","tuffslab":"tuff_slab","tuffstairs":"tuff_stairs","tuffwall":"tuff_wall","turtleegg":"turtle_egg","turtlehelmet":"turtle_helmet","turtleshellpiece":"turtle_shell_piece","twistingvines":"twisting_vines","unknown":"unknown","unlitredstonetorch":"unlit_redstone_torch","vault":"vault","verdantfroglight":"verdant_froglight","vexarmortrimsmithingtemplate":"vex_armor_trim_smithing_template","vine":"vine","wardarmortrimsmithingtemplate":"ward_armor_trim_smithing_template","warpedbutton":"warped_button","warpeddoor":"warped_door","warpeddoubleslab":"warped_double_slab","warpedfence":"warped_fence","warpedfencegate":"warped_fence_gate","warpedfungus":"warped_fungus","warpedfungusonastick":"warped_fungus_on_a_stick","warpedhangingsign":"warped_hanging_sign","warpedhyphae":"warped_hyphae","warpednylium":"warped_nylium","warpedplanks":"warped_planks","warpedpressureplate":"warped_pressure_plate","warpedroots":"warped_roots","warpedsign":"warped_sign","warpedslab":"warped_slab","warpedstairs":"warped_stairs","warpedstandingsign":"warped_standing_sign","warpedstem":"warped_stem","warpedtrapdoor":"warped_trapdoor","warpedwallsign":"warped_wall_sign","warpedwartblock":"warped_wart_block","water":"water","waterlily":"waterlily","waxedchiseledcopper":"waxed_chiseled_copper","waxedcopper":"waxed_copper","waxedcopperbulb":"waxed_copper_bulb","waxedcopperdoor":"waxed_copper_door","waxedcoppergrate":"waxed_copper_grate","waxedcoppertrapdoor":"waxed_copper_trapdoor","waxedcutcopper":"waxed_cut_copper","waxedcutcopperslab":"waxed_cut_copper_slab","waxedcutcopperstairs":"waxed_cut_copper_stairs","waxedexposedchiseledcopper":"waxed_exposed_chiseled_copper","waxedexposedcopper":"waxed_exposed_copper","waxedexposedcopperbulb":"waxed_exposed_copper_bulb","waxedexposedcopperdoor":"waxed_exposed_copper_door","waxedexposedcoppergrate":"waxed_exposed_copper_grate","waxedexposedcoppertrapdoor":"waxed_exposed_copper_trapdoor","waxedexposedcutcopper":"waxed_exposed_cut_copper","waxedexposedcutcopperslab":"waxed_exposed_cut_copper_slab","waxedexposedcutcopperstairs":"waxed_exposed_cut_copper_stairs","waxedoxidizedchiseledcopper":"waxed_oxidized_chiseled_copper","waxedoxidizedcopper":"waxed_oxidized_copper","waxedoxidizedcopperbulb":"waxed_oxidized_copper_bulb","waxedoxidizedcopperdoor":"waxed_oxidized_copper_door","waxedoxidizedcoppergrate":"waxed_oxidized_copper_grate","waxedoxidizedcoppertrapdoor":"waxed_oxidized_copper_trapdoor","waxedoxidizedcutcopper":"waxed_oxidized_cut_copper","waxedoxidizedcutcopperslab":"waxed_oxidized_cut_copper_slab","waxedoxidizedcutcopperstairs":"waxed_oxidized_cut_copper_stairs","waxedweatheredchiseledcopper":"waxed_weathered_chiseled_copper","waxedweatheredcopper":"waxed_weathered_copper","waxedweatheredcopperbulb":"waxed_weathered_copper_bulb","waxedweatheredcopperdoor":"waxed_weathered_copper_door","waxedweatheredcoppergrate":"waxed_weathered_copper_grate","waxedweatheredcoppertrapdoor":"waxed_weathered_copper_trapdoor","waxedweatheredcutcopper":"waxed_weathered_cut_copper","waxedweatheredcutcopperslab":"waxed_weathered_cut_copper_slab","waxedweatheredcutcopperstairs":"waxed_weathered_cut_copper_stairs","wayfinderarmortrimsmithingtemplate":"wayfinder_armor_trim_smithing_template","weatheredchiseledcopper":"weathered_chiseled_copper","weatheredcopper":"weathered_copper","weatheredcopperbulb":"weathered_copper_bulb","weatheredcopperdoor":"weathered_copper_door","weatheredcoppergrate":"weathered_copper_grate","weatheredcoppertrapdoor":"weathered_copper_trapdoor","weatheredcutcopper":"weathered_cut_copper","weatheredcutcopperslab":"weathered_cut_copper_slab","weatheredcutcopperstairs":"weathered_cut_copper_stairs","web":"web","weepingvines":"weeping_vines","wetsponge":"wet_sponge","wheat":"wheat","wheatseeds":"wheat_seeds","whitecandle":"white_candle","whitecandlecake":"white_candle_cake","whitecarpet":"white_carpet","whiteconcrete":"white_concrete","whiteconcretepowder":"white_concrete_powder","whiteglazedterracotta":"white_glazed_terracotta","whiteharness":"white_harness","whitestainedglass":"white_stained_glass","whitestainedglasspane":"white_stained_glass_pane","whiteterracotta":"white_terracotta","whitetulip":"white_tulip","whitewool":"white_wool","wildarmortrimsmithingtemplate":"wild_armor_trim_smithing_template","wildflowers":"wildflowers","windcharge":"wind_charge","witherrose":"wither_rose","witherskeletonskull":"wither_skeleton_skull","wolfarmor":"wolf_armor","woodenaxe":"wooden_axe","woodenbutton":"wooden_button","woodendoor":"wooden_door","woodenhoe":"wooden_hoe","woodenpickaxe":"wooden_pickaxe","woodenpressureplate":"wooden_pressure_plate","woodenshovel":"wooden_shovel","woodenslab":"wooden_slab","woodensword":"wooden_sword","wool":"wool","writablebook":"writable_book","writtenbook":"written_book","yellowcandle":"yellow_candle","yellowcandlecake":"yellow_candle_cake","yellowcarpet":"yellow_carpet","yellowconcrete":"yellow_concrete","yellowconcretepowder":"yellow_concrete_powder","yellowflower":"yellow_flower","yellowglazedterracotta":"yellow_glazed_terracotta","yellowharness":"yellow_harness","yellowstainedglass":"yellow_stained_glass","yellowstainedglasspane":"yellow_stained_glass_pane","yellowterracotta":"yellow_terracotta","yellowwool":"yellow_wool","zombiehead":"zombie_head"};

/**
 * 查官方中文名。查不到返回 undefined。
 */
function officialDisplayName(typeId) {
  if (!typeId) return undefined;
  if (Object.prototype.hasOwnProperty.call(OFFICIAL_ITEM_NAMES, typeId)) {
    return OFFICIAL_ITEM_NAMES[typeId];
  }
  const key = typeId.replace(/_/g, "").toLowerCase();
  if (Object.prototype.hasOwnProperty.call(NORMALIZED, key)) {
    return OFFICIAL_ITEM_NAMES[NORMALIZED[key]];
  }
  return undefined;
}

function officialNameCount() {
  return Object.keys(OFFICIAL_ITEM_NAMES).length;
}

// ===== item_names.js =====
/**
 * typeId -> 中文名 映射表。
 *
 * 设计原则：**映射不到就显示原始 ID**，不做任何猜测。
 * 所以这张表可以随时补充，不会出现"某个物品显示不出来"的情况 ——
 * 没列进去的只是暂时显示成 diamond 而不是"钻石"。
 *
 * 键是去掉 minecraft: 前缀的 typeId（见 util.js 的 stripNamespace）。
 *
 * 表里有同义项是刻意的：同一件东西在不同版本里的 typeId 变过
 * （wood -> oak_planks、grass -> grass_block、lit_furnace -> furnace 等），
 * 两个都留着就能跨版本兼容，反正查不到的那个永远不会被命中。
 */



const ITEM_NAMES = {
  // ===== 容器 =====
  chest: "箱子",
  trapped_chest: "陷阱箱",
  barrel: "木桶",
  ender_chest: "末影箱",
  dispenser: "发射器",
  dropper: "投掷器",
  hopper: "漏斗",
  crafter: "合成器",
  furnace: "熔炉",
  lit_furnace: "熔炉",
  blast_furnace: "高炉",
  lit_blast_furnace: "高炉",
  smoker: "烟熏炉",
  lit_smoker: "烟熏炉",
  brewing_stand: "酿造台",
  lectern: "讲台",
  campfire: "营火",
  soul_campfire: "灵魂营火",
  chest_minecart: "箱子矿车",
  hopper_minecart: "漏斗矿车",
  undyed_shulker_box: "潜影盒",
  white_shulker_box: "白色潜影盒",
  orange_shulker_box: "橙色潜影盒",
  magenta_shulker_box: "品红色潜影盒",
  light_blue_shulker_box: "淡蓝色潜影盒",
  yellow_shulker_box: "黄色潜影盒",
  lime_shulker_box: "黄绿色潜影盒",
  pink_shulker_box: "粉红色潜影盒",
  gray_shulker_box: "灰色潜影盒",
  light_gray_shulker_box: "淡灰色潜影盒",
  cyan_shulker_box: "青色潜影盒",
  purple_shulker_box: "紫色潜影盒",
  blue_shulker_box: "蓝色潜影盒",
  brown_shulker_box: "棕色潜影盒",
  green_shulker_box: "绿色潜影盒",
  red_shulker_box: "红色潜影盒",
  black_shulker_box: "黑色潜影盒",

  // ===== 矿物与材料 =====
  coal: "煤炭",
  charcoal: "木炭",
  iron_ingot: "铁锭",
  gold_ingot: "金锭",
  copper_ingot: "铜锭",
  netherite_ingot: "下界合金锭",
  netherite_scrap: "下界合金碎片",
  diamond: "钻石",
  emerald: "绿宝石",
  lapis_lazuli: "青金石",
  redstone: "红石",
  quartz: "下界石英",
  amethyst_shard: "紫水晶碎片",
  echo_shard: "回响碎片",
  iron_nugget: "铁粒",
  gold_nugget: "金粒",
  nether_star: "下界之星",
  stick: "木棍",
  blaze_rod: "烈焰棒",
  blaze_powder: "烈焰粉",
  gunpowder: "火药",
  flint: "燧石",
  leather: "皮革",
  feather: "羽毛",
  string: "线",
  bone: "骨头",
  bone_meal: "骨粉",
  slime_ball: "黏液球",
  ender_pearl: "末影珍珠",
  ender_eye: "末影之眼",
  ghast_tear: "恶魂之泪",
  magma_cream: "岩浆膏",
  nautilus_shell: "鹦鹉螺壳",
  prismarine_shard: "海晶碎片",
  prismarine_crystals: "海晶砂粒",
  ink_sac: "墨囊",
  glow_ink_sac: "荧光墨囊",
  honeycomb: "蜜脾",
  clay_ball: "黏土球",
  brick: "红砖",
  nether_brick: "下界砖",
  paper: "纸",
  book: "书",
  writable_book: "书与笔",
  written_book: "成书",
  enchanted_book: "附魔书",
  name_tag: "命名牌",
  map: "地图",
  arrow: "箭",
  spectral_arrow: "光灵箭",
  stick_pile: "木棍堆",

  // ===== 方块 =====
  cobblestone: "圆石",
  mossy_cobblestone: "苔石",
  stone: "石头",
  granite: "花岗岩",
  diorite: "闪长岩",
  andesite: "安山岩",
  deepslate: "深板岩",
  cobbled_deepslate: "深板岩圆石",
  tuff: "凝灰岩",
  calcite: "方解石",
  dripstone_block: "滴水石块",
  obsidian: "黑曜石",
  crying_obsidian: "哭泣的黑曜石",
  bedrock: "基岩",
  dirt: "泥土",
  coarse_dirt: "砂土",
  rooted_dirt: "带根泥土",
  grass_block: "草方块",
  grass: "草方块",
  grass_path: "土径",
  dirt_with_roots: "带根泥土",
  sand: "沙子",
  red_sand: "红沙",
  gravel: "沙砾",
  clay: "黏土",
  sandstone: "砂岩",
  red_sandstone: "红砂岩",
  snow: "雪",
  snow_layer: "雪",
  ice: "冰",
  packed_ice: "浮冰",
  blue_ice: "蓝冰",
  netherrack: "下界岩",
  soul_sand: "灵魂沙",
  soul_soil: "灵魂土",
  glowstone: "荧石",
  basalt: "玄武岩",
  blackstone: "黑石",
  end_stone: "末地石",
  purpur_block: "紫珀块",
  prismarine: "海晶石",
  sea_lantern: "海晶灯",
  magma: "岩浆块",
  sponge: "海绵",
  wet_sponge: "湿海绵",
  glass: "玻璃",
  glass_pane: "玻璃板",
  brick_block: "红砖块",
  stone_bricks: "石砖",
  bookshelf: "书架",
  crafting_table: "工作台",
  furnace_block: "熔炉",
  anvil: "铁砧",
  enchanting_table: "附魔台",
  beacon: "信标",
  tnt: "TNT",
  torch: "火把",
  soul_torch: "灵魂火把",
  lantern: "灯笼",
  soul_lantern: "灵魂灯笼",
  ladder: "梯子",
  scaffolding: "脚手架",
  iron_bars: "铁栏杆",
  cobweb: "蜘蛛网",
  web: "蜘蛛网",
  hay_block: "干草捆",
  seagrass: "海草",
  kelp: "海带",
  dried_kelp_block: "干海带块",
  bamboo: "竹子",
  ochre_froglight: "赭黄蛙明灯",
  verdant_froglight: "青翠蛙明灯",
  pearlescent_froglight: "珠光蛙明灯",

  // ===== 木头与木板 =====
  log: "橡木原木",
  oak_log: "橡木原木",
  spruce_log: "云杉原木",
  birch_log: "白桦原木",
  jungle_log: "丛林原木",
  acacia_log: "金合欢原木",
  dark_oak_log: "深色橡木原木",
  mangrove_log: "红树原木",
  cherry_log: "樱花原木",
  planks: "橡木木板",
  oak_planks: "橡木木板",
  spruce_planks: "云杉木板",
  birch_planks: "白桦木板",
  jungle_planks: "丛林木板",
  acacia_planks: "金合欢木板",
  dark_oak_planks: "深色橡木木板",
  mangrove_planks: "红树木板",
  cherry_planks: "樱花木板",
  bamboo_planks: "竹板",
  crimson_planks: "绯红木板",
  warped_planks: "诡异木板",
  stripped_oak_log: "去皮橡木原木",
  stripped_spruce_log: "去皮云杉原木",
  stripped_birch_log: "去皮白桦原木",

  // ===== 羊毛与染料 =====
  white_wool: "白色羊毛",
  orange_wool: "橙色羊毛",
  magenta_wool: "品红色羊毛",
  light_blue_wool: "淡蓝色羊毛",
  yellow_wool: "黄色羊毛",
  lime_wool: "黄绿色羊毛",
  pink_wool: "粉红色羊毛",
  gray_wool: "灰色羊毛",
  light_gray_wool: "淡灰色羊毛",
  cyan_wool: "青色羊毛",
  purple_wool: "紫色羊毛",
  blue_wool: "蓝色羊毛",
  brown_wool: "棕色羊毛",
  green_wool: "绿色羊毛",
  red_wool: "红色羊毛",
  black_wool: "黑色羊毛",
  white_dye: "白色染料",
  orange_dye: "橙色染料",
  magenta_dye: "品红色染料",
  light_blue_dye: "淡蓝色染料",
  yellow_dye: "黄色染料",
  lime_dye: "黄绿色染料",
  pink_dye: "粉红色染料",
  gray_dye: "灰色染料",
  light_gray_dye: "淡灰色染料",
  cyan_dye: "青色染料",
  purple_dye: "紫色染料",
  blue_dye: "蓝色染料",
  brown_dye: "棕色染料",
  green_dye: "绿色染料",
  red_dye: "红色染料",
  black_dye: "黑色染料",
  cocoa_beans: "可可豆",

  // ===== 工具与武器 =====
  wooden_pickaxe: "木镐",
  stone_pickaxe: "石镐",
  iron_pickaxe: "铁镐",
  golden_pickaxe: "金镐",
  diamond_pickaxe: "钻石镐",
  netherite_pickaxe: "下界合金镐",
  wooden_axe: "木斧",
  stone_axe: "石斧",
  iron_axe: "铁斧",
  golden_axe: "金斧",
  diamond_axe: "钻石斧",
  netherite_axe: "下界合金斧",
  wooden_shovel: "木锹",
  stone_shovel: "石锹",
  iron_shovel: "铁锹",
  golden_shovel: "金锹",
  diamond_shovel: "钻石锹",
  netherite_shovel: "下界合金锹",
  wooden_hoe: "木锄",
  stone_hoe: "石锄",
  iron_hoe: "铁锄",
  golden_hoe: "金锄",
  diamond_hoe: "钻石锄",
  netherite_hoe: "下界合金锄",
  wooden_sword: "木剑",
  stone_sword: "石剑",
  iron_sword: "铁剑",
  golden_sword: "金剑",
  diamond_sword: "钻石剑",
  netherite_sword: "下界合金剑",
  bow: "弓",
  crossbow: "弩",
  trident: "三叉戟",
  shield: "盾牌",
  fishing_rod: "钓鱼竿",
  flint_and_steel: "打火石",
  shears: "剪刀",
  bucket: "桶",
  water_bucket: "水桶",
  lava_bucket: "熔岩桶",
  milk_bucket: "奶桶",
  cod_bucket: "鳕鱼桶",
  salmon_bucket: "鲑鱼桶",
  pufferfish_bucket: "河豚桶",
  tropical_fish_bucket: "热带鱼桶",
  axolotl_bucket: "美西螈桶",
  tadpole_bucket: "蝌蚪桶",
  powder_snow_bucket: "细雪桶",
  compass: "指南针",
  clock: "时钟",
  spyglass: "望远镜",
  lead: "拴绳",
  saddle: "鞍",
  elytra: "鞘翅",
  firework_rocket: "烟花火箭",
  firework_star: "焰火之星",
  fireworks_charge: "焰火之星",
  fireworksCharge: "焰火之星",
  bundle: "收纳袋",
  banner_pattern: "旗帜图案",
  potion: "药水",
  splash_potion: "喷溅药水",
  lingering_potion: "滞留药水",
  horse_armor_leather: "皮革马铠",
  horse_armor_iron: "铁马铠",
  horse_armor_gold: "金马铠",
  horse_armor_diamond: "钻石马铠",
  leather_horse_armor: "皮革马铠",
  iron_horse_armor: "铁马铠",
  golden_horse_armor: "金马铠",
  diamond_horse_armor: "钻石马铠",
  // 官方 zh_CN.lang 里这四件仍是**老式连写 id**（item.horsearmorleather.name 等），
  // 运行时引擎报的就是它 —— 这也是皮革马铠一直没图标的原因之一
  // （例外表里只写了 leather_horse_armor 那种写法，见 item_texture_map.mjs）。
  horsearmorleather: "皮革马铠",
  horsearmoriron: "铁马铠",
  horsearmorgold: "金马铠",
  horsearmordiamond: "钻石马铠",
  // 1.26 新增的马铠：id 与贴图同名，名字取自官方 zh_CN.lang
  // （item.copper_horse_armor.name / item.netherite_horse_armor.name）。
  // 这两个 id 在官方数值 id 表（item_numeric_ids.js）里已经存在，这里补的是
  // **名字**与**物品宇宙**这一层：item_names.js 是枚举源，加了 id 就是加了物品。
  copper_horse_armor: "铜马铠",
  netherite_horse_armor: "下界合金马铠",
  oak_chest_boat: "橡木运输船",
  // 旧版把运输船报成单个 chest_boat（木种只是变体），所以要单独给名字，
  // 否则标题区会退化成显示英文 id。
  chest_boat: "运输船",
  bamboo_chest_raft: "竹筏运输船",
  spruce_chest_boat: "云杉运输船",
  birch_chest_boat: "白桦运输船",
  jungle_chest_boat: "丛林木运输船",
  acacia_chest_boat: "金合欢运输船",
  dark_oak_chest_boat: "深色橡木运输船",
  mangrove_chest_boat: "红树运输船",
  cherry_chest_boat: "樱花运输船",
  pale_oak_chest_boat: "苍白橡木运输船",
  // ===== 1.26 新增（图标来自 Java 1.21.4+ 的染色收纳袋贴图兜底）=====
  // 名字按"颜色+收纳袋"的官方命名习惯补；矛类是 1.26 新武器，官方中文名
  // 以后如有出入再改。染料色的英文对照：light_gray 在表里其它地方都译"淡灰"。
  black_bundle: "黑色收纳袋",
  blue_bundle: "蓝色收纳袋",
  brown_bundle: "棕色收纳袋",
  cyan_bundle: "青色收纳袋",
  gray_bundle: "灰色收纳袋",
  green_bundle: "绿色收纳袋",
  light_blue_bundle: "淡蓝色收纳袋",
  light_gray_bundle: "淡灰色收纳袋",
  lime_bundle: "黄绿色收纳袋",
  magenta_bundle: "品红色收纳袋",
  orange_bundle: "橙色收纳袋",
  pink_bundle: "粉红色收纳袋",
  purple_bundle: "紫色收纳袋",
  red_bundle: "红色收纳袋",
  white_bundle: "白色收纳袋",
  yellow_bundle: "黄色收纳袋",
  // 矛（1.26 新武器）。这些目前没有贴图来源（基岩 1.26 的贴图在 .fsb 里，
  // Java 还没这个物品），所以暂时仍是问号；名字先占位。
  wooden_spear: "木矛",
  stone_spear: "石矛",
  copper_spear: "铜矛",
  iron_spear: "铁矛",
  golden_spear: "金矛",
  diamond_spear: "钻石矛",
  netherite_spear: "下界合金矛",
  // 1.26 新植物/方块物品，同样暂无贴图来源，名字占位
  red_shrub: "红色灌木",
  shelf_mushroom: "架生蘑菇",
  totem_of_undying: "不死图腾",
  ender_chest_item: "末影箱",

  // ===== 1.26 铜傀儡雕像（8 件）=====
  //
  // 名字取自 1.26.60.24 预览版官方语言文件 `resource_pack/texts/zh_CN.lang`：
  //   tile.copper_golem_statue.name=铜傀儡像
  //   tile.exposed_copper_golem_statue.name=斑驳铜傀儡像     （oxidized/weathered 同理）
  //   tile.waxed_copper_golem_statue.name=涂蜡铜傀儡像       （涂蜡 = waxed，叠加在最前）
  // 1.21.90 的官方语言表里没有这 8 个 id，所以整批物品都没被枚举到；
  // 本表同时是**物品枚举的来源**（allItemIds = 本表 ∪ 官方表），
  // 所以这 8 条一写进来，构建脚本就会把它们当真的物品去要图标 ——
  // 图标由 build-item-glyphs.mjs 的 renderCopperGolemStatueIcon 自渲染
  // （原版没有它们的静态物品贴图，只有实体贴图）。
  copper_golem_statue: "铜傀儡像",
  exposed_copper_golem_statue: "斑驳铜傀儡像",
  weathered_copper_golem_statue: "风化铜傀儡像",
  oxidized_copper_golem_statue: "氧化铜傀儡像",
  waxed_copper_golem_statue: "涂蜡铜傀儡像",
  waxed_exposed_copper_golem_statue: "涂蜡斑驳铜傀儡像",
  waxed_weathered_copper_golem_statue: "涂蜡风化铜傀儡像",
  waxed_oxidized_copper_golem_statue: "涂蜡氧化铜傀儡像",

  // ===== 盔甲 =====
  leather_helmet: "皮革帽子",
  leather_chestplate: "皮革外套",
  leather_leggings: "皮革裤子",
  leather_boots: "皮革靴子",
  chainmail_helmet: "锁链头盔",
  chainmail_chestplate: "锁链胸甲",
  chainmail_leggings: "锁链护腿",
  chainmail_boots: "锁链靴子",
  iron_helmet: "铁头盔",
  iron_chestplate: "铁胸甲",
  iron_leggings: "铁护腿",
  iron_boots: "铁靴子",
  golden_helmet: "金头盔",
  golden_chestplate: "金胸甲",
  golden_leggings: "金护腿",
  golden_boots: "金靴子",
  diamond_helmet: "钻石头盔",
  diamond_chestplate: "钻石胸甲",
  diamond_leggings: "钻石护腿",
  diamond_boots: "钻石靴子",
  netherite_helmet: "下界合金头盔",
  netherite_chestplate: "下界合金胸甲",
  netherite_leggings: "下界合金护腿",
  netherite_boots: "下界合金靴子",
  turtle_helmet: "海龟壳",

  // ===== 食物 =====
  apple: "苹果",
  golden_apple: "金苹果",
  enchanted_golden_apple: "附魔金苹果",
  bread: "面包",
  cooked_beef: "熟牛肉",
  beef: "生牛肉",
  cooked_porkchop: "熟猪排",
  porkchop: "生猪排",
  cooked_chicken: "熟鸡肉",
  chicken: "生鸡肉",
  cooked_mutton: "熟羊肉",
  mutton: "生羊肉",
  cooked_rabbit: "熟兔肉",
  rabbit: "生兔肉",
  cooked_cod: "熟鳕鱼",
  cod: "生鳕鱼",
  cooked_salmon: "熟鲑鱼",
  salmon: "生鲑鱼",
  tropical_fish: "热带鱼",
  pufferfish: "河豚",
  carrot: "胡萝卜",
  golden_carrot: "金胡萝卜",
  potato: "马铃薯",
  baked_potato: "烤马铃薯",
  poisonous_potato: "毒马铃薯",
  beetroot: "甜菜根",
  beetroot_soup: "甜菜汤",
  mushroom_stew: "蘑菇煲",
  rabbit_stew: "兔肉煲",
  suspicious_stew: "迷之炖菜",
  melon_slice: "西瓜片",
  melon_block: "西瓜",
  pumpkin_pie: "南瓜派",
  pumpkin: "南瓜",
  carved_pumpkin: "雕刻南瓜",
  jack_o_lantern: "南瓜灯",
  cookie: "曲奇",
  cake: "蛋糕",
  sugar: "糖",
  egg: "鸡蛋",
  honey_bottle: "蜂蜜瓶",
  sweet_berries: "甜浆果",
  glow_berries: "发光浆果",
  dried_kelp: "干海带",
  chorus_fruit: "紫颂果",
  wheat: "小麦",
  wheat_seeds: "小麦种子",
  pumpkin_seeds: "南瓜种子",
  melon_seeds: "西瓜种子",
  beetroot_seeds: "甜菜种子",
  nether_wart: "下界疣",
  brown_mushroom: "棕色蘑菇",
  red_mushroom: "红色蘑菇",

  // ===== 1.26 新增物品 =====
  //
  // 下面三批在 1.21.90 的官方 zh_CN.lang 里**没有**，而 item_names_generated.js
  // 是按那份语言表生成的、每次构建都会被覆盖 —— 所以只能写在这张手工表里。
  // 名字逐条取自 1.26.60.24 预览版 resource_pack/texts/zh_CN.lang（键名见每节注释）。
  //
  // 顺带一提：这张表同时也是**物品枚举的来源**（见 allItemIds），
  // 所以加在这里的物品会被构建脚本捡起来去做图标；不写在这里就等于不存在。

  // 鹦鹉螺盔甲（lang 键：item.<id>.name）
  copper_nautilus_armor: "铜鹦鹉螺盔甲",
  iron_nautilus_armor: "铁鹦鹉螺盔甲",
  golden_nautilus_armor: "金鹦鹉螺盔甲",
  diamond_nautilus_armor: "钻石鹦鹉螺盔甲",
  netherite_nautilus_armor: "下界合金鹦鹉螺盔甲",

  // 失活的珊瑚（lang 键：tile.coral.<颜色>_dead / tile.coral_block.<颜色>_dead /
  // tile.coral_fan_dead.<颜色>_fan / tile.dead_<类型>_coral_wall_fan）
  //
  // ⚠️ 物品 id 用**类型词**（tube/brain/bubble/fire/horn），官方的中文名却是按
  // **颜色词**组织的（blue=管 / pink=脑纹 / purple=气泡 / red=火 / yellow=鹿角），
  // 所以下面这些名字是"id → 类型词 → 中文"直接对应，不是照颜色猜的。
  dead_tube_coral: "失活的管珊瑚",
  dead_brain_coral: "失活的脑纹珊瑚",
  dead_bubble_coral: "失活的气泡珊瑚",
  dead_fire_coral: "失活的火珊瑚",
  dead_horn_coral: "失活的鹿角珊瑚",
  dead_tube_coral_block: "失活的管珊瑚块",
  dead_brain_coral_block: "失活的脑纹珊瑚块",
  dead_bubble_coral_block: "失活的气泡珊瑚块",
  dead_fire_coral_block: "失活的火珊瑚块",
  dead_horn_coral_block: "失活的鹿角珊瑚块",
  dead_tube_coral_fan: "失活的管珊瑚扇",
  dead_brain_coral_fan: "失活的脑纹珊瑚扇",
  dead_bubble_coral_fan: "失活的气泡珊瑚扇",
  dead_fire_coral_fan: "失活的火珊瑚扇",
  dead_horn_coral_fan: "失活的鹿角珊瑚扇",
  dead_tube_coral_wall_fan: "失活的管珊瑚壁扇",
  dead_brain_coral_wall_fan: "失活的脑纹珊瑚壁扇",
  dead_bubble_coral_wall_fan: "失活的气泡珊瑚壁扇",
  dead_fire_coral_wall_fan: "失活的火珊瑚壁扇",
  dead_horn_coral_wall_fan: "失活的鹿角珊瑚壁扇",

  // 展示架（lang 键：tile.<id>.name）
  acacia_shelf: "金合欢木展示架",
  bamboo_shelf: "竹木展示架",
  birch_shelf: "白桦木展示架",
  cherry_shelf: "樱花木展示架",
  crimson_shelf: "绯红木展示架",
  dark_oak_shelf: "深色橡木展示架",
  jungle_shelf: "丛林木展示架",
  mangrove_shelf: "红树木展示架",
  oak_shelf: "橡木展示架",
  pale_oak_shelf: "苍白橡木展示架",
  poplar_shelf: "白杨木展示架",
  spruce_shelf: "云杉木展示架",
  warped_shelf: "诡异木展示架",

  // ===== 旗帜 =====
  //
  // 官方语言表里旗帜的名字是**按颜色分**的（item.banner.<颜色>.name），
  // 但用户的决定是"图标不分色、一律显示白色旗帜"——
  // 名字仍然按颜色补齐（真出现了才用得上），图标则统一走 banner_base 那一格。
  //
  // ⚠️ 提醒：本表同时是**物品枚举的来源**（allItemIds = 本表 ∪ 官方表），
  // 所以下面这 16 个 <颜色>_banner 会被构建脚本当成 16 个物品去要图标 ——
  // 已在 item_texture_map.mjs 的 ruleCandidates 里把它们统统映到 banner_base，
  // 否则它们会以"没有可用贴图"的形态出现在无图标清单里。
  banner: "旗帜",
  // tile.wall_banner.name（壁挂形态；站立的那个 lang 里就叫"旗帜"）
  wall_banner: "壁挂旗帜",
  // item.banner.<颜色>.name —— 颜色词用本工程自己的写法（language 里的 silver = light_gray，
  // lightBlue = light_blue），与 COLOR_TEXTURE_WORDS 的 16 个键一一对应。
  white_banner: "白色旗帜",
  orange_banner: "橙色旗帜",
  magenta_banner: "品红色旗帜",
  light_blue_banner: "淡蓝色旗帜",
  yellow_banner: "黄色旗帜",
  lime_banner: "黄绿色旗帜",
  pink_banner: "粉红色旗帜",
  gray_banner: "灰色旗帜",
  light_gray_banner: "淡灰色旗帜",
  cyan_banner: "青色旗帜",
  purple_banner: "紫色旗帜",
  blue_banner: "蓝色旗帜",
  brown_banner: "棕色旗帜",
  green_banner: "绿色旗帜",
  red_banner: "红色旗帜",
  black_banner: "黑色旗帜"
};

/**
 * 旧版 typeId 别名 -> 当前 typeId。
 *
 * 单独放一张表，而不是往 ITEM_NAMES 里塞重复键 ——
 * JavaScript 对象字面量遇到重复键会**静默覆盖**，不会报错，
 * 所以重复键是个查不出来的隐患。这里显式列出就不会有这个问题。
 *
 * 这些是历史上真实改过名的 typeId，留着可以跨版本兼容。
 */
const LEGACY_ALIASES = {
  wood: "oak_planks",
  grass: "grass_block",
  lit_furnace: "furnace",
  web: "cobweb",
  magma: "magma_block",
  brick_block: "bricks",
  stone_bricks: "stone_brick_block"
};

/**
 * 取物品的显示名。
 *
 * 查找顺序：
 *   1. 手工表（本文件的 ITEM_NAMES）  —— 精确、可覆盖
 *   2. 旧版 ID 别名表                 —— 跨版本兼容
 *   3. **官方语言文件生成的表**       —— 约 1000 条，覆盖面最广
 *   4. 都没有就退回 typeId 本身        —— 保证任何物品都有东西可显示
 *
 * 第 3 步是关键：手工表只有 350 多条，遇到没收录的物品（海泡菜、音符盒）
 * 以前只能显示英文 ID。现在官方表兜底，覆盖到近千种物品。
 */
function displayName(typeId) {
  if (!typeId) return "";

  if (Object.prototype.hasOwnProperty.call(ITEM_NAMES, typeId)) {
    return ITEM_NAMES[typeId];
  }

  // 旧 ID 先换成新 ID 再查一次
  if (Object.prototype.hasOwnProperty.call(LEGACY_ALIASES, typeId)) {
    const current = LEGACY_ALIASES[typeId];
    if (Object.prototype.hasOwnProperty.call(ITEM_NAMES, current)) {
      return ITEM_NAMES[current];
    }
    const official = officialDisplayName(current);
    if (official) return official;
  }

  const official = officialDisplayName(typeId);
  if (official) return official;

  return typeId;
}

/**
 * 所有已知的物品 ID（手工表 + 官方表的并集）。
 *
 * 构建脚本用这个来枚举物品，而不是只用 ITEM_NAMES ——
 * 否则会漏掉手工表没收录、但官方表有的那 700 多个物品。
 */
function allItemIds() {
  const ids = new Set(Object.keys(ITEM_NAMES));
  for (const id of Object.keys(OFFICIAL_ITEM_NAMES)) {
    ids.add(id);
  }
  return [...ids].sort();
}

/**
 * 手工表里有多少条映射。用于自测确认表没被写坏。
 */
function mappedCount() {
  return Object.keys(ITEM_NAMES).length;
}

// ===== box_overlay.js =====
/**
 * **潜影盒那一格的内容**：角标 / 空白 —— 一格到底怎么拼出来，这里说了算。
 *
 * ## 为什么单独成模块
 *
 * 两种内容的拼法都受**同一条硬约束**：引擎按"墨迹宽度"算字形前进宽度（不变量 I2），
 * 而**一格正好是 64 源像素**（屏幕上 16×16，见不变量 I1）。一格里的内容必须凑出
 * 正好 64 像素，否则这一行**后面所有格子一起推歪**。于是"一格能放什么"是可以算的：
 *
 * | 内容 | 前进宽度 | 补位 | 合计 |
 * |---|---|---|---|
 * | 角标字形 | 64（自身通宽，图案在右下） | 0 | 64 ✓ |
 * | 空白字形 | 64（自身通宽） | 0 | 64 ✓ |
 *
 * 这两个数（`BADGE_INK_PX` / `BOX_CELL_PX`）分别由生成器与图集几何决定，所以
 * `cellAdvance()` 的存在意义就是**把这条算式写成代码**，让自测与游戏内自检都能直接从
 * 成品字形宽度上核对它 —— 而不是各自手推一遍公式。
 *
 * ## 这里踩过的两个坑（别再走一遍）
 *
 *   ① **角标的墨迹只有右半边**：引擎既按墨迹算前进宽度、又把墨迹画在**笔位起点**
 *      （前导空白列被裁掉），所以"半格墨迹"的角标会落到格子的**左半边** ——
 *      实机表现就是"角标显示在左下角"，而且那一格的前进宽度只有 32。
 *      第一版试图用"角标 + 半格空格尺"凑够一格，方向正好反了（那只能挪动后续内容，
 *      挪不动角标自己）。**修法在生成器**：角标也和其它字形一样铺**通宽**的 alpha=1
 *      补位线（行 0 / 行 63 铺满 64 像素），前进宽度回到一整格，图案靠自身偏移落在右下。
 *      于是脚本侧**一个空格尺都不需要**，`cellFor()` 直接返回角标字形本身。
 *   ② **同一格想画两样东西**（角标 + 盒内总数）时，"定优先级"是最差解法：谁赢都有一方
 *      看不见，用户两次报上来（"开了总数看不到数字"／"开了总数看不到角标"）。真正能做的是
 *      给第二样东西**另找位置**；而"另找位置"又受"多一行就会让整块预览挪半行"的限制。
 *      这条路走不通（总数功能已整体删除，见 docs/PROGRESS.md §7.13），教训留在文档里。
 *
 * 断言：`cellAdvance()` 由自测与 `/peek:check` 双向核对；角标的"墨迹通宽 + 图案只在右下
 * 32×32"由生成器逐格断言、自测再按成品像素抽查一遍。
 */



/** 一格 = 64 源像素（与生成器的 CELL 一致；不变量 I1 保证它显示成 16 单位）。 */
const BOX_CELL_PX = 64;

/** 角标**图案**的边长：右下角 32×32（生成器有断言）。字形的前进宽度是整格（见文件头）。 */
const BADGE_INK_PX = 32;

/** 描述的种类。用常量而不是散落的字符串字面量 —— 拼错的时候能一眼看出来。 */
const BOX_OVERLAY = {
  badge: "badge",
  blank: "blank"
};

/** 空白叠放（潜影盒那一格不画堆叠数时用它）。 */
const BOX_OVERLAY_BLANK = Object.freeze({ kind: BOX_OVERLAY.blank });

/**
 * 角标叠放描述。字形为空（该物品没有图标）时返回 `null` = "不叠放"。
 *
 * @param {string} glyph 角标字形（`item_glyphs.boxBadgeGlyph` 给的）
 */
function boxBadgeOverlay(glyph) {
  return glyph ? { kind: BOX_OVERLAY.badge, glyph: String(glyph) } : null;
}

/** 空格尺在 `units` 档时的前进宽度（像素）。1 档 = 1/8 格。 */
function spacerAdvancePx(units) {
  return Math.round((BOX_CELL_PX * units) / SPACER_STEPS);
}

/**
 * 把叠放描述变成**一整格的内容字符串**。
 *
 * @param {object} descriptor `boxBadgeOverlay` / `BOX_OVERLAY_BLANK` 的产物
 * @returns {string} 一整格内容；`""` = 这个描述不管这一格（调用方照常画数目）
 */
function cellFor(descriptor) {
  if (!descriptor) return "";
  if (descriptor.kind === BOX_OVERLAY.badge) {
    if (!descriptor.glyph) return "";
    // 角标字形**自己就是一整格**（墨迹通宽、图案在右下，见文件头坑 ①）：
    // 不加任何空格尺 —— 加了反而把图案推到下一格去。
    return descriptor.glyph;
  }
  if (descriptor.kind === BOX_OVERLAY.blank) return blankGlyph();
  return "";
}

/**
 * 描述对应的**前进宽度**（像素）。不变式：`cellFor()` 非空时它必须正好等于一格 64。
 *
 * 自测与 `/peek:check` 都调它，并拿**实测的字形墨迹宽度**去核对（不是相信常量）。
 */
function cellAdvance(descriptor) {
  if (!descriptor) return 0;
  if (descriptor.kind === BOX_OVERLAY.badge) {
    if (!descriptor.glyph) return 0;
    // 角标字形自带通宽墨迹（生成器的补位线）→ 前进宽度就是一整格
    return BOX_CELL_PX;
  }
  if (descriptor.kind === BOX_OVERLAY.blank) return BOX_CELL_PX;
  return 0;
}

// ===== palette.js =====
/**
 * 位置网格的配色表 —— **这是唯一的一处定义，其他地方都从这里取。**
 *
 * 为什么必须集中：配色有**两种**落地方式
 *   1. `§` 文字颜色代码（scripts/text_colors.js，默认）
 *   2. 自定义彩色方块字形（scripts/grid_colors.js，备用）
 * 两条路都必须给出"第 N 列 = 同一种颜色"，否则切换开关时颜色会整体错位。
 * 之前两张表是各写一份的，结果文字表里"紫"和"粉"都写成了 `§d` ——
 * 实际只有 8 种颜色，而字形表是 9 种，两边根本对不上。重复定义就会这样。
 *
 * 语义：**索引 = 列号（从 0 数）**。
 * 也就是说第 1 列的物品永远是第 0 种颜色，第 2 行第 1 列也是第 0 种。
 * 这样颜色传达的信息是"在哪一列"，而不是"列表里的第几个"。
 *
 * 9 种正好对应标准容器的 9 列，所以不需要轮换，一列一色。
 */

/**
 * 9 种颜色。
 *
 * 顺序是按**相邻列对比度**排的：网格里左右相邻的格子颜色差别要明显，
 * 否则 9 个格子连成一片时看不出分隔。
 * 所以刻意让"黄/绿/青/蓝"这类相近色不相邻。
 *
 * `code` 是 `§` 后面的那个字符（16 种原版颜色里挑区分度高的 9 种）。
 * `rgb` 是画彩色方块字形时用的颜色，尽量贴近 `code` 对应的原版色，
 * 这样两种方案看起来是同一种颜色。
 */
const PALETTE = [
  { name: "红",   code: "c", rgb: [255, 85, 85] },
  { name: "黄",   code: "e", rgb: [255, 255, 85] },
  { name: "绿",   code: "a", rgb: [85, 255, 85] },
  { name: "青",   code: "b", rgb: [85, 255, 255] },
  { name: "蓝",   code: "9", rgb: [85, 130, 255] },
  { name: "淡紫", code: "d", rgb: [190, 85, 255] },
  { name: "金",   code: "6", rgb: [255, 170, 0] },
  { name: "白",   code: "f", rgb: [240, 240, 240] },
  // 第 9 种只能用剩下的暗色系了。选深紫而不是深绿/暗青，
  // 因为它和表里已有的绿、青、淡紫都拉得开（深绿会跟"绿"混淆）。
  { name: "深紫", code: "5", rgb: [140, 60, 190] }
];

/**
 * 空格子（容器里没东西的槽位）。
 *
 * 用深灰而不是某种彩色，因为"灰色 = 没东西"是最直觉的读法；
 * 而且灰色不在 PALETTE 里，不会和任何一列撞色。
 * 半透明是为了让它明显比有物品的格子弱一档。
 */
const EMPTY_CELL = { name: "空", code: "8", rgb: [90, 90, 100] };

/** 配色数量（= 标准容器的列数 9）。 */
const PALETTE_SIZE = PALETTE.length;

/**
 * 取第 index 种颜色的 `§` 代码字符（越界取模）。
 * 只返回字符，不含 `§` 本身 —— 拼接由调用方负责，便于集中处理。
 */
function paletteCode(index) {
  if (typeof index !== "number" || index < 0) return "";
  return PALETTE[index % PALETTE_SIZE].code;
}

// ===== grid_colors.js =====
/**
 * 位置网格的色块字形码点 —— **由 tools/icons/build-grid-glyphs.mjs 自动生成**，手改会被下次生成覆盖。
 *
 * 这是**备用**上色方案：默认走 § 文字颜色代码（scripts/text_colors.js）。
 * 两条路共用 scripts/palette.js 的颜色表，所以索引含义一致：
 *   **索引 = 列号（从 0 数）**，同一列的格子和物品名永远同色。
 */

/** 空格子字符的码点 */
const EMPTY_CELL_CODE = 58633;

const BASE = 58624;

/**
 * 取第 index 个配色的字符（index 会对配色数量取模）。
 */
function colorGlyph(index) {
  if (typeof index !== 'number' || index < 0) return '';
  return String.fromCharCode(BASE + (index % PALETTE_SIZE));
}

/**
 * 取空格子的字符。
 */
function emptyCellGlyph() {
  return String.fromCharCode(EMPTY_CELL_CODE);
}

// ===== text_colors.js =====
/**
 * 文字颜色代码。
 *
 * 用 Minecraft 的 `§` 颜色代码（section sign + 一个字符）**直接给文字上色**，
 * 而不是插彩色方块字形 —— 方块的横向占位窄，容易和相邻格重叠，
 * 而且需求本身就是"文字变色"。
 *
 * **已实测确认**：`§` 代码在 actionbar 上会被正常解析并渲染成颜色。
 *
 * 颜色表本身在 scripts/palette.js（唯一源头），这里只负责拼 `§` 前缀和
 * 取模等文本层面的处理。
 */



/** § 字符。写成转义序列，避免源码里出现裸控制字符。 */
const SECTION = "\u00a7";

/** 配色数量。索引 = 列号，一共 9 列 9 色。 */
const TEXT_COLOR_COUNT = PALETTE_SIZE;

/** 配色名称，仅用于说明和自测（游戏内不显示）。 */
const TEXT_COLOR_NAMES = PALETTE.map((c) => c.name);

/** 空格子用的颜色代码字符（深灰）。 */
const EMPTY_CELL_COLOR_CODE = EMPTY_CELL.code;

/** 取第 index 种颜色的 § 代码串（index 会取模）。 */
function colorCode(index) {
  const code = paletteCode(index);
  return code === "" ? "" : SECTION + code;
}

/** 取空格子的 § 代码串。 */
function emptyCellColorCode() {
  return SECTION + EMPTY_CELL_COLOR_CODE;
}

/** 取"重置颜色"的 § 代码串。 */
function resetColorCode() {
  return SECTION + "r";
}

// ===== container_shapes.js =====
/**
 * 异形容器的内部布局（槽位 -> 网格坐标）。
 *
 * ## 为什么需要它
 *
 * 默认网格按"槽位号顺序"排（每行 9 格），对箱子/潜影盒成立，但熔炉、酿造台、
 * 漏斗、发射器、合成器这些容器的**内部界面不是矩形**：
 *   - 熔炉：原料在上、燃料在左下、产物在右
 *   - 酿造台：上面三个药水槽 + 下面原料/燃料
 *   - 漏斗：一排五格
 * 默认排法会把它们挤成一行，分不出哪个格子对应哪个槽位。
 *
 * 这里给每种容器一张"槽位 -> 行列"的坐标表，排版时按坐标放图标，
 * 从而还原打开容器时看到的布局。
 *
 * ## 约定
 *
 *   · 坐标从 (0,0) 开始（左上角），数组次序是 [列, 行]
 *   · 坐标表里没有的槽位不显示，该位置保持空白
 *   · 图标层与数目层共用同一张表，数字因此仍压在对应图标的右下角
 *   · 容器不在表中（或槽位数与形状不符）时返回 null，调用方退回普通矩形网格
 *
 * 槽位顺序按 Bedrock 容器的标准槽位号（和打开界面时的位置一致）。
 */

/**
 * 每种容器的形状：
 *   size   : 容器槽位总数（用于识别）
 *   width  : 网格宽（列数）
 *   height : 网格高（行数）
 *   cells  : 槽位号 -> [列, 行]
 */
const CONTAINER_SHAPES = {
  // 熔炉 / 高炉 / 烟熏炉：待烧物保持左上原位，燃料和产物各自**下移一格**，
  // 于是待烧物与产物之间留出中间那格（原版进度箭头的位置）。
  furnace: {
    size: 3,
    width: 3,
    height: 3,
    cells: { 0: [0, 0], 1: [0, 2], 2: [2, 1] }
  },
  blast_furnace: null, // 见 ALIASES
  smoker: null,
  lit_furnace: null,
  lit_blast_furnace: null,
  lit_smoker: null,

  // 酿造台：三行五列排布 ——
  //   第一行：空/空/空/原料/空
  //   第二行：烈焰粉/空/空/空/空
  //   第三行：空/空/药水1/药水2/药水3
  //
  // 槽位号约定：**0 = 原料，1..3 = 药水，4 = 燃料**。
  // 若按"0-2 是药水"排，上排会与 1 号药水槽正好互换，故该编号不可调换。
  brewing_stand: {
    size: 5,
    width: 5,
    height: 3,
    cells: { 0: [3, 0], 4: [0, 1], 1: [2, 2], 2: [3, 2], 3: [4, 2] }
  },

  // 漏斗：一排五格
  hopper: {
    size: 5,
    width: 5,
    height: 1,
    cells: { 0: [0, 0], 1: [1, 0], 2: [2, 0], 3: [3, 0], 4: [4, 0] }
  },

  // 发射器 / 投掷器：3x3
  dispenser: {
    size: 9,
    width: 3,
    height: 3,
    cells: {
      0: [0, 0], 1: [1, 0], 2: [2, 0],
      3: [0, 1], 4: [1, 1], 5: [2, 1],
      6: [0, 2], 7: [1, 2], 8: [2, 2]
    }
  },
  dropper: null,

  // 合成器（crafter）：3x3，与发射器同形（被禁用的槽位由空白表现）
  crafter: {
    size: 9,
    width: 3,
    height: 3,
    cells: {
      0: [0, 0], 1: [1, 0], 2: [2, 0],
      3: [0, 1], 4: [1, 1], 5: [2, 1],
      6: [0, 2], 7: [1, 2], 8: [2, 2]
    }
  }
};

// 别名：同形的其它 id 指向同一个形状（带 lit_ 前缀的燃烧状态等）
const ALIASES = {
  blast_furnace: "furnace",
  smoker: "furnace",
  lit_furnace: "furnace",
  lit_blast_furnace: "furnace",
  lit_smoker: "furnace",
  dropper: "dispenser",
  // 漏斗矿车与漏斗同为 5 格，**显示也应当一致**（用户要求）。
  // 不加这条会走默认矩形网格：列数取全局 CONTAINER_COLUMNS(=9)，
  // 5 格于是排成"1 行 9 格"—— 既不像漏斗，底衬也会按 1×9 画出一块过宽的灰区。
  hopper_minecart: "hopper"
};

/**
 * 取某种容器的形状。返回 null 表示"用默认矩形网格"。
 *
 * @param {string} typeId 去掉 minecraft: 前缀的 id
 * @param {number} [containerSize] 实际槽位数；和形状的 size 对不上就不用形状，
 *        免得版本变化时画错 —— 宁可退回默认矩形，也不画错布局
 */
function shapeFor(typeId, containerSize) {
  if (typeof typeId !== "string") return null;

  let shape = CONTAINER_SHAPES[typeId];
  const alias = ALIASES[typeId];
  if (!shape && alias) shape = CONTAINER_SHAPES[alias];
  if (!shape) return null;

  // 槽位数和形状对不上（版本改了容器）-> 不用形状，退回默认矩形网格
  if (typeof containerSize === "number" && containerSize !== shape.size) {
    return null;
  }
  return shape;
}

// ===== format.js =====
// 潜影盒那一格的叠放内容（角标 / 总数 / 空白）与"整格前进 = 64 像素"的核算都在这里：
// 一格怎么拼是**唯一一处**说了算，本模块只负责把它的产物放进格子里。





/**
 * 取图标字形：**先去掉命名空间**再查表。
 *
 * 字形表（item_glyphs.js）里的键都是不带命名空间的裸 id（"diamond"、"composter"），
 * 但调用方给过来的 id 不一定这么干净：
 *   · 容器里的物品由适配层统一剥过前缀 -> "diamond"
 *   · 但"伪容器"那条路径（堆肥桶、唱片机这类特殊方块）直接把方块 id 传进来，
 *     带着 minecraft: 前缀 -> "minecraft:composter"
 * 精确匹配会让这种 id 永远查不到图标，退化成占位问号，所以两种写法都试。
 */
function glyphForId(id, bright) {
  if (!id) return "";
  const raw = String(id);
  const bare = raw.replace(/^[a-z_]+:/, "");
  // bright = 容器界面里那套预览：用**提亮 + 提饱和**的副本字形（见 item_glyphs.js
  // 的 BOX_ITEM_GLYPHS）。容器界面会在 HUD 上方压一层暗幕，把图标一起压暗压灰 ——
  // 详见那个常量的说明。查不到亮版会自动退回普通图标。
  const pick = bright ? boxItemGlyph : itemGlyph;
  return pick(bare) || pick(raw);
}

/**
 * 横向微调的**行首/行尾垫片**（见 config.js 的 HSPACE_UNITS）。
 *
 * 为什么用字形而不是空格：普通空格只有几像素宽，而且引擎按**墨迹**算前进宽度，
 * 空格这种"没有墨迹"的字符推不动任何东西。空格尺字形本身就是一条极淡墨迹，
 * 宽度可调，所以推得动。
 *
 * 居中标签的总宽每增加 N，内容起点只净移 N/2：插在行首让内容右移 N/2，
 * 插在行尾让它左移 N/2。所以正数放行首、负数放行尾。
 *
 * 图标层和数目层必须用**同一个**垫片，否则两层会错开 ——
 * 所以这里只暴露这一对函数，两边都从它取。
 */
function hspacePrefix() {
  const units = runtime.HSPACE_UNITS;
  return typeof units === "number" && units > 0 ? spacerGlyph(units) : "";
}

function hspaceSuffix() {
  const units = runtime.HSPACE_UNITS;
  return typeof units === "number" && units < 0 ? spacerGlyph(-units) : "";
}

/**
 * 颜色语义：**一格一色，索引 = 列号。**
 *
 * 第 1 列永远是第 0 种颜色，第 2 行第 1 列也是第 0 种 —— 颜色表达的是
 * "物品在第几列"，而不是"列表里的第几个"。9 列正好 9 色，不需要轮换，
 * 同列物品永远同色；代价是同列物品颜色相同，只能靠**名字**区分。
 */

/**
 * 推算容器实际列数。
 *
 * 标准容器都是 9 列（箱子、木桶、潜影盒、大箱子），行从上往下数。
 * CONTAINER_COLUMNS 设为 0 时按容量自动推算：能被 9 整除就用 9 列，
 * 否则退回 0（表示"列数未知"），避免算出行列都错的假位置。
 */
function effectiveColumns(containerSize) {
  if (CONTAINER_COLUMNS > 0) return CONTAINER_COLUMNS;
  return typeof containerSize === "number" && containerSize % 9 === 0 ? 9 : 0;
}

/**
 * 槽位 -> 配色索引。**索引就是列号**，这是整个颜色方案的核心。
 *
 * 返回 -1 表示"这个槽位算不出列"，调用方就不上色（而不是猜一个颜色出来
 * —— 猜错颜色比没颜色更糟，会让网格和物品对不上）。
 */
function columnColorIndex(slot, columns) {
  if (typeof slot !== "number" || slot < 0) return -1;
  if (!(typeof columns === "number" && columns > 0)) return -1;
  return slot % columns;
}

/** 把槽位号换算成"行,列"。都以 1 起始。只在 SHOW_SLOT_POSITION 打开时用到。 */
function slotToPosition(slot, columns) {
  if (typeof slot !== "number" || slot < 0) return null;
  if (!(typeof columns === "number" && columns > 0)) return null;
  return { row: Math.floor(slot / columns) + 1, column: (slot % columns) + 1 };
}

/**
 * 生成"位置网格"。
 *
 * 每个格子对应容器里的一个槽位：
 *   有物品 -> 该槽位**所在列**的颜色
 *   没物品 -> 深灰空格子
 *
 * 空槽位也画出来，这样格子的相对位置和游戏里打开容器看到的排布一致，
 * 能直接看出物品是集中在一角还是散落各处。
 *
 * @param occupiedSlots  容器里**所有**被占用的槽位（不是只算显示出来的那些）
 * @param containerSize  容器总槽位数（27 / 54 等）
 * @param columns        每行格数
 * @returns 若干行文本，或空数组（不显示网格时）
 */
function buildSlotGrid(occupiedSlots, containerSize, columns) {
  if (!runtime.SHOW_SLOT_GRID) return [];
  if (typeof containerSize !== "number" || containerSize <= 0) return [];
  if (!(columns > 0)) return [];

  // **必须标记所有被占用的槽位，而不是只标记显示出来的那些。**
  //
  // 传截断后的 shown 列表会让超出显示上限的物品**在网格里连位置都没有** ——
  // 网格等于在说谎，声称容器比实际更空。
  //
  // 颜色改成**按列**之后这个顾虑不成立了：颜色表达的是"第几列"，不是"第几个物品"，
  // 所以超出列表的物品照样能用列色标出来，语义完全一致。
  const occupied = new Set();
  for (let i = 0; i < occupiedSlots.length; i++) {
    occupied.add(occupiedSlots[i]);
  }

  const rows = Math.ceil(containerSize / columns);
  const lines = [];
  const emptyFill = GRID_FILL_CHAR;
  let lastOccupiedRow = -1;

  for (let row = 0; row < rows; row++) {
    const cells = [];
    let rowHasItem = false;

    for (let column = 0; column < columns; column++) {
      const slot = row * columns + column;
      if (slot >= containerSize) break;

      // 注意：这里读的是 runtime.XXX 而不是从 config.js 直接 import 的常量。
      // 自测需要切换这个开关来覆盖两条路径，而 config.js 的 `export const`
      // 是只读绑定、改不了；写成常量会让备用分支永远测不到。
      const colorIndex = occupied.has(slot) ? column : -1;
      if (colorIndex >= 0) rowHasItem = true;

      if (runtime.GRID_USE_COLOR_CODES) {
        // 文字颜色方案：格子是染色的实心字符；不插字形，横向占位正常，不会重叠。
        cells.push(
          (colorIndex < 0 ? emptyCellColorCode() : colorCode(colorIndex)) + emptyFill
        );
      } else {
        // 字形方案（已实测渲染可用，但横向占位窄、可能重叠）
        cells.push(colorIndex < 0 ? emptyCellGlyph() : colorGlyph(colorIndex));
      }
    }

    if (rowHasItem) lastOccupiedRow = row;

    // 行尾重置颜色，避免颜色溢出到后面的行
    lines.push(cells.join(" ") + (runtime.GRID_USE_COLOR_CODES ? resetColorCode() : ""));
  }

  // 裁掉**尾部全空**的网格行：actionbar 显示行数有限，而大箱子网格有 6 行，
  // 是整块文本里最占地方的部分；物品又几乎总是堆在上几行
  // （shift 点击、漏斗输入都是从左上角开始塞），所以尾部几行常年全空。
  //
  // 安全性：被裁掉的行在**下面**，没有任何东西需要它们定位；剩余格子的数量、
  // 颜色和相对位置都没变。至少保留一行，避免物品全空时输出空行。
  if (lastOccupiedRow >= 0 && lastOccupiedRow < lines.length - 1) {
    lines.length = lastOccupiedRow + 1;
  }

  return lines;
}

/**
 * 拼单个物品。位置前缀、图标、名称、数量在这里拼成一段"正文"，
 * 配色方案（文字颜色码 / 色块字形）由 GRID_USE_COLOR_CODES 决定。
 */
/**
 * 拼一个物品的显示文本。
 *
 * @param item       物品（需要 slot / typeId / amount）
 * @param columns    容器列数（决定这一格属于哪一列的颜色）
 * @param iconsOnly  **格位排版专用**：一格只放一个字形，不带名称/数量。
 *                   原因：格位排版靠"每格宽度相同"来对齐，而名字和数量的宽度
 *                   跟字形差很多，带上它们整列都会错位。
 *                   所以按格位排版时强制只放图标 —— 这正是这个模式的全部意义。
 * @param bright     使用提亮版字形（容器界面预览，见 item_glyphs.js）
 */
function formatItem(item, columns, iconsOnly, bright) {
  const name = displayName(item.typeId);

  // 位置前缀（默认关闭：颜色已经在表达"在哪一列"，再加上坐标太占宽度，
  // 而宽度就是手机上被截断的主因）
  let position = "";
  if (runtime.SHOW_SLOT_POSITION) {
    const pos = slotToPosition(item.slot, columns);
    if (pos) {
      position = "槽位(" + pos.row + "," + pos.column + "):";
    } else if (typeof item.slot === "number") {
      // 推不出行列就退化成裸槽位号，至少不丢信息
      position = "槽位" + (item.slot + 1) + ":";
    }
  }

  const colorIndex = columnColorIndex(item.slot, columns);
  const shouldColor = COLOR_LINK_GRID && runtime.SHOW_SLOT_GRID && colorIndex >= 0;

  // 图标（字形方案才用）。注意：**有没有图标**和**上不上色**是两件正交的事，
  // 所以这里统一先算出来，两种配色方案共用同一份"正文"。
  const glyph = runtime.GLYPHS_ENABLED ? glyphForId(item.typeId, bright) : "";
  const glyphPart = glyph ? glyph + " " : "";

  // 正文 = 位置 + 图标 + 名称 + 数量。
  // 只算一次，是因为几条分支各写一份时，每次改一处都会漏掉另外几处。
  //
  // 数量写成 `名称x64` 而**不是** `名称 x64`：省下那一个空格。
  // 看着不起眼，但它是"一行能放几个"的决定性因素：
  //   "钻石 x64" 8 列 → 32 列预算一行只能放 3 个
  //   "钻石x64"  7 列 → 同一预算一行能放 4 个（7×4+3 = 31）
  // 而"一行多放一个"直接等于"同样行数能多显示 1/3 的物品"。
  // 数量部分默认关闭（见 config.js 的 SHOW_ITEM_COUNTS）：
  // 数字是原版字体，在当前字号下只有 2~3 像素高，读不了。
  const countPart = !iconsOnly && runtime.SHOW_ITEM_COUNTS ? "x" + item.amount : "";

  let body;
  if (!glyph) {
    // 没有图标：格位排版下用**占位图**（一张特殊图片，不用文字）。
    //
    // 这不只是为了好看 —— 中文名的宽度和图标完全不同，会让那一行整列错位，
    // 而 4 成以上的物品没有图标。用等比占位图，每格宽度重新一致，对齐问题一起消失。
    //
    // 非格位排版（紧凑/纯文字）仍然显示名字：那种模式下没有对齐问题，名字更有用。
    body = iconsOnly ? placeholderGlyph() : position + name + countPart;
  } else if (iconsOnly) {
    // 格位排版：一格只能一个字形（见 formatItem 的 iconsOnly 说明）
    body = position + glyph;
  } else if (runtime.SHOW_ITEM_NAMES) {
    body = position + glyphPart + name + countPart;
  } else {
    body = position + glyph + countPart;
  }

  if (runtime.GRID_USE_COLOR_CODES) {
    // 文字颜色方案：**整段文字**染成这一列的颜色，不需要额外的色标前缀
    // （文字本身就是同色的，色标是多余的，而且每项多占 2 个字符宽）。
    // 行尾统一重置，所以这里也不逐个加重置码。
    if (!shouldColor) return body;
    return colorCode(colorIndex) + body;
  }

  // 字形色块方案：文字本身不变色，必须靠色块前缀来对应
  if (!shouldColor) return body;
  return colorGlyph(colorIndex) + " " + body;
}

/**
 * 按容器**真实格位**排版：一个槽位一格，空格位用空白字形占位。
 *
 * ===== 为什么要有这个模式 =====
 *
 * 紧凑排版（每行塞满 9 个）顺序是对的，但**看不出位置**：
 * 物品散落在容器的不同角落时，显示出来却是挨在一起的一排。
 * 按格位排版之后空格位留空 —— 能直接看出"东西在哪一片"，
 * 这才是真正的"仿箱子页面"。
 *
 * 行数由**容器容量**决定（小箱子 3 行、大箱子 6 行），所以屏幕上显示出的
 * 形状就是箱子的形状。
 *
 * ===== 两个关键细节 =====
 *
 * 1. 空格位必须用 `blankGlyph()`（宽度和图标一格一样、肉眼不可见的字形），
 *    **不能用普通空格** —— 空格只有几像素宽，而一格图标有十几像素，
 *    用空格占位整张表会错列。
 * 2. 行尾要重置颜色（如果开着按列上色），否则这一行的颜色会串到下一行。
 *
 * 已知取舍：**没有图标的物品会退化成中文名**（见 formatItem 的分支），
 * 中文名的宽度和图标不同，会让那一行错列。这是刻意的降级 ——
 * 宁可错列也要能分辨是什么，总比显示一片空白强。
 */
function formatAsGrid(typeId, sorted, containerSize, columns, noTitle, disabledSlots, bright) {
  const cols = columns > 0 ? columns : CONTAINER_COLUMNS;
  const total = containerSize > 0 ? containerSize : sorted.length;

  const bySlot = new Map();
  for (let i = 0; i < sorted.length; i++) {
    const item = sorted[i];
    if (typeof item.slot === "number") bySlot.set(item.slot, item);
  }

  // 被机器禁用的槽位（目前只有合成器有）：这些格子放不进东西，
  // 但**仍然是格子**，所以在图标层画一个"禁用"记号而不是留透明空白 ——
  // 否则"被锁住的格子"和"空着的格子"看起来一模一样。
  const disabled = new Set();
  if (disabledSlots) {
    for (let i = 0; i < disabledSlots.length; i++) disabled.add(disabledSlots[i]);
  }
  const disabledMark = disabled.size > 0 ? disabledSlotGlyph() : "";

  // 异形容器（熔炉/酿造台/漏斗/发射器/合成器）：按内部布局的坐标表放图标
  const shape = shapeFor(typeId, containerSize);
  const gridWidth = shape ? shape.width : cols;
  const rowCount = shape ? shape.height : Math.max(1, Math.ceil(total / cols));

  // 槽位 -> [列, 行]；普通矩形就是 r*cols+c
  const slotAt = (r, c) => {
    if (shape) {
      for (const slotKey of Object.keys(shape.cells)) {
        const coord = shape.cells[slotKey];
        if (coord[0] === c && coord[1] === r) return Number(slotKey);
      }
      return null;
    }
    const slot = r * cols + c;
    return slot < total ? slot : null;
  };

  const blank = blankGlyph();
  const gap = "\n".repeat(Math.max(0, runtime.ROW_GAP));
  const reset = runtime.GRID_USE_COLOR_CODES ? resetColorCode() : "";

  // 高度预算：每行占 1 + ROW_GAP 个文本行，超了就整行截断。
  // 大箱子（6 行）在 ROW_GAP=6 时是 6x7+7 = 49 行，默认预算放得下。
  const linesPerRow = 1 + Math.max(0, runtime.ROW_GAP);
  const rowsBudget = Math.max(
    1,
    Math.floor((runtime.MAX_TOTAL_LINES - TITLE_LINES) / linesPerRow)
  );
  const shownRows = Math.min(rowCount, rowsBudget);

  const rows = [];
  for (let r = 0; r < shownRows; r++) {
    const icons = [];
    for (let c = 0; c < gridWidth; c++) {
      const slot = slotAt(r, c);
      const item = slot === null ? null : bySlot.get(slot);
      // 图标块：每槽位一格。空槽位用透明空白占位（保持列对齐）；
      // 被禁用的槽位用"叉"字形（同样是满格宽，列不会错位）。
      if (item) {
        icons.push(formatItem(item, gridWidth, true, bright));
      } else if (slot !== null && disabled.has(slot) && disabledMark) {
        icons.push(disabledMark);
      } else {
        icons.push(blank);
      }
    }
    // 横向垫片：**每一行都要加**，否则各行宽度不同、居中之后会互相错开
    rows.push(hspacePrefix() + icons.join(ITEM_SEPARATOR) + hspaceSuffix() + reset);
  }

  // noTitle（堆肥桶这类）：不画标题行，整块直接从图标网格开始 ——
  // 于是显示成"堆肥桶图标 = 层数"，没有多余的一行名字。
  // 数目层必须同步去掉对应的空行，否则两层会错开一格。
  //
  // ⚠️ 这里**不再**垫顶部空行（peek_top）。那两个换行改由 formatTopPad 走**字幕**
  // 通道送去，资源包把它们变成网格上方一块"零宽、P 行高"的占位。
  // 原因见 formatTopPad 的说明：底衬尺寸取内容盒，填充留在字符串里就会把灰区撑大。
  const iconBlock = noTitle
    ? rows.join("\n" + gap)
    // ⚠️ **标题行也要加同一对垫片**（用户报的"移动位置时上面那个容器图标不跟着动"就是这个）：
    // 每一行都是**各自居中**的，所以只有加了同样的垫片，标题行才会和网格一起平移；
    // 不加的话网格横着走、容器图标留在原地。
    : hspacePrefix() + formatTitle(typeId, bright) + hspaceSuffix() +
      "\n" + gap + rows.join("\n" + gap);
  let out = iconBlock;

  if (shownRows < rowCount) {
    // 行被截断了：至少说一声（大箱子 6 行在默认预算内，正常不会发生）
    out += ITEM_SEPARATOR + "…+" + (rowCount - shownRows) + "行";
  }

  return out;
}

/**
 * 数目块的文本（给 **title 通道**用）。
 *
 * 行结构必须和 `formatContents`（图标块）**逐行一致**：
 *   图标块 = [标题行][gap][物品行]...
 *   数目块 = [空行  ][gap][数目行]...   ← 首行留空，对应标题行
 *
 * 因为数目标签和图标标签是**同父控件、同锚点、同字号、同字形页几何**，
 * 只要行结构一致，第 i 个数目格就正好压在第 i 个图标格的右下角 ——
 * 这就是"数字叠在物品上"（背包/箱子里的样子）。
 *
 * 空槽位用空白字形占位（宽度和图标一格一样），否则列会错位。
 *
 * @param {string} typeId 容器 id
 * @param {object} contents 容器内容
 * @param {Function} [overlayForSlot] **潜影盒那一格的叠放**：`slot -> 叠放描述`。
 *        描述由 `scripts/box_overlay.js` 定义（角标 / 总数 / 空白），本模块只调
 *        `cellFor(描述)` 拿到"一整格的内容"。返回 `null` / 不认识的描述 → 照常画数目。
 *
 *        为什么这一格的拼法不写在**这里**：那三样东西都受同一条硬约束（一格正好 64
 *        源像素前进宽度），拼错了整行都会歪，所以几何只在 box_overlay.js 里定义一次，
 *        并由 `cellAdvance()` 让自测与游戏内自检双向核对（见那个文件头）。
 */
function formatCountsGrid(typeId, contents, overlayForSlot) {
  const containerSize = contents.containerSize;
  const sorted = sortBySlot(contents.items);
  const columns = effectiveColumns(containerSize);
  const cols = columns > 0 ? columns : CONTAINER_COLUMNS;
  const total = containerSize > 0 ? containerSize : sorted.length;

  const bySlot = new Map();
  for (let i = 0; i < sorted.length; i++) {
    const item = sorted[i];
    if (typeof item.slot === "number") bySlot.set(item.slot, item);
  }

  // 与图标层共用同一张异形坐标表，数字才能压在正确的图标上
  const shape = shapeFor(typeId, containerSize);
  const gridWidth = shape ? shape.width : cols;
  const rowCount = shape ? shape.height : Math.max(1, Math.ceil(total / cols));
  const slotAt = (r, c) => {
    if (shape) {
      for (const slotKey of Object.keys(shape.cells)) {
        const coord = shape.cells[slotKey];
        if (coord[0] === c && coord[1] === r) return Number(slotKey);
      }
      return null;
    }
    const slot = r * cols + c;
    return slot < total ? slot : null;
  };

  // 数目层的空槽位：普通空白即可（深色底由图标层负责，
  // 数目层叠在上面，不需要再画一遍深色）
  const blank = blankGlyph();
  const gap = "\n".repeat(Math.max(0, runtime.ROW_GAP));
  const reset = runtime.GRID_USE_COLOR_CODES ? resetColorCode() : "";

  // 行数预算必须和图标块一致（两边截断策略不同就会错行）
  const linesPerRow = 1 + Math.max(0, runtime.ROW_GAP);
  const rowsBudget = Math.max(
    1,
    Math.floor((runtime.MAX_TOTAL_LINES - TITLE_LINES) / linesPerRow)
  );
  const shownRows = Math.min(rowCount, rowsBudget);

  const rows = [];
  for (let r = 0; r < shownRows; r++) {
    const cells = [];
    for (let c = 0; c < gridWidth; c++) {
      const slot = slotAt(r, c);
      const item = slot === null ? null : bySlot.get(slot);
      // 潜影盒那一格：由叠放描述决定画什么（见 overlayForSlot 的说明）
      let overlay = null;
      if (item && typeof overlayForSlot === "function") {
        try {
          overlay = overlayForSlot(slot) || null;
        } catch (_err) {
          overlay = null;
        }
      }
      // 算不出内容（描述不认识 / 总数为 0 / 角标字形为空）时 `cellFor` 返回空串 →
      // 照常画数目。**绝不能推一个空串进格子**：那一格会塌掉，后面整行都错位。
      const overlayCell = cellFor(overlay);
      cells.push(overlayCell !== "" ? overlayCell : (item ? countGlyph(item.amount) : blank));
    }
    // 横向垫片：必须和图标层**完全一样**（见 hspacePrefix 的说明），
    // 否则数字会整体偏离图标
    rows.push(hspacePrefix() + cells.join(ITEM_SEPARATOR) + hspaceSuffix() + reset);
  }

  // 首行留空，对应图标块的标题行；顶部空行不由本函数负责（见 formatTopPad）。
  // noTitle 时图标块没有标题行，这一行也必须去掉，否则数字整体下移一格。
  //
  // ⚠️ 这一行虽然**没有墨迹**，也要带上与图标层标题行**同样的垫片**：两层逐行同构
  // 是这个包的老约定（行结构一致才不会有"数字相对图标错开"的意外），
  // 而且垫片本身没有墨迹、不会画出来（见 hspacePrefix 的说明）。
  return contents.noTitle
    ? rows.join("\n" + gap)
    : hspacePrefix() + hspaceSuffix() + "\n" + gap + rows.join("\n" + gap);
}

/**
 * 数目块的公开入口：给 main.js 送 **subtitle 通道**用。
 * 参数和 formatContents 完全一样；多一个可选的叠放提供函数（见 formatCountsGrid）。
 */
function formatCounts(typeId, contents, overlayForSlot) {
  return formatCountsGrid(typeId, contents, overlayForSlot);
}

/**
 * 顶部填充（`peek_top` 旋钮）的字符串：**只有换行**，走**字幕通道**。
 *
 * ===== 为什么它不在 formatContents / formatCounts 里了 =====
 *
 * 这两个函数原先在字符串**最前面**拼 P 个换行，作用只有一个：把网格从锚点往下推。
 * 脚本侧这么写没问题（actionbar 那条文本本身没有别的定位手段），但资源包那边的
 * 底衬尺寸取的是 `100%c`（= 这条文本的内容盒），于是灰区把 P 个填充行**一起**包进去：
 * 默认 20 行 ≈ 42 显示单位，而且容器越小越离谱 —— 用户报的"底衬比预览高好几倍"。
 *
 * 关键约束：JSON-UI **绑不了运行期的 offset/size**（原版 1.21 全部界面里一条都没有），
 * 所以"填充留在文本里、只把底衬缩小"这条路走不通；填充必须离开 actionbar 这条文本。
 * 但它的高度又不能丢 —— 丢了这个旋钮就不动了。
 *
 * 结论：换通道。填充的几个换行送到**字幕**（HUD 上唯一还没被本包占用的文本通道：
 * actionbar = 图标，title = 数目），资源包把它变成一个"零宽、P 行高"的占位块，
 * 摆在底衬**上方**。于是
 *   · 底衬的内容盒 = 只看得到网格（灰区高度正确）；
 *   · 整块的竖直位置仍由填充决定（peek_top 照旧把网格往下推）。
 * 资源包侧的结构见 tools/pack/build-rp-ui.mjs 的 peekActionbar / peekPadLabel。
 *
 * 行数**必须和旋钮一模一样**（不折半）：资源包那边填充与网格同属一个自顶向下的栈，
 * 一层换行就是一行位移。折半会让"旋钮到底移多少"这件事变得说不清。
 *
 * ⚠️ 这一行**只负责高度**，不要往里放可见内容。曾经的"盒内总数"就想借它的末行画数字
 * （想省一行），在这个项目里试了两轮都没画出来，最后整个功能删掉了 —— 教训与判别过程
 * 见 docs/PROGRESS.md §7.13：**要能画字形的标签就不写 `size`**（`hud_peek_pad` 写了
 * 显式宽度，文字会被整段裁掉；同树的 `hud_peek_counts` 没写，一直正常）。
 *
 * @returns {string} P 个换行（P = runtime.TOP_PADDING_LINES，0 时返回空串）
 */
function formatTopPad() {
  return "\n".repeat(Math.max(0, runtime.TOP_PADDING_LINES));
}

/**
 * 拼标题（容器名）。
 * 纯文字模式就是容器名；带图标时可只显示图标。
 */
function formatTitle(typeId, bright) {
  const name = displayName(typeId);

  if (!runtime.GLYPHS_ENABLED) return name;

  const glyph = glyphForId(typeId, bright);
  if (!glyph) return name;
  if (!runtime.SHOW_CONTAINER_NAME) return glyph;

  // 图标 + 垫片 + 中文名。
  //
  // 名字走的是**字形**（见 item_glyphs.js 的 CONTAINER_NAME_GLYPHS），不是
  // 普通文字：这个 label 被写上了 `font_scale_factor: 0.25`，普通中文在那个
  // 字号下只有 2~3 像素高。而字形的显示尺寸跟着**格子尺寸**走 —— 容器名字形页
  // 的格子和物品图标页一样是 64 像素，所以名字和图标**显示成同样大**，
  // 而且两者同属这一条标签、同一个 font_scale_factor（这是硬要求：
  // 另起一条标签或另设一个字号，两者就会对不齐）。
  //
  // 垫片含义：图标与名字之间的间隙。用保留页那套**空格尺**字形
  // （见 item_glyphs.js 的 SPACER_GLYPH_BASE）而不是普通空格 ——
  // 引擎按**墨迹**算前进宽度，普通空格没有墨迹、推不动任何东西。
  const nameGlyphs = containerNameGlyphs(name);
  if (!nameGlyphs) {
    // 名字里只要有一个字没有字形就整串放弃（见 containerNameGlyphs 的说明），
    // 此时**只显示图标**：绝不退回普通中文 —— 在那个字号下它是看不清的残影，
    // 显示出来等于给标题行加了一团噪点，还不如没有。
    return glyph;
  }
  return glyph + spacerGlyph(4) + nameGlyphs;
}

/** 按槽位号排序。显示顺序稳定，同列（同色）的物品也会排在一起。 */
function sortBySlot(items) {
  return items.slice().sort((a, b) => {
    const sa = typeof a.slot === "number" ? a.slot : 0;
    const sb = typeof b.slot === "number" ? b.slot : 0;
    return sa - sb;
  });
}

/**
 * 判断一个码点是不是"宽字符"（占 2 列）。
 *
 * 汉字、日文、韩文、全角标点都占 2 列，字母数字占 1 列。
 * 排版必须按**列**算而不是按字符个数算，否则
 * "箭 x64"（6 个字符）和"附魔金苹果 x1"（8 个字符）会被当成差不多宽，
 * 而实际是 6 列 vs 14 列，差一倍多。
 *
 * 私有使用区（U+E000..U+F8FF，图标/色块字形）**故意不算宽**：
 * 字形按行高渲染，横向也就占一列左右。
 */
function isWideCodePoint(cp) {
  return (
    (cp >= 0x1100 && cp <= 0x115f) ||
    (cp >= 0x2e80 && cp <= 0x303e) ||
    (cp >= 0x3041 && cp <= 0x33ff) ||
    (cp >= 0x3400 && cp <= 0x4dbf) ||
    (cp >= 0x4e00 && cp <= 0x9fff) ||
    (cp >= 0xa000 && cp <= 0xa4cf) ||
    (cp >= 0xac00 && cp <= 0xd7a3) ||
    (cp >= 0xf900 && cp <= 0xfaff) ||
    (cp >= 0xfe30 && cp <= 0xfe6f) ||
    (cp >= 0xff00 && cp <= 0xff60) ||
    (cp >= 0xffe0 && cp <= 0xffe6)
  );
}

/**
 * 算一段文本的显示列数，用来判断一行会不会超宽。
 *
 * 先剥掉 `§` 颜色代码 —— 它们是零宽的格式控制符，不算进宽度。
 */
function displayColumns(text) {
  const plain = text.replace(/\u00a7[0-9a-fk-or]/gi, "");
  let width = 0;
  for (const ch of plain) {
    width += isWideCodePoint(ch.codePointAt(0)) ? 2 : 1;
  }
  return width;
}

/**
 * 把物品排成若干行。
 *
 * 规则：**每行放 runtime.ITEMS_PER_LINE 个**。
 *
 * 另外有一个**可选**的列数上限 runtime.LINE_WIDTH_BUDGET，默认是 0（不限制）。
 * 只有设了非 0 值才参与判断，用来在"名字特别长"时当保险。
 *
 * ===== 为什么默认只有一个约束 =====
 *
 * 同时用"个数"和"列数"两个上限时，撞到其中一个上限，另一个怎么调都没有反应，
 * 而两个上限无法从显示结果区分，只能逐个试。两个互相遮挡的旋钮本身就是设计错误 ——
 * 所以现在默认只认"个数"，加多少显示多少，撞到屏幕宽度时自然折行、一眼可见。
 *
 * 返回**二维结构**（每行是 {item, text} 的数组）而不是拼好的字符串，
 * 因为调用方还要按"行数上限"截断，并且需要知道每行里有哪些物品。
 *
 * @returns {{item: object, text: string}[][]}
 */
function packItemLines(items, columns, bright) {
  const lines = [];
  let parts = [];
  let width = 0;
  const widthCap = runtime.LINE_WIDTH_BUDGET;

  const flush = () => {
    if (parts.length > 0) {
      lines.push(parts);
      parts = [];
      width = 0;
    }
  };

  for (let i = 0; i < items.length; i++) {
    const text = formatItem(items[i], columns, false, bright);

    if (parts.length > 0) {
      const added = displayColumns(ITEM_SEPARATOR) + displayColumns(text);
      const overWidth = widthCap > 0 && width + added > widthCap;
      if (overWidth || parts.length >= runtime.ITEMS_PER_LINE) {
        flush();
      }
    }

    if (parts.length === 0) {
      parts.push({ item: items[i], text });
      width = displayColumns(text);
    } else {
      parts.push({ item: items[i], text });
      width += displayColumns(ITEM_SEPARATOR) + displayColumns(text);
    }
  }

  flush();
  return lines;
}

/**
 * 拼容器内容。
 *
 * @param {string} typeId   容器/物品 id
 * @param {object} contents {containerSize, items, noTitle, disabledSlots}
 * @param {object} [opts]   { bright: true } = 用**提亮版**字形
 *
 * `bright` 只给"在打开的容器/背包界面里点潜影盒"那套预览用：容器界面会在
 * HUD 上方压一层暗幕，把 HUD 整层（含图标）一起压暗压灰，所以要换成
 * 提亮 + 提饱和的副本字形来抵消。普通准星预览不传这个参数，用的是原版字形。
 */
function formatContents(typeId, contents, opts) {
  const bright = !!(opts && opts.bright);
  const items = contents.items;
  const containerSize = contents.containerSize;

  // 空容器：格位排版下画一张**全空**的网格（和真实空箱子一样），
  // 不再显示"(空)"和容器中文名 —— 那是原版字体，在当前字号下只有 2~3 像素高。
  if (items.length === 0 && !runtime.LAYOUT_AS_GRID) {
    return formatTitle(typeId, bright) + "\n(空)";
  }

  const columns = effectiveColumns(containerSize);

  // 先按槽位排序：显示顺序稳定，不受引擎返回物品的顺序影响
  const sorted = sortBySlot(items);

  // ===== 按容器真实格位排版（默认，见 formatAsGrid）=====
  //
  // 紧凑排版顺序对但看不出位置，所以默认改成按格位排版。
  // 想把紧凑排版要回来：把 LAYOUT_AS_GRID 设成 false。
  if (runtime.LAYOUT_AS_GRID) {
    return formatAsGrid(typeId, sorted, containerSize, columns, contents.noTitle, contents.disabledSlots, bright);
  }

  // ===== 位置网格要先算 =====
  //
  // 顺序很重要：网格占几行**决定了留给物品几行**，所以必须先知道
  // 网格的实际行数（它会被裁剪，行数事先算不出来）。
  //
  // **传的是全部物品的槽位，不是截断后的**：网格的职责是如实画出
  // "容器里哪些格子有东西"，即使物品名列表因为行数限制没显示全。
  // 否则物品一多，网格就会漏掉后面那些格子的位置。
  const occupiedSlots = [];
  for (let i = 0; i < items.length; i++) occupiedSlots.push(items[i].slot);
  const gridLines = buildSlotGrid(occupiedSlots, containerSize, columns);

  // ===== 高度预算 =====
  //
  // 只限制**物品行数**、不把网格算进高度会导致：小箱子（网格 3 行）一切正常，
  // 大箱子（网格 6 行）就从屏幕下面溢出。原因是"上限"和"实际可用空间"是两回事 ——
  // 网格多吃一行，物品就该少吃一行。
  //
  // 现在按**总行数**封顶：物品行额度 = 总预算 − 标题 − 网格实际行数。
  // 这样还能自适应：网格因裁剪只剩 2 行时，物品就自动多出 4 行可用。
  const gridBlock = gridLines.length > 0 ? gridLines.length : 0;
  const gapLines = gridBlock > 0 ? Math.max(0, runtime.ROW_GAP) : 0;
  const itemBudget = Math.max(
    1,
    Math.min(MAX_ITEM_LINES, runtime.MAX_TOTAL_LINES - TITLE_LINES - gridBlock - gapLines)
  );

  // 全部排一遍，再按**行数**截断 —— 不是按物品个数截断。
  // 行数才是屏幕的真实约束，而一行能放几个物品取决于名字长短。
  const packed = packItemLines(sorted.slice(0, MAX_ITEMS_SHOWN), columns, bright);
  const kept = packed.slice(0, itemBudget);

  let shownCount = 0;
  for (let i = 0; i < kept.length; i++) shownCount += kept[i].length;
  let hidden = items.length - shownCount;

  // "…+N" 追加在**最后一行末尾**，不单独占一行（单独占一行是白扔一行高度）。
  //
  // 只在**设了列数上限**时才需要为它腾位置：标记自己占几列，
  // 而它是排完行之后才接上去的 —— 不管宽度的话，最后一行会被顶到上限之外，
  // 直接折行，反而多占一行。
  //
  // 默认没有列数上限，所以通常整段都跳过。
  if (hidden > 0 && runtime.LINE_WIDTH_BUDGET > 0) {
    const widthCap = runtime.LINE_WIDTH_BUDGET;
    let marker = "…+" + hidden;
    while (kept.length > 0) {
      const last = kept[kept.length - 1];
      const texts = [];
      for (let i = 0; i < last.length; i++) texts.push(last[i].text);
      const lineWidth = displayColumns(texts.join(ITEM_SEPARATOR));
      const need = displayColumns(ITEM_SEPARATOR) + displayColumns(marker);
      if (lineWidth + need <= widthCap) break;

      // 放不下：这一行最后那个物品改成不显示
      last.pop();
      hidden++;
      marker = "…+" + hidden;
      if (last.length === 0) kept.pop();
    }
  }

  const itemLines = [];
  for (let i = 0; i < kept.length; i++) {
    const texts = [];
    for (let j = 0; j < kept[i].length; j++) texts.push(kept[i][j].text);
    // 行尾重置颜色，防止这一行的颜色串到下一行
    itemLines.push(texts.join(ITEM_SEPARATOR) + (runtime.GRID_USE_COLOR_CODES ? resetColorCode() : ""));
  }

  if (hidden > 0) {
    if (itemLines.length > 0) {
      itemLines[itemLines.length - 1] += ITEM_SEPARATOR + "…+" + hidden;
    } else {
      itemLines.push("…+" + hidden);
    }
  }

  // 行之间按 ROW_GAP 插空行（图标模式下**必须**：字形高度远大于行高，
  // 不撑开就会上下重叠，见 config.js 里 ROW_GAP 的推导）
  const gap = "\n".repeat(Math.max(0, runtime.ROW_GAP));

  // 块与块之间也要留 ROW_GAP：标题里的容器图标和物品图标都比行高高得多，
  // 只用单个换行会让后一块的第一行压在它身上。
  //
  // 网格块**内部**不插空行 —— 网格用的是原版实心方块字符（高度≈行高），
  // 本来就不会重叠，插了纯属白占行数。
  const blocks = [];
  const gridBlockText = gridLines.length > 0 ? gridLines.join("\n") : "";
  const itemBlockText = itemLines.join("\n" + gap);

  blocks.push(formatTitle(typeId, bright));
  if (gridBlockText) blocks.push(gridBlockText);
  if (itemBlockText) blocks.push(itemBlockText);

  return blocks.join("\n" + gap);
}

// ===== grid_shapes.js =====
/**
 * 网格形状：**容器 -> "渲染出来的行数 x 列数"** 的唯一来源。
 *
 * ## 为什么需要它
 *
 * 资源包的底衬（淡灰圆角灰区）本轮从"按文字内容算尺寸（`100%c`）"改成
 * **按容器形状写死的尺寸**。于是出现一条跨文件契约：
 *
 *   脚本按哪种形状排版  ==  资源包给那种形状留多大的灰区
 *
 * 两边口径差一个数字，表现就是"灰区和网格差一截"，而且**游戏里才能看出来**。
 * 所以把"容器 -> 形状"这条推导独立成模块，脚本侧（发标记）与构建侧
 * （生成底衬变体）**引用同一份**，谁也不许自己再推一遍。
 *
 * ## 口径：必须与 scripts/format.js 的实际排版一致
 *
 * format.js 的格位排版用的是这两个量：
 *   · 列数 `gridWidth`：有自定义形状（container_shapes.js）就用形状的宽度，
 *     否则用 CONTAINER_COLUMNS（config.js，当前 9）
 *   · 行数 `rowCount`：有自定义形状就用形状的高度，否则 ceil(容量 / 列数)
 * 本模块逐条照抄这两个量（`gridShapeFor`），并有一条自测断言把它和
 * **真正排版出来的字符串**对齐（见 tests/run.mjs 的"网格形状"一节）——
 * 不靠"两边都看着一样"。
 *
 * ## 形状标记（走 title 通道，见 hud_protocol.js）
 *
 *   `r{行}c{列}`   例：`r3c9` = 3 行 9 列（小箱子）
 *   `r0c0`         兜底：算不出形状（行列超过一位数时也用这个）——
 *                  **长度仍然是 SHAPE_TOKEN_LENGTH**，于是资源包那条"剪掉定长前缀"
 *                  的绑定照样剪得干净，只是没有任何底衬变体命中（网格照常显示，
 *                  只是没有灰区），不会漏出多余字符。
 */



// 运行期开关（`/peek:backdrop`）：本模块只读它，不写。


/** 算不出形状时用的兜底标记：长度合法、但没有任何底衬变体匹配。 */
const UNKNOWN_SHAPE_TOKEN = "r0c0";

/**
 * 形状标记的**首字符**（`r{行}c{列}` 里的那个 `r`）。
 *
 * 单独导出是因为它被用来做"这条 title 是不是准星预览"的判据：
 * 资源包比 `'%.7s' * #peek_title = 'peek::r'`（见 build-rp-ui.mjs 的
 * PREVIEW_TITLE_MARKER），容器界面那套的 `peek::box::` 第二个字符是 `b`，
 * 清屏时的 title 又只有一个 `peek::`，三种状态因此天然区分开。
 * 资源包那边也从这个常量取，两边不可能对不上。
 */
const SHAPE_TOKEN_PREFIX = "r";

/** 行列都最多一位数（形状标记是定宽的，资源包按定长剪前缀）。 */
const MAX_DIGIT = 9;

/**
 * 形状标记：`r{行}c{列}`。**定宽**（见 SHAPE_TOKEN_LENGTH）。
 *
 * 行或列超过一位数（= 现实里不存在的容器，属于版本漂移）时返回兜底标记，
 * 而不是拼出一个更长的串 —— 变长会让资源包那条定长剪前缀的绑定错位。
 */
function shapeToken(rows, cols) {
  if (
    !Number.isInteger(rows) || !Number.isInteger(cols) ||
    rows < 0 || cols < 0 || rows > MAX_DIGIT || cols > MAX_DIGIT
  ) {
    return UNKNOWN_SHAPE_TOKEN;
  }
  return SHAPE_TOKEN_PREFIX + rows + "c" + cols;
}

/**
 * 某种容器**实际会渲染成**的网格形状（行列数）。
 *
 * 与 format.js 的 formatAsGrid / formatCountsGrid 口径一致：
 *   · 自定义形状（熔炉族 / 酿造台 / 漏斗 / 发射器 / 合成器）优先；
 *     槽位数与形状记录不符时 shapeFor 返回 null，这里同样退回矩形
 *   · 矩形网格的列数 = CONTAINER_COLUMNS（0 = 按容量推，推不出就 1 列兜底）
 *
 * @param {string} typeId 去掉 minecraft: 前缀的 id
 * @param {number} containerSize 容器槽位数（读不到时给 0/undefined）
 * @returns {{rows: number, cols: number, token: string}}
 */
function gridShapeFor(typeId, containerSize) {
  const shape = shapeFor(typeId, containerSize);
  if (shape) {
    return madeShape(shape.height, shape.width);
  }

  const columns = shapeColumnsFor(containerSize);
  const total = typeof containerSize === "number" && containerSize > 0 ? containerSize : 1;
  const cols = columns > 0 ? columns : 1;
  return madeShape(Math.max(1, Math.ceil(total / cols)), cols);
}

/**
 * 与 format.js 的 effectiveColumns 同口径（CONTAINER_COLUMNS > 0 时直接用它）。
 *
 * ⚠️ 名字必须与 format.js 里的那个不同：LSE 插件把 scripts/ 下的模块**拼成一个文件**，
 * 顶层声明重名在 QuickJS 里是语法错误（打包器会直接拦下来）。
 */
function shapeColumnsFor(containerSize) {
  if (CONTAINER_COLUMNS > 0) return CONTAINER_COLUMNS;
  return typeof containerSize === "number" && containerSize % 9 === 0 ? 9 : 0;
}

function madeShape(rows, cols) {
  return { rows: rows, cols: cols, token: shapeToken(rows, cols) };
}

/**
 * 发往 title 标记的**形状字段**（给两条排版路径共用的入口）。
 *
 * 与 `gridShapeFor` 分开的理由只有一条：底衬的尺寸是**按网格**写死的，
 * 而 `runtime.LAYOUT_AS_GRID`（游戏内 `/peek:grid` 旋钮）关掉之后预览是一串
 * 紧凑列表、根本不是网格 —— 那时发形状会让资源包画一块对不上的灰区。
 * 所以非格位排版**刻意不发形状**：标记仍是合法的 `peek::`（原版标题照常被过滤），
 * 只是没有任何底衬变体命中 = 不画灰区。这是"灰区只服务网格预览"的直接表达。
 *
 * @param {string} typeId 容器 id（去命名空间）
 * @param {number} containerSize 容量
 * @param {boolean} layoutAsGrid 是否格位排版（传 runtime.LAYOUT_AS_GRID）
 * @returns {string} 4 字符形状标记，或空串（不发形状）
 */
function previewShapeToken(typeId, containerSize, layoutAsGrid) {
  if (layoutAsGrid === false) return "";
  // 这两种是"假容器"（内容只有一件、堆肥桶还刻意不画标题行）：用户要求
  // **不给它们画灰区**，所以不命中任何底衬变体。
  //
  // ⚠️ 这里发的是**未知形状标记**而不是空串：资源包按"定长 4 字符"剪前缀，
  // 少发 4 个字符会把后面的正文前 4 个字形当成形状剪掉（预览会缺一格）。
  // r0c0 与任何变体都不匹配，所以效果同样是"不画灰区"，但长度是对的。
  if (NO_BACKDROP_CONTAINERS.has(String(typeId))) return UNKNOWN_SHAPE_TOKEN;
  // 游戏内旋钮 `/peek:backdrop off`：与上面同一条路 —— 不发形状 = 不画灰区。
  if (runtime.SHOW_BACKDROP === false) return UNKNOWN_SHAPE_TOKEN;
  return gridShapeFor(typeId, containerSize).token;
}

/**
 * 准星预览发往 title 的**形状字段**：档位码 + 4 字符形状（共 5 字符，见
 * `hud_protocol.js` 的 `TITLE_FIELD_LENGTH`）。
 *
 * 为什么单独一个函数而不是给 `previewShapeToken` 加参数：这个函数**只给准星预览用**，
 * 容器界面那套（左边缘）的形状字段永远是 4 字符（它不参与缩放），两者长度不同、
 * 混用会各自剪错 —— 分开写，长度就不可能串。
 *
 * @param {string} typeId / `containerSize` / `layoutAsGrid` 同 `previewShapeToken`
 * @param {string} step 档位名（`full` / `three4` / `half`，见 hud_protocol 的 PREVIEW_STEP_CODES）
 * @returns {string} 5 字符；`previewShapeToken` 返回空串时也返回空串（不画灰区）
 */
function previewTitleField(typeId, containerSize, layoutAsGrid, step) {
  const token = previewShapeToken(typeId, containerSize, layoutAsGrid);
  if (!token) return "";
  return previewStepCode(step) + token;
}

/**
 * 不画灰区的容器：**假容器**（`makeFakeContainer` 造出来的单件容器）。
 *
 * 堆肥桶是"图标 = 层数"、唱片机是"图标 = 唱片"，两者都不是真正的格子容器，
 * 网格形状对它们没有意义（尺寸表按 1×9 画出来的灰区明显不合身），
 * 用户也已明确要求这两个不要背景。
 */
const NO_BACKDROP_CONTAINERS = new Set(["composter", "jukebox"]);

/**
 * 每种容器**可能出现的容量**（标准槽位数）。
 *
 * 这是"事实"（游戏里打开容器能数出来的格子数），不是猜的形状：形状由上方的
 * `gridShapeFor` 从容量推出来。列在这里的理由是它同时充当**覆盖清单**——
 * 自测会核对 config.js 白名单里的每个容器 id 都能在这里查到容量，
 * 新加一种容器却忘了写容量时，构建期就报错，而不是等到游戏里"没有灰区"。
 *
 * 大箱子（54）与小箱子（27）是**同一个 id 的两种容量**，所以描述成数组。
 */
const BLOCK_CAPACITIES = {
  chest: [27, 54], // 小箱子 / 大箱子（并排放的两个箱子合成 54 格）
  trapped_chest: [27, 54],
  barrel: [27],
  dispenser: [9],
  dropper: [9],
  hopper: [5],
  crafter: [9],
  furnace: [3],
  lit_furnace: [3],
  blast_furnace: [3],
  lit_blast_furnace: [3],
  smoker: [3],
  lit_smoker: [3],
  brewing_stand: [5],
  composter: [1], // 伪容器：容量 1（也就是"堆肥层数"那一格）
  jukebox: [1] // 伪容器：容量 1（唱片那一格）
};

/**
 * 实体容器（矿车 / 运输船）的容量。
 *
 * 用**规则**而不是一张穷举表：木种在版本间会加（pale_oak、bamboo 都是后加的），
 * 漏一个就等于那种船没有灰区。规则只认三种结尾，白名单里出现规则覆盖不了的
 * 实体时，自测会报错。
 */
function entityCapacity(id) {
  if (id === "hopper_minecart") return 5;
  if (id === "chest_minecart") return 27;
  if (/_chest_boat$/.test(id) || id === "chest_boat") return 27;
  if (/_chest_raft$/.test(id)) return 27;
  return null;
}

/** 潜影盒（全部颜色）：容量恒为 27，用规则覆盖而不是列 17 个 id。 */
function blockCapacity(id) {
  if (Object.prototype.hasOwnProperty.call(BLOCK_CAPACITIES, id)) {
    return BLOCK_CAPACITIES[id];
  }
  if (id === "undyed_shulker_box" || id.indexOf("_shulker_box") >= 0) return [27];
  return null;
}

/**
 * 白名单里每一种容器 -> 容量。**覆盖清单本体**（自测核对无遗漏）。
 *
 * 返回 [{ id, kind, capacities }]；kind = "block" | "entity"。
 */
function containerCapacityList() {
  const out = [];

  for (const id of CONTAINER_BLOCK_IDS) {
    const capacities = blockCapacity(id);
    if (capacities) out.push({ id: id, kind: "block", capacities: capacities });
  }
  for (const id of CONTAINER_ENTITY_IDS) {
    const capacity = entityCapacity(id);
    if (capacity !== null) out.push({ id: id, kind: "entity", capacities: [capacity] });
  }
  return out;
}

/**
 * 本包**会渲染出来的全部网格形状**（去重后），每种形状一条。
 *
 * 资源包据此生成底衬变体（一形状一个），脚本据此发标记：
 * 两边引用的是这一份列表，所以不可能出现"脚本发的形状资源包没有"。
 *
 * 顺序固定（先按列数、再按行数），生成的 JSON 因此是确定性的（可 diff）。
 */
const RENDERED_GRID_SHAPES = buildShapeTable();

function buildShapeTable() {
  const byToken = new Map();

  for (const entry of containerCapacityList()) {
    for (const capacity of entry.capacities) {
      const shape = gridShapeFor(entry.id, capacity);
      const existing = byToken.get(shape.token);
      if (existing) {
        existing.containers.push(entry.id + "(" + capacity + ")");
        continue;
      }
      byToken.set(shape.token, {
        token: shape.token,
        rows: shape.rows,
        cols: shape.cols,
        containers: [entry.id + "(" + capacity + ")"]
      });
    }
  }

  const list = Array.from(byToken.values());
  list.sort((a, b) => (a.cols - b.cols) || (a.rows - b.rows));
  return list;
}

// ===== 模块加载期自检 =====
//
// 这两条属于"错了不报错、只是游戏里少一块灰区或漏出字符"，所以放在模块加载期
// （脚本侧与构建侧都会 import 本模块，因此两边都拦得住）。
{
  if (SHAPE_TOKEN_LENGTH !== 4) {
    throw new Error(
      "形状标记长度变了（SHAPE_TOKEN_LENGTH = " + SHAPE_TOKEN_LENGTH +
      "）：资源包那条「剪掉定长前缀」的绑定按 4 位写死，两处必须同步。"
    );
  }

  if (shapeToken(3, 9).length !== SHAPE_TOKEN_LENGTH ||
      UNKNOWN_SHAPE_TOKEN.length !== SHAPE_TOKEN_LENGTH) {
    throw new Error(
      "形状标记不是定宽 " + SHAPE_TOKEN_LENGTH + "：" +
      JSON.stringify([shapeToken(3, 9), UNKNOWN_SHAPE_TOKEN])
    );
  }

  for (const shape of RENDERED_GRID_SHAPES) {
    if (shape.token.length !== SHAPE_TOKEN_LENGTH || !/^[\x20-\x7e]+$/.test(shape.token)) {
      throw new Error("形状标记必须是定宽纯 ASCII：" + JSON.stringify(shape));
    }
    // 形状必须和标记自洽（行列数改了却忘了改标记 = 资源包选错灰区）
    if (shape.token !== shapeToken(shape.rows, shape.cols)) {
      throw new Error(
        "形状与标记对不上：" + JSON.stringify(shape) + " 期望标记 " +
        shapeToken(shape.rows, shape.cols)
      );
    }
  }

  // 白名单覆盖：新加容器却忘了写容量 -> 这里直接失败（否则游戏里没有灰区）
  for (const id of CONTAINER_BLOCK_IDS) {
    if (!blockCapacity(id)) {
      throw new Error(
        "config.js 白名单里的方块容器 " + id + " 没有登记容量（见 BLOCK_CAPACITIES）——" +
        "不登记就推不出网格形状，资源包也就没有对应尺寸的底衬。"
      );
    }
  }
  for (const id of CONTAINER_ENTITY_IDS) {
    if (entityCapacity(id) === null) {
      throw new Error(
        "config.js 白名单里的实体容器 " + id + " 没有容量规则（见 entityCapacity）"
      );
    }
  }
}

/**
 * 有**自定义形状**的容器 id（熔炉族 / 酿造台 / 漏斗 / 发射器 / 合成器）。
 *
 * 只是导出给探针与文档用：真正的形状查询一律走 `shapeFor`（它还会处理别名、
 * 并在实际槽位数与形状记录不符时退回矩形网格）。
 */
const CUSTOM_SHAPE_IDS = Object.keys(CONTAINER_SHAPES).filter(
  (id) => CONTAINER_SHAPES[id]
);

// ===== hud_test.js =====
/**
 * **HUD 显示自检**：把"排查显示问题"要看的几行**原版文字**画到屏幕上。
 *
 * ## 为什么需要它（用户的原话："在屏幕上显示文字排查显示问题"）
 *
 * 预览本身完全由**私有区字形**画成（`U+E2xx`–`U+F8xx`），所以一旦客户端的资源包没装上，
 * 画面上就是"问号/方框 + 原版 actionbar 的黑底"叠在一起 —— 而**服务端无法知道**
 * 客户端有没有装包，玩家也说不清自己看到的是哪一种。这个自检就是为了把这件事变成
 * 玩家自己能回答的**一个是非题**：
 *
 *   1. **纯文字行**（不带 `peek::` 标记、不带任何私有区字形）：只要 HUD 文本通道能显示，
 *      这一行就一定能读到 —— 读不到说明问题不在资源包，而在"这个玩家的 HUD 根本看不到文本"；
 *   2. **字形测试行**：里面放一个已知的字形（钻石图标）。看到图标 = 资源包生效；
 *      看到方框/问号 = 资源包没生效 ✓ 这一条就是判据；
 *   3. **旋钮快照行 + 怎么读**：把几个最容易"看起来像坏了"的开关当前值写出来
 *      （display / backdrop / scale / badgelevel / boxbadge），省掉"你有没有关过什么"的来回问。
 *
 * ⚠️ 那几行**一律不带 `peek::` 标记**（title 那条必须走 `sendPlainTitle`，不能用 `sendTitle`）：
 * 带了标记就等于"用被检验的那套渲染去检验它自己"，而且资源包没装时屏幕上会多出 `peek::`
 * 几个字母。不带标记时，原版标题/字幕/动作栏照常渲染 —— 那正是"玩家本来就能看到什么"。
 *
 * ## 为什么是纯函数
 *
 * 这里只负责**拼字符串**，不碰引擎：谁能显示、什么时候发、发到哪条通道由 `main.js` 决定。
 * 于是这几行文本可以在 Node 自测里逐字断言（"不含私有区字形""含已知字形""含旋钮快照"）。
 */

/** 私有区码点范围（字形用它们；自检的**纯文字行**里一个都不许出现）。 */
const PRIVATE_USE_RANGES = [
  [0xe000, 0xf8ff],   // BMP 私有区：本包所有字形都在这里
  [0xf0000, 0x10fffd] // 补充私有区（留着，防以后搬过去）
];

/** 这段文本里有没有私有区字形（自检用：纯文字行必须为 false）。 */
function hasPrivateUseGlyph(text) {
  const s = String(text === undefined || text === null ? "" : text);
  for (let i = 0; i < s.length; i++) {
    const code = s.codePointAt(i);
    for (let r = 0; r < PRIVATE_USE_RANGES.length; r++) {
      if (code >= PRIVATE_USE_RANGES[r][0] && code <= PRIVATE_USE_RANGES[r][1]) return true;
    }
    if (code > 0xffff) i++;   // 代理对：跳过低位
  }
  return false;
}

/**
 * 拼出显示自检的几段文本。
 *
 * @param {object} deps 注入的字符串/取值来源：
 *   · `itemGlyph(itemId)` → 已知字形（钻石图标），用于"资源包生效了吗"那一行
 *   · `knobs` → `{ display, backdrop, scale, badgelevel, boxbadge }` 的当前有效值（已转成文字）
 *   · `seconds` → 这段自检会显示多少秒（写在提示里）
 * @returns {{actionbar: string, title: string, subtitle: string, chat: string[]}}
 *   · `actionbar` / `title` / `subtitle`：三条通道各自要发的文本（**都不带预览标记**）
 *   · `chat`：同内容发到聊天栏一份（可复制、可截图发给别人）
 */
function hudTestTexts(deps) {
  const d = deps || {};
  const glyphOf = typeof d.itemGlyph === "function" ? d.itemGlyph : function () { return ""; };
  const knobs = d.knobs || {};
  const seconds = Number(d.seconds) > 0 ? Math.round(Number(d.seconds)) : 15;
  const diamond = String(glyphOf("diamond") || "");

  // 第 1 行：纯文字（一个私有区字形都没有）—— 能读到就说明 HUD 文本通道正常。
  // 放在**字幕**通道（字号比标题小，这一行字最多）。
  const lineText = "§e[peek] 1/3 文字行：能看到这行 = 屏幕能显示文字";
  // 第 2 行：字形测试 —— **这一条就是判据**。放**标题**通道（字号最大、最显眼），
  // 因此刻意写得很短：原版标题是"大号字 + 一块跟着文本长的深色底板"，
  // 写长了底板会糊满半个屏幕（那正是别人服务器上看到的那块黑框）。
  const lineGlyph = diamond
    ? "§b[peek] 2/3 图标：" + diamond + diamond + diamond
    : "§b[peek] 2/3 图标：字形表里没有 diamond";
  // 第 3 行：旋钮快照 + 时限（动作栏，字号最小，所以宽一点没关系）
  const lineKnobs = "§7[peek] 3/3 显示 " + (knobs.display || "?") +
    "｜底衬 " + (knobs.backdrop || "?") +
    "｜尺寸 " + (knobs.scale || "?") +
    "｜角标 " + (knobs.badgelevel || "?") +
    "｜盒角标 " + (knobs.boxbadge || "?") +
    "　（" + seconds + " 秒后自动恢复）";
  // 第 4 行：怎么读（也在动作栏，跟判据行贴在一起）
  const lineHowTo = "§8图标是方框/问号 = 客户端没装资源包；连 1/3 文字行都看不到 = 这个玩家的 HUD 文本被挡住了";

  // 通道分配：title 用最大字号（最显眼）+ 判据行；subtitle 放纯文字行；
  // actionbar 放旋钮快照 + 怎么读（原版 actionbar 就在屏幕下方，方便对着看）。
  //
  // ⚠️ 三段**都不能带 `peek::` 标记**：带了就会被资源包当成"我们自己的预览"，按 0.25 倍
  // 字号 + 我们那套位置画出来 —— 自检就变成了"用被检验的东西去检验自己"；而资源包没装时
  // 那个标记又会原样显示成 `peek::` 几个字母，反而更乱。
  // 因此 title 必须走 `sendPlainTitle`（见 llse_adapter.js）：`sendTitle` 会加标记。
  const title = lineGlyph;
  const subtitle = lineText;
  const actionbar = lineKnobs + "\n" + lineHowTo;

  // 聊天栏那一份：屏幕上那几行会自己淡出、也进不了聊天记录，所以同时发一份到聊天栏
  // （玩家可以直接复制或截图发给人看）。这里用去掉颜色码的纯文本。
  //
  // ⚠️ 这个函数**不能**叫 `stripColor`：单文件打包后所有模块共享同一个顶层作用域，
  // main.js 里已经有一个 `stripColor`（控制台日志用），重名会让整个插件加载失败
  // （见 tools/pack/bundle-lse-plugin.mjs 的重名守门）。
  const chat = [
    "§a[peek] HUD 显示自检（" + seconds + " 秒后自动恢复；再敲一次 /peek:hudtest 立刻结束）",
    "§7 1. 文字行（字幕）：" + hudTestPlainText(lineText),
    "§7 2. 图标行（标题）：" + hudTestPlainText(lineGlyph),
    "§7 3. 旋钮行（动作栏）：" + hudTestPlainText(lineKnobs),
    "§8 怎么读：文字能看见 + 图标也看得见 = 一切正常；文字看得见而图标是方框/问号 = 客户端没装资源包；",
    "§8 三者都看不见 = 这个玩家的 HUD 文本显示被别的东西挡住了（或客户端把 HUD 关了）。"
  ];

  return { actionbar: actionbar, title: title, subtitle: subtitle, chat: chat };
}

/** 去掉 § 颜色码（聊天栏那份用纯文本，复制出去没有乱码）。 */
function hudTestPlainText(text) {
  return String(text === undefined || text === null ? "" : text).replace(/§./g, "");
}

// ===== selftest.js =====
/**
 * LSE 插件自检（Headless Self-Test）。
 *
 * ## 为什么需要它
 *
 * 插件里有一批调用只能进服务器才能确认（LSE 文档给的是通用签名，
 * 不同 LeviLamina / LSE 版本的实际签名有出入）。人工验证需要一名玩家
 * 站在方块前盯着看，很慢而且只能覆盖肉眼能看出来的部分。
 *
 * 这个模块把"能脱离玩家验证的部分"全部自动跑一遍：
 *   · 引擎 API 的真实形状（`Object.keys(mc)` + 类原型链上的成员名）
 *   · 世界读写：用 runcmd 放一个箱子 -> 写物品 -> 用适配层读回来
 *   · 各类容器（箱子/漏斗/熔炉/酿造台/发射器/潜影盒/木桶…）的真实槽位数
 *   · 容器实体：生成箱子矿车/运输船，确认**真实实体 id** 与容器槽位数
 *   · 排版：把读到的内容走一遍 formatContents / formatCounts，
 *     并把结果按 \uXXXX 转义后写进结果文件（控制台显示不了私有区字形）
 *
 * ## 这些写法由引擎 API 的实际形状决定
 *
 *   1. `mc.getBlock(pos, dimid)` 报 Wrong number of arguments —— 这个版本
 *      **没有** (pos, dimid) 这种两参形式，要么给 IntPos，要么给 (x,y,z,dim)。
 *   2. `mc.setBlock({x,y,z}, "minecraft:chest")` 报 Wrong type of argument ——
 *      坐标必须是 `mc.newIntPos()` 造出来的 IntPos，普通 JS 对象不行。
 *   3. 放方块改用 `mc.runcmdEx("setblock ...")`：走原生命令，绕开签名差异，
 *      也少一堆引擎报错刷屏。
 *
 * 结论同时打到控制台和 plugins/CrosshairContainerPeek/selftest-result.txt。
 *
 * ## 怎么触发
 *
 *   · 服务器控制台输入：peek:selftest
 *   · 或者放一个标记文件 plugins/CrosshairContainerPeek/selftest.on，
 *     服务器启动后约 6 秒自动跑一次（给自动化流程用；正常服不要建这个文件）
 *
 * 自检只动高空坐标（默认 0,200,0 一带），跑完把方块恢复成空气、实体删掉。
 */





/**
 * 自检工位：地面上方的空中（y=100）。
 *
 * ⚠️ 第二轮自检学到：没有玩家在线时区块不会被加载，
 * `setblock` 会回 "Cannot place block outside of the world" ——
 * 所以自检自己用 tickingarea 把工位所在区块强制加载起来（跑完再移除）。
 */
const selftestPost = { x: 0, y: 100, z: 0 };

/**
 * 开 tickingarea 之后要等多久才探测世界。
 * tickingarea 是异步生效的，实测隔 6 秒再 setblock 就成功了。
 */
const SELFTEST_WORLD_DELAY_MS = 6000;

/**
 * `simulateLookAt` 之后要等多久才射线。
 *
 * 模拟玩家"转头"是个模拟动作，要在后续 tick 里才生效
 * （实测紧接着调 getBlockFromViewVector 还是旧朝向，命中为空）。
 * 所以瞄准和射线必须分成两段，中间隔一会儿。
 */
const SELFTEST_LOOK_DELAY_MS = 1500;

/** 结果行缓存（最后一次性写文件）。 */
let selftestLines = [];
let selftestRunning = false;

/**
 * 插件主流程的句柄（入口 main.js 传进来）。
 * 自检要拿它走一遍真正的 updatePlayer，验证"射线 -> 读容器 -> 排版 -> 发 HUD"整条链。
 */
let selftestPlugin = null;

function selftestOut(text) {
  selftestLines.push(String(text));
  try {
    if (typeof logger !== "undefined" && logger.info) logger.info("[selftest] " + text);
  } catch (_err) {
    // 控制台打不出去就算了，文件里还有一份
  }
}

/** 把结果写到插件目录，方便自动化流程直接读文件。 */
function selftestFlush() {
  try {
    if (typeof File === "undefined" || !File.writeTo) return;
    File.writeTo("plugins/CrosshairContainerPeek/selftest-result.txt", selftestLines.join("\n") + "\n");
  } catch (_err) {
    // 写不了文件不影响控制台输出
  }
}

/**
 * 把非 ASCII 字符转成 \uXXXX。
 * HUD 用的都是私有区字形（U+E2xx 起），控制台和编辑器都显示不出来，
 * 转义之后才能精确比对"哪一格放了哪个字形"。
 */
function selftestEscape(text) {
  let out = "";
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    if (code === 10) out += "\\n";
    else if (code === 13) out += "\\r";
    else if (code >= 32 && code < 127) out += text[i];
    else out += "\\u" + ("000" + code.toString(16)).slice(-4);
  }
  return out;
}

/** 收集对象原型链上的属性名：用来确认引擎到底给了哪些方法。 */
function selftestMemberNames(obj) {
  if (obj === null || obj === undefined) return [];
  const out = [];
  const seen = {};
  let proto = Object.getPrototypeOf(obj);
  let guard = 0;
  while (proto && proto !== Object.prototype && guard < 8) {
    let names = [];
    try {
      names = Object.getOwnPropertyNames(proto);
    } catch (_err) {
      names = [];
    }
    for (let i = 0; i < names.length; i++) {
      const name = names[i];
      if (name === "constructor" || seen[name]) continue;
      seen[name] = true;
      out.push(name);
    }
    proto = Object.getPrototypeOf(proto);
    guard++;
  }
  return out;
}

/** 安全取值：拿不到就返回一个标记字符串，绝不抛。 */
function selftestPeek(obj, path) {
  try {
    const value = path.split(".").reduce((acc, key) => (acc === null || acc === undefined ? acc : acc[key]), obj);
    if (value === undefined) return "<undefined>";
    if (value === null) return "<null>";
    if (typeof value === "object") return "<" + (value.constructor ? value.constructor.name : "Object") + ">";
    return String(value);
  } catch (err) {
    return "<抛错: " + err + ">";
  }
}

/**
 * 依次尝试几种调用形式，返回第一个"真的给出结果"的。
 *
 * 用来"问引擎"：这个 API 在这个版本到底认哪种签名。
 *
 * ⚠️ 第一轮自检学到的坑：**参数写错时 LSE 不抛 JS 异常**，
 * 只在引擎日志里打一行 ERROR，然后把 undefined 返回给脚本。
 * 所以这里不能只看 `catch`，必须把 undefined/null 也当成"这种形式不认"。
 */
function selftestTryVariants(variants) {
  const rejected = [];
  for (let i = 0; i < variants.length; i++) {
    const desc = variants[i][0];
    let value;
    try {
      value = variants[i][1]();
    } catch (err) {
      rejected.push(desc + "(抛错)");
      continue;
    }
    if (value === undefined || value === null || value === false) {
      rejected.push(desc);
      continue;
    }
    return { desc: desc, value: value, ok: true, rejected: rejected };
  }
  return { desc: "<全都失败>", value: null, ok: false, rejected: rejected };
}

/** 造一个 IntPos（这个版本的方块 API 只认它）。 */
function selftestIntPos(x, y, z) {
  try {
    return mc.newIntPos(x, y, z, 0);
  } catch (_err) {
    return { x: x, y: y, z: z, dimid: 0 };
  }
}

/** 用原生命令改方块：绕开 setBlock 的签名差异。 */
function selftestRuncmd(cmd) {
  try {
    const r = mc.runcmdEx ? mc.runcmdEx(cmd) : mc.runcmd(cmd);
    if (r && typeof r === "object" && "success" in r) {
      return r.success ? "ok" : "失败:" + (r.output === undefined ? "<无输出>" : String(r.output).trim());
    }
    return "ok";
  } catch (err) {
    return "抛错:" + err;
  }
}

/** 读一个方块的 Block 对象（先试 4 数字形式，再试 IntPos 形式）。 */
function selftestGetBlock(x, y, z) {
  const found = selftestTryVariants([
    ["getBlock(x,y,z,dimid)", () => mc.getBlock(x, y, z, 0)],
    ["getBlock(IntPos)", () => mc.getBlock(selftestIntPos(x, y, z))]
  ]);
  return { desc: found.desc, block: found.ok ? found.value : null };
}

/** 一段容器容量 + 成员表。 */
function selftestDescribeContainer(tag, container) {
  if (!container) {
    selftestOut(tag + ": <拿不到容器对象>");
    return null;
  }
  selftestOut(tag + ": size=" + selftestPeek(container, "size") +
    " 成员=[" + selftestMemberNames(container).join(",") + "]");
  return container;
}

/** 往容器 0 号槽写一个物品，再读回来：确认 setItem / getItem / 数量字段。 */
function selftestWriteRead(tag, container, itemName, amount) {
  if (!container) return null;
  let item = null;
  try {
    item = mc.newItem(itemName, amount);
  } catch (err) {
    selftestOut(tag + ": newItem(" + itemName + ") 抛错 " + err);
    return null;
  }
  if (!item) {
    selftestOut(tag + ": newItem(" + itemName + ") 返回空");
    return null;
  }
  selftestOut(tag + " newItem: type=" + selftestPeek(item, "type") +
    " count=" + selftestPeek(item, "count") +
    " amount=" + selftestPeek(item, "amount") +
    " 成员=[" + selftestMemberNames(item).join(",") + "]");

  let setOk = "<抛错>";
  try {
    setOk = String(container.setItem(0, item));
  } catch (err) {
    setOk = "抛错 " + err;
  }
  selftestOut(tag + " setItem(0): " + setOk);

  let back = null;
  try {
    back = container.getItem(0);
  } catch (err) {
    selftestOut(tag + " getItem(0) 抛错: " + err);
    return null;
  }
  if (!back) {
    selftestOut(tag + " getItem(0): <空>");
    return null;
  }
  selftestOut(tag + " getItem(0): type=" + selftestPeek(back, "type") +
    " count=" + selftestPeek(back, "count") +
    " amount=" + selftestPeek(back, "amount"));
  return back;
}

/**
 * 放一种方块 -> 读 Block 对象 -> 报类型/成员/容器槽位数 -> 清掉。
 * 只对第一个方块打一次 Block 成员表（同类对象成员表一样）。
 */
function selftestBlockProbe(name, verbose) {
  const x = selftestPost.x;
  const y = selftestPost.y;
  const z = selftestPost.z;

  const placed = selftestRuncmd("setblock " + x + " " + y + " " + z + " " + name);
  if (placed !== "ok") {
    selftestOut(name + ": 放置失败（" + placed + "）");
    return;
  }

  const got = selftestGetBlock(x, y, z);
  const block = got.block;
  if (!block) {
    selftestOut(name + ": 放上去了但读回来是空");
    selftestRuncmd("setblock " + x + " " + y + " " + z + " air");
    return;
  }

  // hasContainer() 决定"要不要调 getContainer()"：
  // 引擎的 BlockClass::getContainer() 内部是 getBlockEntity(pos)->getContainer()，
  // 对没有方块实体的方块调它属于空指针路径，所以适配层先看 hasContainer()。
  let hasContainer = "<抛错>";
  try {
    hasContainer = typeof block.hasContainer === "function" ? String(block.hasContainer()) : "<无此方法>";
  } catch (err) {
    hasContainer = "抛错 " + err;
  }

  const read = readBlockContainer(block);

  let states = "<无>";
  try {
    const st = readBlockStates(block);
    if (st) states = selftestEscape(JSON.stringify(st));
  } catch (err) {
    states = "抛错 " + err;
  }

  selftestOut(name + ": type=" + selftestPeek(block, "type") +
    " id=" + selftestPeek(block, "id") +
    " hasContainer=" + hasContainer +
    " 适配层容器=" + (read ? "size=" + read.containerSize + " 件数=" + read.items.length : "<无>") +
    " [" + got.desc + "]");
  selftestOut("  方块状态=" + states);

  if (verbose) {
    selftestOut("  Block 成员=[" + selftestMemberNames(block).join(",") + "]");
  }

  // 真读一遍：能用适配层拿到容器就写一个物品进去，再读回来
  if (read) {
    const container = (() => {
      try {
        return block.getContainer();
      } catch (_err) {
        return null;
      }
    })();
    if (container) {
      selftestWriteRead("  " + name, container, "minecraft:diamond", 7);
      selftestOut("  " + name + " 适配层读回: " + selftestEscape(JSON.stringify(readBlockContainer(block))));
    }
  }

  // 收尾：拆掉方块，顺手清掉掉出来的物品实体。
  // ⚠️ 把装着东西的容器 setblock 成 air，里面的东西会**掉出来变成 item 实体**
  // 停在工位旁边；不清的话后面的实体探测会被这些掉落物干扰。
  selftestRuncmd("setblock " + x + " " + y + " " + z + " air");
  selftestClearDroppedItems(x, y, z);
}

/** 清掉工位附近的掉落物实体（自检收尾用）。 */
function selftestClearDroppedItems(x, y, z) {
  // 带命名空间的写法在新版本生效，不带的是老写法，两个都发一遍
  selftestRuncmd("kill @e[type=minecraft:item,x=" + x + ",y=" + y + ",z=" + z + ",r=3]");
  selftestRuncmd("kill @e[type=item,x=" + x + ",y=" + y + ",z=" + z + ",r=3]");
}

/**
 * 合成器专项：被禁用的槽位。
 *
 * 禁用状态存在**方块实体 NBT** 里（方块状态里没有），所以这里顺带验证
 * `block.getBlockEntity().getNbt()` / `setNbt()` 这条路能不能走通。
 * 自己写一个掩码进去再读回来，就能在不靠玩家手动锁格子的情况下验证整条链。
 */
function selftestCrafterProbe() {
  const x = selftestPost.x + 4;
  const y = selftestPost.y;
  const z = selftestPost.z;

  selftestOut("合成器专项：");
  const placed = selftestRuncmd("setblock " + x + " " + y + " " + z + " minecraft:crafter");
  selftestOut("  setblock: " + placed);
  if (placed !== "ok") return;

  const block = selftestGetBlock(x, y, z).block;
  if (!block) {
    selftestOut("  读不到方块");
    return;
  }

  // 先塞两个物品，让预览有内容
  const container = (() => {
    try {
      return block.getContainer ? block.getContainer() : null;
    } catch (_err) {
      return null;
    }
  })();
  if (container) {
    try {
      container.setItem(0, mc.newItem("minecraft:oak_planks", 4));
      container.setItem(4, mc.newItem("minecraft:stick", 8));
    } catch (err) {
      selftestOut("  放物品抛错: " + err);
    }
  }

  // 方块实体 NBT：读 -> 改 -> 写回 -> 再读
  let entity = null;
  try {
    entity = typeof block.getBlockEntity === "function" ? block.getBlockEntity() : null;
  } catch (err) {
    selftestOut("  getBlockEntity 抛错: " + err);
  }
  selftestOut("  方块实体: " + (entity ? "有（成员 " + selftestMemberNames(entity).join(",") + "）" : "<无>"));

  if (!entity) {
    selftestRuncmd("setblock " + x + " " + y + " " + z + " air");
    return;
  }

  let nbt = null;
  try {
    nbt = entity.getNbt();
  } catch (err) {
    selftestOut("  getNbt 抛错: " + err);
  }
  if (!nbt) {
    selftestOut("  NBT 读不到，禁用槽位这条路走不通");
    selftestRuncmd("setblock " + x + " " + y + " " + z + " air");
    return;
  }

  selftestOut("  NBT 键=[" + (typeof nbt.getKeys === "function" ? nbt.getKeys().join(",") : "?") + "]");
  selftestOut("  disabled_slots=" + selftestPeek({ v: nbt.getData("disabled_slots") }, "v") +
    "（类型 " + typeof nbt.getData("disabled_slots") + "）");
  selftestOut("  适配层读回（掩码 0）=" + selftestEscape(JSON.stringify(readDisabledSlots(block))));

  // ⚠️ 写入这条路走不通：`blockEntity.setNbt()` 底层是 `BlockActor::load()`，
  // 实测写进去之后读回来还是 0（合成器的 load 不认这个键，或者要配套的完整 NBT）。
  // 反正功能只需要**读**，所以这里不再纠结写入，改用**构造掩码**验证显示路径：
  // 位掩码 0b10101 = 槽位 0、2、4 被禁用。
  const mask = 1 + 4 + 16;
  selftestOut("  显示验证用掩码=" + mask + "（二进制 " + mask.toString(2) + " → 槽位 0/2/4）");

  const synthetic = {
    containerSize: 9,
    items: [
      { slot: 1, typeId: "oak_planks", amount: 4 },
      { slot: 7, typeId: "stick", amount: 8 }
    ],
    disabledSlots: [0, 2, 4],
    fingerprint: "selftest:crafter"
  };
  try {
    const text = formatContents("crafter", synthetic);
    selftestOut("  图标行: " + selftestEscape(text));
    selftestOut("  （叉字形码点 " + DISABLED_SLOT_GLYPH_CODE + " 应落在第 1、3、5 格；" +
      "物品在 2、8 格）");
  } catch (err) {
    selftestOut("  排版抛错: " + err);
  }

  selftestRuncmd("setblock " + x + " " + y + " " + z + " air");
  selftestClearDroppedItems(x, y, z);
}

/**
 * 潜影盒专项：验证"能不能读出潜影盒**物品**里的内容物"。
 *
 * 关键不在显示，而在**数据能不能拿到**：潜影盒的内容物在 NBT 里（一个 Items 列表），
 * 需要确认 `方块实体 NBT` 与 `物品 NBT` 两条路都读得到。
 */
function selftestShulkerNbtProbe(plugin) {
  const x = selftestPost.x + 6;
  const y = selftestPost.y;
  const z = selftestPost.z;

  selftestOut("潜影盒内容物 NBT 专项：");
  const placed = selftestRuncmd("setblock " + x + " " + y + " " + z + " minecraft:shulker_box");
  selftestOut("  setblock: " + placed);
  if (placed !== "ok") return;

  const block = selftestGetBlock(x, y, z).block;
  if (!block) {
    selftestOut("  读不到方块");
    return;
  }

  // 往潜影盒里放三件东西
  const container = (() => {
    try {
      return block.getContainer ? block.getContainer() : null;
    } catch (_err) {
      return null;
    }
  })();
  if (container) {
    try {
      container.setItem(0, mc.newItem("minecraft:diamond", 5));
      container.setItem(1, mc.newItem("minecraft:stone", 64));
      container.setItem(26, mc.newItem("minecraft:apple", 3));
      selftestOut("  已放入 3 件物品");
    } catch (err) {
      selftestOut("  放物品抛错: " + err);
    }
  }

  // ---- 路 1：方块实体 NBT 里到底有没有内容物 ----
  //
  // ⚠️ 键名是 **Items**（首字母大写），不是 items —— 一开始按小写找，什么也没找到。
  // 这是 Bedrock 方块实体的原始 NBT 键名（同一份 NBT 里还有 id/isMovable/x/y/z 等）。
  let beNbt = null;
  try {
    const entity = block.getBlockEntity();
    beNbt = entity ? entity.getNbt() : null;
  } catch (err) {
    selftestOut("  方块实体 NBT 抛错: " + err);
  }
  if (beNbt) {
    selftestOut("  方块实体 NBT 键=[" + (typeof beNbt.getKeys === "function" ? beNbt.getKeys().join(",") : "?") + "]");

    // getData() 会把 NBT 递归转成 JS 值 —— 列表就是数组，这是最省事的一条路
    let items = null;
    try {
      items = typeof beNbt.getData === "function" ? beNbt.getData("Items") : null;
    } catch (err) {
      selftestOut("  getData(Items) 抛错: " + err);
    }
    selftestOut("  getData(\"Items\") 类型=" + (items === null ? "<null>" : typeof items) +
      (Array.isArray(items) ? " 长度=" + items.length : ""));
    if (items) {
      selftestOut("  内容物=" + selftestEscape(JSON.stringify(items)));
    }

    // getTag() 走另一条路（返回 NBT 对象），对照一下两种写法
    try {
      const tag = typeof beNbt.getTag === "function" ? beNbt.getTag("Items") : null;
      selftestOut("  getTag(\"Items\")=" + (tag ? "有（成员 " + selftestMemberNames(tag).join(",") + "）" : "<null>"));
      if (tag && typeof tag.getSize === "function") selftestOut("    getSize()=" + tag.getSize());
      if (tag && typeof tag.toArray === "function") {
        selftestOut("    toArray=" + selftestEscape(JSON.stringify(tag.toArray()).slice(0, 400)));
      }
    } catch (err) {
      selftestOut("  getTag(Items) 抛错: " + err);
    }
  }

  // ---- 路 2：把潜影盒打掉，读**掉落物那个物品**的 NBT ----
  //
  // 这一条才是"容器里的潜影盒能不能预览"的关键：要读的是**物品 NBT**，
  // 不是方块实体 NBT。打掉之后物品以掉落物实体形式出现，
  // 而 LSE 的实体有 isItemEntity() / toItemEntity()，能拿到 ItemStack。
  //
  // ⚠️ 方法名是 block.destroy(drop)，不是 destroyBlock —— 按后者写会得到
  // "<无此方法>"，然后什么都测不出来（第一轮就是这么空跑的）。
  try {
    const destroyed = typeof block.destroy === "function" ? block.destroy(true) : "<无此方法>";
    selftestOut("  block.destroy(true): " + destroyed);
  } catch (err) {
    selftestOut("  block.destroy 抛错: " + err);
  }

  let drops = [];
  try {
    const all = mc.getAllEntities() || [];
    for (let i = 0; i < all.length; i++) {
      const e = all[i];
      let isItem = false;
      try {
        isItem = typeof e.isItemEntity === "function" ? e.isItemEntity() === true
          : String(e.type) === "minecraft:item";
      } catch (_err) {
        isItem = false;
      }
      if (!isItem) continue;

      let pos = null;
      try {
        pos = e.pos;
      } catch (_err) {
        pos = null;
      }
      const near = pos && Math.abs(pos.x - x) + Math.abs(pos.y - y) + Math.abs(pos.z - z) <= 6;
      if (near) drops.push(e);
    }
  } catch (err) {
    selftestOut("  找掉落物抛错: " + err);
  }
  selftestOut("  工位附近的掉落物实体数=" + drops.length);

  // 掉落的那个潜影盒物品：用来验证"物品 NBT 里的内容物读得到"
  if (drops.length > 0) {
    let stack = null;
    try {
      // 方法名是 toItem()，直接返回 ItemStack（不是 toItemEntity，
      // 那个名字不存在，写错了只会拿到 "not a function"）
      stack = typeof drops[0].toItem === "function" ? drops[0].toItem() : null;
      selftestOut("  掉落物 toItem(): " + (stack ? "成功" : "<null>"));
    } catch (err) {
      selftestOut("  toItem 抛错: " + err);
    }

    if (stack) {
      selftestOut("  掉落物品: type=" + selftestPeek(stack, "type") + " count=" + selftestPeek(stack, "count"));
      try {
        const itemNbt = stack.getNbt();
        selftestOut("  物品 NBT 键=[" +
          (itemNbt && typeof itemNbt.getKeys === "function" ? itemNbt.getKeys().join(",") : "?") + "]");

        // ⚠️ 内容物**不在顶层**：LLSE 的物品 NBT 把玩家数据都塞在 `tag` 这个子复合里
        // （顶层只有 Block/Count/Damage/Name/WasPickedUp 这些物品栈字段）。
        // 所以正确路径是 item.getNbt().getTag("tag").getTag("Items")。
        const userTag = itemNbt && typeof itemNbt.getTag === "function" ? itemNbt.getTag("tag") : null;
        selftestOut("  物品 NBT 的 tag 子复合=" +
          (userTag ? "有（键 " + (typeof userTag.getKeys === "function" ? userTag.getKeys().join(",") : "?") + "）" : "<无>"));

        const list = userTag && typeof userTag.getTag === "function" ? userTag.getTag("Items") : null;
        if (list && typeof list.getSize === "function") {
          selftestOut("  ★ 潜影盒物品里的 Items 大小=" + list.getSize());
          if (typeof list.toArray === "function") {
            selftestOut("  ★ 潜影盒物品里的内容物=" + selftestEscape(JSON.stringify(list.toArray())));
          }
        } else {
          selftestOut("  潜影盒物品里没读到 Items");
        }
      } catch (err) {
        selftestOut("  读物品 NBT 抛错: " + err);
      }
    }
  }

  selftestRuncmd("setblock " + x + " " + y + " " + z + " air");
  selftestClearDroppedItems(x, y, z);
}

/**
 * 堆肥桶专项：验证"方块状态 -> 伪装成容器 -> 排版"这条特殊路径。
 *
 * 用带方块状态的 setblock 造一个"装了 4 层"的堆肥桶，
 * 走一遍 readBlockStates -> readSpecialBlockContent -> formatContents。
 */
function selftestComposterProbe() {
  const x = selftestPost.x + 2;
  const y = selftestPost.y;
  const z = selftestPost.z;

  selftestOut("堆肥桶专项：");
  // ⚠️ 方块状态的写法是 ["名字"=值]，用冒号会报 Syntax error
  const placed = selftestRuncmd("setblock " + x + " " + y + " " + z +
    ' minecraft:composter ["composter_fill_level"=4]');
  selftestOut("  setblock（带状态 fill_level=4）: " + placed);
  if (placed !== "ok") return;

  const block = selftestGetBlock(x, y, z).block;
  if (!block) {
    selftestOut("  读不到方块");
    return;
  }

  const states = readBlockStates(block);
  selftestOut("  方块状态=" + selftestEscape(JSON.stringify(states)));

  const contents = readSpecialBlockContent(block);
  selftestOut("  特殊内容=" + selftestEscape(JSON.stringify(contents)));

  if (contents) {
    try {
      const text = formatContents("composter", contents);
      const counts = formatCounts("composter", contents);
      selftestOut("  图标行: " + selftestEscape(text));
      selftestOut("  数量行: " + selftestEscape(counts));
    } catch (err) {
      selftestOut("  排版抛错: " + err);
    }
  }

  selftestRuncmd("setblock " + x + " " + y + " " + z + " air");
}

/**
 * 实体容器探测：用原生命令 summon 造一个容器实体，再从 getAllEntities 里找回来。
 *
 * ## 为什么不用 mc.spawnMob
 *
 * 源码里 `McClass::spawnMob` 只认 **2 个或 5 个** 参数
 * （name, pos）或（name, x, y, z, dimid），
 * 第三/第四个参数的形式会直接被判 "Wrong number of arguments"。
 * 而且它底层走的是刷怪器，对生成位置有要求，空中/无效底面会给 undefined。
 * 用 `summon` 走原生命令最省事，也不用猜签名。
 */
function selftestEntityProbe(name) {
  const x = selftestPost.x + 8;
  const y = selftestPost.y;
  const z = selftestPost.z + 8;

  // 先铺一层地板：实体要站在实心方块上才生成得稳
  selftestRuncmd("setblock " + x + " " + (y - 1) + " " + z + " minecraft:stone");

  const summoned = selftestRuncmd("summon " + name + " " + x + " " + y + " " + z);
  selftestOut(name + ": summon -> " + summoned);
  if (summoned !== "ok") return;

  // 从实体表里找回刚生成的那一个：**先按 type 精确匹配**，再退回按距离匹配。
  //
  // ⚠️ 只按距离匹配会被"掉落物实体"抢走：前面的方块探测收尾时把装有物品的容器
  // setblock 成 air，里面的东西掉出来变成 minecraft:item 实体停在工位旁边，
  // 距离比刚生成的矿车更近，于是读到的是掉落物而不是目标实体。
  // 因此必须先按类型匹配。
  let entity = null;
  let matchedBy = "<没找到>";
  try {
    const all = mc.getAllEntities() || [];
    let typeMatch = null;
    let typeBest = 1e9;
    let nearest = null;
    let nearBest = 1e9;

    for (let i = 0; i < all.length; i++) {
      const e = all[i];
      let d = 1e9;
      try {
        const p = e.pos;
        d = Math.abs(p.x - x) + Math.abs(p.y - y) + Math.abs(p.z - z);
      } catch (_err) {
        d = 1e9;
      }
      if (d < nearBest) {
        nearBest = d;
        nearest = e;
      }
      const eType = e.type === undefined || e.type === null ? "" : String(e.type);
      if (eType === name && d < typeBest) {
        typeBest = d;
        typeMatch = e;
      }
    }

    if (typeMatch) {
      entity = typeMatch;
      matchedBy = "type";
    } else if (nearest && nearBest <= 4) {
      entity = nearest;
      matchedBy = "距离（" + selftestPeek(nearest, "type") + "）";
    }
  } catch (err) {
    selftestOut(name + ": getAllEntities 抛错 " + err);
  }

  if (!entity) {
    selftestOut(name + ": summon 命令成功了，但实体表里没有这个 id 的实体（原版可能没这个 id）");
    return;
  }
  selftestOut(name + ": 匹配方式=" + matchedBy);

  const type = selftestPeek(entity, "type");
  selftestOut(name + ": 实体真实 type=" + type +
    " name=" + selftestPeek(entity, "name") +
    " isContainerEntityType=" + isContainerEntityType(type));
  selftestOut("  Entity 成员=[" + selftestMemberNames(entity).join(",") + "]");

  let container = null;
  try {
    container = entity.getContainer ? entity.getContainer() : null;
  } catch (err) {
    selftestOut("  实体 getContainer 抛错: " + err);
  }
  selftestDescribeContainer("  " + name + " 容器", container);
  if (container) {
    selftestWriteRead("  " + name, container, "minecraft:gold_ingot", 3);
    const read = readEntityContainer(entity);
    selftestOut("  " + name + " 适配层读回: " + selftestEscape(JSON.stringify(read)));
  } else {
    selftestOut("  " + name + " 没有容器（适配层会当成非容器实体忽略）");
  }

  selftestRuncmd("kill @e[type=" + name + ",x=" + x + ",y=" + y + ",z=" + z + ",r=3]");
  selftestRuncmd("setblock " + x + " " + (y - 1) + " " + z + " air");
}

/**
 * 模拟玩家探测：让"必须有玩家"的那部分也能离线验。
 *
 * LSE 有 `mc.spawnSimulatedPlayer(name, pos, dimid)`（模拟玩家，BDS 自带）。
 * 有了它就能在没人进服的情况下：
 *   · 看到 Player / SimulatedPlayer 类上到底有哪些方法
 *     （getBlockFromViewVector / getEntityFromViewVector / setTitle 是否存在）
 *   · 用 `simulateLookAt` 把机器人转向箱子，真的走一遍**插件主流程**
 *     （updatePlayer：射线 -> 读容器 -> 排版 -> 发 actionbar/title），
 *     把排版结果打出来人眼核对
 *
 * 注意：模拟玩家也会被算进 getOnlinePlayers()，所以跑完必须 `simulateDisconnect()`
 * 删掉（`remove()` 不在 Player 类上，会报 not a function），
 * 否则服务器的玩家数就永远不是 0。
 */
function selftestSimPlayerProbe(plugin) {
  selftestOut("=== 模拟玩家探测 ===");

  const x = selftestPost.x + 8;
  const y = selftestPost.y;
  const z = selftestPost.z + 8;

  if (typeof mc.spawnSimulatedPlayer !== "function") {
    selftestOut("mc.spawnSimulatedPlayer 不存在，跳过");
    selftestFinish();
    return;
  }

  const found = selftestTryVariants([
    ["(name, FloatPos, dimid)", () => mc.spawnSimulatedPlayer("peek_bot", mc.newFloatPos(x, y, z, 0), 0)],
    ["(name, FloatPos)", () => mc.spawnSimulatedPlayer("peek_bot", mc.newFloatPos(x, y, z, 0))],
    ["(name, IntPos)", () => mc.spawnSimulatedPlayer("peek_bot", selftestIntPos(x, y, z))],
    ["(name, x, y, z, dimid)", () => mc.spawnSimulatedPlayer("peek_bot", x, y, z, 0)]
  ]);
  selftestOut("spawnSimulatedPlayer 认的形式: " + found.desc +
    (found.rejected.length ? "（被否掉：" + found.rejected.join(" / ") + "）" : ""));

  const sim = found.value;
  if (!sim) {
    selftestOut("模拟玩家没生成出来，玩家相关 API 仍需真人进服验证");
    selftestFinish();
    return;
  }

  selftestOut("  模拟玩家: name=" + selftestPeek(sim, "name") +
    " pos=" + selftestPeek(sim, "pos") +
    " isSimulatedPlayer=" + selftestPeek(sim, "isSimulatedPlayer"));
  selftestOut("  Player 类成员=[" + selftestMemberNames(sim).join(",") + "]");
  selftestOut("  关键 API: getBlockFromViewVector=" + typeof sim.getBlockFromViewVector +
    " getEntityFromViewVector=" + typeof sim.getEntityFromViewVector +
    " setTitle=" + typeof sim.setTitle +
    " simulateLookAt=" + typeof sim.simulateLookAt +
    " simulateDisconnect=" + typeof sim.simulateDisconnect);

  // HUD 通道：只验签名能调通，肉眼效果要真人看
  try {
    sim.setTitle("peek selftest", 2, 0, 60, 0);
    selftestOut("  setTitle(title) 调用成功");
  } catch (err) {
    selftestOut("  setTitle(title) 抛错: " + err);
  }
  try {
    sim.setTitle(" ", 4, 0, 60, 0);
    selftestOut("  setTitle(actionbar) 调用成功");
  } catch (err) {
    selftestOut("  setTitle(actionbar) 抛错: " + err);
  }

  // 摆一个箱子，把机器人转过去，然后走插件主流程
  const bx = x;
  const by = y;
  const bz = z + 3;
  selftestRuncmd("setblock " + bx + " " + (by - 1) + " " + bz + " minecraft:stone");
  selftestRuncmd("setblock " + bx + " " + by + " " + bz + " minecraft:chest");

  // 往箱子里塞点东西，让预览有内容可显示
  const chestBlock = selftestGetBlock(bx, by, bz).block;
  if (chestBlock) {
    const ct = (() => {
      try {
        return chestBlock.getContainer ? chestBlock.getContainer() : null;
      } catch (_err) {
        return null;
      }
    })();
    if (ct) {
      selftestWriteRead("  自检箱", ct, "minecraft:diamond", 12);
      try {
        ct.setItem(4, mc.newItem("minecraft:stone", 64));
        ct.setItem(13, mc.newItem("minecraft:water_bucket", 1));
        ct.setItem(26, mc.newItem("minecraft:arrow", 32));
      } catch (err) {
        selftestOut("  往自检箱放物品抛错: " + err);
      }
    }
  }

  let looked = false;
  try {
    looked = sim.simulateLookAt(mc.newFloatPos(bx + 0.5, by + 0.5, bz + 0.5, 0)) === true;
  } catch (err) {
    selftestOut("  simulateLookAt 抛错: " + err);
  }
  selftestOut("  simulateLookAt 箱子: " + looked +
    "（转头要等 " + (SELFTEST_LOOK_DELAY_MS / 1000) + " 秒才生效，射线放在下一段）");

  // 瞄准和射线必须分两段：转头是异步模拟动作
  setTimeout(() => selftestSimPlayerRayPhase(sim, plugin, bx, by, bz), SELFTEST_LOOK_DELAY_MS);
}

/** 模拟玩家射线阶段：等转头生效后，走一遍插件主流程。 */
function selftestSimPlayerRayPhase(sim, plugin, bx, by, bz) {
  try {
    selftestOut("=== 模拟玩家射线（转头后）===");

    // 先看看机器人现在朝向哪
    selftestOut("  朝向 direction=" + selftestPeek(sim, "direction") +
      " pos=" + selftestPeek(sim, "pos"));

    // 射线本身
    try {
      const hit = sim.getBlockFromViewVector(false, false, 8, false);
      selftestOut("  射线 getBlockFromViewVector(false,false,8,false) -> " +
        (hit ? selftestPeek(hit, "type") : "<没命中>"));
    } catch (err) {
      selftestOut("  射线抛错: " + err);
    }

    // 插件主流程（真正的端到端：射线 -> 读容器 -> 排版 -> 发 HUD）
    if (plugin && typeof plugin.updatePlayer === "function") {
      try {
        // 用 force 跳过节流：主循环每 2 tick 也在跑同一个玩家，
        // 等这里再调的时候内容往往已经被它发过一次了，不加 force 只会拿到 null
        let key = "<拿不到>";
        if (typeof plugin.playerKey === "function") key = String(plugin.playerKey(sim));
        selftestOut("  玩家标识 key=" + selftestEscape(key));

        const sent = plugin.updatePlayer(sim, true);
        if (sent) {
          selftestOut("  插件主流程 updatePlayer: typeId=" + sent.typeId + " kind=" + sent.kind);
          selftestOut("    图标行: " + selftestEscape(sent.text));
          selftestOut("    数量行: " + selftestEscape(sent.counts));
        } else {
          selftestOut("  插件主流程 updatePlayer: 返回空（说明射线没命中容器）");
        }
      } catch (err) {
        selftestOut("  插件主流程 updatePlayer 抛错: " + err);
      }
    } else {
      selftestOut("  没拿到插件主流程句柄，跳过端到端测试");
    }
  } catch (err) {
    selftestOut("模拟玩家射线阶段抛错: " + err);
  } finally {
    // 清场：拆箱子、断开机器人
    selftestRuncmd("setblock " + bx + " " + by + " " + bz + " air");
    selftestRuncmd("setblock " + bx + " " + (by - 1) + " " + bz + " air");

    let removed = false;
    try {
      if (typeof sim.simulateDisconnect === "function") removed = sim.simulateDisconnect() === true;
    } catch (err) {
      selftestOut("  simulateDisconnect 抛错: " + err);
    }
    if (!removed) {
      try {
        if (typeof sim.kick === "function") removed = sim.kick() === true;
      } catch (_err) {
        // 下面统一报
      }
    }
    selftestOut("  模拟玩家移除: " + (removed ? "已移除" : "失败，需要手动 /kick peek_bot"));

    const players = (() => {
      try {
        return mc.getOnlinePlayers() || [];
      } catch (_err) {
        return [];
      }
    })();
    selftestOut("  移除后在线玩家数=" + players.length);

    selftestFinish();
  }
}

/**
 * 排版自检用的样例：每种容器给**真实槽位数**和几件散落的物品。
 * 槽位数必须和 container_shapes.js 里的 size 一致，
 * 否则 shapeFor() 会判定"版本对不上"而退回矩形网格（这样就测不出形状）。
 */
function selftestShapeCases() {
  return [
    { typeId: "chest", size: 27, filled: [[0, "diamond", 12], [4, "stone", 64], [13, "water_bucket", 1], [26, "arrow", 32]] },
    { typeId: "barrel", size: 27, filled: [[2, "oak_planks", 3], [25, "iron_ingot", 7]] },
    { typeId: "shulker_box", size: 27, filled: [[0, "emerald", 1], [14, "torch", 64]] },
    { typeId: "hopper", size: 5, filled: [[0, "raw_iron", 5], [4, "coal", 9]] },
    { typeId: "furnace", size: 3, filled: [[0, "raw_iron", 5], [1, "coal", 9], [2, "iron_ingot", 2]] },
    { typeId: "blast_furnace", size: 3, filled: [[0, "iron_ore", 3], [1, "coal", 4], [2, "iron_ingot", 1]] },
    { typeId: "smoker", size: 3, filled: [[0, "beef", 3], [1, "coal", 4], [2, "cooked_beef", 1]] },
    { typeId: "brewing_stand", size: 5, filled: [[0, "nether_wart", 2], [1, "potion", 1], [2, "potion", 1], [3, "potion", 1], [4, "blaze_powder", 6]] },
    { typeId: "dispenser", size: 9, filled: [[0, "arrow", 64], [8, "egg", 16]] },
    { typeId: "dropper", size: 9, filled: [[3, "cobblestone", 64]] },
    { typeId: "crafter", size: 9, filled: [[1, "oak_planks", 4], [7, "stick", 8]] }
  ];
}

/**
 * 主入口：跑完整套自检。
 *
 * @param {{updatePlayer?: Function, reach?: number}} [plugin] 插件主流程句柄
 */
function selftestRun(plugin) {
  if (selftestRunning) {
    selftestOut("自检正在运行，忽略重复触发");
    return;
  }
  if (plugin) selftestPlugin = plugin;
  selftestRunning = true;
  selftestLines = [];

  try {
    selftestOut("=== CrosshairContainerPeek 自检开始 ===");
    selftestOut("BDS=" + (typeof mc.getBDSVersion === "function" ? selftestPeek({ v: mc.getBDSVersion() }, "v") : "?") +
      " 协议=" + (typeof mc.getServerProtocolVersion === "function" ? selftestPeek({ v: mc.getServerProtocolVersion() }, "v") : "?"));

    // 1) 引擎给我的全局对象长什么样
    selftestOut("全局: " + ["mc", "ll", "logger", "File", "i18n", "network", "data"]
      .map((n) => n + "=" + (typeof globalThis[n])).join(" "));
    selftestOut("mc 的 API（共 " + Object.keys(mc).length + " 个）: " + Object.keys(mc).join(","));

    // 2) 位置对象：IntPos / FloatPos 能被哪些 API 接受
    const pos = selftestTryVariants([
      ["newIntPos(x,y,z,dimid)", () => mc.newIntPos(selftestPost.x, selftestPost.y, selftestPost.z, 0)],
      ["newIntPos(x,y,z)", () => mc.newIntPos(selftestPost.x, selftestPost.y, selftestPost.z)],
      ["newFloatPos(x,y,z,dimid)", () => mc.newFloatPos(selftestPost.x, selftestPost.y, selftestPost.z, 0)]
    ]);
    selftestOut("位置对象: " + pos.desc + " -> " + selftestPeek({ v: pos.value }, "v") +
      (pos.ok ? " 成员=[" + selftestMemberNames(pos.value).join(",") + "]" : ""));

    // 3) 没有玩家时区块不加载 —— 自检自己开一块 tickingarea 出来。
    //    ⚠️ 第三轮自检学到：**tickingarea 是异步生效的**。命令返回 ok 之后
    //    立刻 setblock 仍然报 "Cannot place block outside of the world"
    //    （手动在控制台先 add、隔几秒再 setblock 就成功）。
    //    所以世界相关的探测全部丢到 selftestWorldPhase，等 5 秒再跑。
    const waAdd = selftestRuncmd("tickingarea add " + selftestPost.x + " 0 " + selftestPost.z + " " +
      (selftestPost.x + 15) + " 255 " + (selftestPost.z + 15) + " peek_selftest");
    selftestOut("工位 tickingarea: " + waAdd + "（等 " + (SELFTEST_WORLD_DELAY_MS / 1000) + " 秒再探测世界）");

    // 4) 排版：把样例内容走一遍真排版，结果转义输出。
    //    这一段不碰世界，所以先跑，人工看结果时不用等。
    selftestOut("=== 排版自检 ===");
    const cases = selftestShapeCases();
    for (let i = 0; i < cases.length; i++) {
      const c = cases[i];
      const items = c.filled.map((f) => ({ slot: f[0], typeId: f[1], amount: f[2] }));
      const contents = {
        containerSize: c.size,
        items: items,
        fingerprint: "selftest:" + c.typeId
      };
      let text = "<抛错>";
      let counts = "<抛错>";
      try {
        text = formatContents(c.typeId, contents);
      } catch (err) {
        text = "<抛错 " + err + ">";
      }
      try {
        counts = formatCounts(c.typeId, contents);
      } catch (err) {
        counts = "<抛错 " + err + ">";
      }
      selftestOut(c.typeId + "（" + c.size + " 槽，放 " + items.length + " 件）");
      selftestOut("  图标: " + selftestEscape(text));
      selftestOut("  数量: " + selftestEscape(counts));
    }

    selftestOut("=== 排版自检结束，等待世界探测 ===");
  } catch (err) {
    selftestOut("自检（前半段）抛错: " + err);
  }

  // 世界部分延后执行：等 tickingarea 真的把区块加载出来
  setTimeout(selftestWorldPhase, SELFTEST_WORLD_DELAY_MS);
}

/** 世界探测阶段：需要在区块加载之后才能跑。 */
function selftestWorldPhase() {
  try {
    selftestOut("=== 世界探测开始 ===");
    // 工位所在的方块（能读到就说明区块已经加载）
    const probe = selftestGetBlock(selftestPost.x, selftestPost.y, selftestPost.z);
    selftestOut("工位 (" + selftestPost.x + "," + selftestPost.y + "," + selftestPost.z + ") 原方块=" +
      (probe.block ? selftestPeek(probe.block, "type") : "<读不到>") + " [" + probe.desc + "]");

    // 各类方块的容器能力
    const blockNames = [
      "minecraft:chest",
      "minecraft:trapped_chest",
      "minecraft:barrel",
      "minecraft:hopper",
      "minecraft:furnace",
      "minecraft:blast_furnace",
      "minecraft:smoker",
      "minecraft:brewing_stand",
      "minecraft:dispenser",
      "minecraft:dropper",
      "minecraft:crafter",
      "minecraft:undyed_shulker_box",
      "minecraft:light_blue_shulker_box",
      "minecraft:composter",
      "minecraft:jukebox",
      "minecraft:decorated_pot",
      "minecraft:lectern"
    ];
    for (let i = 0; i < blockNames.length; i++) selftestBlockProbe(blockNames[i], i === 0);

    // 堆肥桶：方块状态那条特殊路径
    selftestComposterProbe();

    // 合成器：禁用槽位（方块实体 NBT）
    selftestCrafterProbe();

    // 潜影盒：内容物 NBT 能不能读（决定"容器里的潜影盒预览"能不能做）
    selftestShulkerNbtProbe(selftestPlugin);

    // 容器实体
    const entityNames = [
      "minecraft:chest_minecart",
      "minecraft:hopper_minecart",
      "minecraft:chest_boat",
      "minecraft:oak_chest_boat",
      "minecraft:bamboo_chest_raft"
    ];
    for (let i = 0; i < entityNames.length; i++) selftestEntityProbe(entityNames[i]);

    // 模拟玩家：让"需要玩家"的那部分 API 也能离线验。
    // 这一段的射线要等转头生效，所以收尾（关 tickingarea、写结果文件）
    // 交给它自己的下一段做 —— 见 selftestSimPlayerRayPhase。
    selftestSimPlayerProbe(selftestPlugin);

    selftestOut("=== 世界探测结束 ===");
  } catch (err) {
    selftestOut("世界探测抛错: " + err);
    selftestFinish();
  }
}

/**
 * 收尾：关掉自检开的 tickingarea、落盘结果、复位运行标记。
 *
 * 之所以单独抽出来：世界探测分成了"同步（方块/实体）"和
 * "延后（模拟玩家转头后射线）"两段，收尾只能在最后一段做。
 */
function selftestFinish() {
  selftestOut("工位 tickingarea 回收: " + selftestRuncmd("tickingarea remove peek_selftest"));
  selftestOut("=== 自检结束 ===");
  selftestRunning = false;
  selftestFlush();
}

/** 注册控制台命令 + 标记文件自动触发。入口在服务器就绪后调用。 */
function selftestInstall(plugin) {
  if (plugin) selftestPlugin = plugin;

  try {
    if (typeof mc.regConsoleCmd === "function") {
      mc.regConsoleCmd("peek:selftest", "运行容器预览插件自检", () => selftestRun());
    }
  } catch (err) {
    selftestOut("注册 peek:selftest 失败: " + err);
  }

  // 标记文件：自动化流程用；正常服务器上不会存在这个文件。
  try {
    if (typeof File !== "undefined" && File.exists && File.exists("plugins/CrosshairContainerPeek/selftest.on")) {
      setTimeout(() => selftestRun(), 6000);
    }
  } catch (_err) {
    // 没有 File API 就跳过
  }
}

// ===== box_content.js =====
/**
 * **潜影盒里装了什么** —— 判定与"该画什么"的策略。纯逻辑，无引擎依赖。
 *
 * ## 为什么这样切
 *
 * 上一版把"事实"和"策略"揉在一个函数里（一个 `uniformFullItemId` 既算全满又算同种
 * 又算满堆，还直接决定打不打角标），结果是：
 *   · 想加一档判据就得改那个函数、再顺手改调用方；
 *   · 空盒子也要"登记"这种事只能靠调用方反推（`badge: ""` 既表示"没图"也表示"不合格"）；
 *   · 三档判据的名字（`low/high/max`）散在命令表、判定表、文档三处。
 * 现在拆成三层，每层只干一件事，各自可以单独测：
 *
 *   ① **事实** `readBoxFacts(inner, stackSizeFor)`：盒里有几格、是不是同一种、每格是不是满堆、
 *      总数多少、第一件是什么。**只描述盒子，不管画什么。**
 *   ② **策略** `badgeItemIdFor(facts, mode)`：按档位决定"该给哪件物品打角标"（空串=不打）。
 *   ③ **扫描** `scanBoxes(...)`：把容器里每个潜影盒跑一遍 ①②，产出按槽位可查的记录表。
 *
 * 显示层（角标 / 总数 / 空白）不在这里决定 —— 见 `scripts/box_overlay.js`（一格怎么拼）
 * 与 `overlayFor()`（同格优先级）。
 *
 * ## 四档判据（用户拍板）
 *
 * | 档位 | 判据 |
 * |---|---|
 * | `max`（默认） | 27 格**全占满** + 全是**同一种** + 每格**堆满**（按该物品自己的上限） |
 * | `high` | 盒里**只有一种**物品（不要求装满、不要求满堆） |
 * | `low` | 盒里**有东西**就画**槽位最小**那件（混装也画） |
 * | `off` | **一律不打**（那一格留白；开着总数时显示总数） |
 *
 * `off` 这一档的意义是"这一格不想看角标"，而不是"关掉整个角标功能"：
 * 关掉功能是 `BOX_BADGE_ENABLED`（`/peek:boxbadge off`，连盒内 NBT 都不读）；
 * `off` 档仍然扫描（总数要用），只是不打角标。同格只能画一个，
 * 所以开总数时插件会把档位**自动设成 off**（见 main.js 的 applySetting）。
 *
 * ## 防御性输入
 *
 * NBT 是外来数据，坏值（条目为 null、槽位越界/重复、id 为空）一律**当成不满足**，
 * 绝不抛异常、也绝不猜：宁可少打一个角标，也不要在游戏里报错。
 */

// 一格的拼法在 scripts/（行为包与插件共用同一份，见 tools/pack/build-lse-plugin.ps1 的 $shared）。


/** 潜影盒的槽位数（固定 27 格）。"全满"说的就是这个数。 */
const SHULKER_SLOT_COUNT = 27;

/**
 * Bedrock 的**满堆只可能是这三个数**：1 / 16 / 64。
 *
 * 用途：`stackSizeFor` 返回 0（表里没这个物品、引擎也不肯说）时用它兜底 ——
 * 比按 64 一刀切强得多，也不会把"每格 63"这种半满的当成满堆。
 *
 * 📌 "默认 64" 这个数**不在本模块**：它属于堆叠上限那一层
 *（`leplugin/box_stack_sizes.js` 的 `DEFAULT_STACK_COUNT`）。两边各写一份的话，
 * 打包成单文件时就是**顶层重名**（打包器会直接拒收，踩过一次）。
 */
const POSSIBLE_FULL_STACKS = [1, 16, 64];

/** 四个档位的名字（也是 `/peek:badgelevel` 的取值）。`off` = 不打角标（那格留白或显示总数）。 */
const BADGE_MODES = ["off", "low", "high", "max"];

/** 默认档位。 */
const DEFAULT_BADGE_MODE = "max";

/**
 * 档位规范化：不认识的档位**退回默认的 max**（不静默变成"全打"）。
 *
 * @returns {{mode: string, fallback: boolean}} `fallback` 为真时调用方可如实报告"这个档位名不认识"
 */
function normalizeBadgeMode(mode) {
  const text = String(mode === undefined || mode === null ? "" : mode).trim().toLowerCase();
  if (BADGE_MODES.indexOf(text) >= 0) return { mode: text, fallback: false };
  return { mode: DEFAULT_BADGE_MODE, fallback: text !== "" };
}

/** 去掉 `minecraft:` 这类命名空间前缀。 */
function bareItemId(value) {
  return String(value === undefined || value === null ? "" : value)
    .replace(/^[a-z_]+:/, "")
    .trim();
}

/**
 * 问一次"这个物品的堆叠上限"。**0 = 不知道**（调用方按 1/16/64 兜底）。
 *
 * 注入函数抛错、返回非数字、返回 <=0 时一律当"不知道" —— 判定不许因为探测失败而崩，
 * 也不许把"探不到"当成"上限是 0"（那会让任何盒子都打不出角标）。
 */
function stackCountOf(stackSizeFor, itemId) {
  if (typeof stackSizeFor !== "function") return 0;
  let value = NaN;
  try {
    value = Number(stackSizeFor(itemId));
  } catch (_err) {
    value = NaN;
  }
  return isFinite(value) && value > 0 ? Math.round(value) : 0;
}

/**
 * 把一个盒子内部的条目列表整理成"事实"。
 *
 * @param {Array<{slot:number,id:string,count:number}>} inner NBT 里的 `Items`（只含非空格）
 * @param {Function} [stackSizeFor] `itemId -> 该物品的堆叠上限`（0 = 不知道）
 * @returns {{
 *   valid: boolean, slots: number, filled: number, total: number,
 *   uniformItemId: string, firstItemId: string,
 *   allFullStack: boolean, isCompletelyFull: boolean, brokenReason: string
 * }}
 *   · `slots` 合法条目数；`filled` 槽位去重后的实际占格数；
 *   · `uniformItemId` 全是同一种时是那个**裸 id**，否则空串；
 *   · `allFullStack` 每格都达到该物品上限（上限拿不到时按 1/16/64 三选一）；
 *   · `isCompletelyFull` 27 格全占满（0..26 都被覆盖）；
 *   · `brokenReason` 数据不合法时的一句话（只为诊断，判定只看上面几个字段）。
 *
 * **坏数据一律 `valid = false`**（条目为 null、id 为空、槽位越界/重复、条目数超 27）：
 * 上层判定先看 `valid`，看到假就直接不打角标 —— 宁可少打一个，也不要用"读了一半"
 * 的事实去猜。这也是上一版的坑：坏数据只是提前 return，`valid` 却留在 true 上。
 */
function readBoxFacts(inner, stackSizeFor) {
  const facts = {
    valid: false,
    slots: 0,
    filled: 0,
    total: 0,
    uniformItemId: "",
    firstItemId: "",
    allFullStack: false,
    isCompletelyFull: false,
    brokenReason: ""
  };
  if (!Array.isArray(inner)) {
    facts.brokenReason = "不是数组";
    return facts;
  }
  facts.valid = true;
  facts.slots = inner.length;

  const slots = new Set();
  let uniform = "";
  let allSame = true;
  let firstId = "";
  let firstSlot = -1;
  let allFullStack = true;
  let want = 0;

  for (let i = 0; i < inner.length; i++) {
    const entry = inner[i];
    if (!entry) {
      // 坏数据一律 valid=false（别让"读了一半"的事实被上层当成完整事实用）
      facts.valid = false;
      facts.brokenReason = "有条目是空的";
      return facts;
    }
    const id = bareItemId(entry.id);
    if (!id) {
      facts.valid = false;
      facts.brokenReason = "有条目的物品 id 为空";
      return facts;
    }
    const slot = Number(entry.slot);
    if (!Number.isInteger(slot) || slot < 0 || slot >= SHULKER_SLOT_COUNT) {
      facts.valid = false;
      facts.brokenReason = "槽位不合法：" + entry.slot;
      return facts;
    }

    const count = Number(entry.count);
    if (i === 0) {
      uniform = id;
      want = stackCountOf(stackSizeFor, id);
    } else if (id !== uniform) {
      allSame = false;
    }
    // 第一件（槽位最小）= 按槽位比，不是按数组顺序（NBT 的顺序不保证）
    if (firstSlot < 0 || slot < firstSlot) {
      firstSlot = slot;
      firstId = id;
    }

    if (allFullStack) {
      if (want > 0) {
        if (count !== want) allFullStack = false;
      } else if (POSSIBLE_FULL_STACKS.indexOf(count) < 0) {
        allFullStack = false;
      }
    }

    facts.total += isFinite(count) && count > 0 ? count : 0;
    slots.add(slot);
  }

  facts.filled = slots.size;
  facts.uniformItemId = allSame && facts.slots > 0 ? uniform : "";
  facts.firstItemId = firstId;
  facts.allFullStack = allFullStack && facts.slots > 0;
  facts.isCompletelyFull = facts.filled === SHULKER_SLOT_COUNT;

  // 数据自相矛盾的两种情形：27 条却只占 26 格（重复槽位）、或条目数超过 27
  if (facts.slots > SHULKER_SLOT_COUNT) {
    facts.valid = false;
    facts.brokenReason = "条目数超过 27：" + facts.slots;
  } else if (facts.slots === SHULKER_SLOT_COUNT && facts.filled !== SHULKER_SLOT_COUNT) {
    facts.valid = false;
    facts.brokenReason = "27 条但槽位有重复（只占 " + facts.filled + " 格）";
  }
  return facts;
}

/**
 * 按档位决定"该给哪件物品打角标"。
 *
 * @param {object} facts `readBoxFacts` 的产物
 * @param {string} mode `low` | `high` | `max`
 * @returns {string} 物品的裸 id；空串 = 这一档不打角标
 */
function badgeItemIdFor(facts, mode) {
  if (!facts || !facts.valid || facts.slots === 0) return "";
  const normalized = normalizeBadgeMode(mode).mode;
  if (normalized === "off") return "";
  if (normalized === "low") return facts.firstItemId;
  if (normalized === "high") return facts.uniformItemId;
  // max：全占满 + 同一种 + 每格堆满
  if (!facts.isCompletelyFull || !facts.uniformItemId || !facts.allFullStack) return "";
  return facts.uniformItemId;
}

/**
 * 扫描容器里的潜影盒，产出**按槽位可查**的记录表。
 *
 * 记录里带的是"事实 + 该档位下的角标字形"，**不含**往格子上画什么（那是显示层的事）。
 *
 * @param {object} contents 容器内容：`{ items: [{ slot, typeId, stack }] }`
 * @param {object} deps 注入的引擎相关能力：
 *   · `readInner(stack)` → 盒内条目数组；抛错按"读不到"处理
 *   · `isShulkerType(typeId)` → 是不是潜影盒
 *   · `glyphFor(itemId)` → 角标字形（空串 = 这个物品没有图标）
 *   · `stackSizeFor(itemId)` → 堆叠上限（0 = 不知道）
 *   · `mode` → 档位
 * @returns {{bySlot: Map<number, object>, records: object[], totals: number[], boxCount: number}}
 *   `records` / `totals` 按**槽位升序**（稳定的顺序；`totals` 是各盒子内容物数量之和，
 *   目前没有功能用它 —— 留着是因为它是事实层的一部分，自检也拿它核对求和）
 */
function scanBoxes(contents, deps) {
  const bySlot = new Map();
  const records = [];
  if (!contents || !Array.isArray(contents.items)) {
    return { bySlot: bySlot, records: records, totals: [], boxCount: 0 };
  }
  const d = deps || {};
  const mode = normalizeBadgeMode(d.mode).mode;

  for (let i = 0; i < contents.items.length; i++) {
    const entry = contents.items[i];
    if (!entry || !d.isShulkerType || !d.isShulkerType(entry.typeId)) continue;

    let inner = null;
    try {
      inner = d.readInner ? d.readInner(entry.stack) : null;
    } catch (_err) {
      inner = null;
    }
    const facts = readBoxFacts(inner, d.stackSizeFor);
    const itemId = badgeItemIdFor(facts, mode);
    let glyph = "";
    if (itemId && typeof d.glyphFor === "function") {
      try {
        glyph = d.glyphFor(itemId) || "";
      } catch (_err) {
        glyph = "";
      }
    }

    const record = {
      slot: entry.slot,
      typeId: entry.typeId,
      total: facts.total,
      badgeGlyph: glyph,
      badgeItemId: glyph ? itemId : "",
      facts: facts
    };
    bySlot.set(entry.slot, record);
    records.push(record);
  }

  records.sort(function (a, b) { return a.slot - b.slot; });
  const totals = [];
  for (let i = 0; i < records.length; i++) {
    if (records[i].total > 0) totals.push(records[i].total);
  }
  return { bySlot: bySlot, records: records, totals: totals, boxCount: records.length };
}

/**
 * **显示策略**：某个盒子那一格该画什么 —— 只有两种结果（角标 / 空白）。
 *
 *   · 判据给出角标字形 → 画角标；
 *   · 给不出（档位不够、物品没图标、盒子是空的） → **空白**：潜影盒那一格
 *   **永远不画堆叠数**（盒子不可堆叠、恒为 1，是噪声）。
 *
 * ⚠️ 这里曾经还要管"盒内总数"（总数优先、角标让位），两样东西抢同一格的三种解法
 * 都试过、都失败（见 docs/PROGRESS.md §7.13），最后**总数功能整体删掉**：
 * 现在这一格只剩"画不画角标"一件事，简单到不可能再出这类问题。
 *
 * @param {object} record `scanBoxes` 的一条记录
 * @returns {object|null} 叠放描述；`null` = 不叠放（照常画数目，非潜影盒才走这条）
 */
function overlayFor(record) {
  if (!record) return null;
  const badge = boxBadgeOverlay(record.badgeGlyph);
  if (badge) return badge;
  return BOX_OVERLAY_BLANK;
}

// ===== item_stack_sizes.js =====
/**
 * 物品 -> **堆叠上限** —— **由 tools/icons/build-item-stack-sizes.mjs 自动生成**，手改会被覆盖。
 *
 * 用途：`/peek:badgelevel max` 要判"每格堆满"，而不同物品的上限不同
 *（多数 64、雪球/告示牌/鸡蛋 16、工具/盔甲/桶 1）。引擎不肯告诉我们这个数
 *（实测：Item 上没有 max-stack 取值方法，`mc.newItem(type, 64).count` 也不夹），
 * 所以在这里烤成表。
 *
 * 来源：
 *   ① 原版行为包 items/*.json 里声明的 minecraft:max_stack_size（权威，共 22 条）
 *   ② 家族规则（`*_sign` / `*_boat` / `*_pickaxe` … 只覆盖整类同值的物品）
 *   ③ 其余按 64（拿不准就留 64：少打角标看得见，多打会让人以为判据坏了）
 *
 * 本次生成：物品 1612 个 → 1 堆叠 203 个、16 堆叠 58 个、其余 64；表里记下 261 个非默认值。
 *
 * ⚠️ **表里没有的物品**：`maxStackSizeOf()` 返回 0（= 不知道），判定层（leplugin/box_content.js）
 * 按“Bedrock 的满堆只有 1 / 16 / 64 三种取值”兜底（POSSIBLE_FULL_STACKS）。
 */

/** 默认堆叠上限（表里没有的物品按这个算）。 */
const DEFAULT_STACK_SIZE = 64;

/** 非默认上限的物品：id -> 上限。 */
const STACK_SIZE_OVERRIDES = {
  "acacia_boat": 1,
  "acacia_chest_boat": 1,
  "acacia_hanging_sign": 16,
  "acacia_sign": 16,
  "acacia_standing_sign": 16,
  "armor_stand": 16,
  "axolotl_bucket": 1,
  "bamboo_chest_raft": 1,
  "bamboo_hanging_sign": 16,
  "bamboo_raft": 1,
  "bamboo_sign": 16,
  "banner_pattern": 1,
  "bed": 1,
  "beetroot_soup": 1,
  "birch_boat": 1,
  "birch_chest_boat": 1,
  "birch_hanging_sign": 16,
  "birch_sign": 16,
  "birch_standing_sign": 16,
  "black_banner": 16,
  "black_bundle": 1,
  "black_shulker_box": 1,
  "blue_banner": 16,
  "blue_bundle": 1,
  "blue_shulker_box": 1,
  "bow": 1,
  "brown_banner": 16,
  "brown_bundle": 1,
  "brown_shulker_box": 1,
  "brush": 1,
  "bucket": 1,
  "bundle": 1,
  "cake": 1,
  "carrot_on_a_stick": 1,
  "chainmail_boots": 1,
  "chainmail_chestplate": 1,
  "chainmail_helmet": 1,
  "chainmail_leggings": 1,
  "cherry_boat": 1,
  "cherry_chest_boat": 1,
  "cherry_hanging_sign": 16,
  "cherry_sign": 16,
  "chest_boat": 1,
  "chest_minecart": 1,
  "cod_bucket": 1,
  "command_block_minecart": 1,
  "copper_horse_armor": 1,
  "crimson_hanging_sign": 16,
  "crimson_sign": 16,
  "crimson_standing_sign": 16,
  "crimson_wall_sign": 16,
  "crossbow": 1,
  "cyan_banner": 16,
  "cyan_bundle": 1,
  "cyan_shulker_box": 1,
  "dark_oak_boat": 1,
  "dark_oak_chest_boat": 1,
  "dark_oak_hanging_sign": 16,
  "dark_oak_sign": 16,
  "darkoak_sign": 16,
  "darkoak_standing_sign": 16,
  "decorated_pot": 1,
  "diamond_axe": 1,
  "diamond_boots": 1,
  "diamond_chestplate": 1,
  "diamond_helmet": 1,
  "diamond_hoe": 1,
  "diamond_horse_armor": 1,
  "diamond_leggings": 1,
  "diamond_pickaxe": 1,
  "diamond_shovel": 1,
  "diamond_sword": 1,
  "egg": 16,
  "elytra": 1,
  "enchanted_book": 1,
  "ender_pearl": 16,
  "fishing_rod": 1,
  "flint_and_steel": 1,
  "goat_horn": 1,
  "golden_axe": 1,
  "golden_boots": 1,
  "golden_chestplate": 1,
  "golden_helmet": 1,
  "golden_hoe": 1,
  "golden_horse_armor": 1,
  "golden_leggings": 1,
  "golden_pickaxe": 1,
  "golden_shovel": 1,
  "golden_sword": 1,
  "gray_banner": 16,
  "gray_bundle": 1,
  "gray_shulker_box": 1,
  "green_banner": 16,
  "green_bundle": 1,
  "green_shulker_box": 1,
  "honey_bottle": 16,
  "hopper_minecart": 1,
  "iron_axe": 1,
  "iron_boots": 1,
  "iron_chestplate": 1,
  "iron_helmet": 1,
  "iron_hoe": 1,
  "iron_horse_armor": 1,
  "iron_leggings": 1,
  "iron_pickaxe": 1,
  "iron_shovel": 1,
  "iron_sword": 1,
  "jungle_boat": 1,
  "jungle_chest_boat": 1,
  "jungle_hanging_sign": 16,
  "jungle_sign": 16,
  "jungle_standing_sign": 16,
  "lava_bucket": 1,
  "leather_boots": 1,
  "leather_chestplate": 1,
  "leather_helmet": 1,
  "leather_horse_armor": 1,
  "leather_leggings": 1,
  "light_blue_banner": 16,
  "light_blue_bundle": 1,
  "light_blue_shulker_box": 1,
  "light_gray_banner": 16,
  "light_gray_bundle": 1,
  "light_gray_shulker_box": 1,
  "lime_banner": 16,
  "lime_bundle": 1,
  "lime_shulker_box": 1,
  "lingering_potion": 1,
  "magenta_banner": 16,
  "magenta_bundle": 1,
  "magenta_shulker_box": 1,
  "mangrove_boat": 1,
  "mangrove_chest_boat": 1,
  "mangrove_hanging_sign": 16,
  "mangrove_sign": 16,
  "map": 1,
  "milk_bucket": 1,
  "minecart": 1,
  "mushroom_stew": 1,
  "music_disc_11": 1,
  "music_disc_13": 1,
  "music_disc_5": 1,
  "music_disc_blocks": 1,
  "music_disc_cat": 1,
  "music_disc_chirp": 1,
  "music_disc_creator": 1,
  "music_disc_creator_music_box": 1,
  "music_disc_far": 1,
  "music_disc_mall": 1,
  "music_disc_mellohi": 1,
  "music_disc_otherside": 1,
  "music_disc_pigstep": 1,
  "music_disc_precipice": 1,
  "music_disc_relic": 1,
  "music_disc_stal": 1,
  "music_disc_strad": 1,
  "music_disc_tears": 1,
  "music_disc_wait": 1,
  "music_disc_ward": 1,
  "netherite_axe": 1,
  "netherite_boots": 1,
  "netherite_chestplate": 1,
  "netherite_helmet": 1,
  "netherite_hoe": 1,
  "netherite_horse_armor": 1,
  "netherite_leggings": 1,
  "netherite_pickaxe": 1,
  "netherite_shovel": 1,
  "netherite_sword": 1,
  "oak_boat": 1,
  "oak_chest_boat": 1,
  "oak_hanging_sign": 16,
  "oak_sign": 16,
  "ominous_bottle": 1,
  "orange_banner": 16,
  "orange_bundle": 1,
  "orange_shulker_box": 1,
  "pale_oak_boat": 1,
  "pale_oak_chest_boat": 1,
  "pale_oak_hanging_sign": 16,
  "pale_oak_sign": 16,
  "pink_banner": 16,
  "pink_bundle": 1,
  "pink_shulker_box": 1,
  "potion": 1,
  "powder_snow_bucket": 1,
  "pufferfish_bucket": 1,
  "purple_banner": 16,
  "purple_bundle": 1,
  "purple_shulker_box": 1,
  "rabbit_stew": 1,
  "record_11": 1,
  "record_13": 1,
  "record_5": 1,
  "record_blocks": 1,
  "record_cat": 1,
  "record_chirp": 1,
  "record_creator": 1,
  "record_creator_music_box": 1,
  "record_far": 1,
  "record_mall": 1,
  "record_mellohi": 1,
  "record_otherside": 1,
  "record_pigstep": 1,
  "record_precipice": 1,
  "record_relic": 1,
  "record_stal": 1,
  "record_strad": 1,
  "record_tears": 1,
  "record_wait": 1,
  "record_ward": 1,
  "red_banner": 16,
  "red_bundle": 1,
  "red_shulker_box": 1,
  "saddle": 1,
  "salmon_bucket": 1,
  "shears": 1,
  "shield": 1,
  "snowball": 16,
  "splash_potion": 1,
  "spruce_boat": 1,
  "spruce_chest_boat": 1,
  "spruce_hanging_sign": 16,
  "spruce_sign": 16,
  "spruce_standing_sign": 16,
  "spyglass": 1,
  "standing_banner": 16,
  "standing_sign": 16,
  "stone_axe": 1,
  "stone_hoe": 1,
  "stone_pickaxe": 1,
  "stone_shovel": 1,
  "stone_sword": 1,
  "suspicious_stew": 1,
  "tadpole_bucket": 1,
  "tnt_minecart": 1,
  "totem_of_undying": 1,
  "trident": 1,
  "tropical_fish_bucket": 1,
  "turtle_helmet": 1,
  "undyed_shulker_box": 1,
  "wall_banner": 16,
  "warped_fungus_on_a_stick": 1,
  "warped_hanging_sign": 16,
  "warped_sign": 16,
  "warped_standing_sign": 16,
  "warped_wall_sign": 16,
  "water_bucket": 1,
  "white_banner": 16,
  "white_bundle": 1,
  "white_shulker_box": 1,
  "wooden_axe": 1,
  "wooden_hoe": 1,
  "wooden_pickaxe": 1,
  "wooden_shovel": 1,
  "wooden_sword": 1,
  "writable_book": 1,
  "written_book": 1,
  "yellow_banner": 16,
  "yellow_bundle": 1,
  "yellow_shulker_box": 1
};

/**
 * 取某个物品的堆叠上限。
 *
 * @param {string} itemId 物品 id（带不带 minecraft: 前缀都认）
 * @returns {number} 上限；**0 = 这个物品不在表里**（调用方自己兜底，别当成 0 个）
 */
function maxStackSizeOf(itemId) {
  if (!itemId) return 0;
  const raw = String(itemId);
  const bare = raw.replace(/^[a-z_]+:/, "");
  if (Object.prototype.hasOwnProperty.call(STACK_SIZE_OVERRIDES, bare)) {
    return STACK_SIZE_OVERRIDES[bare];
  }
  if (Object.prototype.hasOwnProperty.call(STACK_SIZE_OVERRIDES, raw)) {
    return STACK_SIZE_OVERRIDES[raw];
  }
  const known = KNOWN_ITEM_IDS.indexOf("\n" + bare + "\n") >= 0;
  return known ? DEFAULT_STACK_SIZE : 0;
}

/**
 * 这张表覆盖到的物品 id（换行分隔，前后各补一个换行便于整串查找）。
 *
 * 为什么要存"知道哪些"：判 0 与判 64 是两回事 —— 表里写着 64 的物品要严格等于 64，
 * 而**表里没有**的物品（新版本/模组）只能按"1 / 16 / 64"兜底。
 */
const KNOWN_ITEM_IDS = "\nacaciaFence\nacacia_boat\nacacia_button\nacacia_chest_boat\nacacia_door\nacacia_double_slab\nacacia_fence\nacacia_fence_gate\nacacia_hanging_sign\nacacia_leaves\nacacia_log\nacacia_planks\nacacia_pressure_plate\nacacia_sapling\nacacia_shelf\nacacia_sign\nacacia_slab\nacacia_stairs\nacacia_standing_sign\nacacia_trapdoor\nacacia_wood\nactivator_rail\nallium\nallow\namethyst_block\namethyst_cluster\namethyst_shard\nancient_debris\nandesite\nandesite_double_slab\nandesite_slab\nandesite_stairs\nandesite_wall\nangler_pottery_sherd\nanvil\napple\nappleEnchanted\narcher_pottery_sherd\narmadillo_scute\narmor_stand\narms_up_pottery_sherd\narrow\naxolotl_bucket\nazalea\nazalea_leaves\nazalea_leaves_flowered\nazure_bluet\nbaked_potato\nbamboo\nbamboo_block\nbamboo_button\nbamboo_chest_raft\nbamboo_door\nbamboo_double_slab\nbamboo_fence\nbamboo_fence_gate\nbamboo_hanging_sign\nbamboo_mosaic\nbamboo_mosaic_double_slab\nbamboo_mosaic_slab\nbamboo_mosaic_stairs\nbamboo_planks\nbamboo_pressure_plate\nbamboo_raft\nbamboo_shelf\nbamboo_sign\nbamboo_slab\nbamboo_stairs\nbamboo_trapdoor\nbanner\nbanner_pattern\nbarrel\nbarrier\nbasalt\nbeacon\nbed\nbedrock\nbee_nest\nbeef\nbeehive\nbeetroot\nbeetroot_seeds\nbeetroot_soup\nbell\nbig_dripleaf\nbirchFence\nbirch_boat\nbirch_button\nbirch_chest_boat\nbirch_door\nbirch_double_slab\nbirch_fence\nbirch_fence_gate\nbirch_hanging_sign\nbirch_leaves\nbirch_log\nbirch_planks\nbirch_pressure_plate\nbirch_sapling\nbirch_shelf\nbirch_sign\nbirch_slab\nbirch_stairs\nbirch_standing_sign\nbirch_trapdoor\nbirch_wood\nblack_banner\nblack_bundle\nblack_candle\nblack_candle_cake\nblack_carpet\nblack_concrete\nblack_concrete_powder\nblack_dye\nblack_glazed_terracotta\nblack_harness\nblack_shulker_box\nblack_stained_glass\nblack_stained_glass_pane\nblack_terracotta\nblack_wool\nblackstone\nblackstone_double_slab\nblackstone_slab\nblackstone_stairs\nblackstone_wall\nblade_pottery_sherd\nblast_furnace\nblaze_powder\nblaze_rod\nblue_banner\nblue_bundle\nblue_candle\nblue_candle_cake\nblue_carpet\nblue_concrete\nblue_concrete_powder\nblue_dye\nblue_egg\nblue_glazed_terracotta\nblue_harness\nblue_ice\nblue_orchid\nblue_shulker_box\nblue_stained_glass\nblue_stained_glass_pane\nblue_terracotta\nblue_wool\nbolt_armor_trim_smithing_template\nbone\nbone_block\nbone_meal\nbook\nbookshelf\nborder_block\nbordure_indented_banner_pattern\nbow\nbowl\nbrain_coral\nbrain_coral_block\nbrain_coral_fan\nbread\nbreeze_rod\nbrewer_pottery_sherd\nbrewing_stand\nbrick\nbrick_block\nbrick_double_slab\nbrick_slab\nbrick_stairs\nbrick_wall\nbrown_banner\nbrown_bundle\nbrown_candle\nbrown_candle_cake\nbrown_carpet\nbrown_concrete\nbrown_concrete_powder\nbrown_dye\nbrown_egg\nbrown_glazed_terracotta\nbrown_harness\nbrown_mushroom\nbrown_mushroom_block\nbrown_shulker_box\nbrown_stained_glass\nbrown_stained_glass_pane\nbrown_terracotta\nbrown_wool\nbrush\nbubble_coral\nbubble_coral_block\nbubble_coral_fan\nbucket\nbucketAxolotl\nbucketCustomFish\nbucketFish\nbucketLava\nbucketPowderSnow\nbucketPuffer\nbucketSalmon\nbucketTadpole\nbucketTropical\nbucketWater\nbudding_amethyst\nbundle\nburn_pottery_sherd\nbush\ncactus\ncactus_flower\ncake\ncalcite\ncalibrated_sculk_sensor\ncamera\ncampfire\ncandle\ncandle_cake\ncarpet\ncarrot\ncarrotOnAStick\ncarrot_on_a_stick\ncarrots\ncartography_table\ncarved_pumpkin\ncauldron\ncave_vines\ncave_vines_body_with_berries\ncave_vines_head_with_berries\nchain\nchain_command_block\nchainmail_boots\nchainmail_chestplate\nchainmail_helmet\nchainmail_leggings\ncharcoal\ncherry_boat\ncherry_button\ncherry_chest_boat\ncherry_door\ncherry_double_slab\ncherry_fence\ncherry_fence_gate\ncherry_hanging_sign\ncherry_leaves\ncherry_log\ncherry_planks\ncherry_pressure_plate\ncherry_sapling\ncherry_shelf\ncherry_sign\ncherry_slab\ncherry_stairs\ncherry_trapdoor\ncherry_wood\nchest\nchest_boat\nchest_minecart\nchicken\nchipped_anvil\nchiseled_bookshelf\nchiseled_copper\nchiseled_deepslate\nchiseled_nether_bricks\nchiseled_polished_blackstone\nchiseled_quartz_block\nchiseled_red_sandstone\nchiseled_resin_bricks\nchiseled_sandstone\nchiseled_stone_bricks\nchiseled_tuff\nchiseled_tuff_bricks\nchorus_flower\nchorus_fruit\nchorus_fruit_popped\nchorus_plant\nclay\nclay_ball\nclock\nclosed_eyeblossom\nclownfish\ncoal\ncoal_block\ncoal_ore\ncoarse_dirt\ncoast_armor_trim_smithing_template\ncobbled_deepslate\ncobbled_deepslate_double_slab\ncobbled_deepslate_slab\ncobbled_deepslate_stairs\ncobbled_deepslate_wall\ncobblestone\ncobblestone_double_slab\ncobblestone_slab\ncobblestone_wall\ncobweb\ncocoa\ncocoa_beans\ncod\ncod_bucket\ncommand_block\ncommand_block_minecart\ncomparator\ncompass\ncomposter\nconduit\ncooked_beef\ncooked_chicken\ncooked_cod\ncooked_fish\ncooked_mutton\ncooked_porkchop\ncooked_rabbit\ncooked_salmon\ncookie\ncopper_block\ncopper_bulb\ncopper_door\ncopper_golem_statue\ncopper_grate\ncopper_horse_armor\ncopper_ingot\ncopper_nautilus_armor\ncopper_ore\ncopper_spear\ncopper_trapdoor\ncornflower\ncracked_deepslate_bricks\ncracked_deepslate_tiles\ncracked_nether_bricks\ncracked_polished_blackstone_bricks\ncracked_stone_bricks\ncrafter\ncrafting_table\ncreaking_heart\ncreeper_banner_pattern\ncreeper_head\ncrimson_button\ncrimson_door\ncrimson_double_slab\ncrimson_fence\ncrimson_fence_gate\ncrimson_fungus\ncrimson_hanging_sign\ncrimson_hyphae\ncrimson_nylium\ncrimson_planks\ncrimson_pressure_plate\ncrimson_roots\ncrimson_shelf\ncrimson_sign\ncrimson_slab\ncrimson_stairs\ncrimson_standing_sign\ncrimson_stem\ncrimson_trapdoor\ncrimson_wall_sign\ncrossbow\ncrying_obsidian\ncut_copper\ncut_copper_slab\ncut_copper_stairs\ncut_red_sandstone\ncut_red_sandstone_slab\ncut_sandstone\ncut_sandstone_slab\ncyan_banner\ncyan_bundle\ncyan_candle\ncyan_candle_cake\ncyan_carpet\ncyan_concrete\ncyan_concrete_powder\ncyan_dye\ncyan_glazed_terracotta\ncyan_harness\ncyan_shulker_box\ncyan_stained_glass\ncyan_stained_glass_pane\ncyan_terracotta\ncyan_wool\ndamaged_anvil\ndandelion\ndanger_pottery_sherd\ndarkOakFence\ndark_oak_boat\ndark_oak_button\ndark_oak_chest_boat\ndark_oak_door\ndark_oak_double_slab\ndark_oak_fence\ndark_oak_fence_gate\ndark_oak_hanging_sign\ndark_oak_leaves\ndark_oak_log\ndark_oak_planks\ndark_oak_pressure_plate\ndark_oak_sapling\ndark_oak_shelf\ndark_oak_sign\ndark_oak_slab\ndark_oak_stairs\ndark_oak_trapdoor\ndark_oak_wood\ndark_prismarine\ndark_prismarine_double_slab\ndark_prismarine_slab\ndark_prismarine_stairs\ndarkoak_sign\ndarkoak_standing_sign\ndaylight_detector\ndead_brain_coral\ndead_brain_coral_block\ndead_brain_coral_fan\ndead_brain_coral_wall_fan\ndead_bubble_coral\ndead_bubble_coral_block\ndead_bubble_coral_fan\ndead_bubble_coral_wall_fan\ndead_fire_coral\ndead_fire_coral_block\ndead_fire_coral_fan\ndead_fire_coral_wall_fan\ndead_horn_coral\ndead_horn_coral_block\ndead_horn_coral_fan\ndead_horn_coral_wall_fan\ndead_tube_coral\ndead_tube_coral_block\ndead_tube_coral_fan\ndead_tube_coral_wall_fan\ndeadbush\ndecorated_pot\ndeepslate\ndeepslate_brick_double_slab\ndeepslate_brick_slab\ndeepslate_brick_stairs\ndeepslate_brick_wall\ndeepslate_bricks\ndeepslate_coal_ore\ndeepslate_copper_ore\ndeepslate_diamond_ore\ndeepslate_emerald_ore\ndeepslate_gold_ore\ndeepslate_iron_ore\ndeepslate_lapis_ore\ndeepslate_redstone_ore\ndeepslate_tile_double_slab\ndeepslate_tile_slab\ndeepslate_tile_stairs\ndeepslate_tile_wall\ndeepslate_tiles\ndeny\ndetector_rail\ndiamond\ndiamond_axe\ndiamond_block\ndiamond_boots\ndiamond_chestplate\ndiamond_helmet\ndiamond_hoe\ndiamond_horse_armor\ndiamond_leggings\ndiamond_nautilus_armor\ndiamond_ore\ndiamond_pickaxe\ndiamond_shovel\ndiamond_spear\ndiamond_sword\ndiorite\ndiorite_double_slab\ndiorite_slab\ndiorite_stairs\ndiorite_wall\ndirt\ndirt_with_roots\ndisc_fragment\ndisc_fragment_5\ndispenser\ndoorWood\ndouble_cut_copper_slab\ndouble_plant\ndouble_stone_slab\ndouble_wooden_slab\ndragon_breath\ndragon_egg\ndragon_head\ndried_ghast\ndried_kelp\ndried_kelp_block\ndripstone_block\ndropper\ndune_armor_trim_smithing_template\necho_shard\negg\nelytra\nemerald\nemerald_block\nemerald_ore\nemptyLocatorMap\nemptyMap\nenchanted_book\nenchanted_golden_apple\nenchanting_table\nend_brick_stairs\nend_bricks\nend_crystal\nend_portal_frame\nend_rod\nend_stone\nend_stone_brick_double_slab\nend_stone_brick_slab\nend_stone_brick_wall\nenderChest\nender_chest\nender_chest_item\nender_eye\nender_pearl\nexperience_bottle\nexplorer_pottery_sherd\nexposed_chiseled_copper\nexposed_copper\nexposed_copper_bulb\nexposed_copper_door\nexposed_copper_golem_statue\nexposed_copper_grate\nexposed_copper_trapdoor\nexposed_cut_copper\nexposed_cut_copper_slab\nexposed_cut_copper_stairs\nexposed_double_cut_copper_slab\neye_armor_trim_smithing_template\nfarmland\nfeather\nfence\nfence_gate\nfermented_spider_eye\nfern\nfield_masoned_banner_pattern\nfire\nfire_coral\nfire_coral_block\nfire_coral_fan\nfireball\nfirefly_bush\nfirework_rocket\nfirework_star\nfireworks\nfireworksCharge\nfireworks_charge\nfish\nfishing_rod\nfletching_table\nflint\nflint_and_steel\nflow_armor_trim_smithing_template\nflow_banner_pattern\nflow_pottery_sherd\nflower_banner_pattern\nflower_pot\nflowering_azalea\nflowing_lava\nflowing_water\nframe\nfriend_pottery_sherd\nfrog_spawn\nfrosted_ice\nfurnace\nfurnace_block\nghast_tear\ngilded_blackstone\nglass\nglass_bottle\nglass_pane\nglazedTerracottaBlack\nglazedTerracottaBlue\nglazedTerracottaBrown\nglazedTerracottaCyan\nglazedTerracottaGray\nglazedTerracottaGreen\nglazedTerracottaLightBlue\nglazedTerracottaLime\nglazedTerracottaMagenta\nglazedTerracottaOrange\nglazedTerracottaPink\nglazedTerracottaPurple\nglazedTerracottaRed\nglazedTerracottaSilver\nglazedTerracottaWhite\nglazedTerracottaYellow\nglobe_banner_pattern\nglow_berries\nglow_frame\nglow_ink_sac\nglow_lichen\nglowstone\nglowstone_dust\ngoat_horn\ngold_block\ngold_ingot\ngold_nugget\ngold_ore\ngolden_apple\ngolden_axe\ngolden_boots\ngolden_carrot\ngolden_chestplate\ngolden_helmet\ngolden_hoe\ngolden_horse_armor\ngolden_leggings\ngolden_nautilus_armor\ngolden_pickaxe\ngolden_rail\ngolden_shovel\ngolden_sword\ngranite\ngranite_double_slab\ngranite_slab\ngranite_stairs\ngranite_wall\ngrass\ngrass_block\ngrass_path\ngravel\ngray_banner\ngray_bundle\ngray_candle\ngray_candle_cake\ngray_carpet\ngray_concrete\ngray_concrete_powder\ngray_dye\ngray_glazed_terracotta\ngray_harness\ngray_shulker_box\ngray_stained_glass\ngray_stained_glass_pane\ngray_terracotta\ngray_wool\ngreen_banner\ngreen_bundle\ngreen_candle\ngreen_candle_cake\ngreen_carpet\ngreen_concrete\ngreen_concrete_powder\ngreen_dye\ngreen_glazed_terracotta\ngreen_harness\ngreen_shulker_box\ngreen_stained_glass\ngreen_stained_glass_pane\ngreen_terracotta\ngreen_wool\ngrindstone\ngunpowder\nguster_banner_pattern\nguster_pottery_sherd\nhanging_roots\nhardened_clay\nhay_block\nheart_of_the_sea\nheart_pottery_sherd\nheartbreak_pottery_sherd\nheavy_core\nheavy_weighted_pressure_plate\nhoney_block\nhoney_bottle\nhoneycomb\nhoneycomb_block\nhopper\nhopper_minecart\nhorn_coral\nhorn_coral_block\nhorn_coral_fan\nhorse_armor_diamond\nhorse_armor_gold\nhorse_armor_iron\nhorse_armor_leather\nhorsearmordiamond\nhorsearmorgold\nhorsearmoriron\nhorsearmorleather\nhost_armor_trim_smithing_template\nhowl_pottery_sherd\nice\ninfested_chiseled_stone_bricks\ninfested_cobblestone\ninfested_cracked_stone_bricks\ninfested_deepslate\ninfested_mossy_stone_bricks\ninfested_stone\ninfested_stone_bricks\nink_sac\ninvisibleBedrock\niron_axe\niron_bars\niron_block\niron_boots\niron_chestplate\niron_door\niron_helmet\niron_hoe\niron_horse_armor\niron_ingot\niron_leggings\niron_nautilus_armor\niron_nugget\niron_ore\niron_pickaxe\niron_shovel\niron_spear\niron_sword\niron_trapdoor\njack_o_lantern\njigsaw\njukebox\njungleFence\njungle_boat\njungle_button\njungle_chest_boat\njungle_door\njungle_double_slab\njungle_fence\njungle_fence_gate\njungle_hanging_sign\njungle_leaves\njungle_log\njungle_planks\njungle_pressure_plate\njungle_sapling\njungle_shelf\njungle_sign\njungle_slab\njungle_stairs\njungle_standing_sign\njungle_trapdoor\njungle_wood\nkelp\nladder\nlantern\nlapis_block\nlapis_lazuli\nlapis_ore\nlarge_amethyst_bud\nlarge_fern\nlava\nlava_bucket\nlead\nleaf_litter\nleather\nleather_boots\nleather_chestplate\nleather_helmet\nleather_horse_armor\nleather_leggings\nleaves\nlectern\nlever\nlight_block\nlight_blue_banner\nlight_blue_bundle\nlight_blue_candle\nlight_blue_candle_cake\nlight_blue_carpet\nlight_blue_concrete\nlight_blue_concrete_powder\nlight_blue_dye\nlight_blue_glazed_terracotta\nlight_blue_harness\nlight_blue_shulker_box\nlight_blue_stained_glass\nlight_blue_stained_glass_pane\nlight_blue_terracotta\nlight_blue_wool\nlight_gray_banner\nlight_gray_bundle\nlight_gray_candle\nlight_gray_candle_cake\nlight_gray_carpet\nlight_gray_concrete\nlight_gray_concrete_powder\nlight_gray_dye\nlight_gray_harness\nlight_gray_shulker_box\nlight_gray_stained_glass\nlight_gray_stained_glass_pane\nlight_gray_terracotta\nlight_gray_wool\nlight_weighted_pressure_plate\nlightning_rod\nlilac\nlily_of_the_valley\nlime_banner\nlime_bundle\nlime_candle\nlime_candle_cake\nlime_carpet\nlime_concrete\nlime_concrete_powder\nlime_dye\nlime_glazed_terracotta\nlime_harness\nlime_shulker_box\nlime_stained_glass\nlime_stained_glass_pane\nlime_terracotta\nlime_wool\nlingering_potion\nlit_blast_furnace\nlit_furnace\nlit_pumpkin\nlit_smoker\nlodestone\nlodestonecompass\nlog\nloom\nmace\nmagenta_banner\nmagenta_bundle\nmagenta_candle\nmagenta_candle_cake\nmagenta_carpet\nmagenta_concrete\nmagenta_concrete_powder\nmagenta_dye\nmagenta_glazed_terracotta\nmagenta_harness\nmagenta_shulker_box\nmagenta_stained_glass\nmagenta_stained_glass_pane\nmagenta_terracotta\nmagenta_wool\nmagma\nmagma_cream\nmangrove_boat\nmangrove_button\nmangrove_chest_boat\nmangrove_door\nmangrove_double_slab\nmangrove_fence\nmangrove_fence_gate\nmangrove_hanging_sign\nmangrove_leaves\nmangrove_log\nmangrove_planks\nmangrove_pressure_plate\nmangrove_propagule\nmangrove_roots\nmangrove_shelf\nmangrove_sign\nmangrove_slab\nmangrove_stairs\nmangrove_trapdoor\nmangrove_wood\nmap\nmedium_amethyst_bud\nmelon\nmelon_block\nmelon_seeds\nmelon_slice\nmilk\nmilk_bucket\nminecart\nminecartFurnace\nminecart_furnace\nminer_pottery_sherd\nmob_spawner\nmojang_banner_pattern\nmonster_egg\nmoss_block\nmoss_carpet\nmossy_cobblestone\nmossy_cobblestone_double_slab\nmossy_cobblestone_slab\nmossy_cobblestone_stairs\nmossy_cobblestone_wall\nmossy_stone_brick_slab\nmossy_stone_brick_stairs\nmossy_stone_brick_wall\nmossy_stone_bricks\nmourner_pottery_sherd\nmud\nmud_brick_double_slab\nmud_brick_slab\nmud_brick_stairs\nmud_brick_wall\nmud_bricks\nmuddy_mangrove_roots\nmushroom\nmushroom_stem\nmushroom_stew\nmusic_disc_11\nmusic_disc_13\nmusic_disc_5\nmusic_disc_blocks\nmusic_disc_cat\nmusic_disc_chirp\nmusic_disc_creator\nmusic_disc_creator_music_box\nmusic_disc_far\nmusic_disc_mall\nmusic_disc_mellohi\nmusic_disc_otherside\nmusic_disc_pigstep\nmusic_disc_precipice\nmusic_disc_relic\nmusic_disc_stal\nmusic_disc_strad\nmusic_disc_tears\nmusic_disc_wait\nmusic_disc_ward\nmutton\nmuttonCooked\nmuttonRaw\nmutton_cooked\nmutton_raw\nmycelium\nname_tag\nnautilus_shell\nnetherStar\nnether_brick\nnether_brick_double_slab\nnether_brick_fence\nnether_brick_slab\nnether_brick_stairs\nnether_brick_wall\nnether_gold_ore\nnether_sprouts\nnether_star\nnether_wart\nnether_wart_block\nnetherbrick\nnetherite_axe\nnetherite_block\nnetherite_boots\nnetherite_chestplate\nnetherite_helmet\nnetherite_hoe\nnetherite_horse_armor\nnetherite_ingot\nnetherite_leggings\nnetherite_nautilus_armor\nnetherite_pickaxe\nnetherite_scrap\nnetherite_shovel\nnetherite_spear\nnetherite_sword\nnetherite_upgrade_smithing_template\nnetherrack\nnetherreactor\nnormal_stone_slab\nnormal_stone_stairs\nnoteblock\noak_boat\noak_button\noak_chest_boat\noak_door\noak_double_slab\noak_fence\noak_fence_gate\noak_hanging_sign\noak_leaves\noak_log\noak_planks\noak_pressure_plate\noak_sapling\noak_shelf\noak_sign\noak_slab\noak_stairs\noak_trapdoor\noak_wood\nobserver\nobsidian\nochre_froglight\nominous_bottle\nominous_trial_key\nopen_eyeblossom\norange_banner\norange_bundle\norange_candle\norange_candle_cake\norange_carpet\norange_concrete\norange_concrete_powder\norange_dye\norange_glazed_terracotta\norange_harness\norange_shulker_box\norange_stained_glass\norange_stained_glass_pane\norange_terracotta\norange_tulip\norange_wool\noxeye_daisy\noxidized_chiseled_copper\noxidized_copper\noxidized_copper_bulb\noxidized_copper_door\noxidized_copper_golem_statue\noxidized_copper_grate\noxidized_copper_trapdoor\noxidized_cut_copper\noxidized_cut_copper_slab\noxidized_cut_copper_stairs\noxidized_double_cut_copper_slab\npacked_ice\npacked_mud\npainting\npale_hanging_moss\npale_moss_block\npale_moss_carpet\npale_oak_boat\npale_oak_button\npale_oak_chest_boat\npale_oak_door\npale_oak_double_slab\npale_oak_fence\npale_oak_fence_gate\npale_oak_hanging_sign\npale_oak_leaves\npale_oak_log\npale_oak_planks\npale_oak_pressure_plate\npale_oak_sapling\npale_oak_shelf\npale_oak_sign\npale_oak_slab\npale_oak_stairs\npale_oak_trapdoor\npale_oak_wood\npaper\npearlescent_froglight\npeony\npetrified_oak_double_slab\npetrified_oak_slab\nphantom_membrane\npiglin_banner_pattern\npiglin_head\npink_banner\npink_bundle\npink_candle\npink_candle_cake\npink_carpet\npink_concrete\npink_concrete_powder\npink_dye\npink_glazed_terracotta\npink_harness\npink_petals\npink_shulker_box\npink_stained_glass\npink_stained_glass_pane\npink_terracotta\npink_tulip\npink_wool\npiston\npitcher_plant\npitcher_pod\nplanks\nplayer_head\nplenty_pottery_sherd\npodzol\npointed_dripstone\npoisonous_potato\npolished_andesite\npolished_andesite_double_slab\npolished_andesite_slab\npolished_andesite_stairs\npolished_basalt\npolished_blackstone\npolished_blackstone_brick_double_slab\npolished_blackstone_brick_slab\npolished_blackstone_brick_stairs\npolished_blackstone_brick_wall\npolished_blackstone_bricks\npolished_blackstone_button\npolished_blackstone_double_slab\npolished_blackstone_pressure_plate\npolished_blackstone_slab\npolished_blackstone_stairs\npolished_blackstone_wall\npolished_deepslate\npolished_deepslate_double_slab\npolished_deepslate_slab\npolished_deepslate_stairs\npolished_deepslate_wall\npolished_diorite\npolished_diorite_double_slab\npolished_diorite_slab\npolished_diorite_stairs\npolished_granite\npolished_granite_double_slab\npolished_granite_slab\npolished_granite_stairs\npolished_tuff\npolished_tuff_double_slab\npolished_tuff_slab\npolished_tuff_stairs\npolished_tuff_wall\npoplar_shelf\npopped_chorus_fruit\npoppy\nporkchop\nporkchop_cooked\nportal\npotato\npotatoes\npotion\npowder_snow\npowder_snow_bucket\npowered_rail\nprismarine\nprismarine_brick_double_slab\nprismarine_brick_slab\nprismarine_bricks\nprismarine_bricks_stairs\nprismarine_crystals\nprismarine_double_slab\nprismarine_shard\nprismarine_slab\nprismarine_stairs\nprismarine_wall\nprize_pottery_sherd\npufferfish\npufferfish_bucket\npumpkin\npumpkin_pie\npumpkin_seeds\npumpkin_stem\npurple_banner\npurple_bundle\npurple_candle\npurple_candle_cake\npurple_carpet\npurple_concrete\npurple_concrete_powder\npurple_dye\npurple_glazed_terracotta\npurple_harness\npurple_shulker_box\npurple_stained_glass\npurple_stained_glass_pane\npurple_terracotta\npurple_wool\npurpur_block\npurpur_double_slab\npurpur_pillar\npurpur_slab\npurpur_stairs\nquartz\nquartz_block\nquartz_bricks\nquartz_double_slab\nquartz_ore\nquartz_pillar\nquartz_slab\nquartz_stairs\nrabbit\nrabbit_foot\nrabbit_hide\nrabbit_stew\nrail\nraiser_armor_trim_smithing_template\nraw_copper\nraw_copper_block\nraw_gold\nraw_gold_block\nraw_iron\nraw_iron_block\nrecord_11\nrecord_13\nrecord_5\nrecord_blocks\nrecord_cat\nrecord_chirp\nrecord_creator\nrecord_creator_music_box\nrecord_far\nrecord_mall\nrecord_mellohi\nrecord_otherside\nrecord_pigstep\nrecord_precipice\nrecord_relic\nrecord_stal\nrecord_strad\nrecord_tears\nrecord_wait\nrecord_ward\nrecovery_compass\nred_banner\nred_bundle\nred_candle\nred_candle_cake\nred_carpet\nred_concrete\nred_concrete_powder\nred_dye\nred_flower\nred_glazed_terracotta\nred_harness\nred_mushroom\nred_mushroom_block\nred_nether_brick\nred_nether_brick_double_slab\nred_nether_brick_slab\nred_nether_brick_stairs\nred_nether_brick_wall\nred_sand\nred_sandstone\nred_sandstone_double_slab\nred_sandstone_slab\nred_sandstone_stairs\nred_sandstone_wall\nred_shulker_box\nred_stained_glass\nred_stained_glass_pane\nred_terracotta\nred_tulip\nred_wool\nredsandstone\nredstone\nredstone_block\nredstone_lamp\nredstone_ore\nredstone_torch\nredstone_wire\nreeds\nreinforced_deepslate\nrepeater\nrepeating_command_block\nresin_block\nresin_brick\nresin_brick_double_slab\nresin_brick_slab\nresin_brick_stairs\nresin_brick_wall\nresin_bricks\nresin_clump\nrespawn_anchor\nrib_armor_trim_smithing_template\nrooted_dirt\nrose_bush\nrotten_flesh\nruby\nsaddle\nsalmon\nsalmon_bucket\nsand\nsandstone\nsandstone_double_slab\nsandstone_slab\nsandstone_stairs\nsandstone_wall\nscaffolding\nscrape_pottery_sherd\nsculk\nsculk_catalyst\nsculk_sensor\nsculk_shrieker\nsculk_vein\nseaLantern\nsea_lantern\nsea_pickle\nseagrass\nsentry_armor_trim_smithing_template\nshaper_armor_trim_smithing_template\nsheaf_pottery_sherd\nshears\nshelter_pottery_sherd\nshield\nshort_dry_grass\nshort_grass\nshroomlight\nshulkerBox\nshulkerBoxBlack\nshulkerBoxBlue\nshulkerBoxBrown\nshulkerBoxCyan\nshulkerBoxGray\nshulkerBoxGreen\nshulkerBoxLightBlue\nshulkerBoxLime\nshulkerBoxMagenta\nshulkerBoxOrange\nshulkerBoxPink\nshulkerBoxPurple\nshulkerBoxRed\nshulkerBoxSilver\nshulkerBoxWhite\nshulkerBoxYellow\nshulker_box\nshulker_shell\nsign\nsilence_armor_trim_smithing_template\nsilver_glazed_terracotta\nskeleton_skull\nskull_banner_pattern\nskull_pottery_sherd\nslime\nslime_ball\nslimeball\nsmall_amethyst_bud\nsmall_dripleaf_block\nsmithing_table\nsmithing_template\nsmoker\nsmooth_basalt\nsmooth_quartz\nsmooth_quartz_slab\nsmooth_quartz_stairs\nsmooth_red_sandstone\nsmooth_red_sandstone_double_slab\nsmooth_red_sandstone_slab\nsmooth_red_sandstone_stairs\nsmooth_sandstone\nsmooth_sandstone_double_slab\nsmooth_sandstone_slab\nsmooth_sandstone_stairs\nsmooth_stone\nsmooth_stone_double_slab\nsmooth_stone_slab\nsniffer_egg\nsnort_pottery_sherd\nsnout_armor_trim_smithing_template\nsnow\nsnow_layer\nsnowball\nsoul_campfire\nsoul_fire\nsoul_lantern\nsoul_sand\nsoul_soil\nsoul_torch\nspeckled_melon\nspectral_arrow\nspider_eye\nspire_armor_trim_smithing_template\nsplash_potion\nsponge\nspore_blossom\nspruceFence\nspruce_boat\nspruce_button\nspruce_chest_boat\nspruce_door\nspruce_double_slab\nspruce_fence\nspruce_fence_gate\nspruce_hanging_sign\nspruce_leaves\nspruce_log\nspruce_planks\nspruce_pressure_plate\nspruce_sapling\nspruce_shelf\nspruce_sign\nspruce_slab\nspruce_stairs\nspruce_standing_sign\nspruce_trapdoor\nspruce_wood\nspyglass\nstained_hardened_clay\nstanding_banner\nstanding_sign\nsteak\nstick\nstick_pile\nsticky_piston\nstone\nstone_axe\nstone_brick_double_slab\nstone_brick_slab\nstone_brick_stairs\nstone_brick_wall\nstone_bricks\nstone_button\nstone_hoe\nstone_pickaxe\nstone_pressure_plate\nstone_shovel\nstone_slab\nstone_spear\nstone_stairs\nstone_sword\nstonebrick\nstonecutter\nstonecutter_block\nstring\nstripped_acacia_log\nstripped_acacia_wood\nstripped_bamboo_block\nstripped_birch_log\nstripped_birch_wood\nstripped_cherry_log\nstripped_cherry_wood\nstripped_crimson_hyphae\nstripped_crimson_stem\nstripped_dark_oak_log\nstripped_dark_oak_wood\nstripped_jungle_log\nstripped_jungle_wood\nstripped_mangrove_log\nstripped_mangrove_wood\nstripped_oak_log\nstripped_oak_wood\nstripped_pale_oak_log\nstripped_pale_oak_wood\nstripped_spruce_log\nstripped_spruce_wood\nstripped_warped_hyphae\nstripped_warped_stem\nstructure_block\nstructure_void\nsugar\nsugar_cane\nsunflower\nsuspicious_gravel\nsuspicious_sand\nsuspicious_stew\nsweet_berries\nsweet_berry_bush\ntadpole_bucket\ntall_dry_grass\ntall_grass\ntallgrass\ntarget\ntide_armor_trim_smithing_template\ntinted_glass\ntipped_arrow\ntnt\ntnt_minecart\ntorch\ntorchflower\ntorchflower_seeds\ntotem\ntotem_of_undying\ntrapdoor\ntrapped_chest\ntrial_key\ntrial_spawner\ntrident\ntripWire\ntrip_wire\ntripwire_hook\ntropical_fish\ntropical_fish_bucket\ntube_coral\ntube_coral_block\ntube_coral_fan\ntuff\ntuff_brick_double_slab\ntuff_brick_slab\ntuff_brick_stairs\ntuff_brick_wall\ntuff_bricks\ntuff_double_slab\ntuff_slab\ntuff_stairs\ntuff_wall\nturtle_egg\nturtle_helmet\nturtle_shell_piece\ntwisting_vines\nundyed_shulker_box\nunlit_redstone_torch\nvault\nverdant_froglight\nvex_armor_trim_smithing_template\nvine\nwall_banner\nward_armor_trim_smithing_template\nwarped_button\nwarped_door\nwarped_double_slab\nwarped_fence\nwarped_fence_gate\nwarped_fungus\nwarped_fungus_on_a_stick\nwarped_hanging_sign\nwarped_hyphae\nwarped_nylium\nwarped_planks\nwarped_pressure_plate\nwarped_roots\nwarped_shelf\nwarped_sign\nwarped_slab\nwarped_stairs\nwarped_standing_sign\nwarped_stem\nwarped_trapdoor\nwarped_wall_sign\nwarped_wart_block\nwater\nwater_bucket\nwaterlily\nwaxed_chiseled_copper\nwaxed_copper\nwaxed_copper_bulb\nwaxed_copper_door\nwaxed_copper_golem_statue\nwaxed_copper_grate\nwaxed_copper_trapdoor\nwaxed_cut_copper\nwaxed_cut_copper_slab\nwaxed_cut_copper_stairs\nwaxed_double_cut_copper_slab\nwaxed_exposed_chiseled_copper\nwaxed_exposed_copper\nwaxed_exposed_copper_bulb\nwaxed_exposed_copper_door\nwaxed_exposed_copper_golem_statue\nwaxed_exposed_copper_grate\nwaxed_exposed_copper_trapdoor\nwaxed_exposed_cut_copper\nwaxed_exposed_cut_copper_slab\nwaxed_exposed_cut_copper_stairs\nwaxed_exposed_double_cut_copper_slab\nwaxed_oxidized_chiseled_copper\nwaxed_oxidized_copper\nwaxed_oxidized_copper_bulb\nwaxed_oxidized_copper_door\nwaxed_oxidized_copper_golem_statue\nwaxed_oxidized_copper_grate\nwaxed_oxidized_copper_trapdoor\nwaxed_oxidized_cut_copper\nwaxed_oxidized_cut_copper_slab\nwaxed_oxidized_cut_copper_stairs\nwaxed_oxidized_double_cut_copper_slab\nwaxed_weathered_chiseled_copper\nwaxed_weathered_copper\nwaxed_weathered_copper_bulb\nwaxed_weathered_copper_door\nwaxed_weathered_copper_golem_statue\nwaxed_weathered_copper_grate\nwaxed_weathered_copper_trapdoor\nwaxed_weathered_cut_copper\nwaxed_weathered_cut_copper_slab\nwaxed_weathered_cut_copper_stairs\nwaxed_weathered_double_cut_copper_slab\nwayfinder_armor_trim_smithing_template\nweathered_chiseled_copper\nweathered_copper\nweathered_copper_bulb\nweathered_copper_door\nweathered_copper_golem_statue\nweathered_copper_grate\nweathered_copper_trapdoor\nweathered_cut_copper\nweathered_cut_copper_slab\nweathered_cut_copper_stairs\nweathered_double_cut_copper_slab\nweb\nweeping_vines\nwet_sponge\nwheat\nwheat_seeds\nwhite_banner\nwhite_bundle\nwhite_candle\nwhite_candle_cake\nwhite_carpet\nwhite_concrete\nwhite_concrete_powder\nwhite_dye\nwhite_glazed_terracotta\nwhite_harness\nwhite_shulker_box\nwhite_stained_glass\nwhite_stained_glass_pane\nwhite_terracotta\nwhite_tulip\nwhite_wool\nwild_armor_trim_smithing_template\nwildflowers\nwind_charge\nwither_rose\nwither_skeleton_skull\nwolf_armor\nwooden_axe\nwooden_button\nwooden_door\nwooden_hoe\nwooden_pickaxe\nwooden_pressure_plate\nwooden_shovel\nwooden_slab\nwooden_sword\nwool\nwritable_book\nwritten_book\nyellow_banner\nyellow_bundle\nyellow_candle\nyellow_candle_cake\nyellow_carpet\nyellow_concrete\nyellow_concrete_powder\nyellow_dye\nyellow_flower\nyellow_glazed_terracotta\nyellow_harness\nyellow_shulker_box\nyellow_stained_glass\nyellow_stained_glass_pane\nyellow_terracotta\nyellow_wool\nzombie_head\n";

// ===== box_stack_sizes.js =====
/**
 * **物品堆叠上限**的解析：max 档要判"每格堆满"，而每样物品的上限不同。
 *
 * ## 为什么不是问引擎（实测否掉了两条路）
 *
 * 本机实测（LSE 0.13 + LeviLamina 1.4.4）：
 *   · Item 对象上**没有任何** max-stack 取值方法（`getMaxStackCount` / `getMaxStackSize` /
 *     `getMaxCount` / `maxStackCount` / `maxStackSize` 逐个试过，都不存在）；
 *   · `mc.newItem("minecraft:snowball", 64).count` **返回 64** —— 引擎不夹数量。
 * 所以上限只能来自**构建期烤的表**（生成物 `leplugin/item_stack_sizes.js`）。
 *
 * ## 三级来源（按可靠度）
 *
 *   ① **表**（生成物）：覆盖 1612 个已知物品，权威；表里没有的返回 0。
 *   ② **引擎取值方法**：万一日后某个 LSE 版本暴露了（名字见 `MAX_STACK_GETTERS`），就用它。
 *   ③ **夹数量探测**：`mc.newItem(type, 64).count` 若**被夹小**，那个数就是上限。
 *      ⚠️ 返回 64 时**不能**断定"上限就是 64"（也可能根本没夹），所以只认"被夹小"。
 *   都不成立 → **0 = 不知道**，由判定层按"满堆只可能是 1/16/64"兜底（见 box_content.js）。
 *
 * 结果**按物品缓存**：每个物品一辈子只探一次；探测本身只是造一个 ItemStack 对象、不碰世界。
 */



/** 默认堆叠上限：多数物品都是 64（探测时也用它当"请求的数量"）。 */
const DEFAULT_STACK_COUNT = 64;

/**
 * 引擎可能用哪个名字告诉我们"这个物品最多能堆多少"。
 *
 * 本机版本一个都不存在（所以现在靠表），留着是为了**将来的版本**不用再翻一遍文档。
 */
const MAX_STACK_GETTERS = [
  "getMaxStackCount",
  "getMaxStackSize",
  "getMaxCount",
  "maxStackCount",
  "maxStackSize"
];

/** 物品 id -> `{ size, known, source }`（缓存）。 */
let probeCache = new Map();

/** 清空缓存（仅供自测：注入假引擎后需要重新探）。 */
function resetStackSizeCache() {
  probeCache = new Map();
}

/**
 * 探一次某个物品的堆叠上限。
 *
 * @param {string} itemId 物品 id（带不带 `minecraft:` 都认）
 * @param {object} [deps] `{ newItem }`：造物品的能力（默认用全局 `mc.newItem`），便于自测注入
 * @returns {{size: number, known: boolean, source: string}} `size` 在 `known` 为假时是 0
 */
function stackSizeProbe(itemId, deps) {
  const bare = String(itemId === undefined || itemId === null ? "" : itemId)
    .replace(/^[a-z_]+:/, "").trim();
  if (!bare) return { size: 0, known: false, source: "空 id" };
  if (probeCache.has(bare)) return probeCache.get(bare);

  // ① 构建期烤的表（本机唯一真的有效的来源）
  const fromTable = maxStackSizeOf(bare);
  if (fromTable > 0) {
    const hit = { size: fromTable, known: true, source: "堆叠表 " + fromTable };
    probeCache.set(bare, hit);
    return hit;
  }

  // ② / ③ 问引擎（表里没有：新版本物品或模组物品）
  const result = { size: 0, known: false, source: "表里没有，引擎也没说" };
  const newItem = (deps && deps.newItem) || (typeof mc !== "undefined" && mc.newItem ? mc.newItem : null);
  let item = null;
  if (newItem) {
    try {
      item = newItem.call(typeof mc !== "undefined" ? mc : null, "minecraft:" + bare, DEFAULT_STACK_COUNT);
    } catch (_err) {
      item = null;
    }
  }
  if (item) {
    for (let i = 0; i < MAX_STACK_GETTERS.length; i++) {
      const name = MAX_STACK_GETTERS[i];
      try {
        if (typeof item[name] !== "function") continue;
        const value = Number(item[name]());
        if (isFinite(value) && value > 0) {
          result.size = Math.round(value);
          result.known = true;
          result.source = name + "()";
          break;
        }
      } catch (_err) {
        // 换下一个候选名字
      }
    }
    if (!result.known) {
      const got = Number(item.count);
      if (isFinite(got) && got > 0 && got < DEFAULT_STACK_COUNT) {
        result.size = Math.round(got);
        result.known = true;
        result.source = "newItem 夹到 " + Math.round(got);
      }
    }
  }

  probeCache.set(bare, result);
  return result;
}

/**
 * 判定层要的接口：`itemId -> 堆叠上限`，**0 = 不知道**。
 *
 * @param {string} itemId
 * @param {object} [deps] 同 `stackSizeProbe`
 */
function stackSizeFor(itemId, deps) {
  const probe = stackSizeProbe(itemId, deps);
  return probe.known ? probe.size : 0;
}

// ===== box_cache.js =====
/**
 * **盒内内容扫描的缓存**：同一份容器内容只扫一次。
 *
 * ## 缓存键为什么是"位置 + 内容指纹"
 *
 * 内容指纹是 `槽位:物品id x数量`（见 `llse_adapter.js` 的 readContainerObject），
 * **不含盒内 NBT** —— 所以两个外观看上去一模一样的箱子（同一槽位放同一个潜影盒、
 * 数量都是 1）指纹相同，而盒内物品可能完全不同。只用指纹会把 A 盒的角标贴给 B 盒，
 * 错到用户看见为止、而且不报错。位置一进键就不可能串。
 *
 * ## 失效入口只有下面这几个（这就是上一版的 bug 所在）
 *
 * 上一版把 `badgeCache = {...}` 直接写在 main.js 的两个地方，谁也说不清还有哪里该清。
 * 现在统一走 `invalidate(reason)`，并在 trace 日志里记下**原因与次数**：
 *   · `onInventoryChange` —— 任何库存变动（换盒子必然产生，这是"换盒子不串"的保证）；
 *   · 换档位 `/peek:badgelevel` —— 判定结果整体变了；
 *   · 预置/自测。
 *
 * ⚠️ **刻意的行为**：容器外层内容没变时（例如把 A 盒换成外观一样的 B 盒但没触发库存事件、
 * 或者只是又看了一眼），缓存照旧命中 —— 这是用户拍板的"口径甲"（跟着容器内容变）。
 * 自测里有一条用例专门钉住这个行为，别当 bug 改掉。
 */

/** 键构造：**唯一出处**（发送去重那边也用同一个键，别再各写一份字符串拼接）。 */
function contentKey(targetKind, targetId, contents) {
  const kind = String(targetKind || "");
  const id = String(targetId || "");
  const fingerprint = contents && contents.fingerprint ? String(contents.fingerprint) : "empty";
  return kind + "|" + id + "|" + fingerprint;
}

/** 目标位置标识：方块按坐标、实体按 uniqueId；取不到就是 `"?"`（退化成"同指纹共用一次结果"）。 */
function targetLocationKey(block, entity) {
  try {
    if (block) {
      const p = block.pos || block.position;
      if (p && typeof p.x === "number") return "b:" + p.x + "," + p.y + "," + p.z;
    }
    if (entity) {
      const id = entity.uniqueId;
      if (id !== undefined && id !== null) return "e:" + id;
      const p = entity.pos || entity.position;
      if (p && typeof p.x === "number") {
        return "e:" + Math.round(p.x) + "," + Math.round(p.y) + "," + Math.round(p.z);
      }
    }
  } catch (_err) {
    return "?";
  }
  return "?";
}

/** 单条缓存：`{ key, value }`。 */
let cached = { key: "", value: null };

/** 统计（给 `/peek:trace` 用）：命中/未命中/失效次数与最后一次失效原因。 */
let stats = { hits: 0, misses: 0, invalidations: 0, lastReason: "" };

/**
 * 取缓存值；未命中时调 `compute()` 重算并记下。
 *
 * @param {string} key `targetLocationKey(...) + "|" + contentKey(...)`
 * @param {Function} compute 重算函数（只在未命中时调用）
 */
function cachedFor(key, compute) {
  if (cached.key === key && cached.value !== null) {
    stats.hits++;
    return cached.value;
  }
  stats.misses++;
  const value = compute();
  cached = { key: key, value: value };
  return value;
}

/** 作废缓存（唯一的失效入口；`reason` 会出现在 trace 日志里）。 */
function invalidate(reason) {
  cached = { key: "", value: null };
  stats.invalidations++;
  stats.lastReason = String(reason || "");
}

/** 读统计（副本）。 */
function cacheStats() {
  return {
    hits: stats.hits,
    misses: stats.misses,
    invalidations: stats.invalidations,
    lastReason: stats.lastReason,
    hasValue: cached.value !== null
  };
}

/** 清空统计（仅供自测）。 */
function resetCacheStats() {
  stats = { hits: 0, misses: 0, invalidations: 0, lastReason: "" };
}

// ===== box_selfcheck.js =====
/**
 * `/peek:check` 里**潜影盒角标 / 盒内内容**那一组用例。
 *
 * ## 为什么要单独成模块
 *
 * 这一组用例本来是内联在 `main.js` 的 `runSelfCheck()` 里的，一百来行、还夹着一堆
 * 临时变量 —— 想加一条用例就得往那个大函数里塞，谁也说不清现在一共验了哪些情形。
 * 搬出来之后：**用例是表，跑法只有一种**，`main.js` 只负责把结果拼进输出。
 *
 * ## 为什么两边都跑
 *
 * Node 自测（`tests/run.mjs`）能在**成品像素**上验字形宽度；游戏内没有读图能力，
 * 只能用常量核算。两者互补：
 *   · Node 端钉住"字形长什么样"（墨迹宽度、顺序、补位）；
 *   · 游戏内钉住"这条链在真引擎里通不通"（NBT 读得到、档位判得对、堆叠表查得对）。
 *
 * ⚠️ 所以这里**不注入假表**（除了明确标着"假数据"的坏数据用例）：max 档的堆叠上限
 * 直接查真的生成表 —— 那正是要在游戏里核对的东西（雪球是不是 16、剑是不是 1）。
 */







/** 造一个"盒子里装着 N 格同一种物品"的假 NBT 条目数组。 */
function innerOf(itemId, count, n) {
  const out = [];
  const slots = n === undefined ? SHULKER_SLOT_COUNT : n;
  for (let i = 0; i < slots; i++) out.push({ slot: i, id: itemId, count: count });
  return out;
}

/** 造一个"容器里第 3 槽放着一个潜影盒，盒内是 inner"的假内容。 */
function containerWith(inner) {
  return {
    containerSize: 27,
    items: [{ slot: 3, typeId: "undyed_shulker_box", amount: 1, stack: {} }],
    fingerprint: "selftest",
    __inner: inner
  };
}

/** 在假内容上跑一次扫描（读函数从 `__inner` 取，等价于真引擎读 NBT）。 */
function scanFake(contents, mode) {
  return scanBoxes(contents, {
    readInner: function (stack) { void stack; return contents.__inner; },
    isShulkerType: isShulkerBox,
    glyphFor: boxBadgeGlyph,
    stackSizeFor: stackSizeFor,
    mode: mode
  });
}

/** 取某个盒子的角标字形（空串 = 不打）。 */
function badgeOf(inner, mode) {
  const scanned = scanFake(containerWith(inner), mode);
  const record = scanned.bySlot.get(3);
  return record ? record.badgeGlyph : "";
}

/**
 * 跑一遍用例。
 *
 * @returns {Array<{ok: boolean, label: string, evidence: string}>}
 */
function boxSelfCheckCases() {
  const cases = [];
  const add = (ok, label, evidence) => cases.push({ ok: !!ok, label: label, evidence: evidence || "" });

  // ===== ① 四档判据 =====
  const full = innerOf("minecraft:diamond", 64);
  add(badgeOf(full, "max") !== "", "max：27 格全满 + 同一种 + 每格堆满 → 打角标",
    "角标 " + glyphName(badgeOf(full, "max")));
  add(badgeOf(innerOf("minecraft:diamond", 64, 26), "max") === "",
    "max：只有 26 格 → 不打（必须全占满）");
  const oneShort = full.map(function (e, i) {
    return i === 12 ? { slot: 12, id: "minecraft:diamond", count: 63 } : e;
  });
  add(badgeOf(oneShort, "max") === "", "max：有一格 63（未满堆）→ 不打");
  add(badgeOf(oneShort, "high") !== "", "high：同一盒未满堆也打（只看是不是同一种）");

  const mixed = full.map(function (e, i) {
    return i === 20 ? { slot: 20, id: "minecraft:stone", count: 64 } : e;
  });
  add(badgeOf(mixed, "max") === "" && badgeOf(mixed, "high") === "",
    "混装两种：max / high 都不打");
  add(badgeOf(mixed, "low") === boxBadgeGlyph("diamond"),
    "low：混装也打，画**槽位最小**那件（不是数组里的第一条）",
    "数组顺序故意反过来也应当取钻石");

  // off 档（第四档）：一律不打 —— 那一格留白（开着总数时画总数）
  add(badgeItemIdFor(readBoxFacts(full, stackSizeFor), "off") === "" &&
    badgeOf(full, "off") === "" && badgeOf(mixed, "off") === "" &&
    badgeOf(innerOf("minecraft:snowball", 16), "off") === "",
    "off 档：满盒 / 混装 / 半盒一律不打（第四档 = 这一格不想看角标）");
  add(normalizeBadgeMode("off").mode === "off" && normalizeBadgeMode("off").fallback === false &&
    normalizeBadgeMode(" OFF ").mode === "off",
    "off 是**认识的**档位（不会被当成拼错而退回 max）");
  add(normalizeBadgeMode("nope").mode === "max" && normalizeBadgeMode("nope").fallback === true,
    "不认识的档位仍然退回 max（只多一档，没把兜底放松）");

  // ===== ② 非 64 堆叠（用户特意交代过的）=====
  add(badgeOf(innerOf("minecraft:snowball", 16), "max") !== "",
    "16 堆叠的雪球：每格 16 → max 也打（上限查的是该物品）",
    "上限 " + stackSizeText("snowball"));
  add(badgeOf(innerOf("minecraft:snowball", 15), "max") === "",
    "16 堆叠的雪球：每格 15 → 不打（差一个也不满）");
  add(badgeOf(innerOf("minecraft:diamond_sword", 1), "max") !== "",
    "不可堆叠的剑：每格 1 → 打", "上限 " + stackSizeText("diamond_sword"));
  add(badgeOf(innerOf("minecraft:stone", 64), "max") !== "",
    "64 堆叠的石头：每格 64 → 打", "上限 " + stackSizeText("stone"));

  // ===== ③ 表外物品（新版本 / 模组）：上限拿不到时按 1/16/64 兜底 =====
  //
  // ⚠️ 这一条**绕开字形**：表外物品没有图标，`badgeOf()` 拿到的一定是空串 ——
  // 那验的是"没有图就不打"，不是判定对不对；判定要看**选中的物品 id**。
  //
  // 也不能写死"上限报 0"：本机 LSE 确实没有 max-stack 取值方法（探不到，报未知），
  // 但 Node 热路径的假引擎里 `newItem` 暴露了 `getMaxStackCount()`（探得到 64）。
  // 两个环境都该成立的只有**判定行为**：每格 64 算满堆、每格 63 不算。
  const unknownId = "minecraft:peek_selftest_unknown";
  const unknownAt = function (count) {
    return badgeItemIdFor(readBoxFacts(innerOf(unknownId, count), stackSizeFor), "max");
  };
  add(unknownAt(64) === "peek_selftest_unknown" && unknownAt(63) === "",
    "表外物品：每格 64 算满堆、每格 63 不算（探不到上限时按 1/16/64 兜底）",
    "上限 " + stackSizeText("peek_selftest_unknown"));
  add(badgeOf(innerOf(unknownId, 64), "max") === "",
    "表外物品没有图标 → 判满也不打角标（不画半张图）");

  // ===== ④ 坏数据一律不打（NBT 是外来数据）=====
  const badNull = full.slice(0, 27);
  badNull[7] = null;
  add(badgeOf(badNull, "max") === "", "有条目是空的 → 不打（不猜、不报错）");
  const badSlot = full.slice(0, 27);
  badSlot[3] = { slot: 99, id: "minecraft:diamond", count: 64 };
  add(badgeOf(badSlot, "max") === "", "槽位越界 → 不打");
  add(badgeOf(null, "max") === "" && badgeOf([], "max") === "",
    "读不到 NBT / 空盒 → 不打（空盒也不该报错）");

  // ===== ⑤ 事实层：总数与"第一件" =====
  const facts = readBoxFacts([
    { slot: 0, id: "minecraft:diamond", count: 64 },
    { slot: 1, id: "minecraft:stone", count: 55 }
  ], stackSizeFor);
  add(facts.total === 119, "总数 = 所有堆叠相加（64 + 55 = 119）", "total " + facts.total);
  add(facts.uniformItemId === "" && facts.firstItemId === "diamond",
    "事实层分得清「同一种」与「第一件」", "uniform=" + (facts.uniformItemId || "无") +
      " first=" + facts.firstItemId);
  add(readBoxFacts(innerOf("minecraft:diamond", 64), stackSizeFor).isCompletelyFull === true &&
    readBoxFacts(innerOf("minecraft:diamond", 64, 26), stackSizeFor).isCompletelyFull === false,
    "事实层：27 格算全占满、26 格不算");

  // ===== ⑥ 显示策略：一格只有"角标 / 空白"两种结果 =====
  const scanned = scanFake(containerWith(full), "max");
  const record = scanned.bySlot.get(3);
  const asBadge = overlayFor(record);
  add(asBadge && asBadge.kind === "badge",
    "盒子那一格：判据打得出角标就画角标",
    "角标 " + (asBadge ? asBadge.kind : "无"));
  add(overlayFor(scanFake(containerWith([]), "max").bySlot.get(3)).kind === BOX_OVERLAY_BLANK.kind,
    "空盒子那一格 → 空白（潜影盒永远不画堆叠数 1）");
  add(overlayFor(null) === null, "非潜影盒 → 不叠放（照常画它自己的数目）");

  // ===== ⑦ 前进宽度不变式：一格的内容必须正好 64 像素 =====
  //
  // 这条是"角标位置不对 / 行会漂"那类 bug 的根治：一格的内容只要不是正好 64 像素，
  // 这一行后面所有格子一起偏。游戏内只能按常量核算（像素那面由 Node 自测盯）。
  {
    const offenders = [];
    const check = (name, descriptor) => {
      const cell = cellFor(descriptor);
      const advance = cellAdvance(descriptor);
      if (cell === "" || advance !== BOX_CELL_PX) offenders.push(name + "=" + advance);
    };
    check("角标", { kind: "badge", glyph: boxBadgeGlyph("diamond") });
    check("空白", BOX_OVERLAY_BLANK);
    add(offenders.length === 0,
      "每种叠放描述的整格前进都正好 " + BOX_CELL_PX + " 像素（少补就串列、多补就留缝）",
      offenders.length ? "不合格：" + offenders.join(" ") : "角标 / 空白 都等于一格");
  }
  add(cellFor(null) === "" && cellFor(undefined) === "" && cellFor({ kind: "没这个种类" }) === "" &&
    cellFor({ kind: "badge", glyph: "" }) === "",
    "没内容 / 不认识的描述 / 空字形 → 空串（调用方照常画数目，不推空串进格子）");

  // ===== ⑧ 堆叠上限来源（信息项，不算失败，但能一眼看出表有没有生效）=====
  cases.push({
    ok: true,
    label: "满堆上限来源（信息）",
    evidence: ["diamond", "snowball", "diamond_sword", "ender_pearl", "bucket"]
      .map(function (id) { return id + "=" + stackSizeText(id); }).join("　")
  });

  return cases;
}

/** 把"上限来源"写成一行短文本，例如 `16（堆叠表 16）`。 */
function stackSizeText(itemId) {
  const probe = stackSizeProbe(itemId);
  return (probe.known ? probe.size : "未知") + "（" + probe.source + "）";
}

/** 码点写成 `U+XXXX`（日志里能看出是哪个字形）。 */
function glyphName(glyph) {
  if (!glyph) return "无";
  return "U+" + glyph.codePointAt(0).toString(16).toUpperCase();
}

// ===== settings.js =====
/**
 * 插件版的**可调旋钮表**：唯一定义处。
 *
 * ## 为什么单开一个模块
 *
 * 三处读者，都不许自己再抄一份：
 *   · `main.js` —— 注册命令、执行时校验取值；
 *   · `docs/指令一览.md` 的生成器（`tools/docs/build-commands-doc.mjs`）—— 文档从这张表生成，
 *     手写的文档一定会漂（行为包那份就漂过：`/peek:title` 早改名成 `/peek:header` 了）；
 *   · 自测 —— 断言"每个 runtime 键都有旋钮"、"取值区间合理"。
 *
 * ## 取值怎么影响画面
 *
 * 每个旋钮写进 `runtime_config.js` 的 `runtime` 对象（`runtime` 键名写在 `runtime` 字段里），
 * 而 `format.js` / `grid_shapes.js` 读的就是那个对象 —— 于是**不需要**为调参再写一遍排版代码。
 * 唯一需要插件自己动手的是"节奏"三项与两个总开关，见 `main.js` 里的使用点。
 *
 * ## 持久化
 *
 * 见 `settings_store.js`：优先 LSE 的 `JsonConfigFile`，退一步用 `File`，都拿不到就只在
 * 本次会话内有效（`/peek:check` 会如实报告当前用的是哪一种，不假装已保存）。
 */

/**
 * 旋钮表。字段含义：
 *   name     指令名（`/peek:<name>`）与持久化里的键名
 *   scope    **作用域**：`player` = 每人独立（观感类），`global` = 全服共用（性能类）
 *   label    中文名（命令回执、`/peek:status`、生成的文档都用它）
 *   boxbadge 这类开关"省略参数即切换"；enum 旋钮（badgelevel）省略参数 = 跳到下一档
 *   kind     `toggle`（on/off，省略参数即切换）、`int`（带 min/max）
 *            或 `enum`（带 values 枚举；value = 默认值）
 *   value    默认值（**必须与 runtime_config.js 里的默认值一致**，自测盯着）
 *   runtime  写进 runtime 对象的键名；空串 = 这个旋钮由插件自己消费，不进 runtime
 *   desc     一句话说明（生成文档、命令回执用）
 *
 * ## 作用域为什么这样划分
 *
 * · **观感类走 `player`**：它们是"这个人自己看到的画面"，不该由别人替他决定；
 * · **性能类走 `global`**：轮询 / 重读 / 重发 / 探测距离直接决定服务器 CPU 与网络开销，
 *   若每人一份，一个人把轮询调到 1 tick 就等于替全服加倍负载 —— 这类必须全局。
 *
 * 命令需要 OP 权限。对 `player` 类：**玩家身份执行的命令只改他自己那份**；
 * 控制台执行则改"**全局默认**"（没有个人设置的玩家用它）。
 */
const SETTINGS = [
  {
    name: "display",
    brief: "容器内容预览的总开关：关掉后准星对着容器也不显示",
    scope: "player",
    label: "容器预览显示",
    kind: "toggle",
    value: true,
    runtime: "PREVIEW_ENABLED",
    desc: "关掉后不再发预览（并立刻清屏一次），同时停掉每玩家的检测与排版"
  },
  {
    name: "box",
    brief: "容器界面里点潜影盒看内容（显示在屏幕左边缘）",
    scope: "player",
    label: "潜影盒预览",
    kind: "toggle",
    value: true,
    runtime: "BOX_PEEK_ENABLED",
    desc: "容器界面里点潜影盒时的左边缘预览；关掉后点击不再触发"
  },
  {
    name: "boxbadge",
    brief: "在潜影盒图标右下角画一张盒内物品的小图",
    scope: "player",
    label: "潜影盒角标",
    kind: "toggle",
    value: true,
    runtime: "BOX_BADGE_ENABLED",
    desc: "给潜影盒打角标的总开关；关掉后既不画角标也不画总数，连读盒内物品都不做"
  },
  {
    name: "badgelevel",
    brief: "角标判定档位：off 不打 / low 有东西就打 / high 同一种 / max 装满且满堆",
    scope: "player",
    label: "潜影盒角标·档位",
    kind: "enum",
    values: ["off", "low", "high", "max"],
    value: "max",
    runtime: "BADGE_LEVEL",
    desc: "角标的判定档位：off = 不打角标（那一格留白）；low = 画盒里第一个物品；high = 盒里只要只有一种物品就打；max = 27 格全满 + 同一种 + 每格堆满（按该物品自己的堆叠上限：多数 64、雪球/告示牌 16、工具/桶 1）"
  },
  {
    name: "scale",
    brief: "准星预览的大小：full 原始 / three4 75% / half 50%",
    scope: "player",
    label: "预览尺寸",
    kind: "enum",
    values: ["full", "three4", "half"],
    value: "full",
    runtime: "PREVIEW_SCALE",
    desc: "准星预览的字号档位（潜影盒预览不受影响）：full = 原始大小；three4 = 75%（面积约 56%）；half = 50%（面积 1/4）"
  },
  {
    name: "backdrop",
    brief: "预览后面那块淡灰底衬；关掉只留图标，位置更自由",
    scope: "player",
    label: "预览底衬",
    kind: "toggle",
    // ⚠️ **默认关**（用户拍板）：灰区的位置与尺寸是资源包里写死的（只有文本能按运行期值挪），
    // 一旦用 /peek:hspace 横着挪、或用 /peek:gap 改行距，灰区就会与网格错开 ——
    // 与其看一块错位的灰，不如不要。
    value: false,
    runtime: "SHOW_BACKDROP",
    desc: "图标后面那块淡灰底衬。默认关：灰区的位置/尺寸写死在资源包里（只有文本能按运行期值挪），所以用 /peek:hspace 横着挪、或改行距之后灰区会与网格错开"
  },
  {
    name: "top",
    brief: "准星预览上下位置：正数往下、负数往上",
    scope: "player",
    label: "纵向位置",
    kind: "int",
    value: 20,
    // 负数 = 向上（靠"两层文本末尾补换行"实现，见 main.js 的 upShiftLines）
    min: -400,
    max: 400,
    unit: "空行",
    runtime: "TOP_PADDING_LINES",
    desc: "整块预览的纵向位置：正数往下（走填充层）、负数往上（在两层文本末尾补换行）。1 个单位 = 1 个空行 ≈ 平移 1.14 显示单位；范围 ±400 覆盖整屏高度"
  },
  {
    name: "hspace",
    brief: "准星预览左右位置：正数右移、负数左移",
    scope: "player",
    label: "横向位置",
    kind: "int",
    value: 0,
    min: -640,
    max: 640,
    unit: "1/8 格",
    runtime: "HSPACE_UNITS",
    desc: "正数右移、负数左移；标题行（容器图标）与两层一起挪，不会错开。1 个单位 = 平移 1 显示单位（1/8 格的一半），范围 ±640 ≈ 左右各 40 格"
  },
  {
    name: "boxpos",
    brief: "潜影盒预览的上下位置：正数向下、负数向上",
    scope: "player",
    label: "潜影盒预览·纵向位置",
    kind: "int",
    value: 0,
    min: -400,
    max: 400,
    unit: "行",
    runtime: "BOX_POS_LINES",
    desc: "潜影盒预览（容器界面左边缘那套）的纵向位置：正数向下、负数向上。与准星预览的 /peek:top 各自独立"
  },
  {
    name: "boxhspace",
    brief: "潜影盒预览的左右位置：正数右移、负数左移",
    scope: "player",
    label: "潜影盒预览·横向位置",
    kind: "int",
    value: 0,
    min: -640,
    max: 640,
    unit: "1/8 格",
    runtime: "BOX_HSPACE_UNITS",
    desc: "潜影盒预览的横向位置：正数右移、负数左移。与准星预览的 /peek:hspace 各自独立"
  },
  {
    name: "poll",
    brief: "多久看一次准星（tick）：越小越跟手、也越费性能",
    scope: "global",
    label: "轮询间隔",
    kind: "int",
    value: 2,
    min: 1,
    max: 40,
    unit: "tick",
    runtime: "POLL_INTERVAL_TICKS",
    desc: "多久看一次世界：准星跟随的灵敏度，也直接决定耗电；改完自动重启主循环"
  },
  {
    name: "refresh",
    brief: "多久重读一次容器内容（tick）：别人放东西多久后反映出来",
    scope: "global",
    label: "重读间隔",
    kind: "int",
    value: 8,
    min: 2,
    max: 200,
    unit: "tick",
    runtime: "HUD_REFRESH_TICKS",
    desc: "多久重读一次容器内容（别人往箱子里放东西要多久才反映出来）"
  },
  {
    name: "resend",
    brief: "多久重发一次预览文本（tick）：太小费带宽、太大会看到预览闪没",
    scope: "global",
    label: "重发间隔",
    kind: "int",
    value: 2,
    min: 1,
    max: 40,
    unit: "tick",
    runtime: "HUD_RESEND_TICKS",
    desc: "多久重发一次已经算好的文本：原版 actionbar 自己会淡出，靠它压住；调太大容易看到预览闪没"
  },
  {
    name: "reach",
    brief: "准星多远之内算对着容器（格）",
    scope: "global",
    label: "探测距离",
    kind: "int",
    value: 8,
    min: 1,
    max: 32,
    unit: "格",
    runtime: "REACH_DISTANCE",
    desc: "准星多远之内算对着容器；调太大就变成隔墙偷看"
  },
  {
    name: "log",
    brief: "服务端控制台日志：关掉后开机只留一行，出错才说话",
    scope: "global",
    label: "控制台日志",
    kind: "toggle",
    value: true,
    runtime: "INFO_LOG_ENABLED",
    desc: "关掉后不再输出常规信息（开机那一串注册结果、扫描耗时、盒预览收掉的缘由）。" +
      "**关不掉的只有三类**：命令回执（控制台敲 /peek:status 必须看得到结果）、开机那一行" +
      "“已启动”、以及警告/错误 —— 它们正是排障要看的东西。热路径细节日志另由 /peek:trace 控制" +
      "（默认关，且它显式打开时不受本开关影响）"
  }
];

/** 按名字取旋钮定义；名字不存在时返回 undefined（调用方负责报错）。 */
function settingByName(name) {
  const key = String(name === undefined || name === null ? "" : name).trim().toLowerCase();
  for (let i = 0; i < SETTINGS.length; i++) {
    if (SETTINGS[i].name === key) return SETTINGS[i];
  }
  return undefined;
}

/** 每人独立的旋钮（观感类）。 */
function playerScopedSettings() {
  return SETTINGS.filter((s) => s.scope === "player");
}

/** 全服共用的旋钮（性能类）。 */
function globalScopedSettings() {
  return SETTINGS.filter((s) => s.scope === "global");
}

/**
 * 把一个值存成整数时用的规范化（toggle 存 1/0，整数按整数）。
 *
 * 持久化层把布尔写成 1/0（LSE 的配置 API 就是这样），配置里因此只出现数字，
 * 读回来再按 `validateSetting` 归一回布尔 —— 一处归一，别处不再各转一遍。
 */
function storedSettingValue(setting, value) {
  if (setting.kind === "toggle") return value ? 1 : 0;
  return value;
}

/**
 * 校验一个取值。
 *
 * 返回 `{ ok: true, value }` 或 `{ ok: false, reason }` —— **不抛异常**：
 * 命令回调里抛出去只会让玩家看到"命令执行失败"，看不出哪里错了。
 */
function validateSetting(setting, raw) {
  if (!setting) return { ok: false, reason: "没有这个旋钮" };

  if (setting.kind === "toggle") {
    if (raw === undefined || raw === null || raw === "") return { ok: true, value: null }; // null = 切换
    const text = String(raw).trim().toLowerCase();
    if (text === "on" || text === "true" || text === "1" || text === "开") return { ok: true, value: true };
    if (text === "off" || text === "false" || text === "0" || text === "关") return { ok: true, value: false };
    return { ok: false, reason: "取值只能是 on / off（省略参数 = 切换）" };
  }

  if (setting.kind === "enum") {
    if (raw === undefined || raw === null || raw === "") return { ok: true, value: null }; // null = 下一档
    const text = String(raw).trim().toLowerCase();
    const values = setting.values || [];
    if (values.indexOf(text) < 0) {
      return { ok: false, reason: "取值只能是 " + values.join(" / ") + "（省略参数 = 下一档）" };
    }
    return { ok: true, value: text };
  }

  const n = Number(String(raw === undefined ? "" : raw).trim());
  if (!isFinite(n) || Math.floor(n) !== n) {
    return { ok: false, reason: "取值必须是整数" };
  }
  if (n < setting.min || n > setting.max) {
    return { ok: false, reason: "取值范围 " + setting.min + " – " + setting.max };
  }
  return { ok: true, value: n };
}

/** 把值渲染成给人看的文本（回执、状态、文档共用一套写法）。 */
function describeSettingValue(setting, value) {
  if (setting.kind === "toggle") return value ? "开" : "关";
  return String(value) + (setting.unit ? " " + setting.unit : "");
}

// ===== settings_store.js =====
/**
 * 旋钮的**持久化**：把 `/peek:*` 设过的值存到磁盘，重启后还在。
 *
 * ## 为什么要做三级降级
 *
 * 这个插件跑在 QuickJS 上，能拿到哪些全局对象**取决于 LSE 的版本**：
 *   · `JsonConfigFile` —— LSE 的配置 API（`get` / `set`，直接吃 JSON），最省事；
 *   · `File` —— LSE 的文件 API（`readAll` / `write`），需要自己 `JSON.parse`；
 *     注意 `BaseLib.js` 里同时导出了 `file` 与 `File` 两个名字，这里两个都试；
 *   · 都拿不到 —— **只在本次会话内有效**。
 *
 * ⚠️ 降级必须是**静默且可报告**的：任何一个 API 在某个版本上不存在时，
 * `typeof` 检查让它不至于把整个插件带崩（插件加载失败 = 预览全没了），
 * 而 `/peek:check` 会把"当前用的是哪一种"如实报出来。
 *
 * ## 写完必须**读回来核对**（这条是踩过坑补的）
 *
 * LSE 的 `JsonConfigFile` 上同时存在 `write()` 与 `set()`，两者都不像名字暗示的那样：
 *   · `write()` 无参调用报 `Too Few arguments!`（LSE 记一行 ERROR、**不抛异常**），
 *     所以"落盘"不能靠它；
 *   · `set(name, value)` 实测**当场就落盘**。
 * 第一版写成 `cfg.write(values)`：不报错（异常在 LSE 里被吞）、回执说"已保存"，
 * 而文件里只有一个 `{}` —— 玩家以为设置留住了，重启后全部回到默认值，**而且没有任何提示**。
 * 现在先 `set()` 再读回来比对，对不上才试 `write(values)` 兜底，仍然对不上就返回 false，
 * 回执如实说"只在本次会话有效"。
 *
 * 文件位置：`plugins/CrosshairContainerPeek/settings.json`（与插件同目录）。
 */

/** 配置文件路径。相对路径由 LSE 解析到插件根目录（`plugins/`）下。 */
const CONFIG_PATH = "plugins/CrosshairContainerPeek/settings.json";

/**
 * 当前可用的持久化方式（首次使用时探测一次）。
 *
 *   "JsonConfigFile" | "File" | "file" | "none"
 */
let backend = "";

/**
 * 探测并缓存可用的持久化后端。
 *
 * `typeof X === "function"` 而不是 `typeof X !== "undefined"`：有些版本会导出**同名但
 * 不是构造函数**的东西（例如某个常量），`new` 它会抛，照样把插件带崩。
 */
function detectBackend() {
  if (backend) return backend;
  const candidates = ["JsonConfigFile", "File", "file"];
  for (let i = 0; i < candidates.length; i++) {
    const name = candidates[i];
    try {
      // 用 globalThis 显式取，避免打包器/压缩器把未声明的标识符当成错误
      const ctor = globalThis[name];
      if (typeof ctor === "function") {
        backend = name;
        return backend;
      }
    } catch (_err) {
      // 取不到就当没有这个后端
    }
  }
  backend = "none";
  return backend;
}

/** 给人看的后端名字（`/peek:check`、回执用）。 */
function backendLabel() {
  const kind = detectBackend();
  if (kind === "none") return "无（设置只在本次会话有效，重启回默认值）";
  return kind + "（" + CONFIG_PATH + "）";
}

/**
 * 读回已保存的旋钮值。
 *
 * @param {string[]} names 关心的键名（不会把文件里别的键带进来）
 * @returns {object} 只含**读到的**键；任何一步失败都返回空对象（= 全用默认值），
 *          绝不抛异常、也不需要调用方兜底。
 */
function loadSaved(names) {
  const kind = detectBackend();
  if (kind === "none") return {};
  const keys = Array.isArray(names) ? names : [];
  try {
    if (kind === "JsonConfigFile") {
      // eslint-disable-next-line no-undef
      const cfg = new globalThis.JsonConfigFile(CONFIG_PATH);
      const out = {};
      // 首选逐键 get（这是 LSE 配置 API 的标准用法）。
      // 默认值参数不是所有实现都认：先带默认值试一次，拿不到再去掉参数试一次。
      if (typeof cfg.get === "function") {
        for (let i = 0; i < keys.length; i++) {
          let value = null;
          try {
            value = cfg.get(keys[i], null);
          } catch (_err) {
            value = null;
          }
          if (value === null || value === undefined) {
            try {
              value = cfg.get(keys[i]);
            } catch (_err2) {
              value = null;
            }
          }
          if (value === null || value === undefined) continue;
          out[keys[i]] = value;
        }
      }
      return out;
    }
    // File / file：整个文件就是一个 JSON 对象
    const Ctor = globalThis[kind];
    const handle = new Ctor(CONFIG_PATH, Ctor.ReadMode);
    let text = "";
    try {
      text = typeof handle.readAll === "function" ? handle.readAll() : "";
    } finally {
      if (typeof handle.close === "function") handle.close();
    }
    if (!text) return {};
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== "object") return {};
    const out = {};
    for (let i = 0; i < keys.length; i++) {
      if (Object.prototype.hasOwnProperty.call(parsed, keys[i])) out[keys[i]] = parsed[keys[i]];
    }
    return out;
  } catch (err) {
    // 文件不存在、内容被手改坏、API 行为与预期不同 —— 都退化成"用默认值"
    return {};
  }
}

/**
 * 保存旋钮值，并**读回来核对**。
 *
 * ## 两步写（实测出来的顺序）
 *
 * LSE 的 `JsonConfigFile` 上：
 *   · `set(name, value)` —— **实测当场就落盘**（改完立刻读文件，值就在里面）；
 *   · `write()` —— 无参调用会报 `Too Few arguments!`（LSE 记录一行 ERROR 后返回
 *     undefined，**不抛 JS 异常**），所以不能拿它当"落盘"用。
 * 于是顺序反过来：先逐键 `set()`，读回来核对。
 *
 * ## ⚠️ 为什么**没有**"读不回来就 write(values) 兜底"这一步
 *
 * 曾经有过：核对失败时调 `cfg.write(values)`。实测那是个**类型错的调用** ——
 * 服务器日志里刷 `ConfJsonClass::write: Wrong type of argument!`（LSE 的 write 不吃
 * 对象），而它**不抛 JS 异常**，所以代码里既抓不到、也修不好，只能白刷一屏 ERROR。
 * 更糟的是它**掩盖了真正的问题**：本轮 `/peek:badgelevel low` 触发了兜底，
 * 而值其实已经落盘了（`set()` 是成功的，见 settings.json）—— 说明"核对失败"另有原因，
 * 兜底只是把症状变成一行 ERROR。现在核对失败就**如实返回 false**（回执会说明
 * "只在本次会话有效"），并把第一个对不上的键交给调用方报告 —— 要查就查得下去。
 *
 * @param {object} values 要保存的键值对
 * @param {Function} [onMismatch] `(key, backValue, wantValue) -> void`：第一个对不上的键
 * @returns {boolean} 只有"确实写进去且读得回来"才返回 true；返回 false 表示
 *          "只在内存里生效"，调用方应当据此提示玩家。
 */
function saveSaved(values, onMismatch) {
  const kind = detectBackend();
  if (kind === "none") return false;
  const names = Object.keys(values || {});
  if (names.length === 0) return false;

  /**
   * 读回来逐个比对（布尔按 1/0 的语义比，见 sameStoredValue）。
   * 对不上时把**第一个**不一致的键报给调用方 —— 只回一个字"失败"没法排查。
   */
  const verified = () => {
    const back = loadSaved(names);
    for (let i = 0; i < names.length; i++) {
      if (sameStoredValue(back[names[i]], values[names[i]])) continue;
      if (typeof onMismatch === "function") {
        try {
          onMismatch(names[i], back[names[i]], values[names[i]]);
        } catch (_err) {
          // 报告失败不影响判定
        }
      }
      return false;
    }
    return true;
  };

  try {
    if (kind === "JsonConfigFile") {
      // eslint-disable-next-line no-undef
      const cfg = new globalThis.JsonConfigFile(CONFIG_PATH);
      if (typeof cfg.set !== "function") return false;
      for (let i = 0; i < names.length; i++) cfg.set(names[i], values[names[i]]);
      return verified();
    }

    const Ctor = globalThis[kind];
    const handle = new Ctor(CONFIG_PATH, Ctor.WriteMode.CREATE);
    try {
      if (typeof handle.write !== "function") return false;
      handle.write(JSON.stringify(values, null, 2));
      if (typeof handle.flush === "function") handle.flush();
    } finally {
      if (typeof handle.close === "function") handle.close();
    }
    return verified();
  } catch (err) {
    return false;
  }
}

/**
 * 存进去的值与读回来的值算不算"同一个"。
 *
 * 不做严格 `===`：LSE 的配置 API 把布尔写成 **1 / 0**（文件里 `"backdrop": 0`），
 * 严格比较会让"其实存成功了"被误判成失败 —— 回执于是谎报"只在本会话有效"，
 * 而玩家重启后发现设置还在，反而更糊涂。这里按**语义**比：布尔接受 1/0，数字接受数字串。
 */
function sameStoredValue(back, want) {
  if (back === want) return true;
  if (back === undefined || back === null) return false;
  if (typeof want === "boolean") return Number(back) === (want ? 1 : 0);
  if (typeof want === "number") return Number(back) === want;
  return String(back) === String(want);
}

// ===== main.js =====
/**
 * Crosshair Container Peek —— LSE 服务器插件入口。
 *
 * 行为包（@minecraft/server）的服务器原生版，运行于 LeviLamina +
 * LegacyScriptEngine（lse-quickjs）：复用行为包的核心模块（排版、名字表、
 * 字形表、容器形状），仅替换引擎适配层。客户端仍需安装配套资源包，字形通道与行为包一致。
 *
 * 主循环：onTick 每 2 tick 扫一次在线玩家 ——
 *   射线命中方块容器 -> bl.getContainer()；命中容器实体 -> entity.getContainer()；
 *   排版后图标走 actionbar、数量走 title，与行为包一致。
 *
 * 两条预览通道：
 *   · 准星预览：对准容器即显示（上述主循环）；
 *   · 盒预览：在打开的容器/背包界面里点击潜影盒物品，内容显示在屏幕左边缘。
 *
 * 严格只读：不修改任何物品、方块、实体或分数。
 */


// 上面三个日志名分三层（见 llse_adapter.js 的三层日志说明）：
//   · logInfo   —— 常规信息，会被 `/peek:log off` 关掉；
//   · logAlways —— **关不掉**的输出：命令回执、开机那一行、显式打开的诊断日志；
//   · （logWarn 由适配层内部使用，警告与错误任何时候都输出。）
// ⚠️ 注释要写在 import 语句**外面**：`tests/run.mjs` 有一条"每个导入名都得在产物里有声明"
// 的回归断言，它按 `{ … }` 里的逗号切名字 —— 花括号里写注释会被当成一个"导入名"，
// 于是断言自己先崩（真踩过，就这次）。





// 预览标记字形：准星预览的正文带上它（文本内的备用信号）。资源包**当前**的字号判据
// 是 title 通道里的准星预览标记（`peek::r…`，由 previewShapeToken 生成）——
// 也就是说 **sendActionbar 与 sendTitle 必须成对出现**，缺了 title 那一半，资源包会
// 把预览当成"别人的消息"按 1.0 倍字号渲染（图标 4 倍大）。见 hud_protocol.js 的
// markPreviewText 与 tools/pack/build-rp-ui.mjs 的 PREVIEW_TITLE_MARKER。

// 网格形状（行 x 列）：资源包的底衬尺寸按形状写死，title 标记里必须带形状字段
// （见 scripts/grid_shapes.js）。漏了它 = 一个底衬变体都不命中（灰区消失，不报错）。


// HUD 显示自检（`/peek:hudtest`）的文本：**纯函数**，只拼字符串、不碰引擎（见该模块文件头）。
// 那三行刻意不带预览标记 —— 它要回答的正是"连原版文字都看不见吗 / 私有区字形是不是方框"。
// ⚠️ 该模块里那个去色函数叫 `hudTestPlainText`：本文件已经有一个 `stripColor`，
// 单文件打包后共享顶层作用域，重名会让插件加载失败（打包器有重名守门）。



// 盒内内容这一块拆成四个模块，各自只干一件事（本轮重构；原来的 box_badge.js 已删）：
//   box_content     —— 事实（盒里有几格/是不是同一种/满不满）+ 档位策略 + 扫描 + 显示优先级
//   box_stack_sizes —— 物品的堆叠上限怎么来（生成表 → 问引擎 → 夹数量探测 → 不知道）
//   box_cache       —— 扫描结果的缓存、键构造、失效入口（唯一出处）
//   box_selfcheck   —— `/peek:check` 里那一组用例（用例是表，跑法只有一种）







/**
 * 轮询间隔与探测距离现在是**旋钮**（`/peek:poll`、`/peek:reach`），值存在
 * `runtime.POLL_INTERVAL_TICKS` / `runtime.REACH_DISTANCE` 里，默认值与
 * settings.js 的旋钮默认值一致（自测有断言盯着两处一致）。这里只留读取函数。
 */

/** 轮询间隔（tick）：读旋钮值，读到荒唐值时退回默认值（不让排版/循环被坏值带崩）。 */
function pollTicks() {
  const n = Math.floor(Number(runtime.POLL_INTERVAL_TICKS));
  return isFinite(n) && n >= 1 ? n : 2;
}

/** 每玩家上一次显示的指纹；指纹相同即跳过排版与重发。 */
const lastByPlayer = new Map();

/**
 * 每玩家"连续几次没命中容器"的计数（见 updatePlayer 里未命中那一段）。
 *
 * 留着这个容忍窗口是因为射线**偶尔会漏一次**：一次没命中就清屏的表现是
 * "预览自己闪一下没了又回来"，用户报的"注视容器时预览会自动消失"就是这个。
 */
const missByPlayer = new Map();

/** 连续几次没命中才清屏（3 次轮询 ≈ 0.3 秒）。 */
const CONTAINER_MISS_TOLERANCE = 3;

/**
 * **HUD 显示自检**（`/peek:hudtest`）：key -> `{ until, lastSentTick }`。
 *
 * 自检期间**只发那几行原版文字**、不发预览：它是给"看不到图标、说不清为什么"的人用的
 * （文本怎么拼见 hud_test.js）。到点自动恢复，也可以再执行一次立刻结束。
 *
 * 为什么要有这个功能：预览完全由**私有区字形**画成，客户端没装资源包时画面上就是
 * "问号/方框 + 原版黑底"，而**服务端无法知道**客户端装没装 —— 只能让玩家自己看一眼
 * 那三行字回答"图标是不是方块"。用户报的"别人服务器上显示成问号和黑框"就是这条。
 */
const hudTestUntil = new Map();

/** 自检显示时长（tick）：默认 15 秒。 */
function hudTestTicks() {
  const tps = 20;   // BDS 固定 20 tps
  return 15 * tps;
}

/**
 * 自检文本的重发间隔（tick）：2 秒一次。
 *
 * 为什么是 2 秒：自检那几行**不带预览标记**，走的是原版 title / subtitle / actionbar 渲染，
 * 三条通道的 stay 都是 60 tick（3 秒，见 llse_adapter.js）—— 2 秒一次正好重叠 1 秒，
 * 既不断档、也不会把淡入反复重启（fadeIn 是 0，同文本重设看不出变化）。
 * 预览那条路每 2 tick 重发是因为它靠常驻标签画，与这里不是一回事。
 */
const HUD_TEST_RESEND_TICKS = 40;

/**
 * 自检第 3/3 行要写的旋钮快照（**他会看到的值**，已转成文字）。
 *
 * 挑这五个的理由：每一个都能让画面"看起来像坏了" —— display 关 = 什么都不显示；
 * backdrop 开而灰区与网格错位 = "只有一块灰的、没图标"；scale 改小 = "图标变小了"；
 * badgelevel / boxbadge 关 = "盒子上没有小图"。
 * 用 `describeSettingValue` 渲染：屏幕上的写法与 `/peek:status` 完全一致，免得两边各说一套。
 */
function hudTestKnobSnapshot(key) {
  const shot = {};
  const names = ["display", "backdrop", "scale", "badgelevel", "boxbadge"];
  for (let i = 0; i < names.length; i++) {
    const s = settingByName(names[i]);
    if (s) shot[names[i]] = describeSettingValue(s, effectiveSettingValue(s, key));
  }
  return shot;
}

/**
 * 准星预览的诊断日志（`/peek:trace` 打开时才有输出）。
 *
 * 为什么需要它：这个功能的毛病大多**只在客户端看得见**（预览消失、位置不对、闪巨大副本），
 * 服务端这边"发了什么、发了几次"是唯一能查的线索。日志只在状态变化与发包时打，
 * 且由 traceInventory 这个开关控制，默认不刷日志。
 */
function tracePreview(key, message) {
  if (!traceInventory) return;
  // `logAlways` 而不是 `logInfo`：诊断日志是**显式打开**的（`/peek:trace`），
  // 它自己就是"我现在要看日志"的意思 —— 再被 `/peek:log off` 挡掉就自相矛盾了。
  logAlways("[peek-crosshair] " + String(key).slice(0, 12) + " " + message);
}

/** 自增 tick（onTick 每次 +1）。 */
let tick = 0;

// ===== 旋钮：生效、持久化、自检 =====

/**
 * 从配置文件读回旋钮值（启动时调用一次）。
 *
 * 只认**表里有的键**，且每个值都要过一遍 `validateSetting` —— 配置文件是明文 JSON，
 * 手改坏了（越界、写了个字符串）不应该让插件带着荒唐值跑起来。
 */
function loadSettingsOnStart() {
  const saved = loadSaved(settingNames());
  let applied = 0;
  for (let i = 0; i < SETTINGS.length; i++) {
    const s = SETTINGS[i];
    if (!Object.prototype.hasOwnProperty.call(saved, s.name)) continue;
    const result = validateSetting(s, saved[s.name]);
    if (!result.ok) continue;
    // toggle 的 null 表示"切换"，配置文件里必须是明确的值
    if (result.value === null) continue;
    runtime[s.runtime] = result.value;
    applied++;
  }

  // 日志开关**必须在启动日志之前生效**：配置文件里存着 `/peek:log off` 时，
  // 下面那行"旋钮配置"以及后面 8 行事件注册就都不该出现（否则"关掉日志"要等重开一次服
  // 才干净，而管理员正是因为嫌刷屏才关它）。启动完成那一行走的是 `logAlways`，保留。
  setInfoLogEnabled(runtime.INFO_LOG_ENABLED);

  // ===== 个人设置（观感类）=====
  // 名单存在 `p:_index`；每个人的键是 `p:<玩家名>:<旋钮>`。
  // 读不到名单（旧配置文件、或配置后端不支持）时就是"没有个人设置"，不影响使用。
  let players = 0;
  let personal = 0;
  try {
    const indexRaw = loadSaved([PLAYER_INDEX_KEY])[PLAYER_INDEX_KEY];
    const names = typeof indexRaw === "string" ? JSON.parse(indexRaw) : indexRaw;
    if (Array.isArray(names)) {
      for (let i = 0; i < names.length; i++) {
        const key = String(names[i]);
        const view = {};
        const keys = [];
        for (let j = 0; j < PLAYER_SCOPED.length; j++) {
          keys.push(PLAYER_KEY_PREFIX + key + ":" + PLAYER_SCOPED[j].name);
        }
        const stored = loadSaved(keys);
        for (let j = 0; j < PLAYER_SCOPED.length; j++) {
          const s = PLAYER_SCOPED[j];
          const raw = stored[PLAYER_KEY_PREFIX + key + ":" + s.name];
          if (raw === undefined || raw === null) continue;
          const result = validateSetting(s, raw);
          if (!result.ok || result.value === null) continue;
          if (result.value === s.value) continue;   // 等于默认值 = 没设过
          view[s.name] = result.value;
          personal++;
        }
        if (Object.keys(view).length > 0) {
          playerViews.set(key, view);
          players++;
        }
      }
    }
  } catch (err) {
    // 这条是"出事了"级别：走 logAlways，不然 `/peek:log off` 会把唯一的线索也吞掉
    logAlways("个人设置读取失败（忽略，用全局默认）: " + err);
  }

  logInfo("旋钮配置: 全局 " + applied + " 项 / 个人 " + players + " 名玩家共 " + personal +
    " 项，持久化方式 = " + backendLabel());
}

/** 全部旋钮的键名（读写配置时都要用，避免两处各拼一遍）。 */
function settingNames() {
  const out = [];
  for (let i = 0; i < SETTINGS.length; i++) out.push(SETTINGS[i].name);
  return out;
}

// ===== 每人独立的观感设置（scope === "player"）=====

/**
 * 每个玩家的个人设置：`玩家标识 -> { 旋钮名: 值 }`。
 *
 * 观感类旋钮（display / box / backdrop / top / hspace / boxpos / boxhspace）放这里，
 * 性能类（poll / refresh / resend / reach）始终在 `runtime` 里全局一份。
 *
 * 排版是**每个玩家一次同步调用**，所以"临时把个人值套进 runtime、算完再还原"
 * 是安全的（见 withPlayerView）；这样共享的 `format.js` 一个字都不用改。
 */
const playerViews = new Map();

/**
 * 持久化键名：个人设置用 `p:<玩家名>:<旋钮>`，全局默认就是旋钮名本身。
 *
 * 为什么用扁平键而不是嵌套对象：配置 API 的 `get/set` 是按键读写的，
 * 扁平键在任何后端（JsonConfigFile / File）下行为都一样，也不用赌嵌套对象能不能存取。
 */
const PLAYER_KEY_PREFIX = "p:";
/** 个人设置的"名单"（配置 API 没有"列出所有键"，所以自己记一份）。 */
const PLAYER_INDEX_KEY = "p:_index";

/** 观感类旋钮（每人独立）的缓存：SETTINGS 是常量，不必每次过滤一遍。 */
const PLAYER_SCOPED = playerScopedSettings();

/** 某玩家的个人设置对象（没有就建一个）。 */
function playerViewOf(key) {
  let view = playerViews.get(key);
  if (!view) {
    view = {};
    playerViews.set(key, view);
  }
  return view;
}

/** 某玩家某个观感旋钮的**实际生效值**：个人值优先，否则全局默认。 */
function effectiveSettingValue(setting, key) {
  if (setting.scope !== "player" || !key) return runtime[setting.runtime];
  const view = playerViews.get(key);
  if (view && Object.prototype.hasOwnProperty.call(view, setting.name)) return view[setting.name];
  return runtime[setting.runtime];
}

/**
 * 在"某个玩家自己的设置"下执行一段逻辑，执行完还原全局值。
 *
 * 这是整套个人设置的核心手法：`format.js` / `grid_shapes.js` 只读 `runtime` 上的属性，
 * 于是排版前把该玩家的个人值填进去、排完再放回去 —— 不需要给共享模块加参数，
 * 也不会把某个人的设置泄漏给下一个玩家（**必须放在 finally 里还原**）。
 */
function withPlayerView(key, fn) {
  const view = playerViews.get(key);
  if (!view) return fn();

  const touched = [];
  for (let i = 0; i < SETTINGS.length; i++) {
    const s = SETTINGS[i];
    if (s.scope !== "player") continue;
    if (!Object.prototype.hasOwnProperty.call(view, s.name)) continue;
    touched.push({ runtime: s.runtime, saved: runtime[s.runtime], value: view[s.name] });
    runtime[s.runtime] = view[s.name];
  }
  try {
    return fn();
  } finally {
    for (let i = 0; i < touched.length; i++) {
      runtime[touched[i].runtime] = touched[i].saved;
    }
  }
}

/** 某玩家的个人设置里有几项（`/peek:status` 用）。 */
function playerViewCount(key) {
  const view = playerViews.get(key);
  if (!view) return 0;
  let n = 0;
  for (let i = 0; i < SETTINGS.length; i++) {
    if (Object.prototype.hasOwnProperty.call(view, SETTINGS[i].name)) n++;
  }
  return n;
}

/** 把某玩家的个人设置写进配置文件（值等于默认值的不写，等于"没设过"）。 */
function persistPlayerView(key) {
  const view = playerViews.get(key) || {};
  const values = {};
  for (let i = 0; i < PLAYER_SCOPED.length; i++) {
    const s = PLAYER_SCOPED[i];
    if (!Object.prototype.hasOwnProperty.call(view, s.name)) continue;
    if (view[s.name] === s.value) continue;      // 与默认值相同 → 视为未设置
    values[PLAYER_KEY_PREFIX + key + ":" + s.name] = storedSettingValue(s, view[s.name]);
  }
  const keys = Object.keys(values);
  // 没有非默认的个人值 = 没什么可存的（不该因此回执"未保存"）
  const ok = keys.length === 0 ? true : saveSaved(values);
  persistPlayerIndex();
  return ok;
}

/** 把"有哪些玩家存过个人设置"写进配置（配置 API 没有列键的能力）。 */
function persistPlayerIndex() {
  const names = [];
  playerViews.forEach((view, key) => {
    for (let i = 0; i < PLAYER_SCOPED.length; i++) {
      const s = PLAYER_SCOPED[i];
      if (Object.prototype.hasOwnProperty.call(view, s.name) && view[s.name] !== s.value) {
        names.push(key);
        return;
      }
    }
  });
  saveSaved({ [PLAYER_INDEX_KEY]: JSON.stringify(names) });
}

/** 当前值写回配置文件；返回是否真的写盘成功。 */
function persistSettings() {
  const values = savedSettingValues();
  return saveSaved(values);
}

/** 当前全部旋钮值（就是配置文件的内容）。 */
function savedSettingValues() {
  const out = {};
  for (let i = 0; i < SETTINGS.length; i++) {
    const s = SETTINGS[i];
    out[s.name] = runtime[s.runtime];
  }
  return out;
}

/** 持久化方式的名字（回执与自检里用；"memory" 表示只在本次会话有效）。 */
function settingsBackendName() {
  const kind = detectBackend();
  if (kind === "none") return "memory";
  return backendLabel();
}

/**
 * **向上位移**要补的换行数（`/peek:top` < 0 时）。
 *
 * 为什么向上得用这套：填充层（pad）是"在网格上方加一块高度"，高度不可能为负，
 * 所以它只能把预览往下推。上移的唯一办法是在**居中标签**末尾补换行 ——
 * 标签的高度涨 N 行、中心不动，于是内容整体上移 N/2 行（`boxShiftedText` 同一套算法）。
 *
 * ⚠️ 补出来的行数要比档位值多 1：负档时填充层发的是一**个空格**（见发送点），
 * 那也有 1 行的高度、会把预览往下压半行，这里补回来。
 *
 * @returns {number} 要补的换行数（0 = 不需要上移）
 */
function upShiftLines() {
  const lines = Math.floor(Number(runtime.TOP_PADDING_LINES));
  if (!isFinite(lines) || lines >= 0) return 0;
  return -lines + 1;
}

/**
 * 把某个旋钮设成 `value`，并执行它自己的副作用（清屏、作废缓存、重排盒预览）。
 */
function assignSettingValue(setting, value, personScoped, key) {
  if (personScoped) {
    playerViewOf(key)[setting.name] = value;
  } else {
    runtime[setting.runtime] = value;
  }

  // ===== 副作用 =====
  // 关掉预览 / 潜影盒预览时**立刻收掉屏幕上已有的东西**：
  // 否则"关掉了但画面还在"，下次重发才消失（最多 3 秒），看起来像命令没生效。
  if (setting.runtime === "PREVIEW_ENABLED" && value === false) {
    personScoped ? clearHudFor(key) : clearAllHud();
  }
  if (setting.runtime === "BOX_PEEK_ENABLED" && value === false) {
    personScoped ? dropBoxPeekByKey(key, "潜影盒预览已关闭") : dropAllBoxPeeks();
  }
  // 底衬 / 位置类：排版结果变了，缓存必须作废，否则要等到内容变化才更新
  if (setting.runtime === "SHOW_BACKDROP" || setting.runtime === "TOP_PADDING_LINES" ||
      setting.runtime === "HSPACE_UNITS" || setting.runtime === "BADGE_LEVEL" ||
      setting.runtime === "PREVIEW_SCALE" || setting.runtime === "BOX_BADGE_ENABLED") {
    personScoped ? lastByPlayer.delete(key) : lastByPlayer.clear();
  }
  // 角标档位变了：**扫描结果**（每个盒子的角标判定）整体变了，缓存必须作废
  if (setting.runtime === "BADGE_LEVEL") {
    invalidate("换档位 " + setting.runtime);
  }
  // 潜影盒自己的位置旋钮：**正在显示的盒预览**要重排（准星那边与它无关）
  if (setting.runtime === "BOX_POS_LINES" || setting.runtime === "BOX_HSPACE_UNITS") {
    if (personScoped) {
      const peek = boxPeekByPlayer.get(key);
      if (peek) peek.sent = "";
    } else {
      boxPeekByPlayer.forEach((peek) => {
        peek.sent = "";        // 强制下一次重排（重排时会按新位置重建两层文本）
      });
    }
  }
  // 日志开关：立刻作用到适配层的 logInfo 上（`logAlways` / 警告不受影响）。
  //
  // ⚠️ 命令回执本身走的是 `logAlways`（见 outputSink）：不然"关掉日志"这条回执会被它自己
  // 吞掉，管理员只看到一条命令执行了、却不知道结果是什么。
  if (setting.runtime === "INFO_LOG_ENABLED") {
    setInfoLogEnabled(value);
  }
}

/**
 * 应用一条旋钮命令。
 *
 * ## 作用域（见 settings.js 的 scope 字段）
 *
 *   · `global`（性能类：poll / refresh / resend / reach）—— 写 `runtime` + 全局键，全服生效；
 *   · `player`（观感类：display / box / backdrop / top / hspace / boxpos / boxhspace）：
 *       - **玩家执行的** → 只写他自己那份（`playerViews`），别人不受影响；
 *       - **控制台执行的** → 写"全局默认值"，给还没设过个人值的玩家用。
 *
 * @param {object} setting 旋钮定义
 * @param {*} raw 参数原始值
 * @param {string} [key] 执行者的玩家标识（控制台为 undefined）
 * @returns {{ok: boolean, message: string, persisted?: boolean}}
 */
function applySetting(setting, raw, key) {
  if (!setting) return { ok: false, message: "没有这个旋钮" };

  const personScoped = setting.scope === "player" && !!key;
  const result = validateSetting(setting, raw);
  if (!result.ok) {
    return { ok: false, message: setting.label + "：" + result.reason + "。用法 /peek:" + setting.name };
  }

  // 读当前值（个人作用域读他自己的，否则读全局默认）
  const current = personScoped
    ? effectiveSettingValue(setting, key)
    : runtime[setting.runtime];

  let value = result.value;
  if (value === null) {
    // 开关类省略参数 = 切换；enum 类省略参数 = 跳到下一档（循环）
    if (setting.kind === "enum") {
      const values = setting.values || [];
      const cur = String(current === undefined || current === null ? setting.value : current).toLowerCase();
      const idx = values.indexOf(cur);
      value = values[(idx + 1) % values.length] || setting.value;
    } else {
      value = !current;
    }
  }

  assignSettingValue(setting, value, personScoped, key);

  const persisted = personScoped ? persistPlayerView(key) : persistSettings();
  return {
    ok: true,
    persisted: persisted,
    message: setting.label + " = " + describeSettingValue(setting, value) +
      (setting.scope === "player"
        ? (personScoped ? "（只对你生效）" : "（全局默认值，所有人）")
        : "（全局，所有人）") +
      (persisted ? "" : "　⚠️ 未写入配置文件，只在本次会话有效")
  };
}

/**
 * `/peek:reset`：
 *   · 玩家执行 → 清掉**他自己**那份个人设置（全局默认与别人不受影响）；
 *   · 控制台执行 → 清掉全部个人设置并把全局恢复默认。
 */
function resetSettings(key) {
  if (key) {
    playerViews.delete(key);
    lastByPlayer.delete(key);
    persistPlayerView(key);
    return "你的个人设置已清空（回到全局默认）";
  }
  playerViews.clear();
  for (let i = 0; i < SETTINGS.length; i++) {
    const s = SETTINGS[i];
    runtime[s.runtime] = s.value;
  }
  lastByPlayer.clear();
  persistSettings();
  persistPlayerIndex();
  return "全部旋钮已恢复默认值（个人设置一并清空）";
}

/** 按玩家标识找在线玩家（个人作用域的命令要作用在"谁执行的"身上）。 */
function playerByKey(key) {
  const players = onlinePlayers();
  for (let i = 0; i < players.length; i++) {
    if (playerKey(players[i]) === key) return players[i];
  }
  return null;
}

/** 只清某个玩家的预览（个人作用域的 `/peek:display off`）。 */
function clearHudFor(key) {
  const player = playerByKey(key);
  if (!player) return;
  try {
    sendActionbar(player, " ");
    sendTitle(player, "");
    sendSubtitle(player, "");
  } catch (_err) {
    // 单个玩家失败不影响别的
  }
  lastByPlayer.delete(key);
}

/** 只收某个玩家的盒预览（个人作用域的 `/peek:box off`）。 */
function dropBoxPeekByKey(key, why) {
  const player = playerByKey(key);
  if (player) dropBoxPeek(player, why);
}

/** 清掉所有在线玩家的预览（控制台执行的 `/peek:display off` 用）。 */
function clearAllHud() {
  const players = onlinePlayers();
  for (let i = 0; i < players.length; i++) {
    try {
      sendActionbar(players[i], " ");
      sendTitle(players[i], "");
      sendSubtitle(players[i], "");
      const key = playerKey(players[i]);
      if (key) lastByPlayer.delete(key);
    } catch (_err) {
      // 单个玩家失败不影响其它玩家
    }
  }
}

/**
 * 立刻为某个玩家重发一次预览（跳过节流）。
 *
 * 用途：界面打开/关闭这类"引擎会动 HUD 通道"的时刻，别等下一次轮询（默认 2 tick），
 * 当场把三条通道重新压上去。任何失败都只记日志 —— 重发是**尽力而为**，失败了下一次
 * 轮询照样会补上。
 */
function forceRefresh(player) {
  try {
    updatePlayer(player, true);
  } catch (err) {
    logInfo("强制重发失败（忽略，等下次轮询）: " + err);
  }
}

/** 收掉所有玩家的盒预览（`/peek:box off` 用）。function dropAllBoxPeeks() {
  const players = onlinePlayers();
  for (let i = 0; i < players.length; i++) {
    try {
      dropBoxPeek(players[i], "潜影盒预览已关闭");
    } catch (_err) {
      // 同上
    }
  }
}

/**
 * `/peek:check` 的本体：**逐项验证运行链**，只读、不改世界。
 *
 * 每一项都返回"通过 / 失败 + 证据"，失败原因直接写出来 —— 自检的价值全在证据上，
 * 只报"自检失败"等于没检。
 */
function runSelfCheck(key) {
  const lines = [];
  let failed = 0;
  // 项数**单独数**。以前用的是 `lines.length - 2`（头一行 + 末尾那行），后来中间加了一行
  // 信息行，于是"39 项"变成"40 项" —— 数字看着挺好，其实是假的，而它正好是我在服务器上
  // 横向比对两次自检的唯一读数（"项数变了"= 有用例没跑）。
  let items = 0;
  const item = (ok, label, evidence) => {
    items++;
    if (!ok) failed++;
    lines.push((ok ? "§a✔ " : "§c✘ ") + "§7" + label + (evidence ? "　§8" + evidence : ""));
  };

  lines.push("§a[peek] 自检（只读，不改世界）");

  // ① 排版链：用一个假容器跑一遍，产出里必须有图标码点
  try {
    const sample = {
      containerSize: 27,
      items: [{ slot: 0, typeId: "diamond", amount: 3 }],
      fingerprint: "selftest"
    };
    const text = formatContents("chest", sample);
    const counts = formatCounts("chest", sample);
    item(text.length > 0, "排版链能产出文本", text.length + " 字符");
    item(text.indexOf(itemGlyph("diamond")) >= 0, "产出里含 diamond 的图标码点",
      "U+" + itemGlyph("diamond").charCodeAt(0).toString(16).toUpperCase());
    item(counts.indexOf(countGlyph(3)) >= 0, "数量层含 3 的字形");
  } catch (err) {
    item(false, "排版链抛错", String(err));
  }

  // ② 形状协议：定宽 4 字符、纯 ASCII（资源包按定长剪前缀）
  try {
    const token = previewShapeToken("chest", 27, true);
    item(token.length === 4 && /^[\x20-\x7e]+$/.test(token),
      "形状标记定宽且是 ASCII", JSON.stringify(token));
    const noBackdrop = previewShapeToken("chest", 27, true);
    item(runtime.SHOW_BACKDROP === false ? noBackdrop === "r0c0" : true,
      "关掉底衬时形状退化成兜底标记", runtime.SHOW_BACKDROP ? "(底衬开着，跳过)" : noBackdrop);
  } catch (err) {
    item(false, "形状标记抛错", String(err));
  }

  // ③ 字号协议：资源包靠 title 里的准星预览标记认出"我们的预览"
  try {
    const title = "peek::r3c9" + formatCounts("chest", { containerSize: 27, items: [], fingerprint: "x" });
    item(title.slice(0, 7) === "peek::r", "title 标记与资源包判据对得上", title.slice(0, 10));
  } catch (err) {
    item(false, "title 标记检查抛错", String(err));
  }

  // ④ 旋钮：runtime 键齐不齐、值是否合法
  let badKnob = "";
  for (let i = 0; i < SETTINGS.length; i++) {
    const s = SETTINGS[i];
    if (!Object.prototype.hasOwnProperty.call(runtime, s.runtime)) {
      badKnob = s.name + " -> runtime." + s.runtime + " 不存在";
      break;
    }
    const check = validateSetting(s, runtime[s.runtime]);
    if (!check.ok || check.value === null) {
      badKnob = s.name + " 的当前值不合法";
      break;
    }
  }
  item(badKnob === "", "全部 " + SETTINGS.length + " 个旋钮都有对应的 runtime 键且取值合法", badKnob);

  // ⑤ 持久化：**真的写一次再读回来**（值不变，所以不会改变玩家设置），
  //    拿到什么就报什么，不假装已保存。
  const persisted = persistSettings();
  item(persisted, persisted
    ? "配置能持久化（写入后读回一致）"
    : "配置写入后读不回来（改动只在本次会话有效）", backendLabel());

  // ⑤b 个人设置的持久化：**键名里带冒号**，走的是另一条路径（玩家命令写的那些键）。
  //     分开测的理由：全局键（`display` 这种）实测一直正常，而玩家键在本机服务器上
  //     出现过"值已落盘、却核对不回来"的现象 —— 只报一句"失败"没法查，所以这里
  //     把写前值、写入结果、读回值都摆出来，并写一条**假的**个人键（不碰任何人的设置）。
  {
    const probeKey = PLAYER_KEY_PREFIX + "__selftest__:probe";
    const before = loadSaved([probeKey])[probeKey];
    let reported = "";
    const wrote = saveSaved({ [probeKey]: "high" }, function (name, got) {
      reported = name + " 读回 " + JSON.stringify(got);
    });
    const after = loadSaved([probeKey])[probeKey];
    item(wrote && after === "high",
      "个人设置的键（键名带冒号）也能写进配置并读回来",
      "写入" + (wrote ? "成功" : "失败") + "，读回 " + JSON.stringify(after) +
        "（写前 " + JSON.stringify(before) + "）" + (reported ? "　" + reported : ""));
  }

  // ⑥ 命令注册方式：**原生才有客户端补全**
  //    （虚拟命令只在服务端拦聊天输入，客户端根本不知道它存在 —— 用户报的"没有补全"）
  item(commandStatus.mode === "native",
    "命令以原生方式注册（客户端**有**参数补全）",
    commandStatusLabel() + (commandStatus.errors.length > 0 ? "　原因：" + commandStatus.errors[0] : ""));

  // ⑦ 作用域：观感类每人独立、性能类全服
  {
    const playerCount = PLAYER_SCOPED.length;
    const globalCount = SETTINGS.length - playerCount;
    const badScope = SETTINGS.filter((s) => s.scope !== "player" && s.scope !== "global");
    item(badScope.length === 0 && playerCount > 0 && globalCount > 0,
      "旋钮作用域划分正确（每人独立 " + playerCount + " 项 / 全服 " + globalCount + " 项）",
      badScope.length > 0 ? "有旋钮没写 scope: " + badScope.map((s) => s.name).join(", ")
        : (key ? "你自己设了 " + playerViewCount(key) + " 项" : "控制台视角"));
  }

  // ⑧ 个人设置的核心机制：只在该玩家排版期间生效，并且**一定还原**
  //    （这套东西全靠"临时套上再放回"，串了就是"别人的设置跑到我身上"，很难查）
  {
    const fakeKey = "__selftest__";
    const savedTop = runtime.TOP_PADDING_LINES;
    playerViews.set(fakeKey, { top: 99 });
    let inside = null;
    withPlayerView(fakeKey, function () { inside = runtime.TOP_PADDING_LINES; });
    playerViews.delete(fakeKey);
    item(inside === 99 && runtime.TOP_PADDING_LINES === savedTop,
      "个人设置只在该玩家排版期间生效、且一定还原",
      "期间 " + inside + " / 之后 " + runtime.TOP_PADDING_LINES + "（全局原值 " + savedTop + "）");
  }

  // ⑧⑨ 潜影盒角标 / 盒内判定 / 堆叠上限：用例表在 box_selfcheck.js 里（见那个文件头）。
  //    搬出去的理由：这一组原来是一百来行内联代码，加一条用例就得往这个大函数里塞，
  //    谁也说不清算上现在覆盖了哪些情形。现在用例是表、跑法只有一种。
  {
    const cases = boxSelfCheckCases();
    for (let i = 0; i < cases.length; i++) {
      item(cases[i].ok, cases[i].label, cases[i].evidence);
    }
  }


  // ⑩ 总开关状态（信息项，不算失败）
  lines.push("§7总开关（对你的有效值）：预览" +
    (effectiveSettingValue(settingByName("display"), key) ? "开" : "§c关") +
    "　潜影盒" + (effectiveSettingValue(settingByName("box"), key) ? "开" : "§c关") +
    "　底衬" + (effectiveSettingValue(settingByName("backdrop"), key) ? "开" : "§c关"));

  // ⑪ 指路（信息项）：上面这一串验的全是**服务端**这一侧，而"图标变成问号/方框"
  //    那种毛病在客户端 —— 服务端查不到，只能让玩家自己看一眼屏幕。见 /peek:hudtest。
  lines.push("§7看不出图标？§f/peek:hudtest§7 会在你屏幕上画几行自检文字，照着一读就知道是哪一环");

  lines.push(failed === 0
    ? "§a✔ 全部通过（" + items + " 项）"
    : "§c✘ " + failed + " 项失败");
  return lines;
}

/**
 * 扫一遍容器里的潜影盒（**接线**：把引擎相关的能力注入给纯逻辑模块）。
 *
 * 判定在 box_content.js、堆叠上限在 box_stack_sizes.js、缓存在 box_cache.js ——
 * 这里只负责把「读 NBT / 取角标字形 / 判断是不是潜影盒」三件事接上去，并把结果缓存起来。
 *
 * @param {string} cacheKey 缓存键（`targetLocationKey(...) + "|" + contentKey(...)`）
 * @param {object} contents 容器内容
 * @returns {object} `{ bySlot, records, totals, boxCount }`（见 box_content.scanBoxes）
 */
function boxRecordsFor(cacheKey, contents) {
  return cachedFor(cacheKey, function () {
    const started = Date.now();
    const scanned = scanBoxes(contents, {
      readInner: readShulkerItemContents,
      isShulkerType: isShulkerBox,
      glyphFor: boxBadgeGlyph,
      stackSizeFor: stackSizeFor,
      mode: runtime.BADGE_LEVEL
    });
    if (traceInventory) {
      const stats = cacheStats();
      logAlways("[peek-badge] 扫描 " + contents.items.length + " 格 → 命中 " + scanned.boxCount +
        " 个盒子，耗时 " + (Date.now() - started) + " ms（缓存 命中/未命中/失效 = " +
        stats.hits + "/" + stats.misses + "/" + stats.invalidations + "）");
    }
    return scanned;
  });
}

/**
 * 处理一个玩家：找容器 -> 读内容 -> 排版 -> 发 HUD。
 *
 * 外面套一层 `withPlayerView`：观感类旋钮（位置、底衬、开关）是**每人独立**的，
 * 排版前把该玩家自己那份填进 `runtime`、算完立刻还原（见 withPlayerView）。
 *
 * @param {object} player LSE Player
 * @param {boolean} [force] 跳过节流，强制重排重发（仅供自检）
 */
function updatePlayer(player, force) {
  const key = playerKey(player);
  if (!key) return null;
  return withPlayerView(key, function () {
    return updatePlayerInner(player, force, key);
  });
}

/**
 * updatePlayer 的本体（个人设置已经生效）。
 *
 * @param {object} player LSE Player
 * @param {boolean} [force] 跳过节流
 * @param {string} key 玩家标识（已经算好，本体不再重复取）
 */
function updatePlayerInner(player, force, key) {

  // ===== HUD 显示自检（`/peek:hudtest`）：压过一切 =====
  //
  // ⚠️ 放在总开关**前面**是故意的：玩家说"什么都看不到"时最该跑的就是自检，而
  // "什么都看不到"最常见的原因之一恰恰是 display 被关了（个人设置会持久化，关过就忘）——
  // 自检必须照样显示出来才说得清这件事（第 3/3 行会把 display 的当前值写在屏幕上）。
  //
  // 自检期间只发那三行**不带 `peek::` 标记**的原版文字：看到什么 = 这个客户端的 HUD
  // 本身能显示什么。判据见 hud_test.js 的文件头。
  const hudTest = hudTestUntil.get(key);
  if (hudTest) {
    if (tick >= hudTest.until) {
      // 到点：清一次三条通道后**继续往下走**（这一 tick 就能把正常预览压回去，
      // 不会留下"自检结束了但屏幕是空的"那一帧）。
      hudTestUntil.delete(key);
      sendActionbar(player, " ");
      sendTitle(player, "");
      sendSubtitle(player, "");
      lastByPlayer.delete(key);
      missByPlayer.delete(key);
    } else {
      if (force || tick - (hudTest.lastSentTick || 0) >= HUD_TEST_RESEND_TICKS) {
        const texts = hudTestTexts({
          itemGlyph: itemGlyph,
          knobs: hudTestKnobSnapshot(key),
          // 倒计时：读的时候就知道还剩几秒（每一轮重发都会更新这个数）
          seconds: Math.max(1, Math.ceil((hudTest.until - tick) / 20))
        });
        // 顺序与预览一致：actionbar → title → subtitle（文字层最后，见下面发包那一段）。
        // ⚠️ title 走 `sendPlainTitle`（**不加** `peek::` 标记）：自检要的是原版渲染 ——
        // 带上标记就成了"用被检验的那套渲染去检验它自己"，见 llse_adapter.js 的说明。
        sendActionbar(player, texts.actionbar);
        sendPlainTitle(player, texts.title);
        sendSubtitle(player, texts.subtitle);
        hudTest.lastSentTick = tick;
      }
      return { typeId: "", kind: "hudtest", text: "", counts: "" };
    }
  }

  // ===== 总开关：`/peek:display off` =====
  //
  // 关掉之后不再做任何检测、排版与发包（省掉每玩家那一份开销），
  // 并把上一次的显示清掉 —— **只清一次**（靠 lastByPlayer 里有没有记录判断），
  // 否则每个轮询周期都在发清屏包。
  // 准星预览与潜影盒预览一起停：只想停潜影盒预览用 `/peek:box off`。
  if (runtime.PREVIEW_ENABLED === false) {
    if (lastByPlayer.has(key)) {
      sendActionbar(player, " ");
      sendTitle(player, "");
      sendSubtitle(player, "");
      lastByPlayer.delete(key);
    }
    return null;
  }

  // ===== 优先：刚点过的潜影盒（盒预览）=====
  //
  // 盒预览必须优先于准星预览：容器界面打开时准星通常仍对着该容器方块，
  // 若准星预览优先，点击盒子的结果会在同一帧被容器预览刷掉，表现为点击无反应。
  const boxPeek = runtime.BOX_PEEK_ENABLED === false ? null : boxPeekByPlayer.get(key);
  if (boxPeek) {
    // 诊断：盒预览存在期间，准星预览是**整体让位**的（见本段开头的说明）。
    // 这正是"看着容器却什么都没有 / 预览自己消失"的一种可能原因，所以记一笔。
    if (!boxPeek.traceNoted) {
      boxPeek.traceNoted = true;
      tracePreview(key, "盒预览接管中：准星预览暂停，直到 tick=" + boxPeek.until +
        "（TTL " + BOX_PEEK_TTL_TICKS + " tick）");
    }
    // 已离开界面（视线转过阈值角度）则立刻收掉，交回准星预览。
    // 判据细节见 boxPeekShouldDrop。
    const dropReason = boxPeekShouldDrop(player, boxPeek);
    if (dropReason) {
      dropBoxPeek(player, dropReason);
    } else if (tick >= boxPeek.until) {
      // 超过 TTL：清掉盒预览的各通道后照常走准星预览。标记与文本都要重置 ——
      // 标记不匹配会让居中那套控件一直不显示；图标在 title、数量在 subtitle。
      dropBoxPeek(player, "超过显示时长 " + BOX_PEEK_TTL_TICKS + " tick");
    } else if (tick - (boxPeek.armedTick || 0) > BOX_PEEK_HOLD_TICKS && lookedAtPreviewable(player)) {
      // ===== 让位超过"刚点过"的窗口、而准星已经对着容器 → 交回准星预览 =====
      //
      // 这条是用户报的"对准容器看的时候，容器预览会自己消失"的正解：盒预览一旦建立
      // 就**整体占用三条文本通道**（准星预览必须让位），而"界面关了但玩家站着不动、
      // 也不转视角"这一刻**没有事件可听**（背包没有关闭事件），于是让位只能靠 TTL 兜底 ——
      // 5 秒内玩家看到的就是"盯着箱子什么都没有"。
      //
      // 现在补一条主动判据：盒预览是"刚点过盒子"的临时预览，只要**离刚点过已经超过
      // BOX_PEEK_HOLD_TICKS**，而准星正对着一个容器，就交回准星预览。
      // 界面真开着时这条判据也会命中（准星本来就对着那个容器）—— 代价可接受：
      // 容器界面会盖住屏幕中央，准星预览那时基本看不见；而玩家再点一下盒子就会续期。
      dropBoxPeek(player, "准星已对着容器，交回准星预览（点盒子可续期）");
    } else {
      const contentChanged = boxPeek.sent !== boxPeek.fingerprint;
      const dueToResend = tick - (boxPeek.lastSentTick || 0) >= BOX_RESEND_EVERY_TICKS;
      if (force || contentChanged || dueToResend) {
        // 仅内容变化时重新排版；定期重发复用缓存串，不做重活。
        if (contentChanged || !boxPeek.lastText) {          // bright: true —— 容器界面在 HUD 上方压有一层暗幕，左边缘预览需改用
          // 提亮 + 提饱和的副本字形，否则会被压得发灰（见 item_glyphs.js 的 BOX_ITEM_GLYPHS）。
          // 数量层是白色数字，无需亮版，故 formatCounts 不带该参数。
          //
          // 位置：走 boxShiftedText —— 潜影盒预览有**自己的一套**位置旋钮
          //（/peek:boxpos、/peek:boxhspace），与准星预览的 /peek:top、/peek:hspace 无关。
          // 两层必须用**同一个位移**，否则数字会和图标错开。
          const vLines = boxPosLines();
          const hUnits = boxHspaceUnits();
          boxPeek.lastText = boxShiftedText(function () {
            return formatContents(boxPeek.typeId, boxPeek.contents, { bright: true });
          }, vLines, hUnits);
          boxPeek.lastCounts = boxShiftedText(function () {
            return formatCounts(boxPeek.typeId, boxPeek.contents);
          }, vLines, hUnits);
          boxPeek.sent = boxPeek.fingerprint;
        }
        // 左边缘预览通道：图标走 title（带盒子标记 + **形状字段**），数量走 subtitle
        // 形状按盒预览自己的容器读（潜影盒恒为 27 格 -> 3x9）
        //
        // ⚠️ **必须同时把 actionbar 清成空格**（用户报的"对着容器打开背包还是会出现巨大 UI"）。
        // 原因：资源包的判据是"title 是不是 `peek::r…`"。进入盒预览后 title 变成
        // `peek::box::…`（第二个字符是 b）→ 判定为"不是准星预览"→ 走 **1.0 倍字号**那条标签；
        // 而 actionbar 里**还留着上一次准星预览的图标串**（进盒预览时不会自己清），
        // 那串大字号的图标网格就直接画在屏幕中央了。
        // 清成一个空格之后，即使那条 1.0 的标签可见，画的也只是一个空格 ✓。
        sendActionbar(player, " ");
        sendBoxTitle(
          player,
          boxPeek.lastText,
          previewShapeToken(
            boxPeek.typeId,
            boxPeek.contents.containerSize,
            runtime.LAYOUT_AS_GRID
          )
        );
        sendSubtitle(player, boxPeek.lastCounts);
        boxPeek.lastSentTick = tick;
      }
      return {
        typeId: boxPeek.typeId,
        kind: "box",
        text: boxPeek.lastText,
        counts: boxPeek.lastCounts
      };
    }
  }

  let contents = null;
  let targetKind = "block";
  let targetId = "";
  // 目标位置：只给角标缓存用（见 targetLocationKey）。取不到就是 "?"。
  let targetLocation = "?";

  // 方块优先（准星通常先命中方块）；方块不是容器再试实体
  const block = lookedBlock(player, runtime.REACH_DISTANCE);
  if (block) {
    contents = readBlockContainer(block);
    if (!contents) contents = readSpecialBlockContent(block);
    if (contents) {
      targetId = String(block.type).replace("minecraft:", "");
      targetLocation = targetLocationKey(block, null);

      // 合成器等方块：附加"被禁用的槽位"。这些格子放不进物品但仍然存在，
      // 排版时画成禁用字形 —— 否则被锁住的格子与空格子外观完全相同。
      const disabled = readDisabledSlots(block);
      if (disabled && disabled.length > 0) {
        contents.disabledSlots = disabled;
        // 指纹必须包含禁用状态：否则锁上一格后内容物未变，指纹不变导致 HUD 不刷新。
        contents.fingerprint += "|dis:" + disabled.join(",");
      }
    }
  }
  if (!contents) {
    const entity = lookedEntity(player, runtime.REACH_DISTANCE);
    if (entity && isContainerEntityType(entity.type)) {
      contents = readEntityContainer(entity);
      if (contents) {
        targetKind = "entity";
        targetId = String(entity.type).replace("minecraft:", "");
        targetLocation = targetLocationKey(null, entity);
      }
    }
  }

  // 未命中容器：**连续几次都没命中**才清屏。
  //
  // 为什么要容忍几次：射线偶尔会漏（准星压在方块边角、客户端那一帧的视角还没同步、
  // 目标实体短暂离开判定盒）—— 一次没命中就清屏的表现是**预览自己闪一下没了又回来**，
  // 用户报的"注视容器的时候预览会自动消失"就是这个。容忍窗口取 3 次轮询（默认 6 tick
  // ≈ 0.3 秒）：真的移开视线时最多多显示 0.3 秒，而偶发的漏判不会造成闪烁。
  //
  // ⚠️ 清屏顺序与预览路径**相反**：先发 actionbar（把文本换成空格）再发 title。
  // 反过来会出现一帧"旧的图标串 + 新的判据"—— 那一帧资源包按 1.0 倍字号渲染旧文本。
  // 两边都是同一个原则：**让判据先于被它分类的文本生效**（开始看：title → actionbar；
  // 停止看：actionbar → title）。
  if (!contents) {
    const misses = (missByPlayer.get(key) || 0) + 1;
    missByPlayer.set(key, misses);
    if (lastByPlayer.has(key)) {
      tracePreview(key, "未命中容器 第 " + misses + " 次" +
        (misses >= CONTAINER_MISS_TOLERANCE ? "（超过容忍次数，清屏）" : "（还在容忍窗口内，保持显示）"));
    }
    if (misses >= CONTAINER_MISS_TOLERANCE && lastByPlayer.has(key)) {
      sendActionbar(player, " ");
      sendTitle(player, "");
      sendSubtitle(player, "");
      lastByPlayer.delete(key);
      missByPlayer.delete(key);
    }
    return null;
  }
  missByPlayer.delete(key);

  // ===== 三种"要不要发包"的情形（与行为包 main.js 同一套口径）=====
  //   ① 内容变了（指纹不同）—— 功能本身，必须重排重发；
  //   ② 到点该重读了（HUD_REFRESH_TICKS）—— 容器内容变化要能反映出来；
  //   ③ 到点该重发了（HUD_RESEND_TICKS）—— 原版 actionbar 自己会淡出，靠重发压住。
  // 三者都不是时**不发包**，也不重排（排版是这套东西里最贵的一步）。
  const previous = lastByPlayer.get(key);
  // 内容指纹：**唯一出处**是 box_cache.contentKey（发送去重与扫描缓存共用同一个键，
  // 免得两处各拼一遍字符串、改一处忘一处）。
  const fingerprint = contentKey(targetKind, targetId, contents);
  const contentChanged = !previous || previous.fingerprint !== fingerprint;
  const dueToRefresh = !previous || tick - (previous.lastReadTick || 0) >= refreshTicks();
  const dueToResend = previous && tick >= (previous.nextResendTick || 0);

  let text = previous ? previous.text : null;
  let counts = previous ? previous.counts : null;
  let shapeToken = previous ? previous.shape : null;

  if (force || contentChanged || dueToRefresh || !text) {
    // ===== 潜影盒那一格（每人独立开关）=====
    //
    // 关掉时**一次 NBT 都不读**（连扫描都不进）—— 这是"关掉就零开销"的保证，
    // 自测里有断言盯着这个写法。
    //
    // 一格画什么由 `overlayFor()` 决定（角标 / 空白）；本模块不再自己拼条件。
    let overlayForSlot;
    if (runtime.BOX_BADGE_ENABLED !== false) {
      const scanned = boxRecordsFor(targetLocation + "|" + fingerprint, contents);
      if (scanned.boxCount > 0) {
        overlayForSlot = function (slot) {
          return overlayFor(scanned.bySlot.get(slot));
        };
      }
    }
    // 预览正文打标记字形（见 markPreviewText）：图标走 title、数目走 subtitle，
    // 两层都带，保持与行为包同一条文本骨架。
    //
    // ⚠️ **向上移动**（`/peek:top` 取负数）只能靠"在两层文本末尾补换行"实现：
    // 填充层（pad）的机制是"在网格上方加一块高度"，高度不可能为负，所以它只能往下推。
    // 在**居中标签**末尾补 N 个换行 = 内容整体上移 N/2 行（与 boxShiftedText 同一套算法）。
    // 两层必须补**一样多**，否则数字会相对图标错开。
    const upLines = upShiftLines();
    const upPad = upLines > 0 ? "\n".repeat(upLines) : "";
    text = markPreviewText(formatContents(targetId, contents)) + upPad;
    counts = markPreviewText(formatCounts(targetId, contents, overlayForSlot)) + upPad;
    // 渲染形状 + **缩放档位**（5 字符，见 grid_shapes.js 的 previewTitleField）：
    // 资源包按它选"写死尺寸的底衬变体"与"哪一套字号的图标/数目层"。
    shapeToken = previewTitleField(
      targetId,
      contents.containerSize,
      runtime.LAYOUT_AS_GRID,
      runtime.PREVIEW_SCALE
    );
  }

  if (force || contentChanged || dueToRefresh || dueToResend || !previous) {
    // ===== 通道分配（本轮重排：图标搬进 title，与判据同源）=====
    //
    //   title    = 图标串（带标记 + 形状字段）
    //   subtitle = 数目串
    //   actionbar= 顶部填充（P 个换行，没有墨迹 ---- 只负责把网格从锚点往下推）
    //
    // **为什么图标要放 title**：资源包认"这条预览是不是我们的"靠 title 通道的标记
    //（`peek::r…`）；判据在 title、文本在 actionbar 时，两个包分两帧应用 —— 中间只要
    // 有一帧 title 不是我们的（**引擎在打开容器/背包界面时会动 title**），整串图标就会
    // 按 1.0 倍字号画出来。用户报的"对着容器打开背包/容器时会闪一下巨大 UI"就是这个。
    // 文本与判据同源之后，这种不一致在结构上不可能出现，最坏只是空一帧。
    //
    // 顺序：填充（actionbar）→ 图标（title）→ 数目（subtitle）。
    // 数目**必须最后**：部分版本的引擎在收到 title 时会清掉字幕（原版字幕是标题的附属行），
    // 反过来不会。顺序写反的表现是"数字整层消失"，不报任何错。
    // ⚠️ 填充为空串时要发**一个空格**而不是 ""：引擎忽略空的 actionbar 消息，
    // 旧文本会留到自己淡出为止 —— 那样"往上挪"就会因为旧填充还在而失效。
    // 一个空格 = 1 行高（约 2.3 单位），所以负数档的实际位移比标称少半行，这是刻意的取舍。
    sendActionbar(player, formatTopPad() || " ");
    sendTitle(player, text, shapeToken);
    sendSubtitle(player, counts);
    tracePreview(key, "发包 tick=" + tick +
      (contentChanged ? " 内容变了" : "") + (dueToRefresh ? " 到点重排" : "") +
      (dueToResend ? " 到点重发" : "") +
      "　图标 " + text.length + " 字符 / 数目 " + counts.length + " 字符 / 形状 " + shapeToken);
  }

  lastByPlayer.set(key, {
    fingerprint: fingerprint,
    text: text,
    counts: counts,
    shape: shapeToken,
    // ⚠️ 只有**真的重排过**才更新"上次重排时刻"。
    //     早先这里无条件写 tick，于是 dueToRefresh 永远不成立 —— "重读间隔"那个旋钮
    //     实际是死旋钮（改了没有任何效果），而且不报错。
    lastReadTick: (force || contentChanged || dueToRefresh || !previous)
      ? tick
      : (previous.lastReadTick || tick),
    nextResendTick: tick + resendTicks()
  });

  return { typeId: targetId, kind: targetKind, text: text, counts: counts };
}

/** 重读间隔（tick）：旋钮值，读到荒唐值时退回默认值。 */
function refreshTicks() {
  const n = Math.floor(Number(runtime.HUD_REFRESH_TICKS));
  return isFinite(n) && n >= 1 ? n : 8;
}

/** 重发间隔（tick）：同上。给一点余量，让重发一定追得上原版 actionbar 的淡出。 */
function resendTicks() {
  const n = Math.floor(Number(runtime.HUD_RESEND_TICKS));
  return isFinite(n) && n >= 1 ? n : 4;
}

/** 潜影盒预览的纵向位移（行，正=下）：旋钮值，坏值退回 0。 */
function boxPosLines() {
  const n = Math.round(Number(runtime.BOX_POS_LINES));
  return isFinite(n) ? n : 0;
}

/** 潜影盒预览的横向位移（1/8 格，正=右）：旋钮值，坏值退回 0。 */
function boxHspaceUnits() {
  const n = Math.round(Number(runtime.BOX_HSPACE_UNITS));
  return isFinite(n) ? n : 0;
}

/**
 * 给潜影盒预览的正文套上**它自己那套位置**（与准星预览的旋钮无关）。
 *
 * ## 两个方向各自怎么实现的
 *
 *   · **横向**：借用格式器已有的"空格尺"机制 —— 它读 `runtime.HSPACE_UNITS` 往行首/行尾
 *     插不可见垫片。这里临时把这个键换成潜影盒自己的值，格式完再换回去：
 *     `format.js` 只认这一个键（不引引擎、可直接复用），为它再加一个参数就得动行为包
 *     共用的那份代码，代价比这里的"借用 + 还原"大得多。
 *   · **纵向**：JSON-UI 的 `offset` 绑不了运行期值，这条标签（左中锚点）能用的纵向杠杆
 *     只有**文本行数** —— 在上方加 N 个空行会把内容推下去 N/2 行，加在下方则上移 N/2 行。
 *     所以正数（向下）在行首加 2N 个换行、负数在行尾加 2|N| 个。
 *
 * ⚠️ 图标层与数目层必须用**同一个位移**，否则数字会和图标错开（盒子那套是两层分开的两个通道：
 *    图标走 title、数目走 subtitle）。
 */
function boxShiftedText(build, verticalLines, hspaceUnits) {
  const savedHspace = runtime.HSPACE_UNITS;
  let text;
  try {
    runtime.HSPACE_UNITS = hspaceUnits;
    text = build();
  } finally {
    runtime.HSPACE_UNITS = savedHspace;
  }
  const lines = Math.abs(verticalLines) * 2;
  if (lines > 0) {
    let pad = "";
    for (let i = 0; i < lines; i++) pad += "\n";
    text = verticalLines > 0 ? pad + text : text + pad;
  }
  return text;
}

function playerKey(player) {
  try {
    // LSE Player 有唯一标识；字段名随版本而异，依次尝试
    return String(player.uuid || player.xuid || player.realName || player.name || "");
  } catch (_err) {
    return "";
  }
}

/**
 * ===== 命令层：**原生优先、虚拟兜底** =====
 *
 * LSE 提供两套注册方式，差别**只在客户端能不能补全**：
 *   · `mc.newCommand(...)` —— 注册**真命令**：进引擎的命令表，客户端能看到命令名，
 *     参数（枚举/数字）也能下拉补全；
 *   · `mc.regPlayerCmd(...)` / `mc.regConsoleCmd(...)` —— **虚拟命令**：只在服务端
 *     拦截聊天栏里那条输入。执行完全正常，但客户端根本不知道它存在，**没有补全**。
 *
 * 所以：能用原生就全用原生；某条命令原生注册失败才退回虚拟（至少保证有得用），
 * 并把"当前用的是哪一种、几条走哪条路"写进启动日志与 `/peek:check` ——
 * 否则"到底有没有补全"只能靠玩家猜。
 *
 * 命令清单集中在 `commandSpecs()`：旋钮从 `settings.js` 的 SETTINGS 生成，
 * 查询/操作类在下面显式列出。**两条注册路径共用这一张表**，不各抄一份。
 */

/** 命令注册方式的现状（`/peek:check`、启动日志用）。 */
let commandStatus = {
  mode: "none",   // native | mixed | fake | none
  native: 0,
  fake: 0,
  total: 0,
  errors: []
};

/** 权限等级：优先用引擎给的枚举，取不到就用数字（LSE 两种写法都认，1 = OP）。 */
function commandPermission() {
  try {
    if (typeof PermType !== "undefined" && PermType && PermType.GameMasters !== undefined) {
      return PermType.GameMasters;
    }
  } catch (_err) { /* 用数字兜底 */ }
  return 1;
}

/** 参数类型：同上，优先用引擎枚举，取不到用数字。 */
function commandParamType(name) {
  const fallback = { Enum: 0, Int: 1, String: 2 };
  try {
    if (typeof ParamType !== "undefined" && ParamType && ParamType[name] !== undefined) {
      return ParamType[name];
    }
  } catch (_err) { /* 用数字兜底 */ }
  return fallback[name];
}

/** 去掉 § 颜色码（控制台日志不需要它）。 */
function stripColor(text) {
  return String(text === undefined || text === null ? "" : text).replace(/§./g, "");
}

/**
 * 控制台回执的文本清洗：去颜色码 + 去掉文本**自带**的 `[peek]` 前缀。
 *
 * 回执文本里本来带 `§a[peek] `（玩家在聊天栏看到的就是那个），而适配层的日志函数
 * 还会再补一个 `[peek] ` —— 不去掉就成了 `[peek] [peek] 自检（只读，不改世界）`。
 */
function stripConsolePrefix(text) {
  return stripColor(text).replace(/^\[peek\]\s*/, "");
}

/**
 * 回执出口：玩家走聊天栏、控制台走日志。
 *
 * 命令执行体只认这个接口（`say` / `lines`），于是同一份执行体在两条注册路径、
 * 两种来源（玩家 / 控制台）下都能用，不用各写一遍。
 */
function outputSink(player) {
  if (player) {
    return {
      player: player,
      key: playerKey(player),
      say: (msg) => tell(player, msg),
      lines: (list) => {
        for (let i = 0; i < list.length; i++) tell(player, list[i]);
      }
    };
  }
  return {
    player: null,
    key: "",
    // 控制台的"回执"走 `logAlways`：`/peek:log off` 关的是**没人要求**的常规信息，
    // 而"我敲了命令、要看结果"是有人要求的 —— 被关掉的话管理员会以为插件坏了。
    //
    // ⚠️ 顺手去掉回执文本**自带**的那个 `[peek]` 前缀：适配层的日志函数还会再加一个，
    // 不去掉的话控制台就成了 `[peek] [peek] 自检（只读，不改世界）`（以前就是这样）。
    say: (msg) => logAlways(stripConsolePrefix(msg)),
    lines: (list) => {
      for (let i = 0; i < list.length; i++) logAlways(stripConsolePrefix(list[i]));
    }
  };
}

/** `/peek:about` 的正文（署名与指纹）。 */
function aboutForChat() {
  return [
    "§a[peek] " + signatureLine(),
    "§7" + PROJECT_NAME + "　§8指纹 §f" + FINGERPRINT,
    "§7预览容器内容：准星对准容器；在容器/背包界面里点潜影盒看左边缘",
    "§7本插件只读，不修改任何游戏状态"
  ];
}

/**
 * `/peek:status` 的正文：全部旋钮的当前值 + 运行状态。
 *
 * @param {string} [key] 询问者的玩家标识：观感类旋钮按"**他会看到的值**"报，
 *        并标明来源（`自己` / `全局默认`）；性能类旋钮是全服的，只报一份。
 */
function statusLines(key) {
  const lines = [];
  lines.push("§a[peek] LSE 插件运行中");
  lines.push("§7轮询 " + pollTicks() + " tick　重读 " + refreshTicks() +
    " tick　重发 " + resendTicks() + " tick　距离 " + runtime.REACH_DISTANCE + " 格（全服）");
  if (key) {
    lines.push("§7下面带「自己」的是**只对你生效**的值；其余是全局默认（控制台改的就是它）");
    lines.push("§7你的个人设置共 " + playerViewCount(key) + " 项　配置: §f" + settingsBackendName());
    // 最常见的"怎么没反应"就是这条：某个玩家（或他自己）把总开关关掉了。
    // 个人设置会持久化，忘了自己关过的话，看起来就像插件坏了 —— 所以放在最显眼处提醒。
    if (!effectiveSettingValue(settingByName("display"), key)) {
      lines.push("§c⚠ 你把「容器预览」关掉了 —— 现在不管准星对着什么容器都不会有预览。");
      lines.push("§c  恢复：§f/peek:display on§c；全部恢复默认：§f/peek:reset");
    }
    if (!effectiveSettingValue(settingByName("boxbadge"), key)) {
      lines.push("§e⚠ 你关掉了「潜影盒角标」—— 盒子里装什么不会画出来。恢复：§f/peek:boxbadge on");
    }
  } else {
    lines.push("§7控制台视角：下面都是**全局默认值**（观感类旋钮玩家可各自覆盖）");
    lines.push("§7已保存个人设置的玩家: " + playerViews.size + " 名　配置: §f" + settingsBackendName());
  }
  for (let i = 0; i < SETTINGS.length; i++) {
    const s = SETTINGS[i];
    const value = effectiveSettingValue(s, key);
    let source = "§8默认";
    if (s.scope === "global") {
      source = "§8全服" + (runtime[s.runtime] !== s.value ? "（已改）" : "");
    } else {
      const view = key ? playerViews.get(key) : null;
      const own = view && Object.prototype.hasOwnProperty.call(view, s.name);
      if (own) source = "§a自己";
      else if (runtime[s.runtime] !== s.value) source = "§e全局默认";
    }
    lines.push("§7  " + describeSettingValue(s, value) + "　" + source + "　§f/peek:" + s.name + "§7 " + s.label);
  }
  return lines;
}

/** `/peek:usage` 的正文（指令一览，取值从 settings.js 取）。 */
function usageLines() {
  const find = (name) => {
    for (let i = 0; i < SETTINGS.length; i++) if (SETTINGS[i].name === name) return SETTINGS[i];
    return null;
  };
  const range = (name) => {
    const s = find(name);
    return s ? s.min + "-" + s.max : "?";
  };
  return [
    "§a[peek] 指令一览（都需要 OP 权限）",
    "§7总开关：/peek:display、/peek:box、/peek:backdrop",
    "§7位置：/peek:top <" + range("top") + ">、/peek:hspace <" + range("hspace") + ">（准星预览）",
    "§7　　　/peek:boxpos <" + range("boxpos") + ">、/peek:boxhspace <" + range("boxhspace") + ">（潜影盒预览，独立）",
    "§7性能（全服）：/peek:poll、/peek:refresh、/peek:resend、/peek:reach",
    "§7查询：/peek:status、/peek:check、/peek:usage、/peek:about、/peek:trace、/peek:reset",
    "§7排查：/peek:hudtest —— 在屏幕上画几行文字（图标是方框/问号 = 客户端没装资源包）",
    "§7作用域：上面的观察类旋钮**每人独立**（在游戏内敲只改你自己；控制台敲改全局默认），",
    "§7　　　　性能类旋钮是全服的；开关类省略参数 = 切换；改动写进配置文件（重启后仍在）"
  ];
}

/** 切换库存变动日志（诊断点击链路用）。 */
function toggleTrace(sink) {
  traceInventory = !traceInventory;
  logInfo("库存变动日志" + (traceInventory ? "已开启" : "已关闭"));
  sink.say("§a[peek] 库存变动日志" + (traceInventory ? "已开启" : "已关闭"));
  if (traceInventory) sink.say("§7在容器里点几下潜影盒，服务端会把每次变动记下来");
}

/**
 * `/peek:hudtest`：把"排查显示问题"要看的几行**原版文字**画到玩家屏幕上。
 *
 * 三个设计点：
 *   · **再敲一次 = 立刻结束**（不用等 15 秒，也方便连着对比两种状态）；
 *   · 到点**自动恢复**预览，不需要玩家记得关；
 *   · 同时把同样的三行发一份进**聊天栏**：屏幕上那几行会淡出、也进不了聊天记录，
 *     发一份到聊天里，玩家可以直接复制或截图发给别人。
 *
 * 控制台执行没有意义（屏幕上没东西可画）——照实说，而不是静默什么都不做。
 */
function toggleHudTest(sink) {
  const key = sink.key;
  if (!key || !sink.player) {
    sink.say("§c[peek] 这条命令要**在游戏里**由玩家执行：它是在屏幕上画自检文字");
    return;
  }
  const running = hudTestUntil.get(key);
  if (running && tick < running.until) {
    hudTestUntil.delete(key);
    // 立刻把三条通道清掉：自检那三行走的是**原版**渲染，不清就得等它自己淡出 ——
    // 而"再敲一次 = 立刻结束"这句话的意思就是**立刻**（display 关着的时候更明显：
    // 那条路径本来就不会发清屏包）。
    sendActionbar(sink.player, " ");
    sendTitle(sink.player, "");
    sendSubtitle(sink.player, "");
    lastByPlayer.delete(key);
    sink.say("§a[peek] 显示自检已结束");
    return;
  }
  const seconds = Math.round(hudTestTicks() / 20);
  hudTestUntil.set(key, { until: tick + hudTestTicks(), lastSentTick: 0 });
  sink.lines(hudTestTexts({
    itemGlyph: itemGlyph,
    knobs: hudTestKnobSnapshot(key),
    seconds: seconds
  }).chat);
  // 立刻发一次（不等下一次轮询，免得玩家以为命令没生效）
  updatePlayer(sink.player, true);
}

/**
 * 命令表。
 *
 * 字段：
 *   name   命令名（含 `peek:` 前缀）
 *   desc   描述（原生注册时进客户端命令表，玩家在补全列表里能看到）
 *   param  原生注册用的那**一个可选参数**（null = 无参数）
 *   run    执行体：`run(raw, sink)`；raw 是参数原始值（开关为字符串、数字为数字、未给为 undefined）
 */
function commandSpecs() {
  const specs = [];

  // 旋钮：从 settings.js 生成（指令名、取值说明、执行体都在这里定，文档也从那张表生成）
  for (let i = 0; i < SETTINGS.length; i++) {
    const s = SETTINGS[i];
    // 补全列表里那一行**只放功能简介**（settings.js 的 brief）：
    // 客户端本来就会把参数枚举列出来，再写一遍取值/「只对自己生效」既啰嗦、在手机小屏上也看不全。
    // 取值、默认值、作用域这些细节都在交付包里的《指令速查.md》与 /peek:usage 里。
    specs.push({
      name: "peek:" + s.name,
      desc: s.brief || s.label,
      param: (s.kind === "toggle"
        ? { name: "value", kind: "Enum", enumName: "PeekToggle", values: ["on", "off"] }
        : (s.kind === "enum"
            ? {
                name: "value",
                kind: "Enum",
                enumName: "Peek" + s.name.charAt(0).toUpperCase() + s.name.slice(1),
                values: s.values || []
              }
            : { name: "value", kind: "Int" })),
      run: function (raw, sink) {
        // sink.key 是执行者标识：玩家身份 → 只改他自己那份；控制台 → 改全局默认
        const result = applySetting(s, raw, sink.key);
        sink.say((result.ok ? "§a[peek] " : "§c[peek] ") + result.message);
      }
    });
  }

  specs.push({
    name: "peek:status",
    desc: "查看全部旋钮的当前值与运行状态",
    param: null,
    run: function (raw, sink) { sink.lines(statusLines(sink.key)); }
  });
  specs.push({
    name: "peek:check",
    desc: "非破坏性自检：逐项验证预览链路，只读不改世界",
    param: null,
    run: function (raw, sink) { sink.lines(runSelfCheck(sink.key)); }
  });
  specs.push({
    name: "peek:usage",
    desc: "显示指令一览",
    param: null,
    run: function (raw, sink) { sink.lines(usageLines()); }
  });
  specs.push({
    name: "peek:reset",
    desc: "恢复默认值",
    param: null,
    run: function (raw, sink) {
      sink.say("§a[peek] " + resetSettings(sink.key));
    }
  });
  specs.push({
    name: "peek:about",
    desc: "查看本插件名称、署名与指纹",
    param: null,
    run: function (raw, sink) { sink.lines(aboutForChat()); }
  });
  specs.push({
    name: "peek:trace",
    desc: "开关库存变动日志，用来排查点击预览不生效",
    param: null,
    run: function (raw, sink) { toggleTrace(sink); }
  });
  specs.push({
    name: "peek:hudtest",
    desc: "在屏幕上显示自检文字，用来排查看不到预览或图标变方框的问题（再敲一次结束）",
    param: null,
    run: function (raw, sink) { toggleHudTest(sink); }
  });

  return specs;
}

/**
 * 用**原生 API** 注册一条命令（客户端能看到、参数能补全）。
 *
 * 任何一步不支持就抛出去，由调用方退回虚拟注册 —— 不要在这里"尽力而为"地降级，
 * 否则会出现"命令能跑但没人知道为什么没补全"。
 */
function registerNativeCommand(spec) {
  const cmd = mc.newCommand(spec.name, spec.desc, commandPermission());
  if (!cmd || typeof cmd.overload !== "function" || typeof cmd.setCallback !== "function" ||
      typeof cmd.setup !== "function") {
    throw new Error("命令对象缺少 overload / setCallback / setup");
  }

  if (spec.param) {
    if (spec.param.kind === "Enum") {
      if (typeof cmd.setEnum !== "function") throw new Error("命令对象没有 setEnum（枚举补全做不了）");
      cmd.setEnum(spec.param.enumName, spec.param.values || ["on", "off"]);
      cmd.optional(spec.param.name, commandParamType("Enum"), spec.param.enumName);
    } else {
      cmd.optional(spec.param.name, commandParamType("Int"));
    }
    cmd.overload([spec.param.name]);
  } else {
    cmd.overload([]);
  }

  cmd.setCallback(function (_cmd, origin, _output, results) {
    const player = origin && origin.player ? origin.player : null;
    const sink = outputSink(player);
    let raw;
    if (spec.param && results) raw = results[spec.param.name];
    if (raw === null || raw === undefined) raw = undefined;
    else if (typeof raw !== "string" && typeof raw !== "number") raw = String(raw);
    spec.run(raw, sink);
    return true;
  });

  cmd.setup();
}

/** 用**虚拟 API** 注册一条命令（没有补全，但保证能用）。 */
function registerFakeCommand(spec) {
  try {
    mc.regPlayerCmd(spec.name, spec.desc, (pl, args) => {
      const raw = args && args.length > 0 ? args[0] : undefined;
      spec.run(raw, outputSink(pl));
    }, 0);
  } catch (err) {
    logInfo(spec.name + " 虚拟注册失败（玩家）: " + err);
  }
  try {
    mc.regConsoleCmd(spec.name, spec.desc, (args) => {
      const raw = args && args.length > 0 ? args[0] : undefined;
      spec.run(raw, outputSink(null));
    });
  } catch (err) {
    logInfo(spec.name + " 虚拟注册失败（控制台）: " + err);
  }
}

/** 命令注册方式的一句话描述（`/peek:check` 与启动日志共用）。 */
function commandStatusLabel() {
  const s = commandStatus;
  if (s.mode === "native") return "原生 " + s.native + " 条（客户端**有**参数补全）";
  if (s.mode === "mixed") {
    return "原生 " + s.native + " 条 / 虚拟 " + s.fake + " 条（虚拟那几条没有补全）";
  }
  if (s.mode === "fake") return "全部虚拟 " + s.fake + " 条（客户端**没有**参数补全）";
  return "未注册";
}

/**
 * 注册全部命令：先试原生（有补全），失败的那几条退回虚拟（能跑但没补全）。
 *
 * 命令名一律带 `peek:` 前缀，且避开原版同名命令（`title` / `help` / `list` / `clear` 等）——
 * 行为包那边同样的口径（`usage` 而不是 `help`、`header` 而不是 `title`），两边文档对得上。
 */
function registerCommands() {
  const specs = commandSpecs();
  const fallback = [];
  const errors = [];
  let native = 0;

  if (typeof mc.newCommand === "function") {
    for (let i = 0; i < specs.length; i++) {
      try {
        registerNativeCommand(specs[i]);
        native++;
      } catch (err) {
        errors.push(specs[i].name + "：" + err);
        fallback.push(specs[i]);
      }
    }
  } else {
    errors.push("这个 LSE 版本没有 mc.newCommand（只能注册虚拟命令）");
    for (let i = 0; i < specs.length; i++) fallback.push(specs[i]);
  }

  for (let i = 0; i < fallback.length; i++) registerFakeCommand(fallback[i]);

  commandStatus = {
    mode: native === specs.length ? "native" : (native > 0 ? "mixed" : "fake"),
    native: native,
    fake: fallback.length,
    total: specs.length,
    errors: errors
  };

  logInfo("命令注册: " + commandStatusLabel());
  if (errors.length > 0) {
    logInfo("  原生注册失败的原因（前 3 条）: " + errors.slice(0, 3).join(" / "));
  }
}

/** 是否把库存变动打进控制台（诊断用，默认关）。 */
let traceInventory = false;

/** 把一个槽位上的物品描述成类型名（诊断用）。 */
function describeStack(stack) {
  if (!stack) return "空";
  try {
    if (typeof stack.isNull === "function" && stack.isNull() === true) return "空";
    const type = stack.type === undefined ? stack.typeId : stack.type;
    const count = stack.count === undefined ? stack.amount : stack.count;
    return String(type) + " x" + count;
  } catch (_err) {
    return "<读不出>";
  }
}

/**
 * 判定本次库存变动发生在哪一侧（诊断用）。
 *
 * LSE 的 `onInventoryChange(player, slot, oldItem, newItem)` 不提供容器身份
 * （源码里的 `Container&` 参数未传入 JS），而槽位号本身分不出侧别：
 * 箱子是 0..26、玩家背包是 0..35，严重重叠。
 *
 * 判据：事件发生后再读取玩家背包同一槽位的当前内容。
 *   · 事件称"槽位 8 空了"，背包槽位 8 也确实空着 → 变动发生在玩家背包；
 *   · 事件称"槽位 8 空了"，背包槽位 8 里仍有该潜影盒 → 变动发生在别处（箱子），
 *     即箱子侧的变动同样会经过这个钩子。
 */
function inventorySideAfter(player, slot) {
  try {
    const inv = typeof player.getInventory === "function" ? player.getInventory() : null;
    if (!inv) return "<拿不到背包>";
    const size = inv.size;
    if (!(slot >= 0) || slot >= size) return "槽位超出背包（背包 " + size + " 格）";
    return "背包该槽位现在=" + describeStack(inv.getItem(slot));
  } catch (err) {
    return "<读背包出错>";
  }
}

/**
 * 盒预览的显示状态（每玩家一份）。
 *
 * 在打开的容器/背包界面中点击潜影盒，即在该玩家的屏幕左边缘（容器面板覆盖不到处）
 * 绘制内容网格 —— 与准星预览同一套锐利图标，完全不修改物品。
 *
 * 信号为何是"点击"而非悬停：悬停是纯客户端行为，无网络包也无事件，服务器无从得知
 * 指向哪个槽位；槽位移动（点击）有网络包，是服务器唯一能拿到的"指的是这一个"信号。
 *
 * 为何能画在容器界面上：容器界面打开时 `hud_screen` 仍在渲染，只是屏幕中央被容器
 * 面板与一层暗色滤镜压住，四角四边的标记均可见，故预览置于左边缘；资源包侧靠
 * `peek::box::` 标记（见 scripts/hud_protocol.js 的 BOX_MARKER）把该文本画到左边缘那套控件上。
 */
const boxPeekByPlayer = new Map();

/**
 * 盒预览显示多久（tick）。
 *
 * 100 tick = 5 秒。**为什么是 5 秒而不是 15 秒**：盒预览存在期间**准星预览整体让位**
 *（见 updatePlayer 的盒预览分支），而"界面关了但玩家没转视角"这一刻检测不到
 *（背包没有关闭事件，`onCloseContainer` 只挂在箱子/木桶上）—— 于是 TTL 就是让位的
 * 最坏时长。15 秒时用户会看到"盯着容器却一直没有预览、过一会儿自己好了"，
 * 现在改成 5 秒：还想继续看就再点一下盒子（点击会续期）。
 */
const BOX_PEEK_TTL_TICKS = 100;

/**
 * 盒预览"刚点过"的保持窗口（tick）：这段时间内即使准星对着容器也让位给盒预览。
 *
 * 40 tick = 2 秒，够看一眼盒子内容。超过之后若准星正对着容器，就交回准星预览
 *（见 updatePlayerInner 里那条判据）—— 玩家想继续看盒子再点一下即可（点击会续期）。
 */
const BOX_PEEK_HOLD_TICKS = 40;

/**
 * 盒预览文本原样重发的间隔（tick）。
 *
 * title/subtitle 是限定寿命的整条消息（stay 60 tick ≈ 3 秒）：只发一次的话，
 * TTL 未到而文本已被引擎当过期消息收走。内容与指纹不变时只重发已排好版的缓存串
 * （不重排），代价是每 10 tick 两条 setTitle，开销极低。
 * 该兜底只用在盒预览，因为其 TTL（300 tick）远长于一条消息的寿命。
 */
const BOX_RESEND_EVERY_TICKS = 10;

/**
 * 玩家"界面开着"的截止 tick（容器界面或背包界面）。
 *
 * 存在理由：加入服务器时会有一次背包同步，那一瞬间对背包内每个潜影盒各触发一次
 * `onInventoryChange`（一次连发二十余条）。缺少这道门，进服即会弹出某个盒子的内容预览。
 *
 * 计时的起点是 `onOpenContainer` / `onOpenInventory`，之后每次切换界面或操作潜影盒续期。
 */
const uiOpenUntil = new Map();

/** "界面开着"状态的保持时长（tick）：1200 tick = 60 秒，操作潜影盒会续期。 */
const UI_OPEN_TTL_TICKS = 1200;

/**
 * 把刚点过的潜影盒记为预览目标。
 *
 * @param {object} player LSE Player（用于记录生成时的视线快照，见 boxPeekShouldDrop）
 * @param {string} key 玩家标识
 * @param {object} stack 事件中的物品对象；**仅在事件期间**读取其 NBT 是安全的
 * @returns {boolean} 是否成功建立盒预览
 */
function setBoxPeek(player, key, stack) {
  if (!key || !stack) return false;
  // 总开关：`/peek:box off` 之后点击不再触发（已经在显示的那份由 applySetting 收掉）
  if (runtime.BOX_PEEK_ENABLED === false) return false;

  let typeId = "";
  try {
    typeId = String(stack.type).replace("minecraft:", "");
  } catch (_err) {
    return false;
  }
  if (!isShulkerBox(typeId)) return false;

  const raw = readShulkerItemContents(stack);
  if (!raw) return false;

  // readShulkerItemContents 返回 [{slot,id,count}]，排版需要
  // {containerSize, items:[{slot,typeId,amount}]}；潜影盒固定 27 格
  const items = [];
  for (let i = 0; i < raw.length; i++) {
    items.push({ slot: raw[i].slot, typeId: raw[i].id, amount: raw[i].count });
  }
  const contents = {
    containerSize: 27,
    items: items,
    fingerprint: items.map((it) => it.slot + ":" + it.typeId + "x" + it.amount).join("|") || "empty"
  };

  boxPeekByPlayer.set(key, {
    typeId: typeId,
    contents: contents,
    fingerprint: typeId + "|" + contents.fingerprint,
    until: tick + BOX_PEEK_TTL_TICKS,
    // 生成/续期时刻：让位逻辑用它区分"刚点过盒子"与"界面早就关了"（见 updatePlayerInner）
    armedTick: tick,
    sent: "",
    lastText: "",
    lastCounts: "",
    lastSentTick: 0,
    // 生成时刻的视线快照，供"视线已转过"判据使用（见 boxPeekShouldDrop）。
    // 不记录位置快照：位置分不清主动移动与被动位移。
    view: readPlayerView(player)
  });

  // ⚠️ 立刻把 actionbar 清成空格 —— 用户报的"对着容器打开背包还是会出现巨大 UI"。
  //
  // 进入盒预览后 title 变成 `peek::box::…`，资源包据此判定"不是准星预览"，
  // 于是走 **1.0 倍字号**那条标签；而 actionbar 里此刻还留着**上一次准星预览的图标串**
  //（进盒预览不会自动清它）→ 那串图标就按 4 倍大小画在屏幕中央。
  // 换成空格之后，即使那条 1.0 的标签还可见，画的也只是一个空格。
  sendActionbar(player, " ");
  return true;
}


/**
 * 准星是不是正对着"有内容可看的东西"（容器方块或容器实体）。
 *
 * 只给"盒预览该不该交回准星预览"这一条判据用（见 updatePlayerInner）：
 * 刻意**不读容器内容** —— 每个 tick 都要问一次，读 27 格 getItem 不划算。
 */
function lookedAtPreviewable(player) {
  try {
    if (isPreviewableBlock(lookedBlock(player, runtime.REACH_DISTANCE))) return true;
    const entity = lookedEntity(player, runtime.REACH_DISTANCE);
    if (entity && isContainerEntityType(String(entity.type))) return true;
  } catch (_err) {
    // 取不到就当"没对着容器"：宁可让盒预览多留一会儿，也不要误收
  }
  return false;
}

/**
 * "已离开界面"的视线旋转阈值（度）：相对生成时刻转过该角度即判定界面已关。
 *
 * 仅保留"转视角"这一条判据：容器/背包界面打开时镜头是锁死的（鼠标/手指都在操作
 * 界面），故"视线变了"足以证明界面已关，而且它是**纯输入驱动**的 —— 水流、活塞、
 * 爆炸、泡柱都推不动镜头。
 *
 * "位置变了"不具备该性质：位移是结果，水流推动、活塞推、爆炸、泡柱、坐船坐矿车
 * 都会产生无输入位移，引擎也不告知该位移是否由按键产生（LSE 事件表里没有移动事件；
 * 官方的 `player.inputInfo.getMovementVector()` 只有行为包拿得到，插件侧没有）。
 * 用"位移大小窗口 + 在不在液体里"去猜终究是猜，误收的代价大于收益，
 * 故只保留"转视角"这一条：行为确定、不会误触发。
 *
 * 界面关闭后完全静止且不转视角的情形，由 15 秒 TTL 兜底（见 BOX_PEEK_TTL_TICKS）。
 *
 * 阈值取 3 度：客户端存在轻微抖动，阈值过小会误判。
 */
const VIEW_TURN_EPSILON_DEG = 3;

/** 取玩家视线（度）。不可用时返回 null，调用方据此跳过该判据。 */
function readPlayerView(player) {
  try {
    const d = player && player.direction;
    if (!d) return null;
    const yaw = Number(d.yaw);
    const pitch = Number(d.pitch);
    if (!isFinite(yaw) || !isFinite(pitch)) return null;
    return { yaw: yaw, pitch: pitch };
  } catch (_err) {
    return null;
  }
}

/**
 * 盒预览是否应当收掉 —— 即能否证明玩家已离开界面。
 *
 * **唯一判据：视线相对生成时刻已转过阈值角度。**
 *
 * 不以"视线落在别的容器方块上"为判据：界面打开期间镜头锁死，而打开界面本身就是
 * 看着那个容器方块按下的，故点击界面内潜影盒的那一刻准星**必然**正对该容器方块；
 * 按该判据实现，预览会在生成的那一帧被自己收掉，点击等于没反应。
 *
 * "视线**变了**"没有这个问题且覆盖同一场景：要去看别的容器方块总得转过视角，
 * 一转即证明界面已关，预览顺势收掉并由准星预览接管。
 *
 * @returns {string} 空串 = 继续显示；否则为收掉理由（写入日志，便于复盘）
 */
function boxPeekShouldDrop(player, boxPeek) {
  const view = readPlayerView(player);
  if (!view || !boxPeek.view) return "";

  let dyaw = Math.abs(view.yaw - boxPeek.view.yaw);
  if (dyaw > 180) dyaw = 360 - dyaw;
  const dpitch = Math.abs(view.pitch - boxPeek.view.pitch);

  if (dyaw > VIEW_TURN_EPSILON_DEG || dpitch > VIEW_TURN_EPSILON_DEG) {
    return "视线已转过（镜头锁死 => 界面已关）yaw差=" + dyaw.toFixed(1) +
      "° pitch差=" + dpitch.toFixed(1) + "°";
  }
  return "";
}


/**
 * 安全注册一个 LSE 事件。
 *
 * ⚠️ 该函数必须是**顶层**函数：局部 helper 不能跨函数复用，一旦被别的 installer
 * 调用就会抛 `listenSafely is not defined`，导致 registerCommands 之后的注册全部中断。
 *
 * mc.listen 对不认识的事件名返回 false，故把注册结果打进日志 ——
 * 静默失败会表现为"功能偶尔不生效"。
 */
function listenSafely(eventName, handler) {
  try {
    const ok = mc.listen(eventName, handler);
    logInfo("事件 " + eventName + " 注册: " + (ok ? "成功" : "失败（这个版本没有该事件）"));
    return ok;
  } catch (err) {
    logInfo("事件 " + eventName + " 注册抛错（不影响预览）: " + err);
    return false;
  }
}

/**
 * 注册预览相关的事件。
 *
 * ⚠️⚠️ 三条铁律，任何一条破了都会**影响玩家操作**：
 *   1. 这些事件的回调返回 false 会**取消事件本身**
 *      （onOpenContainer 取消 = 箱子打不开；onInventoryChange 取消 = 物品移动被拦），
 *      故每个回调都必须显式 `return true`，即使什么也没做；
 *   2. 整个回调体包在 try/catch 里 —— 异常绝不允许冒出去；
 *   3. 只读，不修改任何游戏状态。
 */
function installPreviewHooks() {
  // 打开容器：只做两件事 —— 记录"界面开着"，以及诊断日志留痕
  listenSafely("onOpenContainer", (player, block) => {
    try {
      const key = playerKey(player);
      if (!key) return true;

      // 记录"界面开着"（供盒预览判断）—— 见 uiOpenUntil 的说明
      uiOpenUntil.set(key, tick + UI_OPEN_TTL_TICKS);

      if (traceInventory) {
        let ctype = "?";
        let csize = "?";
        try {
          const container = block && typeof block.getContainer === "function" ? block.getContainer() : null;
          if (container) {
            ctype = String(container.type);
            csize = String(container.size);
          }
        } catch (_err) {
          // 读取失败即忽略
        }
        logAlways("[peek-open] 打开容器 type=" + ctype + " size=" + csize +
          " 方块=" + String(block && block.type));
      }

      // ⚠️ **立刻重发一次预览**：引擎在打开界面时会动 title 通道，而资源包整套判据
      //（"这条预览是不是我们的"）都挂在 title 上 —— 不重发的话，判据落空的窗口
      // 就取决于下一次轮询（默认 2 tick）。用户报的"对着容器打开背包/容器时会闪一下
      // 巨大 UI"就是这类窗口的表现。重发一次把窗口压到**同一个 tick 内**。
      forceRefresh(player);
    } catch (err) {
      logInfo("onOpenContainer 处理失败（忽略）: " + err);
    }
    return true;
  });

  // 关闭容器：立刻撤掉左边缘的盒预览
  //（否则关掉箱子后预览还会留在屏幕上直到 TTL 结束）
  listenSafely("onCloseContainer", (player) => {
    try {
      const key = playerKey(player);
      if (key) {
        uiOpenUntil.delete(key);
        // 箱子/木桶的关闭事件是 LSE 唯一提供的"界面关闭"信号（见
        // installBoxPeekDismissHooks 的说明），故能收就立刻收
        dropBoxPeek(player, "容器已关闭");
      }
    } catch (_err) {
      // 忽略
    }
    return true;
  });

  // 打开玩家自身的背包界面
  listenSafely("onOpenInventory", (player) => {
    try {
      const key = playerKey(player);
      // 记录"界面开着"（供盒预览判断）—— 见 uiOpenUntil 的说明
      if (key) uiOpenUntil.set(key, tick + UI_OPEN_TTL_TICKS);
      // 理由同 onOpenContainer：界面切换时 title 通道会被引擎动一下，
      // 而我们整套判据都挂在 title 上 —— 立刻重发一次，别等下一次轮询。
      forceRefresh(player);
    } catch (err) {
      logInfo("onOpenInventory 处理失败（忽略）: " + err);
    }
    return true;
  });

  // 物品移动：这是"目标潜影盒"的唯一信号
  listenSafely("onInventoryChange", (player, slot, oldItem, newItem) => {
    try {
      const key = playerKey(player);

      // 库存一动，扫描缓存就作废（失效入口统一在 box_cache.invalidate）。
      //
      // 为什么非作废不可：缓存的键是"容器位置 + 容器**外层**内容指纹"，而指纹是
      // `槽位:物品id x数量` —— **不含盒子内部的 NBT**。于是"把箱子里的 A 盒拿走、
      // 换成外观完全一样的 B 盒"这个动作**指纹不变**，缓存会把 A 的角标继续贴给 B
      //（换盒子必然产生库存变动事件，所以在这里作废刚好覆盖这个口子）。
      invalidate("库存变动 slot=" + slot);

      // 诊断：记录每一次库存变动（由 `/peek:trace` 开关控制）。
      if (traceInventory) {
        const uiOpen = key && tick < (uiOpenUntil.get(key) || 0) ? "界面开着" : "界面没开";
        logAlways("[trace] 库存变动 slot=" + slot + "  " +
          describeStack(oldItem) + " -> " + describeStack(newItem) + "  （" + uiOpen + "，" +
          inventorySideAfter(player, slot) + "）");
      }

      // 变动的那一格是否涉及潜影盒（拿起与放下都算）
      let isShulker = false;
      try {
        isShulker = isShulkerBox(String(newItem && newItem.type).replace("minecraft:", "")) ||
          isShulkerBox(String(oldItem && oldItem.type).replace("minecraft:", ""));
      } catch (_err) {
        isShulker = false;
      }

      // 涉及潜影盒的变动默认记一条：这类事件很少（搬潜影盒才触发），
      // 且是点击预览异常时的唯一线索。
      //
      // ⚠️ 走 `logAlways`：它属于"出问题时要看的东西"，不该被 `/peek:log off` 吞掉 ——
      // 频率也确实很低（只有搬动潜影盒才触发），留着不碍事。
      if (isShulker) {
        logAlways("[peek-shulker] 库存变动 slot=" + slot + "  " +
          describeStack(oldItem) + " -> " + describeStack(newItem) + "  （" +
          inventorySideAfter(player, slot) + "）");
      }

      if (isShulker && key) {
        // 把**刚点过的那个盒子**记为预览目标。
        //
        // ⚠️ 先判断"界面是否开着"**再**续期 —— 顺序反了这道门就恒为真，
        // 加入服务器时的背包同步（一次连发二十余条变动）会立刻弹出一个预览。
        // 界面由 onOpenContainer / onOpenInventory 开始计时。
        const uiOpen = tick < (uiOpenUntil.get(key) || 0);
        if (uiOpen) {
          // 优先用 newItem（刚把盒子放进某个槽位 = 刚点的是它），
          // 否则用 oldItem（刚把盒子拿起来 = 刚点的也是它）。两者都代表"刚点的这一个"。
          const clickedIsNew = (() => {
            try {
              return isShulkerBox(String(newItem && newItem.type).replace("minecraft:", ""));
            } catch (_err) {
              return false;
            }
          })();
          setBoxPeek(player, key, clickedIsNew ? newItem : oldItem);
          uiOpenUntil.set(key, tick + UI_OPEN_TTL_TICKS); // 续期
        }
      }
    } catch (err) {
      logInfo("onInventoryChange 处理失败（忽略）: " + err);
    }
    return true;
  });
}

/**
 * 插件主流程：LSE 里 mc.listen 在引擎就绪后即可用；
 * 用 onServerStarted 保证世界加载完成后再注册命令与事件。
 */
/**
 * 立刻收掉某个玩家的盒预览（清数据 + 清屏幕文本）。
 *
 * 三条清理路径共用：容器关闭、又打开了别的界面、回到世界里做了动作。
 *
 * 三个通道都要清：图标在 title、数量在 subtitle、居中那套的图标在 actionbar。
 * 漏清一个就会留下"预览已收但屏幕中央仍压着一块暗"这类残留。
 *
 * @returns {boolean} 此前是否真的有预览（供调用方决定要不要打日志）
 */
function dropBoxPeek(player, why) {
  const key = playerKey(player);
  if (!key) return false;
  if (!boxPeekByPlayer.delete(key)) return false;

  try {
    sendActionbar(player, " ");
    sendTitle(player, "");
    sendSubtitle(player, "");
  } catch (err) {
    // 清屏失败即忽略；TTL 会兜住
    logInfo("收预览时清屏失败（忽略）: " + err);
  }

  // ⚠️ 必须把准星预览的"内容指纹"缓存一并清掉。
  // 上面三行把 HUD 擦干净了，而准星那条路是"指纹没变就不重发"（避免每 tick 重排）——
  // 不删这条缓存的话，收掉盒预览且准星仍对着同一个箱子时指纹完全相同，
  // 于是**什么都不发**：HUD 空着，得等箱子内容变化或移开视线再回头才恢复。
  // 症状是"盒预览没了，容器预览也不出来"，很难从代码上看出来。
  lastByPlayer.delete(key);

  // 收掉缘由只在诊断开关打开时记：这条在正常游玩里**每次盒预览结束**都会产生一行
  //（每种收掉路径都会打），是最容易刷屏的一条 —— 它属于细节日志，归 `/peek:trace` 管。
  if (why && traceInventory) {
    logAlways("[peek-box] 预览已收掉（" + why + "）");
  }
  return true;
}

/**
 * "界面关了就立刻收掉预览"的替代信号。
 *
 * ## 难点：LSE 0.13.0 **没有"背包/容器界面关闭"事件**
 *
 * 源码（tools/upstream/lse-api/lse__PlayerEvents.cpp）：`onCloseContainer`
 * 只挂在 `ChestBlockActor::$stopOpen` 和 `BarrelBlockActor::$stopOpen` 上 ——
 * 即**只有箱子和木桶**关闭时会收到通知。潜影盒方块、熔炉、末影箱以及玩家自身的
 * 背包界面**都没有关闭事件**（整个 LSE 事件表里只有 onOpenInventory /
 * onOpenContainer / onOpenContainerScreen 三个"打开"类事件）。
 *
 * ## 因此使用两个都能拿到的替代信号
 *
 *   1. **又开了别的界面**（onOpenContainer / onOpenInventory）
 *      → 上一个界面必然已经关了，先把预览收掉；
 *   2. **回到世界里做了动作**（放置 / 开始挖掘 / 使用物品）
 *      → 这些动作在容器界面开着时**不可能发生**（输入都被界面吃掉了），
 *        一旦收到即说明界面已经关了。
 *
 * ⚠️ 这组里**不含"跳跃"**：跳跃属于"移动"，而移动这条判据按决定已经去掉了
 * （位置分不清主动走还是被推着走，见 VIEW_TURN_EPSILON_DEG 的说明）。
 * 转视角那条才是主力，这三条只是顺手的、不会误触发的补充。
 *
 * ## 仍然是近似
 *
 * 关掉背包之后**完全不动、也不转视角**的话，预览会留到 TTL
 *（BOX_PEEK_TTL_TICKS = 300 tick = 15 秒）结束 —— 这就是那道兜底。
 * 严格"关掉那一刻"需要的事件 LSE 不提供。
 */
const WORLD_ACTION_EVENTS = [
  "onPlaceBlock",
  "onStartDestroyBlock",
  "onUseItemOn"
];

function installBoxPeekDismissHooks() {
  for (const name of WORLD_ACTION_EVENTS) {
    listenSafely(name, (player) => {
      try {
        dropBoxPeek(player, "玩家回到世界里做了动作: " + name);
      } catch (_err) {
        // 忽略
      }
      return true;
    });
  }

  // 又开了别的界面：上一个界面一定已经关了（onCloseContainer 覆盖不到的那些
  // 就是靠这条收尾的）。这条也顺手治掉"换界面时预览残留"。
  listenSafely("onOpenContainer", (player) => {
    try {
      dropBoxPeek(player, "又打开了容器");
    } catch (_err) {
      // 忽略
    }
    return true;
  });
}

function bootstrap() {
  mc.listen("onTick", () => {
    tick++;

    if (tick % pollTicks() !== 0) return;

    const players = onlinePlayers();
    for (let i = 0; i < players.length; i++) {
      try {
        updatePlayer(players[i]);
      } catch (err) {
        // 单个玩家出错不得影响其他玩家
        try {
          if (typeof logger !== "undefined" && logger.error) logger.error("[peek] update 失败: " + err);
        } catch (_err2) {
          // 忽略
        }
      }
    }
  });

  try {
    mc.listen("onServerStarted", () => {
      // ⚠️ **先读配置再注册**：`/peek:log off` 存在配置文件里时，必须在下面那些
      // "事件注册: 成功"输出之前生效 —— 否则"关掉日志"要等重开一次服才干净，
      // 而管理员正是因为嫌它刷屏才关的。加载本身不依赖命令表或事件，顺序可以互换。
      loadSettingsOnStart();
      registerCommands();
      installPreviewHooks();
      installBoxPeekDismissHooks();
      installSignatureHook();
      selftestInstall({
        updatePlayer: updatePlayer,
        playerKey: playerKey,
        reach: runtime.REACH_DISTANCE
      });
      // 启动日志带上指纹：日志被转贴时也能看出出处。
      // 这一行走 `logAlways`：哪怕 `/peek:log off` 也要留一行 —— 管理员靠它确认插件起来了。
      logAlways("容器预览插件已启动（LSE 版）  " + FINGERPRINT);
    });
  } catch (err) {
    // 某些版本事件名不同；直接注册一次兜底
    loadSettingsOnStart();
    registerCommands();
    installPreviewHooks();
    installBoxPeekDismissHooks();
    installSignatureHook();
    selftestInstall({
      updatePlayer: updatePlayer,
      playerKey: playerKey,
      reach: runtime.REACH_DISTANCE
    });
    logAlways("容器预览插件已启动（LSE 版，事件兜底路径）  " + FINGERPRINT);
  }
}

/**
 * 进服时弹一次署名提示（每位玩家每个会话一次）。
 *
 * 用吐司而不是聊天：吐司是一次性弹窗，不会在聊天栏里留下堆积；
 * 内容只报项目名与署名，不干扰玩法。
 *
 * **默认关闭**：署名与指纹改由 `/peek:about` 按需查看，进服不再主动弹窗。
 * 需要进服即提示的场合，把下面这个开关改成 true。
 */
const SHOW_SIGNATURE_ON_JOIN = false;

function installSignatureHook() {
  if (!SHOW_SIGNATURE_ON_JOIN) return;

  listenSafely("onJoin", (player) => {
    try {
      if (player && typeof player.sendToast === "function") {
        player.sendToast("§e" + signatureLine(), "§7容器内容预览已启用　§8" + FINGERPRINT);
      }
    } catch (_err) {
      // 吐司发不出去不影响任何功能
    }
    return true;
  });
}

bootstrap();
